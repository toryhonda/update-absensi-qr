<?php

class AppLicense
{
    const LICENSE_SERVER = 'https://lisensi-absensi.troyarya.my.id/verify.php';
    const TIMEOUT        = 10;
    const CACHE_HOURS    = 24;

    public static function read($conn)
    {
        $q = @mysqli_query($conn, "SELECT license_key FROM profil_sekolah LIMIT 1");
        $row = $q ? mysqli_fetch_assoc($q) : null;
        return $row['license_key'] ?? '';
    }

    public static function save($conn, $key)
    {
        self::ensureColumn($conn);
        $key_esc = mysqli_real_escape_string($conn, $key);
        return mysqli_query($conn, "UPDATE profil_sekolah SET license_key='{$key_esc}' WHERE id=1");
    }

    public static function ensureColumn($conn)
    {
        $check = @mysqli_query($conn, "SHOW COLUMNS FROM profil_sekolah LIKE 'license_key'");
        if ($check && mysqli_num_rows($check) == 0) {
            @mysqli_query($conn, "ALTER TABLE profil_sekolah ADD COLUMN license_key VARCHAR(255) DEFAULT NULL AFTER wa_business_account_id");
        }

        $check = @mysqli_query($conn, "SHOW COLUMNS FROM profil_sekolah LIKE 'license_checked_at'");
        if ($check && mysqli_num_rows($check) == 0) {
            @mysqli_query($conn, "ALTER TABLE profil_sekolah ADD COLUMN license_checked_at DATETIME DEFAULT NULL AFTER license_key");
        }
    }

    private static function getLastChecked($conn)
    {
        $q = @mysqli_query($conn, "SELECT license_checked_at FROM profil_sekolah LIMIT 1");
        $row = $q ? mysqli_fetch_assoc($q) : null;
        $dt = $row['license_checked_at'] ?? null;
        if (!$dt) return null;
        $ts = strtotime($dt);
        return $ts !== false ? $ts : null;
    }

    private static function setLastChecked($conn)
    {
        @mysqli_query($conn, "UPDATE profil_sekolah SET license_checked_at=NOW() WHERE id=1");
    }

    private static function clearLastChecked($conn)
    {
        @mysqli_query($conn, "UPDATE profil_sekolah SET license_checked_at=NULL WHERE id=1");
    }

    public static function validate($key, $currentDomain)
    {
        $key = trim($key);
        if ($key === '') {
            return ['valid' => false, 'reason' => 'Lisensi kosong.'];
        }

        $currentDomain = strtolower(trim(preg_replace('/:\d+$/', '', $currentDomain)));

        $ch = curl_init(self::LICENSE_SERVER);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query([
                'domain' => $currentDomain,
                'key'    => $key,
            ]),
            CURLOPT_TIMEOUT        => self::TIMEOUT,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr  = curl_error($ch);
        curl_close($ch);

        if ($curlErr !== '' || $response === false) {
            return [
                'valid'   => false,
                'reason'  => 'Tidak dapat menghubungi server lisensi.',
                'offline' => true,
            ];
        }

        if ($httpCode !== 200) {
            return [
                'valid'   => false,
                'reason'  => 'Server lisensi mengembalikan error (HTTP ' . (int)$httpCode . ').',
                'offline' => true,
            ];
        }

        $result = json_decode($response, true);

        if (!is_array($result) || !isset($result['valid'])) {
            return ['valid' => false, 'reason' => 'Response server lisensi tidak valid.'];
        }

        if (isset($result['reason'])) {
            $result['reason'] = strip_tags($result['reason']);
        }

        return $result;
    }

    public static function check($conn)
    {
        self::ensureColumn($conn);

        $domain = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $key    = self::read($conn);

        if ($key === '') {
            return [
                'valid'     => false,
                'reason'    => 'Lisensi belum diaktivasi.',
                'activated' => false,
            ];
        }

        $lastChecked = self::getLastChecked($conn);
        $cacheValid  = $lastChecked !== null && (time() - $lastChecked) < (self::CACHE_HOURS * 3600);

        if ($cacheValid) {
            return [
                'valid'       => true,
                'domain'      => $domain,
                'activated'   => true,
                'key'         => $key,
                'cached'      => true,
                'cache_age'   => time() - $lastChecked,
            ];
        }

        $result = self::validate($key, $domain);

        if (!empty($result['valid'])) {
            self::setLastChecked($conn);
        } elseif (empty($result['offline'])) {
            self::clearLastChecked($conn);
        }

        $result['activated'] = true;
        $result['key'] = $key;
        return $result;
    }
}
