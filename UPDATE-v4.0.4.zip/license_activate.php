<?php
include 'config.php';
require_once __DIR__ . '/license.php';

AppLicense::ensureColumn($conn);

$domain = preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST'] ?? 'localhost');
$pesan  = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['license_key'])) {
    $key = trim($_POST['license_key']);
    $result = AppLicense::validate($key, $domain);

    if ($result['valid']) {
        AppLicense::save($conn, $key);
        unset($_SESSION['license_reason']);
        $_SESSION['license_notif'] = "Lisensi berhasil diaktivasi.";
        header("Location: dashboard.php");
        exit;
    } else {
        $pesan = $result['reason'];
    }
}

$existing = AppLicense::read($conn);
$info = AppLicense::check($conn);

if (isset($_SESSION['license_reason']) && !$pesan) {
    $pesan = $_SESSION['license_reason'];
    unset($_SESSION['license_reason']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktivasi Lisensi</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root{
            --bg:#f6f8fb;--surface:#ffffff;--surface-2:#f9fafb;
            --line:#e8edf3;--line-strong:#dbe3ec;
            --ink:#0f172a;--ink-2:#334155;--muted:#64748b;--muted-2:#94a3b8;
            --brand:#2a5298;--brand-2:#1e3c72;--brand-soft:rgba(42,82,152,.08);
            --success:#10b981;--danger:#ef4444;
            --radius-lg:16px;--radius-md:12px;--radius-sm:10px;
            --shadow-sm:0 1px 2px rgba(15,23,42,.05);
            --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22);
            --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
        }
        *{box-sizing:border-box;font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;}
        html,body{margin:0;padding:0;}
        body{
            font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(circle at 0% 0%, rgba(42,82,152,.07), transparent 42%),
                radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 42%),
                var(--bg);
            min-height:100vh;
            color:var(--ink);
            display:flex;
            align-items:center;
            justify-content:center;
            padding:24px;
            -webkit-font-smoothing:antialiased;
            -moz-osx-font-smoothing:grayscale;
        }
        .card{
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-lg);
            box-shadow:var(--shadow-lg);
            max-width:540px;width:100%;
            padding:38px 34px 30px;
            position:relative;overflow:hidden;
        }
        .card::before{
            content:"";position:absolute;top:0;left:0;right:0;height:4px;
            background:linear-gradient(90deg, var(--brand), var(--brand-2));
        }
        .icon-mark{
            width:62px;height:62px;border-radius:var(--radius-md);
            background:linear-gradient(135deg, var(--brand), var(--brand-2));
            color:#fff;display:flex;align-items:center;justify-content:center;
            font-size:26px;box-shadow:var(--shadow-brand);margin-bottom:22px;
        }
        h1{font-family:'Rubik', sans-serif;font-size:23px;font-weight:600;margin:0 0 8px;letter-spacing:-.3px;}
        .sub{font-family:'Rubik', sans-serif;font-size:13.5px;color:var(--muted);line-height:1.65;margin:0 0 26px;}
        .info-box{
            background:var(--brand-soft);
            border:1px solid rgba(42,82,152,.15);
            border-left:3px solid var(--brand);
            border-radius:var(--radius-sm);
            padding:13px 16px;font-size:12.5px;
            color:var(--ink-2);line-height:1.7;margin-bottom:22px;
            font-family:'Rubik', sans-serif;
        }
        .info-box strong{color:var(--brand);font-weight:600;}
        .info-box code{
            font-family:'Rubik', sans-serif;font-weight:500;
            background:rgba(255,255,255,.65);
            padding:3px 8px;border-radius:4px;font-size:12px;color:var(--ink);
            letter-spacing:.2px;
        }
        label{display:block;font-family:'Rubik', sans-serif;font-size:12.5px;font-weight:500;color:var(--ink-2);margin-bottom:8px;}
        input[type="text"]{
            width:100%;padding:13px 15px;
            font-family:'Rubik', sans-serif;font-size:13px;
            color:var(--ink);background:var(--surface-2);
            border:1px solid var(--line);border-radius:var(--radius-sm);
            outline:none;transition:all .2s;letter-spacing:.3px;word-break:break-all;
        }
        input[type="text"]::placeholder{
            color:var(--muted-2);font-family:'Rubik', sans-serif;letter-spacing:0;
        }
        input[type="text"]:focus{border-color:var(--brand);background:#fff;box-shadow:0 0 0 4px var(--brand-soft);}
        .btn{
            display:inline-flex;align-items:center;justify-content:center;gap:9px;
            width:100%;padding:14px;
            font-family:'Rubik', sans-serif;font-size:14px;font-weight:600;
            color:#fff;background:linear-gradient(135deg, var(--brand), var(--brand-2));
            border:none;border-radius:var(--radius-sm);cursor:pointer;
            transition:all .2s;box-shadow:var(--shadow-brand);margin-top:18px;
            letter-spacing:.2px;
        }
        .btn:hover{filter:brightness(1.08);transform:translateY(-1px);}
        .btn-ghost{
            background:var(--surface-2);color:var(--ink-2);
            border:1px solid var(--line);box-shadow:var(--shadow-sm);
            text-decoration:none;
        }
        .btn-ghost:hover{background:var(--surface);color:var(--ink);}
        .alert{
            padding:14px 16px;border-radius:var(--radius-sm);
            font-family:'Rubik', sans-serif;
            font-size:13px;line-height:1.6;margin-bottom:20px;
            display:flex;align-items:flex-start;gap:11px;border:1px solid transparent;
        }
        .alert i{margin-top:2px;font-size:15px;flex-shrink:0;}
        .alert-danger{background:rgba(239,68,68,.08);color:#b91c1c;border-color:rgba(239,68,68,.25);}
        .alert-success{background:rgba(16,185,129,.08);color:#047857;border-color:rgba(16,185,129,.25);}
        .badge{
            display:inline-flex;align-items:center;gap:6px;
            padding:5px 12px;
            font-family:'Rubik', sans-serif;font-size:11px;font-weight:600;
            border-radius:999px;text-transform:uppercase;letter-spacing:.4px;margin-top:8px;
        }
        .badge.ok{background:rgba(16,185,129,.12);color:#047857;border:1px solid rgba(16,185,129,.28);}
        .footer-note{
            margin-top:26px;padding-top:18px;border-top:1px solid var(--line);
            font-family:'Rubik', sans-serif;
            font-size:11.5px;color:var(--muted-2);text-align:center;line-height:1.65;
        }
        @media (max-width:520px){
            body{padding:16px;}
            .card{padding:28px 22px 24px;}
            h1{font-size:20px;}
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon-mark"><i class="fas fa-key"></i></div>
        <h1>Aktivasi Lisensi</h1>
        <p class="sub">Masukkan kunci lisensi untuk mengaktifkan aplikasi absensi di domain ini.</p>

        <div class="info-box">
            <strong><i class="fas fa-globe"></i> Domain terdeteksi:</strong><br>
            <code><?= htmlspecialchars($domain); ?></code>
        </div>

        <?php if ($pesan): ?>
            <div class="alert alert-danger">
                <i class="fas fa-times-circle"></i>
                <div>
                    <strong>Aktivasi gagal.</strong><br>
                    <?= htmlspecialchars($pesan, ENT_QUOTES, "UTF-8"); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($info && $info['valid']): ?>
            <div class="alert alert-success">
                <i class="fas fa-circle-check"></i>
                <div>
                    <strong>Lisensi aktif.</strong><br>
                    Domain terdaftar: <b><?= htmlspecialchars($info['domain']); ?></b>
                    <br>
                    <span class="badge ok"><i class="fas fa-infinity"></i> Lifetime</span>
                </div>
            </div>
            <a href="dashboard.php" class="btn btn-ghost">
                <i class="fas fa-arrow-right"></i> Lanjut ke Dashboard
            </a>
        <?php else: ?>
            <form method="post" autocomplete="off">
                <label for="license_key">Kunci Lisensi</label>
                <input type="text"
                       id="license_key"
                       name="license_key"
                       placeholder="TKM-xxxxxxxxxxxxxxxxxxxxxxxx-xxxxxxxxxxxxxxxxxxxx"
                       value="<?= htmlspecialchars($existing); ?>"
                       required
                       spellcheck="false"
                       autocorrect="off"
                       autocapitalize="off">
                <button type="submit" class="btn">
                    <i class="fas fa-unlock"></i> Aktivasi Sekarang
                </button>
            </form>
        <?php endif; ?>

        <div class="footer-note">
            Butuh bantuan? Hubungi vendor aplikasi.<br>
            <strong>Sistem Lisensi</strong> &copy; <?= date('Y'); ?>
        </div>
    </div>
</body>
</html>