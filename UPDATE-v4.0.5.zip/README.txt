========================================================
  SISTEM ABSENSI QR - v4.0.5
  Cara Instalasi
========================================================

LANGKAH 1 - UPLOAD FILE
  Upload semua file di folder ini ke public_html hosting Anda
  (bisa via File Manager cPanel atau FTP).

LANGKAH 2 - BUAT DATABASE
  Di cPanel -> MySQL Databases:
  - Buat database baru, catat namanya.
  - Buat user baru, catat username & password-nya.
  - Tambahkan user ke database dengan privilege ALL.

LANGKAH 3 - IMPORT DATABASE
  Di cPanel -> phpMyAdmin:
  - Pilih database yang baru dibuat.
  - Klik tab "Import".
  - Pilih file database.sql, klik "Go".

LANGKAH 4 - SETTING CONFIG
  - Rename file config.example.php menjadi config.php
  - Buka config.php dengan editor, isi:
      * BASE_URL      -> domain Anda (mis. https://absensi.sekolah.com)
      * $user         -> username database dari Langkah 2
      * $pass         -> password database dari Langkah 2
      * $dbname       -> nama database dari Langkah 2
  - Simpan.

LANGKAH 5 - IZIN FOLDER
  Pastikan folder berikut punya permission 775:
  - uploads/
  - assets/qr/
  - assets/qr_guru/

LANGKAH 6 - LOGIN
  Buka https://domain-anda.com
  Login dengan akun default:
    Username : admin
    Password : admin
  (Segera ganti password setelah login)

========================================================
  CATATAN PENTING
========================================================
1. JANGAN ubah file version.php - akan tertimpa saat update.
2. Simpan file config.php Anda di tempat aman.
3. Saat ada update dari developer:
   - Timpa semua file YANG DIKIRIM, KECUALI config.php.
   - Versi aplikasi akan otomatis diperbarui.

========================================================
  DUKUNGAN
========================================================
  WhatsApp : +62 896-5463-0099
  Email    : tory@autowebportal.com
