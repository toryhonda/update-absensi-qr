<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
include 'config.php';

$qProfil = mysqli_query($conn, "SELECT nama_sekolah FROM profil_sekolah LIMIT 1");
$profil  = mysqli_fetch_assoc($qProfil);
$nama_sekolah = $profil['nama_sekolah'] ?? 'Sistem Absensi Digital';
?>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unduh Aplikasi - <?= htmlspecialchars($nama_sekolah); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .download-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.25);
            width: 100%;
            max-width: 500px;
            padding: 35px;
        }
        .download-avatar {
            width: 90px;
            height: 90px;
            background: #e9ecef;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 2.5rem;
            color: #1e3c72;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .download-item {
            display: flex;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 12px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            border: 1px solid #dee2e6;
        }
        .download-item:hover {
            background: #e2e6ea;
            transform: translateY(-2px);
            color: #0d6efd;
        }
        .download-item i {
            font-size: 1.8rem;
            margin-right: 15px;
            width: 35px;
            text-align: center;
        }
    </style>
</head>
<body>

  <div class="download-card">
    <div class="text-center mb-4">
        <div class="download-avatar">
            <i class="fas fa-download"></i>
        </div>
        <h3 class="fw-bold text-dark mb-1">Pusat Unduhan</h3>
        <p class="text-muted small">Unduh dokumentasi, panduan, atau rilis aplikasi sistem absensi.</p>
    </div>

    <div class="download-list">
        <a href="#" class="download-item">
            <i class="fas fa-file-pdf text-danger"></i>
            <div>
                <strong>Panduan Penggunaan (PDF)</strong><br>
                <span class="text-muted small">Manual Book untuk Admin & Guru</span>
            </div>
        </a>

        <a href="#" class="download-item">
            <i class="fas fa-laptop-code text-primary"></i>
            <div>
                <strong>Aplikasi Absensi berbasis PHP</strong><br>
                <span class="text-muted small">Source Code & File Sistem Utama</span>
            </div>
        </a>

        <a href="#" class="download-item">
            <i class="fas fa-file-excel text-success"></i>
            <div>
                <strong>Template Data Siswa</strong><br>
                <span class="text-muted small">Format Excel untuk Impor Massal</span>
            </div>
        </a>
    </div>

    <div class="text-center mt-4">
        <a href="index.php" class="btn btn-secondary w-100 py-2 rounded-pill">
            <i class="fas fa-arrow-left me-2"></i> Kembali ke Halaman Login
        </a>
    </div>
  </div>

</body>
</html>