<?php

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
include 'config.php';

if (isset($_POST['backup'])) {
    $tables = [];
    $result = $conn->query("SHOW TABLES");
    while ($row = $result->fetch_row()) {
        $tables[] = $row[0];
    }

    $sqlScript = "SET FOREIGN_KEY_CHECKS=0;\n";
    $sqlScript .= "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n";
    $sqlScript .= "START TRANSACTION;\n\n";

    foreach ($tables as $table) {
        $result = $conn->query("SHOW CREATE TABLE `$table`");
        $row = $result->fetch_row();

        $sqlScript .= "\n\nDROP TABLE IF EXISTS `$table`;\n";
        $sqlScript .= $row[1] . ";\n\n";

        $result = $conn->query("SELECT * FROM `$table`");
        if ($result && $result->num_rows > 0) {
            $columnCount = $result->field_count;

            while ($row = $result->fetch_row()) {
                $sqlScript .= "INSERT INTO `$table` VALUES(";
                for ($j = 0; $j < $columnCount; $j++) {
                    if (!isset($row[$j])) {
                        $sqlScript .= "NULL";
                    } else {
                        $escaped = addslashes($row[$j]);
                        $escaped = str_replace("\n", "\\n", $escaped);
                        $sqlScript .= "'$escaped'";
                    }
                    if ($j < ($columnCount - 1)) {
                        $sqlScript .= ',';
                    }
                }
                $sqlScript .= ");\n";
            }
        }
        $sqlScript .= "\n";
    }

    $sqlScript .= "SET FOREIGN_KEY_CHECKS=1;\n";
    $sqlScript .= "COMMIT;\n";

    if (!empty($sqlScript)) {
        $backup_file_name = 'absensiqr ' . date('Ymd') . '.sql';
        header('Content-Type: application/sql');
        header('Content-Disposition: attachment; filename=' . $backup_file_name);
        echo $sqlScript;
        exit;
    }
}

$restore_output = "";

if (isset($_POST['restore'])) {
    if (isset($_FILES['restore_file']['tmp_name']) && $_FILES['restore_file']['tmp_name'] != '') {
        $filename = $_FILES['restore_file']['tmp_name'];
        $sql = file_get_contents($filename);

        $queries = explode(";\n", $sql);
        $success = true;
        $errors = [];

        $conn->query("SET FOREIGN_KEY_CHECKS=0");

        foreach ($queries as $query) {
            $query = trim($query);
            if ($query != '') {
                if (!$conn->query($query)) {
                    $success = false;
                    $errors[] = "Error: " . $conn->error . "\nQuery: " . $query;
                }
            }
        }

        $conn->query("SET FOREIGN_KEY_CHECKS=1");

        if ($success) {
            $restore_output = "<div class='alert alert-success text-center m-3'>Restore berhasil!</div>";
        } else {
            $restore_output = "<div class='alert alert-danger text-center m-3'>Restore gagal!</div>";
            $restore_output .= "<pre style='background:#f8f9fa;padding:10px;border:1px solid #ddd;max-height:300px;overflow:auto'>";
            $restore_output .= implode("\n\n", $errors);
            $restore_output .= "</pre>";
        }
    } else {
        $restore_output = "<div class='alert alert-warning text-center m-3'>Silakan pilih file SQL untuk di-restore.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup &amp; Restore Database</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root{
            --bg:#f6f8fb;
            --surface:#ffffff;
            --surface-2:#f9fafb;
            --line:#e8edf3;
            --line-strong:#dbe3ec;
            --ink:#0f172a;
            --ink-2:#334155;
            --muted:#64748b;
            --muted-2:#94a3b8;
            --brand:#2a5298;
            --brand-2:#1e3c72;
            --brand-soft:rgba(42,82,152,.08);
            --success:#10b981;
            --success-dark:#047857;
            --success-soft:rgba(16,185,129,.08);
            --success-line:rgba(16,185,129,.22);
            --warning:#f59e0b;
            --warning-dark:#b45309;
            --warning-soft:rgba(245,158,11,.10);
            --warning-line:rgba(245,158,11,.22);
            --danger:#ef4444;
            --danger-dark:#b91c1c;
            --danger-soft:rgba(239,68,68,.08);
            --danger-line:rgba(239,68,68,.22);
            --radius-xl:20px;
            --radius-lg:16px;
            --radius-md:12px;
            --radius-sm:10px;
            --shadow-sm:0 1px 2px rgba(15,23,42,.05);
            --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
            --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
            --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
            --shadow-success:0 14px 30px -14px rgba(16,185,129,.55);
            --shadow-warning:0 14px 30px -14px rgba(245,158,11,.55);
        }

        *{box-sizing:border-box;}

        html{scroll-behavior:smooth;}

        body{
            font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
                radial-gradient(circle at 100% 100%, rgba(16,185,129,.05), transparent 40%),
                var(--bg);
            min-height:100vh;
            color:var(--ink);
            margin:0;
            padding:32px 20px 56px;
            -webkit-font-smoothing:antialiased;
            -moz-osx-font-smoothing:grayscale;
        }

        .page-shell{
            max-width:920px;
            margin:0 auto;
        }

        .top-nav{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:16px;
            margin-bottom:24px;
            flex-wrap:wrap;
        }

        .btn-back{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding:9px 16px;
            background:var(--surface);
            color:var(--ink-2);
            border:1px solid var(--line);
            border-radius:999px;
            font-size:13.5px;
            font-weight:500;
            text-decoration:none;
            box-shadow:var(--shadow-sm);
            transition:border-color .2s ease, color .2s ease, transform .2s ease, box-shadow .2s ease;
        }

        .btn-back i{
            font-size:11px;
            color:var(--muted);
            transition:color .2s ease, transform .2s ease;
        }

        .btn-back:hover{
            color:var(--ink);
            border-color:var(--line-strong);
            box-shadow:var(--shadow-md);
            transform:translateY(-1px);
        }

        .btn-back:hover i{
            color:var(--brand);
            transform:translateX(-2px);
        }

        .btn-back:focus-visible{
            outline:3px solid var(--brand-soft);
            outline-offset:2px;
        }

        .page-head{
            display:flex;
            flex-direction:column;
            gap:6px;
            margin-bottom:24px;
        }

        .page-eyebrow{
            font-size:11.5px;
            font-weight:600;
            letter-spacing:1.2px;
            text-transform:uppercase;
            color:var(--brand);
        }

        .page-head h1{
            font-size:26px;
            font-weight:600;
            letter-spacing:-.4px;
            color:var(--ink);
            margin:0;
            line-height:1.25;
        }

        .page-head p{
            margin:0;
            font-size:14px;
            color:var(--muted);
            line-height:1.55;
        }

        .info-banner{
            display:flex;
            align-items:flex-start;
            gap:12px;
            padding:14px 18px;
            border-radius:var(--radius-lg);
            background:var(--brand-soft);
            border:1px solid rgba(42,82,152,.16);
            border-left:4px solid var(--brand);
            margin-bottom:22px;
            font-size:13px;
            color:var(--brand-2);
            line-height:1.6;
        }

        .info-banner i{
            color:var(--brand);
            font-size:15px;
            margin-top:2px;
            flex-shrink:0;
        }

        .info-banner strong{
            font-weight:600;
            color:var(--brand-2);
        }

        .grid{
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:20px;
            align-items:start;
        }

        .card{
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-xl);
            box-shadow:var(--shadow-md);
            overflow:hidden;
            animation:fadeUp .5s ease both;
            display:flex;
            flex-direction:column;
            height:100%;
        }

        @keyframes fadeUp{
            from{opacity:0; transform:translateY(8px);}
            to{opacity:1; transform:translateY(0);}
        }

        .card-head{
            position:relative;
            padding:22px 26px 18px;
            border-bottom:1px solid var(--line);
            background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
        }

        .card-head::before{
            content:"";
            position:absolute;
            top:0;left:0;right:0;
            height:3px;
        }

        .card-head.accent-success::before{
            background:linear-gradient(90deg, #10b981, #047857);
        }

        .card-head.accent-warning::before{
            background:linear-gradient(90deg, #f59e0b, #b45309);
        }

        .card-head-inner{
            display:flex;
            align-items:center;
            gap:14px;
        }

        .card-icon{
            width:44px;
            height:44px;
            border-radius:var(--radius-md);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:17px;
            flex-shrink:0;
        }

        .card-icon.success{
            color:var(--success-dark);
            background:var(--success-soft);
        }

        .card-icon.warning{
            color:var(--warning-dark);
            background:var(--warning-soft);
        }

        .card-title{
            font-size:16px;
            font-weight:600;
            letter-spacing:-.2px;
            color:var(--ink);
            margin:0 0 3px;
            line-height:1.35;
        }

        .card-sub{
            font-size:12.5px;
            color:var(--muted);
            margin:0;
            line-height:1.5;
        }

        .card-body-inner{
            padding:24px 26px 26px;
            display:flex;
            flex-direction:column;
            flex-grow:1;
        }

        .desc-box{
            font-size:13px;
            color:var(--muted);
            line-height:1.65;
            margin-bottom:20px;
        }

        .desc-box ul{
            margin:0;
            padding-left:18px;
            list-style:none;
        }

        .desc-box li{
            position:relative;
            margin-bottom:6px;
            padding-left:18px;
        }

        .desc-box li::before{
            content:"\f00c";
            font-family:"Font Awesome 6 Free";
            font-weight:900;
            font-size:10px;
            color:var(--success);
            position:absolute;
            left:0;
            top:3px;
        }

        .desc-box.warning-desc li::before{
            color:var(--warning);
        }

        .file-input-wrapper{
            position:relative;
            margin-bottom:16px;
        }

        .file-input-wrapper input[type="file"]{
            width:100%;
            padding:11px 14px;
            font-family:inherit;
            font-size:13.5px;
            color:var(--muted);
            background:var(--surface-2);
            border:1px dashed var(--line-strong);
            border-radius:var(--radius-md);
            cursor:pointer;
            outline:none;
            transition:border-color .2s ease, background .2s ease;
        }

        .file-input-wrapper input[type="file"]:hover{
            border-color:var(--warning);
            background:#fff;
        }

        .file-input-wrapper input[type="file"]:focus{
            border-color:var(--warning);
            background:#fff;
            box-shadow:0 0 0 4px var(--warning-soft);
            border-style:solid;
        }

        .file-input-wrapper input[type="file"]::file-selector-button{
            font-family:inherit;
            font-size:12.5px;
            font-weight:500;
            color:var(--ink-2);
            background:#fff;
            border:1px solid var(--line);
            border-radius:8px;
            padding:7px 12px;
            margin-right:12px;
            cursor:pointer;
            transition:border-color .2s ease, background .2s ease;
        }

        .file-input-wrapper input[type="file"]::file-selector-button:hover{
            border-color:var(--line-strong);
            background:var(--surface-2);
        }

        .btn{
            width:100%;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:10px;
            padding:13px 20px;
            font-family:inherit;
            font-size:14.5px;
            font-weight:600;
            letter-spacing:.2px;
            color:#fff;
            border:none;
            border-radius:var(--radius-md);
            cursor:pointer;
            transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
            margin-top:auto;
        }

        .btn i{font-size:14px;}

        .btn-success{
            background:linear-gradient(135deg, #10b981 0%, #047857 100%);
            box-shadow:var(--shadow-success);
        }

        .btn-success:hover{
            transform:translateY(-2px);
            filter:brightness(1.06);
            box-shadow:0 20px 36px -16px rgba(16,185,129,.65);
        }

        .btn-warning{
            background:linear-gradient(135deg, #f59e0b 0%, #b45309 100%);
            box-shadow:var(--shadow-warning);
        }

        .btn-warning:hover{
            transform:translateY(-2px);
            filter:brightness(1.06);
            box-shadow:0 20px 36px -16px rgba(245,158,11,.65);
        }

        .btn:active{transform:translateY(0);}

        .btn:focus-visible{
            outline:3px solid var(--brand-soft);
            outline-offset:3px;
        }

        .btn-success:focus-visible{
            outline-color:rgba(16,185,129,.35);
        }

        .btn-warning:focus-visible{
            outline-color:rgba(245,158,11,.35);
        }

        .restore-result{
            margin-top:22px;
            border-radius:var(--radius-lg);
            overflow:hidden;
            animation:fadeUp .35s ease both;
        }

        .restore-result .alert{
            border-radius:var(--radius-md);
            border:1px solid transparent;
            padding:13px 16px;
            font-size:13.5px;
            font-weight:500;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:10px;
            line-height:1.55;
            margin:0;
        }

        .restore-result .alert::before{
            font-family:"Font Awesome 6 Free";
            font-weight:900;
            flex-shrink:0;
        }

        .restore-result .alert-success{
            background:var(--success-soft);
            border-color:var(--success-line);
            color:var(--success-dark);
        }

        .restore-result .alert-success::before{
            content:"\f058";
        }

        .restore-result .alert-danger{
            background:var(--danger-soft);
            border-color:var(--danger-line);
            color:var(--danger-dark);
        }

        .restore-result .alert-danger::before{
            content:"\f06a";
        }

        .restore-result .alert-warning{
            background:var(--warning-soft);
            border-color:var(--warning-line);
            color:var(--warning-dark);
        }

        .restore-result .alert-warning::before{
            content:"\f05a";
        }

        .restore-result pre{
            margin:14px 0 0;
            padding:14px 16px;
            background:#0f172a;
            color:#e2e8f0;
            border-radius:var(--radius-md);
            font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
            font-size:12px;
            line-height:1.65;
            max-height:280px;
            overflow:auto;
            border:1px solid #1e293b;
            white-space:pre-wrap;
            word-break:break-word;
        }

        @media (max-width:768px){
            body{padding:22px 14px 40px;}
            .page-head h1{font-size:22px;}
            .grid{grid-template-columns:1fr;gap:16px;}
            .card-head{padding:18px 20px 16px;}
            .card-body-inner{padding:20px 20px 22px;}
            .card-icon{width:40px;height:40px;font-size:15px;}
            .card-title{font-size:15px;}
            .btn{font-size:14px;padding:12px 18px;}
            .info-banner{font-size:12.5px;padding:12px 14px;}
        }

        @media (max-width:480px){
            body{padding:16px 10px 32px;}
            .page-head h1{font-size:19px;}
            .page-eyebrow{font-size:10.5px;}
            .card-head{padding:16px 16px 14px;}
            .card-body-inner{padding:16px 16px 20px;}
            .desc-box{font-size:12.5px;}
            .restore-result pre{font-size:11px;padding:12px;}
        }

        @media (prefers-reduced-motion:reduce){
            *{animation:none !important;transition:none !important;}
        }
    </style>
</head>
<body>
    <div class="page-shell">
        <div class="top-nav">
            <a href="pengaturan.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>

        <div class="page-head">
            <span class="page-eyebrow">Pemeliharaan Data</span>
            <h1>Backup &amp; Restore Database</h1>
            <p>Amankan data sistem dengan pencadangan berkala atau pulihkan dari file cadangan.</p>
        </div>

        <div class="info-banner">
            <i class="fas fa-circle-info"></i>
            <div>
                <strong>Tips:</strong> Lakukan backup secara rutin sebelum melakukan perubahan besar pada sistem. File backup berformat <b>.sql</b> dapat digunakan untuk memulihkan seluruh data.
            </div>
        </div>

        <div class="grid">
            <div class="card">
                <div class="card-head accent-success">
                    <div class="card-head-inner">
                        <div class="card-icon success">
                            <i class="fas fa-download"></i>
                        </div>
                        <div>
                            <h2 class="card-title">Backup Database</h2>
                            <p class="card-sub">Unduh salinan seluruh data sistem.</p>
                        </div>
                    </div>
                </div>
                <div class="card-body-inner">
                    <div class="desc-box">
                        <ul>
                            <li>Seluruh tabel database diekspor</li>
                            <li>Struktur dan data tersimpan lengkap</li>
                            <li>File berekstensi <b>.sql</b></li>
                        </ul>
                    </div>

                    <form method="post" style="margin-top:auto;">
                        <button type="submit" name="backup" class="btn btn-success">
                            <i class="fas fa-cloud-arrow-down"></i> Backup Database
                        </button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-head accent-warning">
                    <div class="card-head-inner">
                        <div class="card-icon warning">
                            <i class="fas fa-upload"></i>
                        </div>
                        <div>
                            <h2 class="card-title">Restore Database</h2>
                            <p class="card-sub">Pulihkan data dari file backup.</p>
                        </div>
                    </div>
                </div>
                <div class="card-body-inner">
                    <div class="desc-box warning-desc">
                        <ul>
                            <li>Unggah file <b>.sql</b> hasil backup</li>
                            <li>Data lama akan digantikan</li>
                            <li>Proses tidak dapat dibatalkan</li>
                        </ul>
                    </div>

                    <form method="post" enctype="multipart/form-data" style="margin-top:auto;">
                        <div class="file-input-wrapper">
                            <input type="file" name="restore_file" accept=".sql" required>
                        </div>
                        <button type="submit" name="restore" class="btn btn-warning">
                            <i class="fas fa-cloud-arrow-up"></i> Restore Database
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <?php if (!empty($restore_output)): ?>
            <div class="restore-result">
                <?= $restore_output; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>