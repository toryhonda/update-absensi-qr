<?php
session_start();
include 'config.php';

$user = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
$pass = trim($_POST['password'] ?? '');
$pass_md5 = md5($pass);

$q = mysqli_query($conn, "SELECT * FROM users WHERE username='$user' AND password='$pass_md5' LIMIT 1");

if ($q && mysqli_num_rows($q) > 0) {
    $data = mysqli_fetch_assoc($q);

    $_SESSION['user_id']  = (int)$data['id'];
    $_SESSION['username'] = $user;
    $_SESSION['role']     = $data['role'];
    $_SESSION['nama']     = $data['nama'] ?? $user;

    if ($data['role'] === 'admin') {
        header("Location: dashboard.php");
        exit;
    } elseif ($data['role'] === 'guru') {
        header("Location: dashboard_guru.php");
        exit;
    } elseif ($data['role'] === 'siswa') {
        $qSiswa = mysqli_query($conn, "SELECT id FROM siswa WHERE nisn='$user' LIMIT 1");
        if ($rowSiswa = mysqli_fetch_assoc($qSiswa)) {
            $_SESSION['siswa_id'] = $rowSiswa['id'];
        } else {
            $_SESSION['login_error'] = "Data siswa tidak ditemukan. Hubungi admin.";
            header("Location: index.php");
            exit;
        }
        header("Location: dashboard_siswa.php");
        exit;
    } else {
        $_SESSION['login_error'] = "Role tidak dikenali";
        header("Location: index.php");
        exit;
    }
}

$q_guru = mysqli_query($conn, "SELECT * FROM users_guru WHERE username='$user' AND password='$pass_md5' LIMIT 1");
if ($q_guru && mysqli_num_rows($q_guru) > 0) {
    $data_guru = mysqli_fetch_assoc($q_guru);
    $uname = $data_guru['username'];
    $nama  = $data_guru['nama'];

    $cek_users = mysqli_query($conn, "SELECT id FROM users WHERE username='$uname' LIMIT 1");
    if (mysqli_num_rows($cek_users) > 0) {
        $row_users = mysqli_fetch_assoc($cek_users);
        $user_id = (int)$row_users['id'];
    } else {
        mysqli_query($conn, "INSERT INTO users (username, nama, password, role) VALUES ('$uname', '$nama', '$pass_md5', 'guru')");
        $user_id = (int)mysqli_insert_id($conn);
    }

    $_SESSION['user_id']  = $user_id;
    $_SESSION['username'] = $uname;
    $_SESSION['role']     = 'guru';
    $_SESSION['nama']     = $nama;

    header("Location: dashboard_guru.php");
    exit;
}

$q_guru_direct = mysqli_query($conn, "SELECT * FROM guru WHERE nip='$user' AND status='aktif' LIMIT 1");
if ($q_guru_direct && mysqli_num_rows($q_guru_direct) > 0) {
    $data_gd = mysqli_fetch_assoc($q_guru_direct);

    if ($pass_md5 === md5($data_gd['nip'])) {
        $nip  = $data_gd['nip'];
        $nama = $data_gd['nama'];

        $cek_users = mysqli_query($conn, "SELECT id FROM users WHERE username='$nip' LIMIT 1");
        if (mysqli_num_rows($cek_users) > 0) {
            $row_users = mysqli_fetch_assoc($cek_users);
            $user_id = (int)$row_users['id'];
        } else {
            mysqli_query($conn, "INSERT INTO users (username, nama, password, role) VALUES ('$nip', '$nama', '$pass_md5', 'guru')");
            $user_id = (int)mysqli_insert_id($conn);
        }

        @mysqli_query($conn, "INSERT IGNORE INTO users_guru (username, nama, password, role) VALUES ('$nip', '$nama', '$pass_md5', 'guru')");

        $_SESSION['user_id']  = $user_id;
        $_SESSION['username'] = $nip;
        $_SESSION['role']     = 'guru';
        $_SESSION['nama']     = $nama;

        header("Location: dashboard_guru.php");
        exit;
    }
}

$_SESSION['login_error'] = "Username atau password salah!";
header("Location: index.php");
exit;