<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
require 'fpdf/fpdf.php';

$kelas = $_GET['kelas'] ?? '';
$bulan = $_GET['bulan'] ?? date('m');
$tahun = $_GET['tahun'] ?? date('Y');

$hariIni  = date('d');
$bulanIni = date('m');
$tahunIni = date('Y');

$jumlahHari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);

$profil = mysqli_fetch_assoc(mysqli_query($conn, "SELECT logo, nama_sekolah, alamat, kepala_sekolah, nip_kepala FROM profil_sekolah LIMIT 1"));
$logo_path = null;
if ($profil && !empty($profil['logo'])) {
    $kandidat = __DIR__ . '/uploads/' . $profil['logo'];
    if (file_exists($kandidat)) $logo_path = $kandidat;
}
$nama_sekolah   = $profil['nama_sekolah'] ?? 'SEKOLAH';
$alamat_sekolah = $profil['alamat'] ?? '';
$kepala         = $profil['kepala_sekolah'] ?? '....................................';
$nip_kepala     = $profil['nip_kepala'] ?? '........................';

$wali_nama = '....................................';
$wali_nip  = '........................';
if ($kelas != '') {
    $qWali = mysqli_query($conn, "SELECT nama_wali, nip_wali FROM wali_kelas WHERE kelas = '$kelas' LIMIT 1");
    if ($w = mysqli_fetch_assoc($qWali)) {
        $wali_nama = $w['nama_wali'];
        $wali_nip  = $w['nip_wali'];
    }
}

$siswaQuery = "SELECT * FROM siswa WHERE status='aktif'";
if ($kelas != '') {
    $siswaQuery .= " AND kelas = '$kelas'";
}
$siswaQuery .= " ORDER BY nama";
$siswaResult = mysqli_query($conn, $siswaQuery);

$absensi = [];
$absensiQuery = "SELECT a.*, s.nis, s.nama FROM absensi a 
                 JOIN siswa s ON a.siswa_id = s.id 
                 WHERE MONTH(a.tanggal) = '$bulan' 
                   AND YEAR(a.tanggal) = '$tahun'
                   AND s.status='aktif'";
if ($kelas != '') {
    $absensiQuery .= " AND s.kelas = '$kelas'";
}
$resultAbsensi = mysqli_query($conn, $absensiQuery);
while ($row = mysqli_fetch_assoc($resultAbsensi)) {
    $sid = $row['siswa_id'];
    $tgl = (int)date('j', strtotime($row['tanggal']));
    $absensi[$sid][$tgl] = $row['status'];
}

$libur = [];
$queryLibur = mysqli_query($conn, "SELECT tanggal FROM hari_libur");
if ($queryLibur) {
    while ($row = mysqli_fetch_assoc($queryLibur)) {
        $libur[] = $row['tanggal'];
    }
}

$nama_bulan = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];
$bulan_teks = $nama_bulan[(int)$bulan] . ' ' . $tahun;
$kelas_teks = ($kelas != '') ? 'Kelas: ' . $kelas : 'Kelas: Semua Kelas';
$tanggal_terakhir = date("j F Y", strtotime("$tahun-$bulan-" . cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun)));

class RekapSiswaPDF extends FPDF
{
    public $namaSekolah;
    public $alamatSekolah;
    public $logoPath;

    function Header()
    {
        if ($this->logoPath && file_exists($this->logoPath)) {
            $this->Image($this->logoPath, 8, 6, 16);
        }

        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor(30, 60, 114);
        $this->Cell(0, 7, 'REKAPITULASI ABSENSI SISWA', 0, 1, 'C');

        $this->SetFont('Arial', 'B', 10);
        $this->SetTextColor(15, 23, 42);
        $this->Cell(0, 5, $this->namaSekolah, 0, 1, 'C');

        if (!empty($this->alamatSekolah)) {
            $this->SetFont('Arial', '', 8);
            $this->SetTextColor(100, 116, 139);
            $this->Cell(0, 4, $this->alamatSekolah, 0, 1, 'C');
        }

        $this->SetDrawColor(255, 176, 32);
        $this->SetLineWidth(0.6);
        $this->Line(8, $this->GetY() + 1, 289, $this->GetY() + 1);
        $this->SetLineWidth(0.2);
        $this->Ln(3);
    }

    function Footer()
    {
        $this->SetY(-12);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(148, 163, 184);
        $this->Cell(0, 5, 'Dicetak pada: ' . date('d/m/Y H:i'), 0, 0, 'C');
    }
}

$pdf = new RekapSiswaPDF('L', 'mm', 'A4');
$pdf->namaSekolah   = $nama_sekolah;
$pdf->alamatSekolah = $alamat_sekolah;
$pdf->logoPath      = $logo_path;
$pdf->SetAutoPageBreak(true, 22);
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetTextColor(30, 60, 114);
$pdf->Cell(0, 6, 'Periode: ' . $bulan_teks . '   |   ' . $kelas_teks, 0, 1, 'C');
$pdf->Ln(2);

$col_no    = 6;
$col_nis   = 22;
$col_nama  = 48;
$col_rekap = 10;
$total_fixed = $col_no + $col_nis + $col_nama + ($col_rekap * 4);
$day_w = (281 - $total_fixed) / $jumlahHari;
if ($day_w < 4.2) $day_w = 4.2;
if ($day_w > 7.5) $day_w = 7.5;

$pdf->SetFont('Arial', 'B', 8);
$pdf->SetFillColor(30, 60, 114);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetDrawColor(30, 60, 114);

$row_h = 7;
$pdf->Cell($col_no, $row_h, 'No', 1, 0, 'C', true);
$pdf->Cell($col_nis, $row_h, 'NIS', 1, 0, 'C', true);
$pdf->Cell($col_nama, $row_h, 'Nama Siswa', 1, 0, 'C', true);
for ($i = 1; $i <= $jumlahHari; $i++) {
    $pdf->Cell($day_w, $row_h, $i, 1, 0, 'C', true);
}
$pdf->Cell($col_rekap, $row_h, 'H', 1, 0, 'C', true);
$pdf->Cell($col_rekap, $row_h, 'S', 1, 0, 'C', true);
$pdf->Cell($col_rekap, $row_h, 'I', 1, 0, 'C', true);
$pdf->Cell($col_rekap, $row_h, 'A', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 7);
$pdf->SetDrawColor(232, 237, 243);
$pdf->SetTextColor(51, 65, 85);

$no = 1;
$fill = false;

if ($siswaResult && mysqli_num_rows($siswaResult) > 0) {
    mysqli_data_seek($siswaResult, 0);
    while ($siswa = mysqli_fetch_assoc($siswaResult)) {
        if ($pdf->GetY() > 180) {
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 8);
            $pdf->SetFillColor(30, 60, 114);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetDrawColor(30, 60, 114);

            $pdf->Cell($col_no, $row_h, 'No', 1, 0, 'C', true);
            $pdf->Cell($col_nis, $row_h, 'NIS', 1, 0, 'C', true);
            $pdf->Cell($col_nama, $row_h, 'Nama Siswa', 1, 0, 'C', true);
            for ($i = 1; $i <= $jumlahHari; $i++) {
                $pdf->Cell($day_w, $row_h, $i, 1, 0, 'C', true);
            }
            $pdf->Cell($col_rekap, $row_h, 'H', 1, 0, 'C', true);
            $pdf->Cell($col_rekap, $row_h, 'S', 1, 0, 'C', true);
            $pdf->Cell($col_rekap, $row_h, 'I', 1, 0, 'C', true);
            $pdf->Cell($col_rekap, $row_h, 'A', 1, 1, 'C', true);

            $pdf->SetFont('Arial', '', 7);
            $pdf->SetDrawColor(232, 237, 243);
            $fill = false;
        }

        $sid = $siswa['id'];

        $bg = $fill ? [249, 250, 251] : [255, 255, 255];
        $pdf->SetFillColor($bg[0], $bg[1], $bg[2]);

        $pdf->SetTextColor(51, 65, 85);
        $pdf->Cell($col_no, 5.5, $no, 1, 0, 'C', true);
        $pdf->Cell($col_nis, 5.5, $siswa['nis'], 1, 0, 'C', true);

        $nama = $siswa['nama'];
        if (strlen($nama) > 28) {
            $nama = substr($nama, 0, 25) . '...';
        }
        $pdf->SetFont('Arial', 'B', 7);
        $pdf->Cell($col_nama, 5.5, $nama, 1, 0, 'L', true);
        $pdf->SetFont('Arial', '', 7);

        $countH = $countS = $countI = $countA = 0;

        for ($i = 1; $i <= $jumlahHari; $i++) {
            $tanggal = "$tahun-" . str_pad($bulan, 2, '0', STR_PAD_LEFT) . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
            $day = date('w', strtotime($tanggal));
            $isLibur = in_array($tanggal, $libur);

            $isHariMendatang = false;
            if ($tahun == $tahunIni && $bulan == $bulanIni && $i > $hariIni) {
                $isHariMendatang = true;
            } elseif ($tahun == $tahunIni && $bulan > $bulanIni) {
                $isHariMendatang = true;
            } elseif ($tahun > $tahunIni) {
                $isHariMendatang = true;
            }

            $val = $absensi[$sid][$i] ?? '';

            if ($val == '') {
                if ($day == 0 || $isLibur) {
                    $pdf->SetTextColor(220, 38, 38);
                    $pdf->Cell($day_w, 5.5, 'L', 1, 0, 'C', true);
                    $pdf->SetTextColor(51, 65, 85);
                } elseif ($isHariMendatang) {
                    $pdf->Cell($day_w, 5.5, '', 1, 0, 'C', true);
                } else {
                    $pdf->SetTextColor(185, 28, 28);
                    $pdf->Cell($day_w, 5.5, 'A', 1, 0, 'C', true);
                    $pdf->SetTextColor(51, 65, 85);
                    $countA++;
                }
            } else {
                if ($val == 'H') {
                    $pdf->SetTextColor(4, 120, 87);
                    $pdf->Cell($day_w, 5.5, 'H', 1, 0, 'C', true);
                    $countH++;
                } elseif ($val == 'A') {
                    $pdf->SetTextColor(185, 28, 28);
                    $pdf->Cell($day_w, 5.5, 'A', 1, 0, 'C', true);
                    $countA++;
                } elseif ($val == 'S') {
                    $pdf->SetTextColor(109, 40, 217);
                    $pdf->Cell($day_w, 5.5, 'S', 1, 0, 'C', true);
                    $countS++;
                } elseif ($val == 'I') {
                    $pdf->SetTextColor(180, 83, 9);
                    $pdf->Cell($day_w, 5.5, 'I', 1, 0, 'C', true);
                    $countI++;
                } else {
                    $pdf->SetTextColor(51, 65, 85);
                    $pdf->Cell($day_w, 5.5, $val, 1, 0, 'C', true);
                }
                $pdf->SetTextColor(51, 65, 85);
            }
        }

        $pdf->SetFont('Arial', 'B', 7);

        $pdf->SetTextColor(4, 120, 87);
        $pdf->Cell($col_rekap, 5.5, $countH, 1, 0, 'C', true);

        $pdf->SetTextColor(109, 40, 217);
        $pdf->Cell($col_rekap, 5.5, $countS, 1, 0, 'C', true);

        $pdf->SetTextColor(180, 83, 9);
        $pdf->Cell($col_rekap, 5.5, $countI, 1, 0, 'C', true);

        $pdf->SetTextColor(185, 28, 28);
        $pdf->Cell($col_rekap, 5.5, $countA, 1, 1, 'C', true);

        $pdf->SetFont('Arial', '', 7);
        $no++;
        $fill = !$fill;
    }
} else {
    $total_width = $col_no + $col_nis + $col_nama + ($day_w * $jumlahHari) + ($col_rekap * 4);
    $pdf->SetTextColor(148, 163, 184);
    $pdf->SetFont('Arial', 'I', 10);
    $pdf->Cell($total_width, 12, 'Tidak ada data siswa aktif pada filter ini.', 1, 1, 'C');
}

$pdf->Ln(3);

$total_width = $col_no + $col_nis + $col_nama + ($day_w * $jumlahHari) + ($col_rekap * 4);
$pdf->SetFont('Arial', '', 7.5);
$pdf->SetTextColor(51, 65, 85);
$pdf->SetDrawColor(42, 82, 152);
$pdf->SetFillColor(249, 250, 251);
$pdf->Cell($total_width, 6, '  Keterangan: H = Hadir  |  S = Sakit  |  I = Izin  |  A = Alpha  |  L = Libur/Minggu', 1, 1, 'L', true);

$pdf->Ln(5);

if ($pdf->GetY() > 155) {
    $pdf->AddPage();
}

$y_sig = $pdf->GetY();
$half = 140;
$left_x = 20;
$right_x = 20 + $half + 20;

$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(51, 65, 85);

$pdf->SetXY($left_x, $y_sig);
$pdf->Cell($half, 5, 'Mengetahui,', 0, 2, 'C');
$pdf->SetX($left_x);
$pdf->Cell($half, 5, 'Kepala Sekolah', 0, 2, 'C');

$pdf->SetY($y_sig + 28);
$pdf->SetX($left_x);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->Cell($half, 5, $kepala, 0, 2, 'C');
$pdf->SetX($left_x);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell($half, 5, 'NIP. ' . $nip_kepala, 0, 2, 'C');

$pdf->SetXY($right_x, $y_sig);
$pdf->Cell($half, 5, $tanggal_terakhir . ',', 0, 2, 'C');
$pdf->SetX($right_x);
$pdf->Cell($half, 5, 'Wali Kelas ' . ($kelas != '' ? $kelas : '(Semua Kelas)'), 0, 2, 'C');

$pdf->SetY($y_sig + 28);
$pdf->SetX($right_x);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->Cell($half, 5, $wali_nama, 0, 2, 'C');
$pdf->SetX($right_x);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell($half, 5, 'NIP. ' . $wali_nip, 0, 2, 'C');

mysqli_close($conn);

$pdf->Output('I', 'rekap_absensi_siswa_' . $bulan . '_' . $tahun . '.pdf');
exit;