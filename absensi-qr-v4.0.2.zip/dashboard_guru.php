<?php

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

$username_session = $_SESSION['username'];
$q_user = mysqli_query($conn, "SELECT nama, foto FROM users WHERE username='$username_session' LIMIT 1");
$data_user = mysqli_fetch_assoc($q_user);
$nama_user = $data_user['nama'] ?? 'Guru';

$foto_user = $data_user['foto'] ?? '';
$kandidat_foto = [
    __DIR__ . '/' . $foto_user,
    __DIR__ . '/uploads/' . $foto_user,
];
$path_valid = '';
foreach ($kandidat_foto as $p) {
    if (!empty($foto_user) && file_exists($p)) { $path_valid = $p; break; }
}
$has_foto_user = $path_valid !== '';
$foto_user_url = $has_foto_user
    ? htmlspecialchars(str_replace(__DIR__ . '/', '', $path_valid)) . "?v=" . filemtime($path_valid)
    : "";
$initial_user = strtoupper(substr($nama_user !== '' ? $nama_user : 'G', 0, 1));

$q_profil = mysqli_query($conn, "SELECT nama_sekolah FROM profil_sekolah LIMIT 1");
$data_profil = mysqli_fetch_assoc($q_profil);
$nama_sekolah = $data_profil['nama_sekolah'] ?? 'Nama Sekolah';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Guru Absensi QR</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --danger:#ef4444;
      --radius-xl:20px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{margin:0;padding:0;box-sizing:border-box;}

    html{scroll-behavior:smooth;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      overflow-x:hidden;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .notification-bar{
      background:linear-gradient(135deg,#1e3c72 0%, #2a5298 100%);
      color:#fff;
      padding:12px 0;
      position:relative;
      z-index:20;
      overflow:hidden;
      border-bottom:1px solid rgba(255,255,255,.06);
    }

    .notification-text{
      display:inline-block;
      padding-left:100%;
      white-space:nowrap;
      animation:marquee 32s linear infinite;
      font-weight:400;
      font-size:13.5px;
      letter-spacing:.3px;
      color:rgba(255,255,255,.92);
    }

    .notification-text i{
      margin-right:10px;
      font-size:14px;
      color:var(--accent);
    }

    @keyframes marquee{
      0%{transform:translateX(0);}
      100%{transform:translateX(-100%);}
    }

    header{
      background:rgba(255,255,255,.85);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      color:var(--ink);
      padding:16px 32px;
      display:flex;
      justify-content:space-between;
      align-items:center;
      position:sticky;
      top:0;
      z-index:15;
      border-bottom:1px solid var(--line);
    }

    .header-left{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:42px;
      height:42px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:17px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-text{
      min-width:0;
    }

    header h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      line-height:1.25;
      margin-bottom:2px;
    }

    .user-info{
      font-size:12.5px;
      color:var(--muted);
      font-weight:400;
      line-height:1.4;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
    }

    .user-info b{
      color:var(--ink-2);
      font-weight:600;
    }

    .user-profile-menu{
      position:relative;
      display:inline-block;
      flex-shrink:0;
    }

    .profile-btn{
      display:flex;
      align-items:center;
      gap:10px;
      background:var(--surface);
      padding:6px 14px 6px 6px;
      border-radius:999px;
      cursor:pointer;
      color:var(--ink);
      font-weight:500;
      text-decoration:none;
      border:1px solid var(--line);
      transition:border-color .2s ease, box-shadow .2s ease, transform .2s ease;
      font-size:13.5px;
    }

    .profile-btn:hover{
      border-color:var(--line-strong);
      box-shadow:var(--shadow-sm);
    }

    .profile-avatar{
      width:32px;
      height:32px;
      border-radius:50%;
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:13px;
      font-weight:600;
      flex-shrink:0;
      overflow:hidden;
      border:1px solid rgba(255,255,255,.5);
    }

    .profile-avatar img{
      width:100%;
      height:100%;
      object-fit:cover;
      display:block;
    }

    .profile-btn span{
      display:flex;
      align-items:center;
      gap:8px;
      white-space:nowrap;
      max-width:160px;
      overflow:hidden;
      text-overflow:ellipsis;
    }

    .profile-btn i.fa-caret-down{
      color:var(--muted);
      font-size:11px;
    }

    .dropdown-content{
      display:none;
      position:absolute;
      right:0;
      top:100%;
      padding-top:10px;
      min-width:210px;
      z-index:30;
    }

    .dropdown-box{
      background:#fff;
      border:1px solid var(--line);
      box-shadow:var(--shadow-lg);
      border-radius:var(--radius-md);
      overflow:hidden;
      padding:6px;
    }

    .dropdown-content a{
      color:var(--ink-2);
      padding:10px 12px;
      text-decoration:none;
      display:flex;
      align-items:center;
      gap:10px;
      font-size:13.5px;
      font-weight:500;
      border-radius:8px;
      transition:background .15s ease, color .15s ease;
    }

    .dropdown-content a i{
      width:16px;
      text-align:center;
      color:var(--muted);
      font-size:13px;
    }

    .dropdown-content a:hover{
      background:var(--surface-2);
      color:var(--ink);
    }

    .dropdown-content a:hover i{
      color:var(--brand);
    }

    .dropdown-content a.logout-link{
      color:var(--danger);
    }

    .dropdown-content a.logout-link i{
      color:var(--danger);
    }

    .dropdown-content a.logout-link:hover{
      background:rgba(239,68,68,.06);
    }

    .user-profile-menu:hover .dropdown-content,
    .user-profile-menu:focus-within .dropdown-content{
      display:block;
    }

    .dashboard-container{
      max-width:1240px;
      margin:0 auto;
      padding:36px 28px 48px;
      position:relative;
      z-index:5;
    }

    .page-head{
      display:flex;
      align-items:flex-end;
      justify-content:space-between;
      gap:20px;
      margin-bottom:28px;
      flex-wrap:wrap;
    }

    .page-title{
      display:flex;
      flex-direction:column;
      gap:6px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
    }

    h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-sub{
      font-size:13.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .search-container{
      position:relative;
      width:100%;
      max-width:380px;
    }

    .search-input{
      width:100%;
      padding:12px 18px 12px 44px;
      font-size:14px;
      font-family:inherit;
      color:var(--ink);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      outline:none;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      background:var(--surface);
      box-shadow:var(--shadow-sm);
    }

    .search-input::placeholder{
      color:var(--muted-2);
    }

    .search-input:hover{
      border-color:var(--line-strong);
    }

    .search-input:focus{
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .search-icon{
      position:absolute;
      top:50%;
      left:16px;
      transform:translateY(-50%);
      color:var(--muted-2);
      font-size:14px;
      pointer-events:none;
    }

    .menu-section{
      margin-bottom:32px;
    }

    .menu-section:last-child{
      margin-bottom:0;
    }

    .section-header{
      display:flex;
      align-items:center;
      gap:12px;
      margin-bottom:16px;
      padding-bottom:10px;
      border-bottom:1px dashed var(--line-strong);
      position:relative;
    }

    .section-header::after{
      content:"";
      position:absolute;
      left:0;
      bottom:-1px;
      width:44px;
      height:2px;
      background:var(--section-accent, var(--brand));
      border-radius:2px;
    }

    .section-icon{
      width:30px;
      height:30px;
      border-radius:8px;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:13px;
      color:var(--section-accent, var(--brand));
      background:color-mix(in srgb, var(--section-accent, var(--brand)) 12%, transparent);
      flex-shrink:0;
    }

    .section-title{
      font-size:14.5px;
      font-weight:600;
      letter-spacing:-.1px;
      color:var(--ink);
      margin:0;
    }

    .section-count{
      margin-left:auto;
      font-size:11.5px;
      font-weight:500;
      color:var(--muted);
      background:var(--surface-2);
      border:1px solid var(--line);
      padding:3px 10px;
      border-radius:999px;
      letter-spacing:.3px;
    }

    .menu-grid{
      display:grid;
      grid-template-columns:repeat(auto-fill, minmax(280px, 1fr));
      gap:18px;
    }

    .menu-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      overflow:hidden;
      transition:transform .25s ease, box-shadow .25s ease, border-color .25s ease;
      position:relative;
      height:100%;
      display:flex;
      flex-direction:column;
      box-shadow:var(--shadow-sm);
    }

    .menu-card::before{
      content:"";
      position:absolute;
      top:0;left:0;right:0;
      height:3px;
      background:var(--card-color, var(--brand));
      opacity:.9;
    }

    .menu-card:hover{
      transform:translateY(-4px);
      box-shadow:var(--shadow-lg);
      border-color:var(--line-strong);
    }

    .card-content{
      padding:24px 22px 22px;
      flex-grow:1;
      display:flex;
      flex-direction:column;
      position:relative;
    }

    .card-icon{
      width:48px;
      height:48px;
      border-radius:var(--radius-md);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:19px;
      color:var(--card-color, var(--brand));
      background:color-mix(in srgb, var(--card-color, var(--brand)) 12%, transparent);
      margin-bottom:16px;
      transition:transform .25s ease;
      flex-shrink:0;
    }

    .menu-card:hover .card-icon{
      transform:scale(1.06);
    }

    .card-title{
      font-size:15.5px;
      font-weight:600;
      margin-bottom:6px;
      color:var(--ink);
      letter-spacing:-.15px;
      line-height:1.35;
    }

    .card-desc{
      font-size:13px;
      color:var(--muted);
      line-height:1.55;
      margin-bottom:20px;
      flex-grow:1;
    }

    .card-button{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:6px;
      text-align:center;
      padding:10px 14px;
      background:var(--surface-2);
      color:var(--ink-2);
      text-decoration:none;
      border-radius:var(--radius-sm);
      font-weight:500;
      font-size:13px;
      border:1px solid var(--line);
      transition:background .2s ease, color .2s ease, border-color .2s ease;
      margin-top:auto;
      position:relative;
    }

    .card-button::after{
      content:"\f061";
      font-family:"Font Awesome 6 Free";
      font-weight:900;
      font-size:10px;
      opacity:.55;
      transition:transform .2s ease, opacity .2s ease;
    }

    .menu-card:hover .card-button{
      background:var(--card-color, var(--brand));
      color:#fff;
      border-color:var(--card-color, var(--brand));
    }

    .menu-card:hover .card-button::after{
      transform:translateX(3px);
      opacity:1;
    }

    .card-button:focus-visible{
      outline:3px solid var(--brand-soft);
      outline-offset:2px;
    }

    footer{
      margin-top:48px;
      background:transparent;
      color:var(--muted);
      text-align:center;
      padding:22px 20px 32px;
      font-size:12.5px;
      border-top:1px solid var(--line);
      letter-spacing:.2px;
    }

    footer strong{
      color:var(--ink-2);
      font-weight:600;
    }

    .no-result{
      text-align:center;
      padding:60px 20px;
      color:var(--muted);
      font-size:14px;
    }

    @media (max-width:900px){
      header{padding:14px 20px;}
      header h1{font-size:16px;}
      .dashboard-container{padding:28px 20px 40px;}
      h2{font-size:21px;}
      .menu-grid{grid-template-columns:repeat(auto-fill, minmax(240px, 1fr));gap:16px;}
      .card-content{padding:20px 18px 18px;}
    }

    @media (max-width:640px){
      header{
        padding:12px 16px;
        flex-wrap:wrap;
        gap:12px;
      }
      .brand-mark{width:38px;height:38px;font-size:15px;}
      header h1{font-size:15px;}
      .user-info{font-size:11.5px;white-space:normal;}
      .profile-btn span span{display:none;}
      .profile-btn{padding:5px;}
      .profile-btn > span{display:none;}
      .page-head{flex-direction:column;align-items:stretch;gap:14px;}
      .search-container{max-width:none;}
      h2{font-size:19px;}
      .dashboard-container{padding:22px 16px 32px;}
      .menu-grid{grid-template-columns:1fr;gap:14px;}
      .menu-section{margin-bottom:26px;}
      .section-title{font-size:13.5px;}
      .section-count{font-size:11px;padding:2px 9px;}
      .notification-text{font-size:12px;}
      footer{font-size:11.5px;padding:18px 16px 26px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;scroll-behavior:auto !important;}
    }
  </style>
</head>
<body>
  <div class="notification-bar">
    <div class="notification-text">
      <i class="fas fa-chalkboard-teacher"></i> Kehadiran Bapak/Ibu Guru membersamai siswa belajar tidak akan pernah dapat digantikan oleh Robot AI
    </div>
  </div>

  <header>
    <div class="header-left">
      <div class="brand-mark">
        <i class="fas fa-qrcode"></i>
      </div>
      <div class="brand-text">
        <h1>Dashboard Guru</h1>
        <div class="user-info">Selamat datang, <b><?= htmlspecialchars($nama_user); ?></b> &middot; Role: <?= htmlspecialchars($role); ?></div>
      </div>
    </div>

    <div class="user-profile-menu" tabindex="0">
      <div class="profile-btn">
        <div class="profile-avatar">
          <?php if ($has_foto_user): ?>
            <img src="<?= $foto_user_url ?>" alt="Foto Profil">
          <?php else: ?>
            <?= htmlspecialchars($initial_user); ?>
          <?php endif; ?>
        </div>
        <span><span><?= htmlspecialchars($nama_user); ?></span> <i class="fa-solid fa-caret-down"></i></span>
      </div>
      <div class="dropdown-content">
        <div class="dropdown-box">
          <a href="profil_guru.php"><i class="fa-solid fa-user-pen"></i> Pengaturan Akun</a>
          <a href="logout.php" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
      </div>
    </div>
  </header>

  <div class="dashboard-container">
    <div class="page-head">
      <div class="page-title">
        <span class="page-eyebrow">Menu Utama</span>
        <h2>Kelola Absensi Siswa</h2>
        <span class="page-sub">Pilih menu di bawah untuk mulai bekerja.</span>
      </div>

      <div class="search-container">
        <i class="fas fa-search search-icon"></i>
        <input type="text" id="searchMenu" class="search-input" placeholder="Cari menu (siswa, scan, rekap, wa, jam)" onkeyup="filterMenu()">
      </div>
    </div>

    <div id="menuWrapper">

      <section class="menu-section" data-section style="--section-accent:#f59e0b;">
        <div class="section-header">
          <div class="section-icon"><i class="fas fa-bolt"></i></div>
          <h3 class="section-title">Operasional Harian</h3>
          <span class="section-count">4 menu</span>
        </div>
        <div class="menu-grid">
          <div class="menu-card" style="--card-color: #10b981; --card-dark: #047857;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-qrcode"></i></div>
              <div class="card-title">SCAN QR</div>
              <div class="card-desc">Scan QR Code siswa untuk mencatat kehadiran secara otomatis</div>
              <a href="scan_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>

          <div class="menu-card" style="--card-color: #3b82f6; --card-dark: #1d4ed8;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-clipboard-check"></i></div>
              <div class="card-title">Isi S/I/A</div>
              <div class="card-desc">Input data Sakit, Izin, atau Alpha untuk siswa</div>
              <a href="absensi_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>

          <div class="menu-card" style="--card-color: #ef4444; --card-dark: #b91c1c;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-user"></i></div>
              <div class="card-title">Siswa Belum Hadir</div>
              <div class="card-desc">Lihat daftar siswa yang belum melakukan absensi hari ini</div>
              <a href="belum_absensi_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>

          <div class="menu-card" style="--card-color: #dc2626; --card-dark: #991b1b;">
            <div class="card-content">
              <div class="card-icon"><i class="fas fa-clipboard-user"></i></div>
              <div class="card-title">Rekap Kehadiran Siswa</div>
              <div class="card-desc">Lihat Rekap Kehadiran Harian Siswa</div>
              <a href="export.php" class="card-button">Akses Menu</a>
            </div>
          </div>
        </div>
      </section>

      <section class="menu-section" data-section style="--section-accent:#3b82f6;">
        <div class="section-header">
          <div class="section-icon"><i class="fas fa-users"></i></div>
          <h3 class="section-title">Data &amp; Kelas</h3>
          <span class="section-count">1 menu</span>
        </div>
        <div class="menu-grid">
          <div class="menu-card" style="--card-color: #f59e0b; --card-dark: #b45309;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-user-graduate"></i></div>
              <div class="card-title">Data Siswa</div>
              <div class="card-desc">Kelola data siswa, NIS, NISN, kelas, dan kartu QR absensi</div>
              <a href="siswa_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>
        </div>
      </section>

      <section class="menu-section" data-section style="--section-accent:#8b5cf6;">
        <div class="section-header">
          <div class="section-icon"><i class="fas fa-chart-line"></i></div>
          <h3 class="section-title">Rekap &amp; Laporan</h3>
          <span class="section-count">3 menu</span>
        </div>
        <div class="menu-grid">
          <div class="menu-card" style="--card-color: #475569; --card-dark: #1e293b;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-calendar-days"></i></div>
              <div class="card-title">Rekap Bulanan</div>
              <div class="card-desc">Lihat rekap absensi siswa per bulan</div>
              <a href="rekap_bulanan_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>

          <div class="menu-card" style="--card-color: #0ea5e9; --card-dark: #0369a1;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-chart-line"></i></div>
              <div class="card-title">Grafik</div>
              <div class="card-desc">Visualisasi data kehadiran siswa dalam bentuk grafik</div>
              <a href="grafik_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>

          <div class="menu-card" style="--card-color: #ec4899; --card-dark: #be185d;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-chart-pie"></i></div>
              <div class="card-title">Prosentase Kehadiran</div>
              <div class="card-desc">Statistik persentase kehadiran siswa</div>
              <a href="hadir_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>
        </div>
      </section>

      <section class="menu-section" data-section style="--section-accent:#25d366;">
        <div class="section-header">
          <div class="section-icon"><i class="fas fa-comments"></i></div>
          <h3 class="section-title">Komunikasi</h3>
          <span class="section-count">1 menu</span>
        </div>
        <div class="menu-grid">
          <div class="menu-card" style="--card-color: #25d366; --card-dark: #128c7e;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-brands fa-whatsapp"></i></div>
              <div class="card-title">Kirim WA Orang Tua/Wali Siswa</div>
              <div class="card-desc">Kirim pesan WhatsApp ke orang tua/wali siswa</div>
              <a href="wa-wali-siswa.php" class="card-button">Akses Menu</a>
            </div>
          </div>
        </div>
      </section>

      <section class="menu-section" data-section style="--section-accent:#0ea5e9;">
        <div class="section-header">
          <div class="section-icon"><i class="fas fa-sliders"></i></div>
          <h3 class="section-title">Pengaturan Absensi</h3>
          <span class="section-count">2 menu</span>
        </div>
        <div class="menu-grid">
          <div class="menu-card" style="--card-color: #8b5cf6; --card-dark: #6d28d9;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-clock"></i></div>
              <div class="card-title">Jam Waktu Absensi</div>
              <div class="card-desc">Atur jadwal dan batas waktu absensi siswa</div>
              <a href="jam_absensi_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>

          <div class="menu-card" style="--card-color: #ef4444; --card-dark: #b91c1c;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-plane"></i></div>
              <div class="card-title">Hari Libur</div>
              <div class="card-desc">Kelola hari libur dan cuti bersama</div>
              <a href="libur_2.php" class="card-button">Akses Menu</a>
            </div>
          </div>
        </div>
      </section>

      <section class="menu-section" data-section style="--section-accent:#64748b;">
        <div class="section-header">
          <div class="section-icon"><i class="fas fa-gears"></i></div>
          <h3 class="section-title">Sistem</h3>
          <span class="section-count">1 menu</span>
        </div>
        <div class="menu-grid">
          <div class="menu-card" style="--card-color: #ef4444; --card-dark: #b91c1c;">
            <div class="card-content">
              <div class="card-icon"><i class="fa-solid fa-right-from-bracket"></i></div>
              <div class="card-title">Logout</div>
              <div class="card-desc">Keluar dari sistem absensi</div>
              <a href="logout.php" class="card-button">Keluar</a>
            </div>
          </div>
        </div>
      </section>

    </div>

    <div id="noResultMessage" class="no-result" style="display:none;">
      <i class="fas fa-search" style="font-size:22px;opacity:.4;display:block;margin-bottom:10px;"></i>
      Menu tidak ditemukan. Coba kata kunci lain.
    </div>

  </div>

  <footer>
    <strong><?= htmlspecialchars($nama_sekolah); ?></strong> &middot; &copy; <?= date('Y'); ?> Sistem Absensi QR
  </footer>

  <script>
    function filterMenu() {
      const input = document.getElementById('searchMenu');
      const filter = input.value.toLowerCase().trim();
      const sections = document.querySelectorAll('[data-section]');
      const noResult = document.getElementById('noResultMessage');
      let totalVisible = 0;

      sections.forEach(function(section) {
        const cards = section.querySelectorAll('.menu-card');
        let visibleInSection = 0;

        cards.forEach(function(card) {
          const title = card.querySelector('.card-title');
          const desc = card.querySelector('.card-desc');
          const titleText = (title ? title.textContent : '').toLowerCase();
          const descText = (desc ? desc.textContent : '').toLowerCase();

          if (filter === '' || titleText.indexOf(filter) > -1 || descText.indexOf(filter) > -1) {
            card.style.display = '';
            visibleInSection++;
          } else {
            card.style.display = 'none';
          }
        });

        if (visibleInSection > 0) {
          section.style.display = '';
          totalVisible += visibleInSection;
        } else {
          section.style.display = 'none';
        }
      });

      if (totalVisible === 0 && filter !== '') {
        noResult.style.display = '';
      } else {
        noResult.style.display = 'none';
      }
    }
  </script>
</body>
</html>