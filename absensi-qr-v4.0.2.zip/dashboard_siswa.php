<?php

session_start();
include 'config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
    header("Location: index.php");
    exit;
}

if (!isset($_SESSION['siswa_id'])) {
    die("Data siswa tidak ditemukan, silakan login ulang.");
}

$siswa_id = intval($_SESSION['siswa_id']);
$username = $_SESSION['username'];

$q = mysqli_query($conn, "SELECT nama, kelas FROM siswa WHERE id = $siswa_id");
$siswa = mysqli_fetch_assoc($q);

$bulanFilter = isset($_GET['bulan']) ? $_GET['bulan'] : date("m");
$tahunFilter = isset($_GET['tahun']) ? $_GET['tahun'] : date("Y");

$qAbsensi = mysqli_query($conn, "
    SELECT tanggal, jam, status 
    FROM absensi 
    WHERE siswa_id = $siswa_id
      AND MONTH(tanggal) = '" . mysqli_real_escape_string($conn, $bulanFilter) . "'
      AND YEAR(tanggal) = '" . mysqli_real_escape_string($conn, $tahunFilter) . "'
    ORDER BY tanggal DESC, jam DESC
");

$qStat = mysqli_query($conn, "
    SELECT 
        SUM(CASE WHEN status='H' THEN 1 ELSE 0 END) AS total_h,
        SUM(CASE WHEN status='S' THEN 1 ELSE 0 END) AS total_s,
        SUM(CASE WHEN status='I' THEN 1 ELSE 0 END) AS total_i,
        SUM(CASE WHEN status='A' THEN 1 ELSE 0 END) AS total_a,
        COUNT(*) AS total_all
    FROM absensi 
    WHERE siswa_id = $siswa_id
      AND MONTH(tanggal) = '" . mysqli_real_escape_string($conn, $bulanFilter) . "'
      AND YEAR(tanggal) = '" . mysqli_real_escape_string($conn, $tahunFilter) . "'
");
$stat = mysqli_fetch_assoc($qStat);
$totalH = (int)($stat['total_h'] ?? 0);
$totalS = (int)($stat['total_s'] ?? 0);
$totalI = (int)($stat['total_i'] ?? 0);
$totalA = (int)($stat['total_a'] ?? 0);
$totalAll = (int)($stat['total_all'] ?? 0);

$initial_siswa = strtoupper(substr($siswa['nama'] !== '' ? $siswa['nama'] : 'S', 0, 1));

function statusText($s) {
    switch ($s) {
        case 'H': return 'Hadir';
        case 'S': return 'Sakit';
        case 'I': return 'Izin';
        case 'A': return 'Alpa';
        default: return $s;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Siswa</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --success-dark:#047857;
      --success-soft:rgba(16,185,129,.10);
      --warning:#f59e0b;
      --warning-dark:#b45309;
      --warning-soft:rgba(245,158,11,.12);
      --danger:#ef4444;
      --danger-dark:#b91c1c;
      --danger-soft:rgba(239,68,68,.10);
      --info:#3b82f6;
      --info-dark:#1d4ed8;
      --info-soft:rgba(59,130,246,.10);
      --purple:#8b5cf6;
      --purple-dark:#6d28d9;
      --purple-soft:rgba(139,92,246,.10);
      --radius-xl:20px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg) !important;
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:32px 0 56px;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .page-shell{
      max-width:1100px;
      margin:0 auto;
      padding:0 24px;
    }

    .hero-card{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:20px;
      padding:24px 28px;
      background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
      border-radius:var(--radius-xl);
      box-shadow:var(--shadow-brand);
      margin-bottom:20px;
      position:relative;
      overflow:hidden;
      flex-wrap:wrap;
      animation:fadeUp .5s ease both;
    }

    .hero-card::before{
      content:"";
      position:absolute;
      top:-100px;
      right:-80px;
      width:280px;
      height:280px;
      border-radius:50%;
      background:radial-gradient(circle, rgba(255,255,255,.16), transparent 65%);
      pointer-events:none;
    }

    .hero-left{
      display:flex;
      align-items:center;
      gap:16px;
      position:relative;
      z-index:1;
      min-width:0;
    }

    .hero-avatar{
      width:64px;
      height:64px;
      border-radius:50%;
      background:rgba(255,255,255,.16);
      border:2px solid rgba(255,255,255,.32);
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:26px;
      font-weight:600;
      flex-shrink:0;
      overflow:hidden;
    }

    .hero-info{min-width:0;}

    .hero-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:rgba(255,255,255,.75);
      display:block;
      margin-bottom:4px;
    }

    .hero-name{
      font-size:22px;
      font-weight:600;
      letter-spacing:-.3px;
      color:#fff;
      margin:0 0 6px;
      line-height:1.25;
      overflow:hidden;
      text-overflow:ellipsis;
      white-space:nowrap;
      max-width:100%;
    }

    .hero-meta{
      display:flex;
      flex-wrap:wrap;
      gap:8px;
      align-items:center;
    }

    .hero-pill{
      display:inline-flex;
      align-items:center;
      gap:7px;
      padding:5px 12px;
      background:rgba(255,255,255,.16);
      border:1px solid rgba(255,255,255,.24);
      border-radius:999px;
      color:#fff;
      font-size:12.5px;
      font-weight:500;
    }

    .hero-pill i{font-size:11px;}

    .hero-actions{
      display:flex;
      gap:10px;
      position:relative;
      z-index:1;
      flex-wrap:wrap;
    }

    .btn-hero{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      padding:10px 16px;
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      text-decoration:none;
      border:1px solid transparent;
      transition:background .2s ease, border-color .2s ease, color .2s ease, transform .2s ease;
      cursor:pointer;
      line-height:1;
    }

    .btn-hero i{font-size:13px;}

    .btn-hero-warning{
      background:rgba(255,255,255,.95);
      color:#b45309;
      border-color:rgba(255,255,255,.5);
    }

    .btn-hero-warning:hover{
      background:#fff;
      color:#92400e;
      transform:translateY(-1px);
    }

    .btn-hero-danger{
      background:rgba(255,255,255,.16);
      color:#fff;
      border-color:rgba(255,255,255,.32);
    }

    .btn-hero-danger:hover{
      background:rgba(239,68,68,.35);
      border-color:rgba(239,68,68,.6);
      color:#fff;
      transform:translateY(-1px);
    }

    @keyframes fadeUp{
      from{opacity:0; transform:translateY(10px);}
      to{opacity:1; transform:translateY(0);}
    }

    .stats-grid{
      display:grid;
      grid-template-columns:repeat(4, 1fr);
      gap:14px;
      margin-bottom:20px;
    }

    .stat-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      padding:16px 18px;
      box-shadow:var(--shadow-sm);
      display:flex;
      align-items:center;
      gap:12px;
      transition:transform .2s ease, box-shadow .2s ease, border-color .2s ease;
    }

    .stat-card:hover{
      transform:translateY(-2px);
      box-shadow:var(--shadow-md);
      border-color:var(--line-strong);
    }

    .stat-icon{
      width:42px;
      height:42px;
      border-radius:var(--radius-sm);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:16px;
      flex-shrink:0;
    }

    .stat-icon.h{background:var(--success-soft); color:var(--success-dark);}
    .stat-icon.s{background:var(--purple-soft); color:var(--purple-dark);}
    .stat-icon.i{background:var(--warning-soft); color:var(--warning-dark);}
    .stat-icon.a{background:var(--danger-soft); color:var(--danger-dark);}

    .stat-text{
      display:flex;
      flex-direction:column;
      gap:2px;
      min-width:0;
    }

    .stat-label{
      font-size:11.5px;
      color:var(--muted);
      font-weight:500;
      letter-spacing:.4px;
      text-transform:uppercase;
    }

    .stat-value{
      font-size:20px;
      font-weight:700;
      color:var(--ink);
      letter-spacing:-.3px;
      line-height:1.1;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      margin-bottom:20px;
      overflow:hidden;
      transition:box-shadow .25s ease;
      animation:fadeUp .5s ease both;
    }

    .card-panel:hover{box-shadow:var(--shadow-md);}

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:18px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .card-panel-body{padding:22px 24px;}

    .filter-grid{
      display:grid;
      grid-template-columns:1fr 1fr auto;
      gap:14px;
      align-items:end;
    }

    .filter-item{
      display:flex;
      flex-direction:column;
      gap:7px;
    }

    .form-label{
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
    }

    .form-control,
    .form-select{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
      width:100%;
      outline:none;
    }

    .form-control:hover,
    .form-select:hover{border-color:var(--line-strong);}

    .form-control:focus,
    .form-select:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .btn-primary{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 18px;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:none;
      cursor:pointer;
      color:#fff;
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      box-shadow:var(--shadow-brand);
      transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
      line-height:1;
      text-decoration:none;
    }

    .btn-primary:hover{
      transform:translateY(-1px);
      filter:brightness(1.08);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-primary i{font-size:12.5px;}

    .table-wrapper{
      overflow-x:auto;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
    }

    .table-wrapper::-webkit-scrollbar{height:8px;}
    .table-wrapper::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}

    table.riwayat-table{
      border-collapse:separate;
      border-spacing:0;
      width:100%;
      font-size:13.5px;
      color:var(--ink-2);
      margin:0;
    }

    .riwayat-table thead th{
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:13px 16px;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    .riwayat-table tbody td{
      padding:13px 16px;
      border-bottom:1px solid var(--line);
      vertical-align:middle;
      color:var(--ink-2);
    }

    .riwayat-table tbody tr{transition:background .15s ease;}
    .riwayat-table tbody tr:hover td{background:rgba(42,82,152,.04);}
    .riwayat-table tbody tr:last-child td{border-bottom:none;}

    .badge-tanggal{
      display:inline-flex;
      align-items:center;
      gap:7px;
      padding:5px 11px;
      font-size:12px;
      font-weight:500;
      background:var(--brand-soft);
      color:var(--brand);
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-tanggal i{font-size:11px;}

    .badge-jam{
      display:inline-flex;
      align-items:center;
      gap:7px;
      padding:5px 11px;
      font-size:12px;
      font-weight:500;
      background:var(--surface-2);
      color:var(--ink-2);
      border:1px solid var(--line);
      border-radius:6px;
      letter-spacing:.3px;
      font-variant-numeric:tabular-nums;
    }

    .badge-jam i{font-size:11px;color:var(--muted);}

    .status-badge{
      display:inline-flex;
      align-items:center;
      gap:6px;
      padding:5px 12px;
      font-size:12px;
      font-weight:600;
      border-radius:999px;
      letter-spacing:.2px;
      line-height:1;
      border:1px solid transparent;
    }

    .status-badge i{font-size:10px;}

    .status-badge.h{background:var(--success-soft); color:var(--success-dark); border-color:rgba(16,185,129,.24);}
    .status-badge.s{background:var(--purple-soft); color:var(--purple-dark); border-color:rgba(139,92,246,.24);}
    .status-badge.i{background:var(--warning-soft); color:var(--warning-dark); border-color:rgba(245,158,11,.24);}
    .status-badge.a{background:var(--danger-soft); color:var(--danger-dark); border-color:rgba(239,68,68,.24);}
    .status-badge.unknown{background:var(--surface-2); color:var(--muted); border-color:var(--line);}

    .empty-state{
      text-align:center;
      padding:56px 24px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:42px;
      opacity:.4;
      margin-bottom:14px;
      display:block;
      color:var(--brand);
    }

    .empty-state h4{
      font-size:16px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 6px;
    }

    .empty-state p{
      font-size:13.5px;
      margin:0;
    }

    @media (max-width:900px){
      .page-shell{padding:0 18px;}
      body{padding:24px 0 44px;}
      .hero-card{padding:20px 22px;}
      .hero-name{font-size:20px;}
      .hero-avatar{width:56px;height:56px;font-size:22px;}
      .stats-grid{grid-template-columns:repeat(2, 1fr);}
      .card-panel-body{padding:18px;}
      .card-panel-header{padding:16px 20px;}
      .filter-grid{grid-template-columns:1fr 1fr;}
      .filter-grid .filter-btn{grid-column:1 / -1;}
      .filter-grid .filter-btn .btn-primary{width:100%;}
    }

    @media (max-width:640px){
      body{padding:18px 0 36px;}
      .page-shell{padding:0 14px;}
      .hero-card{padding:18px;border-radius:18px;}
      .hero-left{gap:12px;width:100%;}
      .hero-avatar{width:52px;height:52px;font-size:20px;}
      .hero-name{font-size:17px;white-space:normal;}
      .hero-actions{width:100%;}
      .hero-actions .btn-hero{flex:1;}
      .stats-grid{grid-template-columns:1fr 1fr;gap:10px;}
      .stat-card{padding:14px;}
      .stat-text .stat-value{font-size:18px;}
      .stat-icon{width:38px;height:38px;font-size:14px;}
      .card-panel{border-radius:var(--radius-md);}
      .card-panel-body{padding:14px;}
      .card-panel-header{padding:14px 16px;}
      .card-panel-title{font-size:13.5px;}
      .filter-grid{grid-template-columns:1fr;gap:12px;}
      .filter-grid .filter-btn{grid-column:auto;}
      .riwayat-table thead th,
      .riwayat-table tbody td{padding:11px 12px;font-size:12.5px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="page-shell">

    <div class="hero-card">
      <div class="hero-left">
        <div class="hero-avatar">
          <?= htmlspecialchars($initial_siswa); ?>
        </div>
        <div class="hero-info">
          <span class="hero-eyebrow">Dashboard Siswa</span>
          <h1 class="hero-name">Halo, <?= htmlspecialchars($siswa['nama']) ?></h1>
          <div class="hero-meta">
            <span class="hero-pill"><i class="fas fa-door-open"></i> Kelas <?= htmlspecialchars($siswa['kelas']) ?></span>
            <span class="hero-pill"><i class="fas fa-user"></i> @<?= htmlspecialchars($username) ?></span>
          </div>
        </div>
      </div>
      <div class="hero-actions">
        <a href="ubah_password_siswa.php" class="btn-hero btn-hero-warning">
          <i class="fas fa-key"></i> Ubah Password
        </a>
        <a href="logout.php" class="btn-hero btn-hero-danger">
          <i class="fas fa-right-from-bracket"></i> Logout
        </a>
      </div>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon h"><i class="fas fa-circle-check"></i></div>
        <div class="stat-text">
          <span class="stat-label">Hadir</span>
          <span class="stat-value"><?= number_format($totalH, 0, ',', '.') ?></span>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon s"><i class="fas fa-notes-medical"></i></div>
        <div class="stat-text">
          <span class="stat-label">Sakit</span>
          <span class="stat-value"><?= number_format($totalS, 0, ',', '.') ?></span>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon i"><i class="fas fa-envelope-open-text"></i></div>
        <div class="stat-text">
          <span class="stat-label">Izin</span>
          <span class="stat-value"><?= number_format($totalI, 0, ',', '.') ?></span>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon a"><i class="fas fa-circle-xmark"></i></div>
        <div class="stat-text">
          <span class="stat-label">Alpa</span>
          <span class="stat-value"><?= number_format($totalA, 0, ',', '.') ?></span>
        </div>
      </div>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-filter"></i>
          Filter Periode
        </div>
      </div>
      <div class="card-panel-body">
        <form method="GET" class="filter-grid">
          <div class="filter-item">
            <label class="form-label" for="bulan">Pilih Bulan</label>
            <select name="bulan" id="bulan" class="form-select">
              <?php 
              $namaBulan = [
                  1=>"Januari", 2=>"Februari", 3=>"Maret", 4=>"April",
                  5=>"Mei", 6=>"Juni", 7=>"Juli", 8=>"Agustus",
                  9=>"September", 10=>"Oktober", 11=>"November", 12=>"Desember"
              ];
              foreach ($namaBulan as $num => $nama) {
                  $selected = ($bulanFilter == $num) ? "selected" : "";
                  echo "<option value='$num' $selected>$nama</option>";
              }
              ?>
            </select>
          </div>
          <div class="filter-item">
            <label class="form-label" for="tahun">Pilih Tahun</label>
            <select name="tahun" id="tahun" class="form-select">
              <?php
              $tahunSekarang = date("Y");
              for ($t = $tahunSekarang; $t >= $tahunSekarang - 5; $t--) {
                  $selected = ($tahunFilter == $t) ? "selected" : "";
                  echo "<option value='$t' $selected>$t</option>";
              }
              ?>
            </select>
          </div>
          <div class="filter-item filter-btn">
            <label class="form-label">&nbsp;</label>
            <button type="submit" class="btn-primary">
              <i class="fas fa-search"></i> Tampilkan
            </button>
          </div>
        </form>
      </div>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-clock-rotate-left"></i>
          Riwayat Kehadiran
        </div>
      </div>
      <div class="card-panel-body" style="padding:0;">
        <div class="table-wrapper">
          <table class="riwayat-table">
            <thead>
              <tr>
                <th style="width:60px;">No</th>
                <th>Tanggal</th>
                <th>Jam</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (mysqli_num_rows($qAbsensi) > 0): ?>
                <?php $no=1; while($row = mysqli_fetch_assoc($qAbsensi)): 
                  $s = $row['status'];
                  $badge = 'unknown';
                  $icon = 'fa-circle-info';
                  if ($s === 'H') { $badge = 'h'; $icon = 'fa-circle-check'; }
                  elseif ($s === 'S') { $badge = 's'; $icon = 'fa-notes-medical'; }
                  elseif ($s === 'I') { $badge = 'i'; $icon = 'fa-envelope-open-text'; }
                  elseif ($s === 'A') { $badge = 'a'; $icon = 'fa-circle-xmark'; }
                  $tgl = $row['tanggal'];
                  $tgl_fmt = date('d/m/Y', strtotime($tgl));
                  $hari_map = ['Sunday'=>'Minggu','Monday'=>'Senin','Tuesday'=>'Selasa','Wednesday'=>'Rabu','Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu'];
                  $hari_id = $hari_map[date('l', strtotime($tgl))] ?? date('l', strtotime($tgl));
                ?>
                  <tr>
                    <td><?= $no++ ?></td>
                    <td>
                      <span class="badge-tanggal">
                        <i class="fas fa-calendar-day"></i> <?= htmlspecialchars($tgl_fmt) ?>
                      </span>
                      <small style="color:var(--muted);margin-left:6px;"><?= htmlspecialchars($hari_id) ?></small>
                    </td>
                    <td>
                      <?php if (!empty($row['jam'])): ?>
                        <span class="badge-jam"><i class="fas fa-clock"></i> <?= htmlspecialchars($row['jam']) ?></span>
                      <?php else: ?>
                        <span style="color:var(--muted-2);">-</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span class="status-badge <?= $badge ?>">
                        <i class="fas <?= $icon ?>"></i> <?= htmlspecialchars(statusText($s)) ?>
                      </span>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="4">
                    <div class="empty-state">
                      <i class="fas fa-inbox"></i>
                      <h4>Belum ada data absensi</h4>
                      <p>Tidak ada riwayat kehadiran pada periode ini.</p>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

  </div>

</body>
</html>