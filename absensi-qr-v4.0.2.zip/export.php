<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
require 'fpdf/fpdf.php';

$tanggal = $_GET['tanggal'] ?? date("Y-m-d");
$tanggal_akhir = $_GET['tanggal_akhir'] ?? $tanggal;
$filter_tanggal = $_GET['filter_tanggal'] ?? 'hari';
$kelasFilter = $_GET['kelas'] ?? "";
$namaFilter = $_GET['nama'] ?? "";
$statusFilter = $_GET['status'] ?? "";
$action = $_GET['action'] ?? 'preview';

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

$profil_query = mysqli_query($conn, "SELECT * FROM profil_sekolah LIMIT 1");
$profil = mysqli_fetch_assoc($profil_query);
$kepalaSekolah = $profil['kepala_sekolah'] ?? 'Nama Kepala Sekolah';
$nipKepala = $profil['nip_kepala'] ?? 'NIP Kepala Sekolah';
$namaSekolah = $profil['nama_sekolah'] ?? 'Nama Sekolah';
$alamatSekolah = $profil['alamat'] ?? '';

$waliKelas = '';
$nipWali = '';
if ($kelasFilter != '' && $kelasFilter != 'Semua Kelas') {
    $wali_query = mysqli_query($conn, "SELECT nama_wali, nip_wali FROM wali_kelas WHERE kelas='$kelasFilter' LIMIT 1");
    if ($wali_query && mysqli_num_rows($wali_query) > 0) {
        $dataWali = mysqli_fetch_assoc($wali_query);
        $waliKelas = $dataWali['nama_wali'];
        $nipWali = $dataWali['nip_wali'];
    }
}

$sql = "
    SELECT 
        a.id, 
        s.id AS siswa_id, 
        s.nis,
        s.nama, 
        s.kelas, 
        a.jam AS jam_masuk, 
        a.jam_pulang,
        a.status,
        a.keterangan,
        a.tanggal
    FROM absensi a
    JOIN siswa s ON a.siswa_id = s.id
    WHERE s.status = 'aktif'
";

if ($filter_tanggal == 'hari') {
    $sql .= " AND a.tanggal = '" . mysqli_real_escape_string($conn, $tanggal) . "'";
} else {
    $sql .= " AND a.tanggal BETWEEN '" . mysqli_real_escape_string($conn, $tanggal) . "' AND '" . mysqli_real_escape_string($conn, $tanggal_akhir) . "'";
}
if ($kelasFilter !== "") {
    $sql .= " AND s.kelas = '" . mysqli_real_escape_string($conn, $kelasFilter) . "'";
}
if ($namaFilter !== "") {
    $sql .= " AND s.nama LIKE '%" . mysqli_real_escape_string($conn, $namaFilter) . "%'";
}
if ($statusFilter !== "") {
    $sql .= " AND a.status = '" . mysqli_real_escape_string($conn, $statusFilter) . "'";
}
$sql .= " ORDER BY a.tanggal DESC, s.kelas, s.nama";

$result = mysqli_query($conn, $sql);
if (!$result) {
    die("Error query absensi: " . mysqli_error($conn));
}

function getStatusText($status) {
    switch($status) {
        case 'H': return 'Hadir';
        case 'I': return 'Izin';
        case 'S': return 'Sakit';
        case 'A': return 'Alpa';
        default: return $status;
    }
}

$periodeTeks = ($filter_tanggal == 'hari')
    ? date("d/m/Y", strtotime($tanggal))
    : date("d/m/Y", strtotime($tanggal)) . " s/d " . date("d/m/Y", strtotime($tanggal_akhir));

$kelasTeks = ($kelasFilter == '' ? 'Semua Kelas' : $kelasFilter);
$statusTeks = ($statusFilter == '' ? 'Semua Status' : getStatusText($statusFilter));
$tanggalCetak = date('d/m/Y');

$rows = [];
$countH = $countI = $countS = $countA = 0;
while ($row = mysqli_fetch_assoc($result)) {
    $rows[] = $row;
    switch ($row['status']) {
        case 'H': $countH++; break;
        case 'I': $countI++; break;
        case 'S': $countS++; break;
        case 'A': $countA++; break;
    }
}
$totalRecords = count($rows);

$logo_path = null;
if (!empty($profil['logo'])) {
    $kandidat = __DIR__ . '/uploads/' . $profil['logo'];
    if (file_exists($kandidat)) $logo_path = $kandidat;
}

if ($action === 'pdf') {

    class RekapPDF extends FPDF
    {
        public $namaSekolah;
        public $alamatSekolah;
        public $logoPath;

        function Header()
        {
            if ($this->logoPath && file_exists($this->logoPath)) {
                $this->Image($this->logoPath, 10, 6, 16);
            }

            $this->SetFont('Arial', 'B', 14);
            $this->SetTextColor(30, 60, 114);
            $this->Cell(0, 7, 'REKAP KEHADIRAN SISWA', 0, 1, 'C');

            $this->SetFont('Arial', 'B', 10);
            $this->SetTextColor(15, 23, 42);
            $this->Cell(0, 5, $this->namaSekolah, 0, 1, 'C');

            if (!empty($this->alamatSekolah)) {
                $this->SetFont('Arial', '', 8);
                $this->SetTextColor(100, 116, 139);
                $this->Cell(0, 4, $this->alamatSekolah, 0, 1, 'C');
            }

            $this->SetDrawColor(255, 176, 32);
            $this->SetLineWidth(0.6);
            $this->Line(10, $this->GetY() + 1, 287, $this->GetY() + 1);
            $this->SetLineWidth(0.2);
            $this->Ln(4);
        }

        function Footer()
        {
            $this->SetY(-12);
            $this->SetFont('Arial', 'I', 8);
            $this->SetTextColor(148, 163, 184);
            $this->Cell(0, 5, 'Dicetak pada: ' . date('d/m/Y H:i'), 0, 0, 'C');
        }
    }

    $pdf = new RekapPDF('L', 'mm', 'A4');
    $pdf->namaSekolah = $namaSekolah;
    $pdf->alamatSekolah = $alamatSekolah;
    $pdf->logoPath = $logo_path;
    $pdf->SetAutoPageBreak(true, 20);
    $pdf->AddPage();

    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetFillColor(249, 250, 251);
    $pdf->SetDrawColor(232, 237, 243);
    $pdf->SetTextColor(51, 65, 85);

    $col_w = 68;
    $row_h = 6;

    $pdf->Cell($col_w, $row_h, '  Periode', 1, 0, 'L', true);
    $pdf->Cell($col_w, $row_h, '  Kelas', 1, 0, 'L', true);
    $pdf->Cell($col_w, $row_h, '  Status', 1, 0, 'L', true);
    $pdf->Cell($col_w, $row_h, '  Tanggal Cetak', 1, 1, 'L', true);

    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(15, 23, 42);
    $pdf->Cell($col_w, $row_h, '  ' . $periodeTeks, 1, 0, 'L');
    $pdf->Cell($col_w, $row_h, '  ' . $kelasTeks, 1, 0, 'L');
    $pdf->Cell($col_w, $row_h, '  ' . $statusTeks, 1, 0, 'L');
    $pdf->Cell($col_w, $row_h, '  ' . $tanggalCetak, 1, 1, 'L');

    $pdf->Ln(3);

    $pdf->SetFont('Arial', 'B', 9);

    $pdf->SetFillColor(236, 253, 245);
    $pdf->SetTextColor(4, 120, 87);
    $pdf->Cell(38, 7, 'Hadir: ' . $countH, 0, 0, 'C', true);
    $pdf->Cell(4, 7, '', 0, 0);

    $pdf->SetFillColor(245, 243, 255);
    $pdf->SetTextColor(109, 40, 217);
    $pdf->Cell(38, 7, 'Sakit: ' . $countS, 0, 0, 'C', true);
    $pdf->Cell(4, 7, '', 0, 0);

    $pdf->SetFillColor(255, 251, 235);
    $pdf->SetTextColor(180, 83, 9);
    $pdf->Cell(38, 7, 'Izin: ' . $countI, 0, 0, 'C', true);
    $pdf->Cell(4, 7, '', 0, 0);

    $pdf->SetFillColor(254, 242, 242);
    $pdf->SetTextColor(185, 28, 28);
    $pdf->Cell(38, 7, 'Alpa: ' . $countA, 0, 0, 'C', true);
    $pdf->Cell(4, 7, '', 0, 0);

    $pdf->SetFillColor(239, 246, 255);
    $pdf->SetTextColor(29, 78, 216);
    $pdf->Cell(40, 7, 'Total: ' . $totalRecords, 0, 1, 'C', true);

    $pdf->Ln(4);

    $pdf->SetFont('Arial', 'B', 9);
    $pdf->SetFillColor(30, 60, 114);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetDrawColor(30, 60, 114);

    $col_no = 12;
    $col_tgl = 24;
    $col_nis = 24;
    $col_nama = 68;
    $col_kelas = 22;
    $col_masuk = 22;
    $col_pulang = 28;
    $col_status = 22;
    $col_ket = 55;

    $pdf->Cell($col_no, 8, 'No', 1, 0, 'C', true);
    $pdf->Cell($col_tgl, 8, 'Tanggal', 1, 0, 'C', true);
    $pdf->Cell($col_nis, 8, 'NIS', 1, 0, 'C', true);
    $pdf->Cell($col_nama, 8, 'Nama', 1, 0, 'C', true);
    $pdf->Cell($col_kelas, 8, 'Kelas', 1, 0, 'C', true);
    $pdf->Cell($col_masuk, 8, 'Jam Masuk', 1, 0, 'C', true);
    $pdf->Cell($col_pulang, 8, 'Jam Pulang', 1, 0, 'C', true);
    $pdf->Cell($col_status, 8, 'Status', 1, 0, 'C', true);
    $pdf->Cell($col_ket, 8, 'Keterangan', 1, 1, 'C', true);

    $pdf->SetFont('Arial', '', 8);
    $pdf->SetDrawColor(232, 237, 243);
    $pdf->SetTextColor(51, 65, 85);

    $no = 1;
    $fill = false;

    if ($totalRecords > 0) {
        foreach ($rows as $row) {
            if ($pdf->GetY() > 185) {
                $pdf->AddPage();
                $pdf->SetFont('Arial', 'B', 9);
                $pdf->SetFillColor(30, 60, 114);
                $pdf->SetTextColor(255, 255, 255);
                $pdf->SetDrawColor(30, 60, 114);

                $pdf->Cell($col_no, 8, 'No', 1, 0, 'C', true);
                $pdf->Cell($col_tgl, 8, 'Tanggal', 1, 0, 'C', true);
                $pdf->Cell($col_nis, 8, 'NIS', 1, 0, 'C', true);
                $pdf->Cell($col_nama, 8, 'Nama', 1, 0, 'C', true);
                $pdf->Cell($col_kelas, 8, 'Kelas', 1, 0, 'C', true);
                $pdf->Cell($col_masuk, 8, 'Jam Masuk', 1, 0, 'C', true);
                $pdf->Cell($col_pulang, 8, 'Jam Pulang', 1, 0, 'C', true);
                $pdf->Cell($col_status, 8, 'Status', 1, 0, 'C', true);
                $pdf->Cell($col_ket, 8, 'Keterangan', 1, 1, 'C', true);

                $pdf->SetFont('Arial', '', 8);
                $pdf->SetDrawColor(232, 237, 243);
                $fill = false;
            }

            $jamMasuk = empty($row['jam_masuk']) ? '-' : $row['jam_masuk'];
            $jamPulang = empty($row['jam_pulang']) ? '-' : $row['jam_pulang'];
            $statusText = getStatusText($row['status']);

            $bg = $fill ? [249, 250, 251] : [255, 255, 255];
            $pdf->SetFillColor($bg[0], $bg[1], $bg[2]);

            $pdf->SetTextColor(51, 65, 85);
            $pdf->Cell($col_no, 7, $no, 1, 0, 'C', true);
            $pdf->Cell($col_tgl, 7, date('d/m/Y', strtotime($row['tanggal'])), 1, 0, 'C', true);
            $pdf->SetTextColor(100, 116, 139);
            $pdf->Cell($col_nis, 7, $row['nis'], 1, 0, 'C', true);
            $pdf->SetTextColor(15, 23, 42);
            $pdf->SetFont('Arial', 'B', 8);
            $pdf->Cell($col_nama, 7, substr($row['nama'], 0, 38), 1, 0, 'L', true);
            $pdf->SetFont('Arial', '', 8);
            $pdf->SetTextColor(51, 65, 85);
            $pdf->Cell($col_kelas, 7, $row['kelas'], 1, 0, 'C', true);
            $pdf->Cell($col_masuk, 7, $jamMasuk, 1, 0, 'C', true);
            $pdf->Cell($col_pulang, 7, $jamPulang, 1, 0, 'C', true);

            switch ($row['status']) {
                case 'H': $pdf->SetTextColor(4, 120, 87); break;
                case 'S': $pdf->SetTextColor(109, 40, 217); break;
                case 'I': $pdf->SetTextColor(180, 83, 9); break;
                case 'A': $pdf->SetTextColor(185, 28, 28); break;
                default: $pdf->SetTextColor(51, 65, 85);
            }
            $pdf->SetFont('Arial', 'B', 8);
            $pdf->Cell($col_status, 7, $statusText, 1, 0, 'C', true);

            $pdf->SetFont('Arial', '', 8);
            $pdf->SetTextColor(100, 116, 139);
            $ket = substr($row['keterangan'], 0, 30);
            $pdf->Cell($col_ket, 7, $ket, 1, 1, 'L', true);

            $no++;
            $fill = !$fill;
        }
    } else {
        $pdf->SetTextColor(148, 163, 184);
        $pdf->SetFont('Arial', 'I', 10);
        $pdf->Cell(array_sum([$col_no, $col_tgl, $col_nis, $col_nama, $col_kelas, $col_masuk, $col_pulang, $col_status, $col_ket]), 12, 'Tidak ada data kehadiran pada periode ini.', 1, 1, 'C');
    }

    $pdf->Ln(4);

    $pdf->SetFont('Arial', '', 8);
    $pdf->SetTextColor(51, 65, 85);
    $pdf->SetDrawColor(42, 82, 152);
    $pdf->SetFillColor(249, 250, 251);
    $pdf->Cell(0, 7, '  Keterangan Status: H = Hadir  |  S = Sakit  |  I = Izin  |  A = Alpa', 1, 1, 'L', true);

    $pdf->Ln(6);

    if ($pdf->GetY() > 155) {
        $pdf->AddPage();
    }

    $y_sig = $pdf->GetY();
    $page_width = 287;
    $half = $page_width / 2;

    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(51, 65, 85);

    $pdf->SetXY(10, $y_sig);
    $pdf->Cell($half, 5, 'Mengetahui,', 0, 2, 'C');
    $pdf->SetX(10);
    $pdf->Cell($half, 5, 'Kepala Sekolah', 0, 2, 'C');

    $pdf->SetY($y_sig + 30);
    $pdf->SetX(10);
    $pdf->SetFont('Arial', 'BU', 10);
    $pdf->Cell($half, 5, $kepalaSekolah, 0, 2, 'C');
    $pdf->SetX(10);
    $pdf->SetFont('Arial', '', 9);
    $pdf->Cell($half, 5, 'NIP. ' . $nipKepala, 0, 2, 'C');

    $pdf->SetXY(10 + $half, $y_sig);
    $pdf->Cell($half, 5, $tanggalCetak . ',', 0, 2, 'C');
    $pdf->SetX(10 + $half);
    $pdf->Cell($half, 5, 'Wali Kelas ' . ($kelasFilter == '' || $kelasFilter == 'Semua Kelas' ? '' : $kelasFilter), 0, 2, 'C');

    $pdf->SetY($y_sig + 30);
    $pdf->SetX(10 + $half);
    $pdf->SetFont('Arial', 'BU', 10);
    $pdf->Cell($half, 5, $waliKelas !== '' ? $waliKelas : '....................................', 0, 2, 'C');
    $pdf->SetX(10 + $half);
    $pdf->SetFont('Arial', '', 9);
    $pdf->Cell($half, 5, 'NIP. ' . ($nipWali !== '' ? $nipWali : '........................'), 0, 2, 'C');

    mysqli_close($conn);

    $filename = 'rekap_kehadiran_' . date('Ymd_His') . '.pdf';
    $pdf->Output('I', $filename);
    exit;
}

mysqli_close($conn);

$backUrl = ($_SESSION['role'] === 'guru') ? 'dashboard_guru.php' : 'dashboard.php';

$queryString = http_build_query([
    'tanggal' => $tanggal,
    'tanggal_akhir' => $tanggal_akhir,
    'filter_tanggal' => $filter_tanggal,
    'kelas' => $kelasFilter,
    'nama' => $namaFilter,
    'status' => $statusFilter,
]);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Preview Rekap Kehadiran</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --success-dark:#047857;
      --warning:#f59e0b;
      --warning-dark:#b45309;
      --danger:#ef4444;
      --danger-dark:#b91c1c;
      --purple:#6d28d9;
      --info:#3b82f6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1280px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .topbar-actions{
      display:flex;
      align-items:center;
      gap:10px;
      flex-wrap:wrap;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1280px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
      white-space:nowrap;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-secondary{
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      box-shadow:var(--shadow-sm);
    }
    .btn-secondary:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .info-grid{
      display:grid;
      grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));
      gap:14px;
      margin-bottom:20px;
    }

    .info-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      padding:16px 18px;
      box-shadow:var(--shadow-sm);
      transition:box-shadow .2s ease;
    }

    .info-card:hover{
      box-shadow:var(--shadow-md);
    }

    .info-card-label{
      display:flex;
      align-items:center;
      gap:7px;
      font-size:11.5px;
      font-weight:600;
      letter-spacing:.6px;
      text-transform:uppercase;
      color:var(--muted);
      margin-bottom:8px;
    }

    .info-card-label i{
      font-size:11px;
      color:var(--brand);
    }

    .info-card-value{
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
      line-height:1.35;
      word-break:break-word;
    }

    .stat-row{
      display:grid;
      grid-template-columns:repeat(auto-fit, minmax(140px, 1fr));
      gap:12px;
      margin-bottom:22px;
    }

    .stat-chip{
      border-radius:var(--radius-md);
      padding:14px 16px;
      display:flex;
      align-items:center;
      gap:12px;
      border:1px solid transparent;
      transition:transform .2s ease, box-shadow .2s ease;
    }

    .stat-chip:hover{
      transform:translateY(-2px);
      box-shadow:var(--shadow-md);
    }

    .stat-chip .stat-icon{
      width:38px;
      height:38px;
      border-radius:var(--radius-sm);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:15px;
      flex-shrink:0;
      background:rgba(255,255,255,.6);
    }

    .stat-chip .stat-body{
      display:flex;
      flex-direction:column;
      gap:2px;
      min-width:0;
    }

    .stat-chip .stat-label{
      font-size:11.5px;
      font-weight:500;
      letter-spacing:.3px;
      text-transform:uppercase;
      opacity:.85;
    }

    .stat-chip .stat-value{
      font-size:20px;
      font-weight:700;
      letter-spacing:-.4px;
      line-height:1.1;
    }

    .stat-hadir{background:rgba(16,185,129,.10);color:var(--success-dark);border-color:rgba(16,185,129,.18);}
    .stat-sakit{background:rgba(109,40,217,.10);color:var(--purple);border-color:rgba(109,40,217,.18);}
    .stat-izin{background:rgba(245,158,11,.10);color:var(--warning-dark);border-color:rgba(245,158,11,.18);}
    .stat-alpa{background:rgba(239,68,68,.10);color:var(--danger-dark);border-color:rgba(239,68,68,.18);}
    .stat-total{background:rgba(59,130,246,.10);color:#1d4ed8;border-color:rgba(59,130,246,.18);}

    .table-wrapper{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      overflow:hidden;
    }

    .table-responsive{
      max-height:70vh;
      overflow-y:auto;
      overflow-x:auto;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
    }

    .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
    .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-responsive::-webkit-scrollbar-track{background:transparent;}

    .table{
      margin:0;
      --bs-table-bg:transparent;
      --bs-table-border-color:var(--line);
      --bs-table-striped-bg:transparent;
      --bs-table-hover-bg:rgba(42,82,152,.04);
      font-size:13.5px;
      color:var(--ink-2);
      width:100%;
    }

    .table thead th{
      position:sticky;
      top:0;
      z-index:2;
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:14px 16px;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    .table tbody td{
      padding:13px 16px;
      vertical-align:middle;
      border-bottom:1px solid var(--line);
      color:var(--ink-2);
    }

    .table tbody tr:hover{
      background:rgba(42,82,152,.04);
    }

    .table tbody tr:last-child td{
      border-bottom:0;
    }

    .cell-strong{
      font-weight:600;
      color:var(--ink);
    }

    .badge-nis{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(16,185,129,.1);
      color:#047857;
      border-radius:6px;
      letter-spacing:.3px;
      font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    }

    .badge-kelas{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(139,92,246,.1);
      color:#6d28d9;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-status{
      display:inline-block;
      padding:4px 12px;
      font-size:12px;
      font-weight:600;
      border-radius:999px;
      letter-spacing:.3px;
    }
    .badge-status.status-h{background:rgba(16,185,129,.12);color:#047857;}
    .badge-status.status-s{background:rgba(109,40,217,.12);color:#6d28d9;}
    .badge-status.status-i{background:rgba(245,158,11,.14);color:#b45309;}
    .badge-status.status-a{background:rgba(239,68,68,.12);color:#b91c1c;}

    .cell-empty{color:var(--muted-2);font-style:italic;}

    .empty-state{
      text-align:center;
      padding:60px 20px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:40px;
      opacity:.35;
      margin-bottom:14px;
      display:block;
    }

    .empty-state p{
      font-size:14px;
      margin:0;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .topbar-actions{width:100%;}
      .topbar-actions .btn,
      .topbar-actions .btn-back{flex:1 1 auto;justify-content:center;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .table thead th,
      .table tbody td{padding:11px 12px;font-size:12.5px;}
      .stat-chip{padding:12px 14px;}
      .stat-chip .stat-value{font-size:17px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-file-pdf"></i></div>
        <div class="brand-titles">
          <h1>Preview Rekap Kehadiran</h1>
          <span>Tinjau data sebelum mencetak PDF</span>
        </div>
      </div>
      <div class="topbar-actions">
        <a href="<?= htmlspecialchars($backUrl); ?>" class="btn-back">
          <i class="fas fa-arrow-left"></i>
          <span>Kembali</span>
        </a>
        <a href="export.php?action=pdf&<?= htmlspecialchars($queryString); ?>" target="_blank" class="btn btn-primary">
          <i class="fas fa-print"></i> Cetak PDF
        </a>
      </div>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Laporan</span>
      <h2>Rekap Kehadiran Siswa</h2>
      <p>Tinjau informasi dan data di bawah ini sebelum mencetak ke PDF.</p>
    </div>

    <div class="info-grid">
      <div class="info-card">
        <div class="info-card-label"><i class="fas fa-calendar-days"></i> Periode</div>
        <div class="info-card-value"><?= htmlspecialchars($periodeTeks); ?></div>
      </div>
      <div class="info-card">
        <div class="info-card-label"><i class="fas fa-door-open"></i> Kelas</div>
        <div class="info-card-value"><?= htmlspecialchars($kelasTeks); ?></div>
      </div>
      <div class="info-card">
        <div class="info-card-label"><i class="fas fa-filter"></i> Status</div>
        <div class="info-card-value"><?= htmlspecialchars($statusTeks); ?></div>
      </div>
      <div class="info-card">
        <div class="info-card-label"><i class="fas fa-school"></i> Sekolah</div>
        <div class="info-card-value"><?= htmlspecialchars($namaSekolah); ?></div>
      </div>
    </div>

    <div class="stat-row">
      <div class="stat-chip stat-hadir">
        <div class="stat-icon"><i class="fas fa-circle-check"></i></div>
        <div class="stat-body">
          <span class="stat-label">Hadir</span>
          <span class="stat-value"><?= (int)$countH; ?></span>
        </div>
      </div>
      <div class="stat-chip stat-sakit">
        <div class="stat-icon"><i class="fas fa-thermometer-half"></i></div>
        <div class="stat-body">
          <span class="stat-label">Sakit</span>
          <span class="stat-value"><?= (int)$countS; ?></span>
        </div>
      </div>
      <div class="stat-chip stat-izin">
        <div class="stat-icon"><i class="fas fa-envelope-open-text"></i></div>
        <div class="stat-body">
          <span class="stat-label">Izin</span>
          <span class="stat-value"><?= (int)$countI; ?></span>
        </div>
      </div>
      <div class="stat-chip stat-alpa">
        <div class="stat-icon"><i class="fas fa-circle-xmark"></i></div>
        <div class="stat-body">
          <span class="stat-label">Alpa</span>
          <span class="stat-value"><?= (int)$countA; ?></span>
        </div>
      </div>
      <div class="stat-chip stat-total">
        <div class="stat-icon"><i class="fas fa-list-check"></i></div>
        <div class="stat-body">
          <span class="stat-label">Total</span>
          <span class="stat-value"><?= (int)$totalRecords; ?></span>
        </div>
      </div>
    </div>

    <div class="table-wrapper">
      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th>No</th>
              <th>Tanggal</th>
              <th>NIS</th>
              <th>Nama</th>
              <th>Kelas</th>
              <th>Jam Masuk</th>
              <th>Jam Pulang</th>
              <th>Status</th>
              <th>Keterangan</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($totalRecords > 0): ?>
              <?php $no = 1; foreach ($rows as $row): ?>
                <?php
                  $jamMasuk = empty($row['jam_masuk']) ? '-' : $row['jam_masuk'];
                  $jamPulang = empty($row['jam_pulang']) ? '-' : $row['jam_pulang'];
                  $statusText = getStatusText($row['status']);
                  $statusClass = 'status-' . strtolower($row['status']);
                ?>
                <tr>
                  <td><?= $no++; ?></td>
                  <td><?= date('d/m/Y', strtotime($row['tanggal'])); ?></td>
                  <td><span class="badge-nis"><?= htmlspecialchars($row['nis']); ?></span></td>
                  <td class="cell-strong"><?= htmlspecialchars($row['nama']); ?></td>
                  <td><span class="badge-kelas"><?= htmlspecialchars($row['kelas']); ?></span></td>
                  <td><?= htmlspecialchars($jamMasuk); ?></td>
                  <td><?= htmlspecialchars($jamPulang); ?></td>
                  <td><span class="badge-status <?= $statusClass; ?>"><?= htmlspecialchars($statusText); ?></span></td>
                  <td>
                    <?php if (!empty($row['keterangan'])): ?>
                      <?= htmlspecialchars($row['keterangan']); ?>
                    <?php else: ?>
                      <span class="cell-empty">-</span>
                    <?php endif; ?>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="9">
                  <div class="empty-state">
                    <i class="fas fa-inbox"></i>
                    <p>Tidak ada data kehadiran pada periode ini.</p>
                  </div>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>

</body>
</html>