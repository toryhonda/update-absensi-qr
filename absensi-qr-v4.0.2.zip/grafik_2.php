<?php

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

$query = "SELECT status, COUNT(*) as total FROM absensi GROUP BY status";
$result = mysqli_query($conn, $query);

$dataStat = [
    'H' => 0,
    'S' => 0,
    'I' => 0,
    'A' => 0
];

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        if (array_key_exists($row['status'], $dataStat)) {
            $dataStat[$row['status']] = (int)$row['total'];
        }
    }
}

$totalAll = array_sum($dataStat);
function persen($v, $total) {
    return $total > 0 ? round(($v / $total) * 100, 1) : 0;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Grafik Statistik Kehadiran</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --purple:#8b5cf6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1280px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg,#0ea5e9,#0369a1);
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:0 14px 30px -14px rgba(3,105,161,.6);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .btn-back:focus-visible{
      outline:3px solid var(--brand-soft);
      outline-offset:2px;
    }

    .page-wrap{
      max-width:1280px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--info);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .info-banner{
      display:flex;
      align-items:flex-start;
      gap:12px;
      padding:14px 18px;
      border-radius:var(--radius-md);
      background:rgba(59,130,246,.08);
      border:1px solid rgba(59,130,246,.2);
      border-left:4px solid var(--info);
      color:#1e40af;
      font-size:13px;
      line-height:1.65;
      margin-bottom:20px;
    }

    .info-banner i{
      margin-top:2px;
      font-size:15px;
      flex-shrink:0;
      color:var(--info);
    }

    .info-banner strong{
      font-weight:600;
      color:#1d4ed8;
    }

    .stats-grid{
      display:grid;
      grid-template-columns:repeat(4, 1fr);
      gap:14px;
      margin-bottom:20px;
    }

    .stat-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      padding:16px 18px;
      box-shadow:var(--shadow-sm);
      display:flex;
      align-items:center;
      gap:12px;
      transition:transform .2s ease, box-shadow .2s ease, border-color .2s ease;
    }

    .stat-card:hover{
      transform:translateY(-2px);
      box-shadow:var(--shadow-md);
      border-color:var(--line-strong);
    }

    .stat-icon{
      width:42px;
      height:42px;
      border-radius:var(--radius-sm);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:16px;
      flex-shrink:0;
    }

    .stat-icon.h{background:rgba(16,185,129,.12); color:#047857;}
    .stat-icon.s{background:rgba(245,158,11,.14); color:#b45309;}
    .stat-icon.i{background:rgba(59,130,246,.12); color:#1d4ed8;}
    .stat-icon.a{background:rgba(239,68,68,.12); color:#b91c1c;}

    .stat-text{
      display:flex;
      flex-direction:column;
      gap:2px;
      min-width:0;
    }

    .stat-text .stat-label{
      font-size:11.5px;
      color:var(--muted);
      font-weight:500;
      letter-spacing:.3px;
      text-transform:uppercase;
    }

    .stat-text .stat-value{
      font-size:20px;
      font-weight:700;
      color:var(--ink);
      letter-spacing:-.3px;
      line-height:1.1;
    }

    .stat-text .stat-sub{
      font-size:11.5px;
      color:var(--muted-2);
      font-weight:500;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      overflow:hidden;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:18px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .card-panel-body{
      padding:22px 24px;
    }

    .chart-box{
      position:relative;
      width:100%;
      max-width:760px;
      height:400px;
      margin:0 auto;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .stats-grid{grid-template-columns:repeat(2, 1fr);}
      .card-panel-body{padding:18px;}
      .card-panel-header{padding:16px 20px;}
      .chart-box{height:340px;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .info-banner{font-size:12.5px; padding:12px 14px;}
      .stats-grid{grid-template-columns:1fr; gap:10px;}
      .stat-card{padding:14px;}
      .stat-text .stat-value{font-size:18px;}
      .card-panel{border-radius:var(--radius-md);}
      .card-panel-body{padding:14px;}
      .card-panel-header{padding:14px 16px;}
      .card-panel-title{font-size:13.5px;}
      .chart-box{height:300px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-chart-line"></i></div>
        <div class="brand-titles">
          <h1>Grafik Statistik</h1>
          <span>Visualisasi data kehadiran siswa</span>
        </div>
      </div>
      <a href="dashboard_guru.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Statistik</span>
      <h2>Grafik Statistik Kehadiran Siswa</h2>
      <p>Rekapitulasi jumlah kehadiran secara keseluruhan berdasarkan status.</p>
    </div>

    <div class="info-banner">
      <i class="fas fa-circle-info"></i>
      <div>
        <strong>Informasi:</strong> Grafik di bawah menyajikan rekapitulasi jumlah kehadiran secara keseluruhan berdasarkan status (Hadir, Sakit, Izin, Alpha).
      </div>
    </div>

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon h"><i class="fas fa-circle-check"></i></div>
        <div class="stat-text">
          <span class="stat-label">Hadir</span>
          <span class="stat-value"><?= number_format($dataStat['H'], 0, ',', '.') ?></span>
          <span class="stat-sub"><?= persen($dataStat['H'], $totalAll) ?>% dari total</span>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon s"><i class="fas fa-notes-medical"></i></div>
        <div class="stat-text">
          <span class="stat-label">Sakit</span>
          <span class="stat-value"><?= number_format($dataStat['S'], 0, ',', '.') ?></span>
          <span class="stat-sub"><?= persen($dataStat['S'], $totalAll) ?>% dari total</span>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon i"><i class="fas fa-envelope-open-text"></i></div>
        <div class="stat-text">
          <span class="stat-label">Izin</span>
          <span class="stat-value"><?= number_format($dataStat['I'], 0, ',', '.') ?></span>
          <span class="stat-sub"><?= persen($dataStat['I'], $totalAll) ?>% dari total</span>
        </div>
      </div>

      <div class="stat-card">
        <div class="stat-icon a"><i class="fas fa-circle-xmark"></i></div>
        <div class="stat-text">
          <span class="stat-label">Alpha</span>
          <span class="stat-value"><?= number_format($dataStat['A'], 0, ',', '.') ?></span>
          <span class="stat-sub"><?= persen($dataStat['A'], $totalAll) ?>% dari total</span>
        </div>
      </div>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-chart-column"></i>
          Diagram Batang Kehadiran
        </div>
      </div>
      <div class="card-panel-body">
        <div class="chart-box">
          <canvas id="grafikAbsensi"></canvas>
        </div>
      </div>
    </div>

  </div>

  <script>
    const ctx = document.getElementById('grafikAbsensi').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Hadir (H)', 'Sakit (S)', 'Izin (I)', 'Alpha (A)'],
        datasets: [{
          data: [
            <?= $dataStat['H']; ?>,
            <?= $dataStat['S']; ?>,
            <?= $dataStat['I']; ?>,
            <?= $dataStat['A']; ?>
          ],
          backgroundColor: ['#10b981', '#f59e0b', '#3b82f6', '#ef4444'],
          borderWidth: 0,
          borderRadius: 8,
          maxBarThickness: 62
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: {
          duration: 900,
          easing: 'easeOutQuart'
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#0f172a',
            titleColor: '#fff',
            bodyColor: '#fff',
            padding: 12,
            cornerRadius: 8,
            titleFont: { family: 'Rubik', size: 13, weight: '600' },
            bodyFont: { family: 'Rubik', size: 13 },
            displayColors: false
          }
        },
        scales: {
          x: {
            grid: { display: false, drawBorder: false },
            ticks: {
              color: '#64748b',
              font: { family: 'Rubik', size: 12, weight: '500' }
            }
          },
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
              color: '#94a3b8',
              font: { family: 'Rubik', size: 11 }
            },
            grid: {
              color: '#e8edf3',
              drawBorder: false
            }
          }
        }
      }
    });
  </script>
</body>
</html>