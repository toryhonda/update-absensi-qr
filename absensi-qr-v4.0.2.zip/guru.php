<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

$swal_msg = "";
$swal_icon = "";

$sql = "CREATE TABLE IF NOT EXISTS guru (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nip VARCHAR(20) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  mapel VARCHAR(50) NOT NULL,
  no_wa VARCHAR(20),
  status ENUM('aktif','keluar') DEFAULT 'aktif'
)";
mysqli_query($conn, $sql);

$check_columns = mysqli_query($conn, "DESCRIBE guru");
$columns = [];
while ($row = mysqli_fetch_assoc($check_columns)) {
    $columns[] = $row['Field'];
}
if (!in_array('no_wa', $columns)) {
    mysqli_query($conn, "ALTER TABLE guru ADD no_wa VARCHAR(20) AFTER mapel");
}
if (!in_array('status', $columns)) {
    mysqli_query($conn, "ALTER TABLE guru ADD status ENUM('aktif','keluar') DEFAULT 'aktif' AFTER no_wa");
}

$sql_ug = "CREATE TABLE IF NOT EXISTS users_guru (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  nama VARCHAR(100) NOT NULL,
  password VARCHAR(100) NOT NULL,
  role ENUM('admin','guru') DEFAULT 'guru'
)";
mysqli_query($conn, $sql_ug);

if (isset($_POST['simpan'])) {
    $nip   = mysqli_real_escape_string($conn, $_POST['nip']);
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $mapel = mysqli_real_escape_string($conn, $_POST['mapel']);
    $no_wa = mysqli_real_escape_string($conn, $_POST['no_wa']);

    $cek_nip = mysqli_query($conn, "SELECT id FROM guru WHERE nip='$nip' LIMIT 1");
    if (mysqli_num_rows($cek_nip) > 0) {
        $_SESSION['swal'] = ['icon' => 'error', 'title' => 'Gagal!', 'text' => 'NIP sudah terdaftar!'];
    } else {
        $result = mysqli_query($conn, "INSERT INTO guru (nip, nama, mapel, no_wa, status) VALUES ('$nip', '$nama', '$mapel', '$no_wa', 'aktif')");
        if ($result) {
            $username = $nip;
            $password = md5($nip);
            $role     = 'guru';

            $cek_user = mysqli_query($conn, "SELECT id FROM users_guru WHERE username='$username' LIMIT 1");
            if (mysqli_num_rows($cek_user) == 0) {
                mysqli_query($conn, "INSERT INTO users_guru (username, nama, password, role) VALUES ('$username', '$nama', '$password', '$role')");
            }

            if (file_exists('vendor/phpqrcode/qrlib.php')) {
                require 'vendor/phpqrcode/qrlib.php';
                $qr_dir = "assets/qr_guru/";
                if (!is_dir($qr_dir)) mkdir($qr_dir, 0777, true);
                QRcode::png($nip, $qr_dir . "$nip.png", QR_ECLEVEL_L, 4);
            }

            $_SESSION['swal'] = ['icon' => 'success', 'title' => 'Berhasil!', 'text' => 'Data guru berhasil disimpan!'];
        } else {
            $_SESSION['swal'] = ['icon' => 'error', 'title' => 'Error!', 'text' => mysqli_error($conn)];
        }
    }
    header("Location: guru.php");
    exit;
}

if (isset($_POST['update'])) {
    $id    = intval($_POST['id']);
    $nip   = mysqli_real_escape_string($conn, $_POST['nip']);
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $mapel = mysqli_real_escape_string($conn, $_POST['mapel']);
    $no_wa = mysqli_real_escape_string($conn, $_POST['no_wa']);

    $res_old = mysqli_query($conn, "SELECT nip FROM guru WHERE id=$id LIMIT 1");
    if ($res_old && mysqli_num_rows($res_old) > 0) {
        $old = mysqli_fetch_assoc($res_old);
        $old_nip = $old['nip'];

        $cek_nip = mysqli_query($conn, "SELECT id FROM guru WHERE nip='$nip' AND id != $id LIMIT 1");
        if (mysqli_num_rows($cek_nip) > 0) {
            $_SESSION['swal'] = ['icon' => 'error', 'title' => 'Gagal!', 'text' => 'NIP sudah terdaftar!'];
        } else {
            $result = mysqli_query($conn, "UPDATE guru SET nip='$nip', nama='$nama', mapel='$mapel', no_wa='$no_wa' WHERE id=$id");
            if ($result) {
                mysqli_query($conn, "UPDATE users_guru SET username='$nip', nama='$nama', password=md5('$nip') WHERE username='$old_nip' AND role='guru'");

                if (file_exists('vendor/phpqrcode/qrlib.php')) {
                    require 'vendor/phpqrcode/qrlib.php';
                    $qr_dir = "assets/qr_guru/";
                    if (!is_dir($qr_dir)) mkdir($qr_dir, 0777, true);
                    QRcode::png($nip, $qr_dir . "$nip.png", QR_ECLEVEL_L, 4);
                }

                $_SESSION['swal'] = ['icon' => 'success', 'title' => 'Berhasil!', 'text' => 'Data guru berhasil diupdate!'];
            } else {
                $_SESSION['swal'] = ['icon' => 'error', 'title' => 'Error!', 'text' => mysqli_error($conn)];
            }
        }
    }
    header("Location: guru.php");
    exit;
}

if (isset($_GET['keluar'])) {
    $id = intval($_GET['keluar']);
    $res = mysqli_query($conn, "SELECT nip FROM guru WHERE id=$id LIMIT 1");
    if ($res && mysqli_num_rows($res) > 0) {
        $data = mysqli_fetch_assoc($res);
        $nip_keluar = $data['nip'];

        mysqli_query($conn, "UPDATE guru SET status='keluar' WHERE id=$id");
        mysqli_query($conn, "DELETE FROM users_guru WHERE username='$nip_keluar' AND role='guru'");

        $_SESSION['swal'] = ['icon' => 'success', 'title' => 'Berhasil!', 'text' => 'Data guru berhasil ditandai keluar!'];
    }
    header("Location: guru.php");
    exit;
}

if (isset($_POST['generate_akun'])) {
    $q_guru = mysqli_query($conn, "SELECT nip, nama FROM guru WHERE status='aktif'");
    if ($q_guru) {
        $count = 0;
        while ($g = mysqli_fetch_assoc($q_guru)) {
            $username = $g['nip'];
            $nama     = $g['nama'];
            $password = md5($g['nip']);
            $role     = 'guru';

            $cek = mysqli_query($conn, "SELECT id FROM users_guru WHERE username='$username' LIMIT 1");
            if (mysqli_num_rows($cek) == 0) {
                mysqli_query($conn, "INSERT INTO users_guru (username, nama, password, role) VALUES ('$username', '$nama', '$password', '$role')");
                $count++;
            }
        }
        $_SESSION['swal'] = ['icon' => 'success', 'title' => 'Generate Selesai', 'text' => "$count akun baru berhasil dibuat."];
    }
    header("Location: guru.php");
    exit;
}

$edit_data = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $res = mysqli_query($conn, "SELECT * FROM guru WHERE id=$id LIMIT 1");
    if ($res && mysqli_num_rows($res) > 0) {
        $edit_data = mysqli_fetch_assoc($res);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Guru</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      padding:0;
      margin:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1200px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1200px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      display:flex;
      align-items:flex-end;
      justify-content:space-between;
      gap:20px;
      margin-bottom:22px;
      flex-wrap:wrap;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      padding:24px;
      margin-bottom:20px;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      margin-bottom:18px;
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:15px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .form-label-sm{
      display:block;
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
      margin-bottom:6px;
    }

    .form-control{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
    }

    .form-control::placeholder{
      color:var(--muted-2);
    }

    .form-control:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-warning{
      background:linear-gradient(135deg,#f59e0b,#d97706);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(217,119,6,.7);
    }
    .btn-warning:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-dark{
      background:linear-gradient(135deg,#1e293b,#0f172a);
      color:#fff;
      box-shadow:0 12px 24px -14px rgba(15,23,42,.7);
    }
    .btn-dark:hover{
      filter:brightness(1.15);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-secondary{
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      box-shadow:var(--shadow-sm);
    }
    .btn-secondary:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .btn-outline-danger{
      background:transparent;
      color:var(--danger);
      border:1px solid rgba(239,68,68,.35);
    }
    .btn-outline-danger:hover{
      background:rgba(239,68,68,.06);
      border-color:var(--danger);
      color:var(--danger);
    }

    .btn-info{
      background:linear-gradient(135deg,#3b82f6,#2563eb);
      color:#fff;
      box-shadow:0 10px 20px -10px rgba(37,99,235,.6);
    }
    .btn-info:hover{
      filter:brightness(1.08);
      color:#fff;
      transform:translateY(-1px);
    }

    .btn-sm{
      padding:6px 12px;
      font-size:12.5px;
      border-radius:8px;
    }

    .actions-row{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:20px;
    }

    .actions-row form{
      display:inline-flex;
      margin:0;
    }

    .table-wrapper{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      overflow:hidden;
    }

    .table-responsive{
      max-height:72vh;
      overflow-y:auto;
      overflow-x:auto;
      border:0;
      border-radius:0;
      margin:0;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
    }

    .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
    .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-responsive::-webkit-scrollbar-track{background:transparent;}

    .table{
      margin:0;
      --bs-table-bg:transparent;
      --bs-table-border-color:var(--line);
      --bs-table-striped-bg:transparent;
      --bs-table-hover-bg:rgba(42,82,152,.04);
      font-size:13.5px;
      color:var(--ink-2);
    }

    .table thead th{
      position:sticky;
      top:0;
      z-index:2;
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:14px 16px;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    .table tbody td{
      padding:14px 16px;
      vertical-align:middle;
      border-bottom:1px solid var(--line);
      color:var(--ink-2);
    }

    .table tbody tr{
      transition:background .15s ease;
    }

    .table tbody tr:hover{
      background:rgba(42,82,152,.04);
    }

    .table tbody tr:last-child td{
      border-bottom:0;
    }

    .cell-strong{
      font-weight:600;
      color:var(--ink);
    }

    .badge-nip{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      font-family:'Rubik', monospace;
      background:var(--brand-soft);
      color:var(--brand);
      border-radius:6px;
      letter-spacing:.3px;
    }

    .qr-thumb{
      width:52px;
      height:52px;
      border-radius:8px;
      border:1px solid var(--line);
      object-fit:contain;
      background:#fff;
      padding:2px;
      transition:transform .2s ease, box-shadow .2s ease;
    }

    .qr-thumb:hover{
      transform:scale(1.08);
      box-shadow:var(--shadow-md);
    }

    .barcode-download{
      display:inline-block;
      margin-top:5px;
      font-size:11.5px;
      color:var(--brand);
      text-decoration:none;
      font-weight:500;
      transition:color .2s ease;
    }

    .barcode-download:hover{
      color:var(--brand-2);
      text-decoration:underline;
    }

    .qr-empty{
      display:inline-block;
      font-size:11.5px;
      padding:5px 10px;
      border-radius:6px;
      background:rgba(148,163,184,.12);
      color:var(--muted);
    }

    .action-btns{
      display:inline-flex;
      gap:6px;
      flex-wrap:wrap;
      justify-content:center;
    }

    .empty-state{
      text-align:center;
      padding:52px 20px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:34px;
      opacity:.35;
      margin-bottom:12px;
      display:block;
    }

    .empty-state p{
      font-size:14px;
      margin:0;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .card-panel{padding:20px;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .card-panel{padding:16px;border-radius:var(--radius-md);}
      .actions-row{gap:8px;}
      .actions-row .btn,
      .actions-row form{flex:1 1 auto;}
      .actions-row form .btn{width:100%;}
      .table thead th,
      .table tbody td{padding:11px 12px;font-size:12.5px;}
      .qr-thumb{width:44px;height:44px;}
      .action-btns{flex-direction:column;gap:5px;}
      .action-btns .btn{width:100%;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-chalkboard-teacher"></i></div>
        <div class="brand-titles">
          <h1>Data Guru</h1>
          <span>Manajemen data tenaga pendidik</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <div>
        <span class="page-eyebrow">Manajemen</span>
        <h2><?= isset($edit_data) ? 'Edit Data Guru' : 'Tambah Data Guru' ?></h2>
        <p><?= isset($edit_data) ? 'Perbarui informasi guru yang dipilih.' : 'Lengkapi formulir untuk menambah guru baru.' ?></p>
      </div>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas <?= isset($edit_data) ? 'fa-pen-to-square' : 'fa-user-plus' ?>"></i>
          <?= isset($edit_data) ? 'Form Edit Guru' : 'Form Tambah Guru' ?>
        </div>
      </div>

      <form method="post" class="row g-3">
        <input type="hidden" name="id" value="<?= isset($edit_data['id']) ? $edit_data['id'] : '' ?>">
        <div class="col-12 col-md-3">
          <label class="form-label-sm" for="nip">NIP</label>
          <input type="text" id="nip" name="nip" class="form-control" placeholder="Nomor Induk Pegawai" required value="<?= isset($edit_data['nip']) ? $edit_data['nip'] : '' ?>">
        </div>
        <div class="col-12 col-md-4">
          <label class="form-label-sm" for="nama">Nama Lengkap</label>
          <input type="text" id="nama" name="nama" class="form-control" placeholder="Nama lengkap guru" required value="<?= isset($edit_data['nama']) ? $edit_data['nama'] : '' ?>">
        </div>
        <div class="col-12 col-md-3">
          <label class="form-label-sm" for="mapel">Mata Pelajaran</label>
          <input type="text" id="mapel" name="mapel" class="form-control" placeholder="Mata pelajaran" required value="<?= isset($edit_data['mapel']) ? $edit_data['mapel'] : '' ?>">
        </div>
        <div class="col-12 col-md-2">
          <label class="form-label-sm" for="no_wa">No. WhatsApp</label>
          <input type="text" id="no_wa" name="no_wa" class="form-control" placeholder="08xxxxxxxx" value="<?= isset($edit_data['no_wa']) ? $edit_data['no_wa'] : '' ?>">
        </div>
        <div class="col-12">
          <div class="d-flex gap-2 flex-wrap">
            <?php if (isset($edit_data)): ?>
              <button type="submit" name="update" class="btn btn-warning">
                <i class="fas fa-floppy-disk"></i> Update Data
              </button>
              <a href="guru.php" class="btn btn-secondary">
                <i class="fas fa-xmark"></i> Batal
              </a>
            <?php else: ?>
              <button type="submit" name="simpan" class="btn btn-primary">
                <i class="fas fa-plus"></i> Simpan Data
              </button>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>

    <div class="actions-row">
      <form method="post">
        <button type="submit" name="generate_akun" class="btn btn-dark">
          <i class="fas fa-bolt"></i> Generate Akun Guru
        </button>
      </form>
      <a href="cetak_kartu_guru.php" class="btn btn-success" target="_blank">
        <i class="fas fa-print"></i> Cetak Semua Kartu Guru
      </a>
      <a href="guru_keluar.php" class="btn btn-outline-danger">
        <i class="fas fa-user-slash"></i> Lihat Guru Keluar
      </a>
      <a href="import_guru.php" class="btn btn-success">
        <i class="fas fa-file-import"></i> Import dari Excel
      </a>
    </div>

    <div class="table-wrapper">
      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th>NIP</th>
              <th>Nama</th>
              <th>Mata Pelajaran</th>
              <th>No. WhatsApp</th>
              <th class="text-center">QR Code</th>
              <th class="text-center">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $q = mysqli_query($conn, "SELECT * FROM guru WHERE status='aktif' ORDER BY nama ASC");
            if ($q && mysqli_num_rows($q) > 0) {
              while ($row = mysqli_fetch_assoc($q)) {
                $qr_file = "assets/qr_guru/{$row['nip']}.png";
                echo "<tr>
                  <td><span class='badge-nip'>" . htmlspecialchars($row['nip']) . "</span></td>
                  <td class='cell-strong'>" . htmlspecialchars($row['nama']) . "</td>
                  <td>" . htmlspecialchars($row['mapel']) . "</td>
                  <td>" . htmlspecialchars($row['no_wa']) . "</td>
                  <td class='text-center'>";

                if (file_exists($qr_file)) {
                  echo "<a href='$qr_file' target='_blank'>
                    <img src='$qr_file' class='qr-thumb' alt='QR {$row['nip']}'>
                  </a>
                  <a href='$qr_file' download='barcode_guru_{$row['nip']}.png' class='barcode-download'>
                    <i class='fas fa-download'></i> Download
                  </a>";
                } else {
                  echo "<span class='qr-empty'>QR belum dibuat</span>";
                }

                echo "</td>
                  <td class='text-center'>
                    <div class='action-btns'>
                      <a href='guru.php?edit={$row['id']}' class='btn btn-info btn-sm'>
                        <i class='fas fa-pen'></i> Edit
                      </a>
                      <a href='guru.php?keluar={$row['id']}' class='btn btn-warning btn-sm' onclick='return confirm(\"Yakin guru ini keluar?\")'>
                        <i class='fas fa-right-from-bracket'></i> Keluar
                      </a>
                    </div>
                  </td>
                </tr>";
              }
            } else {
              echo "<tr><td colspan='6'>
                <div class='empty-state'>
                  <i class='fas fa-inbox'></i>
                  <p>Belum ada data guru. Silakan tambahkan guru baru.</p>
                </div>
              </td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <?php if (isset($_SESSION['swal'])): ?>
    <script>
      Swal.fire({
        icon: '<?= $_SESSION['swal']['icon']; ?>',
        title: '<?= $_SESSION['swal']['title']; ?>',
        text: '<?= $_SESSION['swal']['text']; ?>',
        confirmButtonColor: '#2a5298'
      });
    </script>
    <?php unset($_SESSION['swal']); ?>
  <?php endif; ?>

</body>
</html>