<?php

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

include 'config.php';

if (isset($_GET['aktifkan'])) {
    $id = intval($_GET['aktifkan']);
    mysqli_query($conn, "UPDATE guru SET status='aktif' WHERE id=$id");
    header("Location: guru_keluar.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $res = mysqli_query($conn, "SELECT nip FROM guru WHERE id=$id LIMIT 1");
    if ($res && mysqli_num_rows($res) > 0) {
        $data = mysqli_fetch_assoc($res);
        $nip = $data['nip'];
        if (file_exists("assets/qr_guru/$nip.png")) {
            @unlink("assets/qr_guru/$nip.png");
        }
        mysqli_query($conn, "DELETE FROM guru WHERE id=$id");
    }
    header("Location: guru_keluar.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Guru Keluar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1200px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg,#ef4444,#dc2626);
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:0 14px 30px -14px rgba(220,38,38,.55);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1200px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--danger);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .info-banner{
      display:flex;
      align-items:flex-start;
      gap:12px;
      padding:14px 18px;
      border-radius:var(--radius-md);
      background:rgba(239,68,68,.07);
      border:1px solid rgba(239,68,68,.2);
      border-left:4px solid var(--danger);
      color:#b91c1c;
      font-size:13px;
      line-height:1.6;
      margin-bottom:20px;
    }

    .info-banner i{
      margin-top:2px;
      font-size:15px;
      flex-shrink:0;
    }

    .info-banner strong{
      font-weight:600;
      color:#991b1b;
    }

    .stats-row{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:20px;
    }

    .stat-chip{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:8px 14px;
      font-size:12.5px;
      font-weight:500;
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:999px;
      color:var(--ink-2);
      box-shadow:var(--shadow-sm);
    }

    .stat-chip i{
      color:var(--danger);
      font-size:12px;
    }

    .stat-chip strong{
      color:var(--ink);
      font-weight:600;
    }

    .table-wrapper{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      overflow:hidden;
    }

    .table-responsive{
      max-height:72vh;
      overflow-y:auto;
      overflow-x:auto;
      margin:0;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
    }

    .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
    .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-responsive::-webkit-scrollbar-track{background:transparent;}

    .table{
      margin:0;
      --bs-table-bg:transparent;
      --bs-table-border-color:var(--line);
      --bs-table-hover-bg:rgba(42,82,152,.04);
      font-size:13.5px;
      color:var(--ink-2);
      width:100%;
    }

    .table thead th{
      position:sticky;
      top:0;
      z-index:2;
      background:rgba(239,68,68,.06);
      color:#b91c1c;
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:14px 16px;
      border-bottom:1px solid rgba(239,68,68,.15);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    .table tbody td{
      padding:14px 16px;
      vertical-align:middle;
      border-bottom:1px solid var(--line);
      color:var(--ink-2);
    }

    .table tbody tr{
      transition:background .15s ease;
    }

    .table tbody tr:hover{
      background:rgba(42,82,152,.04);
    }

    .table tbody tr:last-child td{
      border-bottom:0;
    }

    .cell-strong{
      font-weight:600;
      color:var(--ink);
    }

    .badge-nip{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:var(--brand-soft);
      color:var(--brand);
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-mapel{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(139,92,246,.1);
      color:#6d28d9;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-keluar{
      display:inline-flex;
      align-items:center;
      gap:5px;
      padding:5px 11px;
      font-size:12px;
      font-weight:500;
      border-radius:999px;
      background:rgba(239,68,68,.1);
      color:#b91c1c;
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 10px 22px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-danger{
      background:linear-gradient(135deg,#ef4444,#dc2626);
      color:#fff;
      box-shadow:0 10px 22px -12px rgba(220,38,38,.7);
    }
    .btn-danger:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-sm{
      padding:6px 12px;
      font-size:12.5px;
      border-radius:8px;
    }

    .action-btns{
      display:inline-flex;
      gap:6px;
      flex-wrap:wrap;
      justify-content:center;
    }

    .empty-state{
      text-align:center;
      padding:56px 24px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:38px;
      opacity:.35;
      margin-bottom:14px;
      display:block;
      color:var(--danger);
    }

    .empty-state h4{
      font-size:15.5px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 6px;
    }

    .empty-state p{
      font-size:13.5px;
      margin:0;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .table thead th,
      .table tbody td{padding:11px 12px;font-size:12.5px;}
      .action-btns{flex-direction:column;gap:5px;}
      .action-btns .btn{width:100%;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-user-slash"></i></div>
        <div class="brand-titles">
          <h1>Data Guru Keluar</h1>
          <span>Riwayat guru non-aktif</span>
        </div>
      </div>
      <a href="guru.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali ke Data Guru Aktif</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Arsip</span>
      <h2>Riwayat Data Guru Keluar</h2>
      <p>Daftar guru yang telah ditandai keluar. Anda dapat mengaktifkan kembali atau menghapus permanen data ini.</p>
    </div>

    <div class="info-banner">
      <i class="fas fa-triangle-exclamation"></i>
      <div>
        <strong>Perhatian:</strong> Menghapus data guru secara permanen akan menghapus file QR code terkait dan tidak dapat dikembalikan.
      </div>
    </div>

    <div class="table-wrapper">
      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th>NIP</th>
              <th>Nama</th>
              <th>Mata Pelajaran</th>
              <th>No. WhatsApp</th>
              <th class="text-center">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $check_status = mysqli_query($conn, "SHOW COLUMNS FROM guru LIKE 'status'");
            if (mysqli_num_rows($check_status) == 0) {
                mysqli_query($conn, "ALTER TABLE guru ADD status ENUM('aktif','keluar') DEFAULT 'aktif'");
            }

            $q = mysqli_query($conn, "SELECT * FROM guru WHERE status='keluar' ORDER BY nama ASC");
            if (mysqli_num_rows($q) > 0) {
                $total = mysqli_num_rows($q);
                while ($row = mysqli_fetch_assoc($q)) {
                  $no_wa = $row['no_wa'] ?? ($row['whatsapp'] ?? '-');
                  echo "<tr>
                    <td><span class='badge-nip'>" . htmlspecialchars($row['nip']) . "</span></td>
                    <td class='cell-strong'>" . htmlspecialchars($row['nama']) . "</td>
                    <td><span class='badge-mapel'>" . htmlspecialchars($row['mapel']) . "</span></td>
                    <td>" . htmlspecialchars($no_wa) . "</td>
                    <td class='text-center'>
                      <div class='action-btns'>
                        <a href='guru_keluar.php?aktifkan={$row['id']}' class='btn btn-success btn-sm' onclick='return confirm(\"Kembalikan guru ini menjadi aktif?\")'>
                          <i class='fas fa-rotate-left'></i> Aktifkan Kembali
                        </a>
                        <a href='guru_keluar.php?hapus={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Hapus permanen data guru ini?\")'>
                          <i class='fas fa-trash'></i> Hapus Permanen
                        </a>
                      </div>
                    </td>
                  </tr>";
                }
                echo "<script>window.__totalGuruKeluar = " . (int)$total . ";</script>";
            } else {
                echo "<tr><td colspan='5'>
                  <div class='empty-state'>
                    <i class='fas fa-inbox'></i>
                    <h4>Tidak ada data guru keluar</h4>
                    <p>Semua guru saat ini berstatus aktif.</p>
                  </div>
                </td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php
    $qCount = mysqli_query($conn, "SELECT COUNT(*) AS total FROM guru WHERE status='keluar'");
    $countRow = $qCount ? mysqli_fetch_assoc($qCount) : ['total' => 0];
    $totalKeluar = (int)$countRow['total'];
    ?>
    <div class="stats-row" style="margin-top:20px;">
      <span class="stat-chip">
        <i class="fas fa-user-slash"></i> Total Guru Keluar: <strong><?= $totalKeluar ?></strong>
      </span>
    </div>

  </div>

</body>
</html>