<?php

ini_set('display_errors', 0);
error_reporting(E_ALL);

session_start();

if (isset($_GET['download_template'])) {
    $file_template = "template/template_siswa.xlsx";
    if (file_exists($file_template)) {
        if (ob_get_level()) { ob_end_clean(); }
        header('Content-Description: File Transfer');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . basename($file_template) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_template));
        readfile($file_template);
        exit;
    } else {
        $_SESSION['msg'] = "<div class='alert alert-danger'><i class='fas fa-times-circle'></i> File template <b>template_siswa.xlsx</b> belum tersedia di folder <code>template/</code>. Hubungi developer.</div>";
        header("Location: import_siswa_2.php");
        exit;
    }
}

if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

if (file_exists('vendor/phpqrcode/qrlib.php')) {
    require 'vendor/phpqrcode/qrlib.php';
}

$msg = "";
$errors = [];

function colLetterToIndex($col) {
    $col = strtoupper($col);
    $len = strlen($col);
    $index = 0;
    for ($i = 0; $i < $len; $i++) {
        $index = $index * 26 + (ord($col[$i]) - ord('A') + 1);
    }
    return $index - 1;
}

function baca_xlsx($filename) {
    $rows = [];
    try {
        $zip = new ZipArchive();
        if ($zip->open($filename) === TRUE) {
            $sharedStrings = [];
            if (($index = $zip->locateName('xl/sharedStrings.xml')) !== false) {
                $xmlContent = $zip->getFromIndex($index);
                if ($xmlContent) {
                    $xml = @simplexml_load_string($xmlContent);
                    if ($xml && isset($xml->si)) {
                        foreach ($xml->si as $si) {
                            if (isset($si->t)) {
                                $sharedStrings[] = (string)$si->t;
                            } elseif (isset($si->r)) {
                                $str = '';
                                foreach ($si->r as $r) { $str .= (string)$r->t; }
                                $sharedStrings[] = $str;
                            } else {
                                $sharedStrings[] = '';
                            }
                        }
                    }
                }
            }
            if (($index = $zip->locateName('xl/worksheets/sheet1.xml')) !== false) {
                $xmlContent = $zip->getFromIndex($index);
                if ($xmlContent) {
                    $xml = @simplexml_load_string($xmlContent);
                    if ($xml && isset($xml->sheetData->row)) {
                        foreach ($xml->sheetData->row as $row) {
                            $rowData = [];
                            if (isset($row->c)) {
                                foreach ($row->c as $c) {
                                    $ref = (string)$c['r'];
                                    preg_match('/^([A-Z]+)/', $ref, $m);
                                    $colIdx = isset($m[1]) ? colLetterToIndex($m[1]) : count($rowData);
                                    $val = "";
                                    $t = isset($c['t']) ? (string)$c['t'] : "";
                                    if ($t === 'inlineStr' && isset($c->is->t)) {
                                        $val = (string)$c->is->t;
                                    } elseif (isset($c->v)) {
                                        $v = (string)$c->v;
                                        $val = ($t === 's') ? ($sharedStrings[intval($v)] ?? '') : $v;
                                    }
                                    $rowData[$colIdx] = trim($val);
                                }
                            }
                            if (!empty($rowData)) {
                                $maxIdx = max(array_keys($rowData));
                                $normalized = [];
                                for ($i = 0; $i <= $maxIdx; $i++) { $normalized[] = $rowData[$i] ?? ''; }
                                $rows[] = $normalized;
                            }
                        }
                    }
                }
            }
            $zip->close();
        }
    } catch (Exception $e) {}
    return $rows;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['import'])) {
    $berhasil = 0;
    $gagal = 0;
    $errors = [];

    if (!empty($_FILES['file_excel']['tmp_name'])) {
        $inputFileName = $_FILES['file_excel']['tmp_name'];
        $ext = strtolower(pathinfo($_FILES['file_excel']['name'], PATHINFO_EXTENSION));

        $data_rows = [];
        if ($ext == 'xlsx') {
            $data_rows = baca_xlsx($inputFileName);
        } else if ($ext == 'csv') {
            if (($handle = fopen($inputFileName, "r")) !== FALSE) {
                while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
                    if (count($data) == 1 && strpos($data[0], ';') !== false) {
                        $data = explode(';', $data[0]);
                    }
                    $data_rows[] = $data;
                }
                fclose($handle);
            }
        }

        if (!empty($data_rows)) {
            $row_idx = 0;
            foreach ($data_rows as $data) {
                $row_idx++;
                if ($row_idx == 1) continue;

                $nis   = trim($data[0] ?? '');
                $nisn  = trim($data[1] ?? '');
                $nama  = trim($data[2] ?? '');
                $kelas = trim($data[3] ?? '');
                $no_wa = trim($data[4] ?? '');

                if ($nis != "" && $nisn != "" && $nama != "" && $kelas != "") {
                    if (!preg_match('/^[0-9]{4}$/', $nis)) {
                        $gagal++;
                        $errors[] = "Baris $row_idx: NIS ($nis) harus 4 digit angka.";
                        continue;
                    }

                    $nis   = mysqli_real_escape_string($conn, $nis);
                    $nisn  = mysqli_real_escape_string($conn, $nisn);
                    $nama  = mysqli_real_escape_string($conn, $nama);
                    $kelas = mysqli_real_escape_string($conn, $kelas);
                    $no_wa = mysqli_real_escape_string($conn, $no_wa);

                    $sql = "INSERT INTO siswa (nis, nisn, nama, kelas, no_wa, status) 
                            VALUES ('$nis','$nisn','$nama','$kelas','$no_wa','aktif') 
                            ON DUPLICATE KEY UPDATE nama='$nama', kelas='$kelas', no_wa='$no_wa', status='aktif'";

                    if (mysqli_query($conn, $sql)) {
                        $berhasil++;
                        $qr_dir = "assets/qr/";
                        if (!is_dir($qr_dir)) mkdir($qr_dir, 0777, true);
                        if (class_exists('QRcode')) {
                            @QRcode::png($nisn, $qr_dir . "$nisn.png", QR_ECLEVEL_L, 4);
                        }
                    } else {
                        $gagal++;
                        $errors[] = "Baris $row_idx: Gagal disimpan ke database (" . mysqli_error($conn) . ").";
                    }
                } else {
                    if (!empty(array_filter($data))) {
                        $gagal++;
                        $errors[] = "Baris $row_idx: Kolom data tidak lengkap.";
                    }
                }
            }

            if ($berhasil > 0 && $gagal === 0) {
                $_SESSION['msg'] = "<div class='alert alert-success'><i class='fas fa-check-circle'></i> Import berhasil! <b>$berhasil</b> data siswa ditambahkan.</div>";
            } elseif ($berhasil > 0 && $gagal > 0) {
                $_SESSION['msg'] = "<div class='alert alert-warning'><i class='fas fa-exclamation-triangle'></i> Import selesai dengan catatan. Berhasil: <b>$berhasil</b>, Gagal: <b>$gagal</b>.</div>";
            } else {
                $_SESSION['msg'] = "<div class='alert alert-danger'><i class='fas fa-times-circle'></i> Import gagal total. Tidak ada data yang tersimpan. Periksa detail error di bawah.</div>";
            }
            $_SESSION['errors'] = $errors;
        } else {
            $_SESSION['msg'] = "<div class='alert alert-danger'><i class='fas fa-times-circle'></i> Gagal membaca file Excel. Pastikan file berformat .xlsx valid dan tidak kosong.</div>";
        }
    } else {
        $_SESSION['msg'] = "<div class='alert alert-danger'><i class='fas fa-times-circle'></i> Harap pilih file terlebih dahulu.</div>";
    }

    header("Location: import_siswa_2.php");
    exit;
}

$msg = $_SESSION['msg'] ?? "";
$errors = $_SESSION['errors'] ?? [];
unset($_SESSION['msg'], $_SESSION['errors']);
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Import Data Siswa</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;--surface:#ffffff;--surface-2:#f9fafb;--line:#e8edf3;--line-strong:#dbe3ec;
      --ink:#0f172a;--ink-2:#334155;--muted:#64748b;--muted-2:#94a3b8;
      --brand:#2a5298;--brand-2:#1e3c72;--brand-soft:rgba(42,82,152,.08);--accent:#ffb020;
      --success:#10b981;--warning:#f59e0b;--danger:#ef4444;--info:#3b82f6;
      --radius-lg:16px;--radius-md:12px;--radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }
    *{box-sizing:border-box;}
    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background: radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%), radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%), var(--bg);
      min-height:100vh;color:var(--ink);margin:0;padding:0;-webkit-font-smoothing:antialiased;
    }
    .topbar{background:rgba(255,255,255,.88);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-bottom:1px solid var(--line);position:sticky;top:0;z-index:100;padding:14px 0;}
    .topbar-inner{max-width:900px;margin:0 auto;padding:0 24px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;}
    .brand-block{display:flex;align-items:center;gap:14px;min-width:0;}
    .brand-mark{width:44px;height:44px;border-radius:var(--radius-md);background:linear-gradient(135deg, var(--brand), var(--brand-2));color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:var(--shadow-brand);flex-shrink:0;}
    .brand-titles h1{font-size:17px;font-weight:600;letter-spacing:-.2px;color:var(--ink);margin:0;line-height:1.25;}
    .brand-titles span{display:block;font-size:12.5px;color:var(--muted);margin-top:2px;}
    .btn-back{display:inline-flex;align-items:center;gap:8px;padding:9px 16px;font-size:13.5px;font-weight:500;color:var(--ink-2);background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-sm);text-decoration:none;transition:border-color .2s ease, background .2s ease, transform .2s ease;box-shadow:var(--shadow-sm);}
    .btn-back:hover{background:var(--surface-2);border-color:var(--line-strong);color:var(--ink);transform:translateX(-2px);}
    .page-wrap{max-width:900px;margin:0 auto;padding:32px 24px 60px;}
    .page-head{margin-bottom:22px;}
    .page-eyebrow{font-size:11.5px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;color:var(--brand);display:block;margin-bottom:6px;}
    .page-head h2{font-size:24px;font-weight:600;letter-spacing:-.4px;color:var(--ink);margin:0;}
    .page-head p{font-size:13.5px;color:var(--muted);margin:6px 0 0;}
    .card-panel{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);padding:28px;margin-bottom:20px;transition:box-shadow .25s ease;}
    .card-panel:hover{box-shadow:var(--shadow-md);}
    .card-panel-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:20px;flex-wrap:wrap;}
    .card-panel-title{display:flex;align-items:center;gap:10px;font-size:15px;font-weight:600;color:var(--ink);}
    .card-panel-title i{width:32px;height:32px;border-radius:var(--radius-sm);background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;font-size:14px;}
    .form-label{display:block;font-size:13px;font-weight:500;color:var(--ink-2);margin-bottom:8px;}
    .form-control{font-family:inherit;font-size:14px;color:var(--ink);background:var(--surface-2);border:1px solid var(--line);border-radius:var(--radius-sm);padding:12px 14px;transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;box-shadow:none;width:100%;}
    .form-control::file-selector-button{font-family:inherit;font-size:13px;font-weight:500;background:var(--surface);color:var(--ink-2);border:1px solid var(--line);border-radius:8px;padding:8px 14px;margin-right:14px;cursor:pointer;transition:background .2s ease, border-color .2s ease, color .2s ease;}
    .form-control::file-selector-button:hover{background:var(--brand-soft);border-color:var(--brand);color:var(--brand);}
    .form-control:hover{border-color:var(--line-strong);}
    .form-control:focus{background:#fff;border-color:var(--brand);box-shadow:0 0 0 4px var(--brand-soft);outline:none;}
    .form-text{display:block;margin-top:10px;font-size:12.5px;color:var(--muted);line-height:1.6;}
    .form-text a{color:var(--brand);text-decoration:none;font-weight:600;display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:8px;background:var(--brand-soft);transition:background .2s ease, color .2s ease;margin-top:4px;}
    .form-text a:hover{background:rgba(42,82,152,.15);color:var(--brand-2);}
    .btn{font-family:inherit;font-size:14px;font-weight:500;border-radius:var(--radius-sm);padding:12px 18px;transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;cursor:pointer;line-height:1.2;text-decoration:none;}
    .btn:active{transform:translateY(1px);}
    .btn-success{background:linear-gradient(135deg,#10b981,#059669);color:#fff;box-shadow:0 14px 30px -14px rgba(5,150,105,.7);width:100%;}
    .btn-success:hover{filter:brightness(1.08);transform:translateY(-1px);color:#fff;}
    .alert{padding:14px 18px;border-radius:var(--radius-md);font-size:13.5px;font-weight:500;border:1px solid transparent;margin-bottom:20px;display:flex;align-items:flex-start;gap:10px;line-height:1.55;}
    .alert i{margin-top:2px;flex-shrink:0;}
    .alert-success{background:rgba(16,185,129,.08);color:#047857;border-color:rgba(16,185,129,.28);}
    .alert-warning{background:rgba(245,158,11,.08);color:#b45309;border-color:rgba(245,158,11,.3);}
    .alert-danger{background:rgba(239,68,68,.08);color:#b91c1c;border-color:rgba(239,68,68,.28);}
    .errors-panel{margin-top:20px;border:1px solid rgba(239,68,68,.28);border-radius:var(--radius-md);overflow:hidden;background:var(--surface);}
    .errors-head{display:flex;align-items:center;gap:10px;padding:12px 16px;background:rgba(239,68,68,.07);color:#b91c1c;font-size:13px;font-weight:600;border-bottom:1px solid rgba(239,68,68,.2);}
    .errors-body{max-height:240px;overflow-y:auto;padding:12px 20px;scrollbar-width:thin;scrollbar-color:#cbd5e1 transparent;}
    .errors-body::-webkit-scrollbar{width:6px;}
    .errors-body::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .errors-body ul{margin:0;padding:0;list-style:none;}
    .errors-body li{font-size:13px;color:var(--ink-2);line-height:1.6;padding:7px 0;border-bottom:1px dashed var(--line);}
    .errors-body li:last-child{border-bottom:0;}
    .format-hint{margin-top:24px;padding-top:22px;border-top:1px solid var(--line);display:flex;gap:14px;align-items:flex-start;}
    .format-hint i{width:36px;height:36px;border-radius:var(--radius-sm);background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;}
    .format-hint-text{font-size:13px;color:var(--muted);line-height:1.65;}
    .format-hint-text strong{color:var(--ink-2);font-weight:600;}
    .format-hint-text b{display:inline-block;padding:2px 8px;font-size:12px;font-weight:500;background:var(--surface-2);border:1px solid var(--line);border-radius:6px;color:var(--ink-2);margin:2px 2px;font-family:'Rubik', monospace;}
    @media (max-width:640px){
      .topbar{padding:12px 0;}.topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}.brand-titles h1{font-size:15px;}.brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}.btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}.page-head h2{font-size:19px;}.page-head p{font-size:12.5px;}
      .card-panel{padding:20px;border-radius:var(--radius-md);}.card-panel-title{font-size:14px;}
      .form-control{padding:11px 12px;font-size:13.5px;}.btn{padding:11px 16px;font-size:13.5px;}
    }
    @media (prefers-reduced-motion:reduce){*{animation:none !important;transition:none !important;}}
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-file-import"></i></div>
        <div class="brand-titles">
          <h1>Import Data Siswa</h1>
          <span>Unggah data siswa dari file Excel</span>
        </div>
      </div>
      <a href="siswa_2.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">
    <div class="page-head">
      <span class="page-eyebrow">Manajemen Data</span>
      <h2>Import Data Siswa</h2>
      <p>Unggah file Excel (.xlsx) untuk menambahkan atau memperbarui data siswa secara massal.</p>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-cloud-arrow-up"></i>
          Unggah File Excel
        </div>
      </div>

      <?= $msg; ?>

      <form method="post" enctype="multipart/form-data" autocomplete="off">
        <div class="mb-3">
          <label class="form-label" for="file_excel">Pilih File Excel (.xlsx)</label>
          <input type="file" id="file_excel" name="file_excel" accept=".xlsx" class="form-control" required>
          <span class="form-text">
            Belum punya template? <a href="?download_template=1"><i class="fas fa-download"></i> Unduh Template Excel (.xlsx)</a>
          </span>
        </div>

        <div class="d-grid">
          <button type="submit" name="import" class="btn btn-success">
            <i class="fas fa-file-import"></i> Import Data
          </button>
        </div>
      </form>

      <?php if (!empty($errors)): ?>
        <div class="errors-panel">
          <div class="errors-head">
            <i class="fas fa-circle-exclamation"></i>
            Detail Error / Gagal (<?= count($errors); ?>)
          </div>
          <div class="errors-body">
            <ul>
              <?php foreach ($errors as $err) { echo "<li>" . htmlspecialchars($err) . "</li>"; } ?>
            </ul>
          </div>
        </div>
      <?php endif; ?>

      <div class="format-hint">
        <i class="fas fa-circle-info"></i>
        <div class="format-hint-text">
          <strong>Format urutan kolom:</strong><br>
          <b>NIS</b> <b>NISN</b> <b>Nama</b> <b>Kelas</b> <b>Nomor WhatsApp</b><br>
          Pastikan NIS terdiri dari 4 digit angka. Kolom WhatsApp opsional dengan format <b>6285xxxx</b> atau <b>08xx</b>.
        </div>
      </div>
    </div>
  </div>

</body>
</html>