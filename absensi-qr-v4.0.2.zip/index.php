<?php

if (file_exists(__DIR__ . "/maintenance.flag")) {
    die("<h1>Sedang update, silakan coba beberapa menit lagi...</h1>");
}
include "config.php";
session_start();

$profil = mysqli_fetch_assoc(mysqli_query($conn, "SELECT nama_sekolah, logo FROM profil_sekolah LIMIT 1"));
$nama_sekolah = $profil['nama_sekolah'] ?? 'Nama Sekolah';
$logo = $profil['logo'] ?? 'default.png';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Absensi</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --accent-dark:#d97706;
      --radius-xl:24px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 30px 60px -22px rgba(15,23,42,.28), 0 10px 24px -16px rgba(15,23,42,.18);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    html,body{margin:0;padding:0;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      min-height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      padding:28px;
      color:var(--ink);
      background-color:#eef2f9;
      background-image:
        radial-gradient(circle at 10% 15%, rgba(42,82,152,.20), transparent 45%),
        radial-gradient(circle at 90% 85%, rgba(255,176,32,.18), transparent 45%),
        radial-gradient(circle at 75% 5%, rgba(30,60,114,.14), transparent 40%);
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .auth-shell{
      width:100%;
      max-width:1000px;
      display:grid;
      grid-template-columns:1.05fr 1fr;
      background:#fff;
      border:1px solid rgba(15,23,42,.06);
      border-radius:var(--radius-xl);
      overflow:hidden;
      box-shadow:var(--shadow-lg);
      animation:fadeIn .6s ease both;
    }

    .brand-panel{
      position:relative;
      display:flex;
      flex-direction:column;
      gap:26px;
      padding:46px 42px;
      color:#fff;
      overflow:hidden;
      background:linear-gradient(150deg,#1e3c72 0%, #2a5298 55%, #3563ad 100%);
    }

    .brand-panel::before{
      content:"";
      position:absolute;
      top:-130px;
      right:-110px;
      width:320px;
      height:320px;
      border-radius:50%;
      background:radial-gradient(circle, rgba(255,255,255,.18), transparent 65%);
      pointer-events:none;
    }

    .brand-panel::after{
      content:"";
      position:absolute;
      bottom:-140px;
      left:-120px;
      width:300px;
      height:300px;
      border-radius:50%;
      background:radial-gradient(circle, rgba(255,176,32,.28), transparent 65%);
      pointer-events:none;
    }

    .brand-top{
      position:relative;
      z-index:1;
      display:flex;
      align-items:center;
      gap:14px;
    }

    .brand-logo{
      width:64px;
      height:64px;
      min-width:64px;
      min-height:64px;
      border-radius:50%;
      object-fit:cover;
      object-position:center;
      padding:0;
      margin:0;
      background:transparent;
      border:0;
      box-shadow:0 10px 22px -10px rgba(0,0,0,.55);
      flex-shrink:0;
      display:block;
    }

    .brand-name{
      margin:0;
      font-size:17px;
      font-weight:600;
      line-height:1.35;
      letter-spacing:.2px;
      text-shadow:0 2px 6px rgba(0,0,0,.18);
    }

    .brand-copy{
      position:relative;
      z-index:1;
    }

    .pill{
      display:inline-block;
      padding:6px 13px;
      border-radius:999px;
      font-size:11.5px;
      font-weight:500;
      letter-spacing:.8px;
      text-transform:uppercase;
      color:rgba(255,255,255,.92);
      background:rgba(255,255,255,.14);
      border:1px solid rgba(255,255,255,.24);
    }

    .brand-copy h2{
      margin:18px 0 10px;
      font-size:26px;
      font-weight:600;
      line-height:1.32;
      letter-spacing:-.2px;
    }

    .brand-copy p{
      margin:0;
      font-size:14px;
      line-height:1.75;
      color:rgba(255,255,255,.82);
      max-width:38ch;
    }

    .info-box{
      position:relative;
      z-index:1;
      margin-top:auto;
      padding:14px 16px;
      font-size:13px;
      line-height:1.7;
      color:rgba(255,255,255,.94);
      background:rgba(255,255,255,.12);
      border:1px solid rgba(255,255,255,.18);
      border-left:4px solid var(--accent);
      border-radius:var(--radius-lg);
      backdrop-filter:blur(6px);
    }

    .info-box strong{
      font-weight:600;
      color:#fff;
    }

    .form-panel{
      display:flex;
      flex-direction:column;
      justify-content:center;
      padding:46px 42px;
      background:#fff;
    }

    .form-header h2{
      margin:0 0 8px;
      font-size:22px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
    }

    .form-header p{
      margin:0 0 28px;
      font-size:14px;
      line-height:1.6;
      color:var(--muted);
    }

    .field{
      margin-bottom:16px;
    }

    .field label{
      display:block;
      margin-bottom:7px;
      font-size:13px;
      font-weight:500;
      color:#334155;
    }

    input[type="text"],
    input[type="password"]{
      width:100%;
      padding:13px 15px;
      font-family:inherit;
      font-size:15px;
      color:var(--ink);
      background:#f8fafc;
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      outline:none;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
    }

    input::placeholder{
      color:#94a3b8;
    }

    input[type="text"]:hover,
    input[type="password"]:hover{
      border-color:#cbd5e1;
    }

    input[type="text"]:focus,
    input[type="password"]:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px rgba(42,82,152,.13);
    }

    button{
      width:100%;
      margin-top:8px;
      padding:14px;
      font-family:inherit;
      font-size:15px;
      font-weight:600;
      letter-spacing:.2px;
      color:#fff;
      cursor:pointer;
      border:none;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, #2a5298, #1e3c72);
      box-shadow:0 14px 26px -14px rgba(30,60,114,.85);
      transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
    }

    button:hover{
      transform:translateY(-2px);
      filter:brightness(1.08);
      box-shadow:0 20px 32px -16px rgba(30,60,114,.9);
    }

    button:active{
      transform:translateY(0);
    }

    button:focus-visible{
      outline:3px solid rgba(42,82,152,.35);
      outline-offset:2px;
    }

    .footer-links{
      margin-top:28px;
      padding-top:20px;
      text-align:center;
      font-size:13.5px;
      color:#94a3b8;
      border-top:1px solid #eef2f7;
    }

    .footer-links a{
      display:inline-block;
      margin:0 10px;
      font-weight:500;
      color:var(--brand);
      text-decoration:none;
      transition:color .2s ease;
    }

    .footer-links a:hover{
      color:var(--brand-2);
      text-decoration:underline;
    }

    .footer-links a:focus-visible{
      outline:2px solid rgba(42,82,152,.45);
      outline-offset:3px;
      border-radius:6px;
    }

    .app-version{
      margin-top:10px;
      font-size:12px;
      letter-spacing:.3px;
      color:#a3aec0;
    }

    @keyframes fadeIn{
      from{opacity:0; transform:translateY(-14px);}
      to{opacity:1; transform:translateY(0);}
    }

    @media (max-width:900px){
      body{padding:20px;}
      .auth-shell{
        grid-template-columns:1fr;
        max-width:520px;
        border-radius:22px;
      }
      .brand-panel{
        gap:18px;
        padding:32px 28px;
      }
      .brand-copy h2{font-size:21px;}
      .brand-copy p{font-size:13px;}
      .info-box{margin-top:0;}
      .form-panel{padding:32px 28px;}
    }

    @media (max-width:480px){
      body{padding:12px;}
      .auth-shell{border-radius:18px;}
      .brand-panel{padding:24px 20px;}
      .brand-logo{
        width:54px;
        height:54px;
        min-width:54px;
        min-height:54px;
      }
      .brand-name{font-size:15px;}
      .brand-copy h2{font-size:18px; margin:14px 0 8px;}
      .brand-copy p{font-size:12.5px;}
      .info-box{font-size:12.5px; padding:12px 14px;}
      .form-panel{padding:26px 20px;}
      .form-header h2{font-size:19px;}
      .form-header p{font-size:13px; margin-bottom:22px;}
      input[type="text"],
      input[type="password"]{font-size:16px; padding:12px 14px;}
      button{padding:13px; font-size:15px;}
      .footer-links{margin-top:22px; padding-top:16px; font-size:13px;}
      .footer-links a{margin:0 8px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important; transition:none !important;}
    }
  </style>
</head>
<body>
  <div class="auth-shell">
    <aside class="brand-panel">
      <div class="brand-top">
        <img class="brand-logo" src="uploads/<?php echo htmlspecialchars($logo); ?>" alt="Logo Sekolah">
        <h1 class="brand-name"><?php echo htmlspecialchars($nama_sekolah); ?></h1>
      </div>

      <div class="brand-copy">
        <span class="pill">Sistem Absensi</span>
        <h2>Kelola kehadiran sekolah dengan cepat dan akurat.</h2>
        <p>Satu platform terpadu untuk administrasi absensi harian yang rapi, transparan, dan mudah dipantau.</p>
      </div>

      <div class="info-box">
        📌 <strong>Fokus Aplikasi:</strong> Mempercepat dan mempermudah pekerjaan <strong>Tenaga Administrasi</strong>, serta mendukung <strong>Tupoksi Wali Kelas</strong>.
      </div>
    </aside>

    <main class="form-panel">
      <div class="form-header">
        <h2>🔑 Login Sistem Absensi</h2>
        <p>Masuk menggunakan akun Anda untuk melanjutkan.</p>
      </div>

      <form method="post" action="cek.php">
        <div class="field">
          <label for="username">Username / NISN / NIP</label>
          <input id="username" type="text" name="username" placeholder="Masukkan username, NISN, atau NIP" required>
        </div>

        <div class="field">
          <label for="password">Password</label>
          <input id="password" type="password" name="password" placeholder="Masukkan password" required>
        </div>

        <button type="submit">Masuk</button>
      </form>

      <div class="footer-links">
        <a href="tentang.html">Tentang</a>
        <a href="kontak.php">Kontak</a>
        <a href="unduh.php">Unduh</a>
        <div class="app-version">Versi Aplikasi 2026</div>
      </div>
    </main>
  </div>

  <?php if (isset($_SESSION['login_error'])): ?>
    <script>
      Swal.fire({
        icon: 'error',
        title: 'Login Gagal',
        text: '<?= $_SESSION['login_error']; ?>',
        confirmButtonColor: '#2a5298'
      });
    </script>
    <?php unset($_SESSION['login_error']); ?>
  <?php endif; ?>
</body>
</html>