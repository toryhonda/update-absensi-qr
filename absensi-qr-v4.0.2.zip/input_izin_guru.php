<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include "config.php";
date_default_timezone_set("Asia/Jakarta");

$message = "";
$message_type = "";

$check_guru_table = mysqli_query($conn, "SHOW TABLES LIKE 'guru'");
$guru_table_exists = (mysqli_num_rows($check_guru_table) > 0);

$check_izin_table = mysqli_query($conn, "SHOW TABLES LIKE 'izin_guru'");
$izin_table_exists = (mysqli_num_rows($check_izin_table) > 0);

$check_kehadiran_table = mysqli_query($conn, "SHOW TABLES LIKE 'kehadiran_guru'");
$kehadiran_table_exists = (mysqli_num_rows($check_kehadiran_table) > 0);

if (!$guru_table_exists) {
    $create_guru_table = "CREATE TABLE guru (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        nip VARCHAR(20) NOT NULL,
        nama VARCHAR(100) NOT NULL,
        status ENUM('aktif', 'non-aktif') DEFAULT 'aktif',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if (mysqli_query($conn, $create_guru_table)) {
        $sample_guru = [
            "INSERT INTO guru (nip, nama) VALUES ('198203122005011001', 'Dr. Ahmad Susanto, M.Pd')",
            "INSERT INTO guru (nip, nama) VALUES ('197911052006042002', 'Drs. Budi Raharjo')",
            "INSERT INTO guru (nip, nama) VALUES ('198506152010012003', 'Siti Aminah, S.Pd')",
            "INSERT INTO guru (nip, nama) VALUES ('199005202015032004', 'Dewi Kusuma, S.Pd')"
        ];
        
        foreach ($sample_guru as $query) {
            mysqli_query($conn, $query);
        }
        
        $guru_table_exists = true;
    }
}

if (!$izin_table_exists) {
    $create_izin_table = "CREATE TABLE izin_guru (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        guru_id INT(11) NOT NULL,
        tanggal DATE NOT NULL,
        jenis_izin ENUM('I', 'S', 'A') NOT NULL,
        keterangan VARCHAR(255) NULL,
        status ENUM('pending', 'disetujui', 'ditolak') DEFAULT 'disetujui',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (guru_id) REFERENCES guru(id) ON DELETE CASCADE
    )";
    
    mysqli_query($conn, $create_izin_table);
    $izin_table_exists = true;
} else {
    $check_status_column = mysqli_query($conn, "SHOW COLUMNS FROM izin_guru LIKE 'status'");
    if (mysqli_num_rows($check_status_column) == 0) {
        $add_status_column = "ALTER TABLE izin_guru ADD COLUMN status ENUM('pending', 'disetujui', 'ditolak') DEFAULT 'disetujui'";
        mysqli_query($conn, $add_status_column);
    }
}

if (!$kehadiran_table_exists) {
    $create_kehadiran_table = "CREATE TABLE kehadiran_guru (
        id INT(11) AUTO_INCREMENT PRIMARY KEY,
        guru_id INT(11) NOT NULL,
        tanggal DATE NOT NULL,
        jam_masuk TIME NULL,
        jam_pulang TIME NULL,
        keterangan VARCHAR(255) NULL,
        status ENUM('hadir', 'terlambat', 'pulang_awal') DEFAULT 'hadir',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (guru_id) REFERENCES guru(id) ON DELETE CASCADE
    )";
    
    mysqli_query($conn, $create_kehadiran_table);
    $kehadiran_table_exists = true;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_izin'])) {
    $guru_id = (int)$_POST['guru_id'];
    $tanggal = $_POST['tanggal'];
    $jenis_izin = $_POST['jenis_izin'];
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
    
    if (empty($guru_id) || empty($tanggal) || empty($jenis_izin)) {
        $message = "Semua field wajib diisi!";
        $message_type = "danger";
    } else {
        $check_existing = mysqli_query($conn, "SELECT id FROM izin_guru WHERE guru_id = $guru_id AND tanggal = '$tanggal'");
        
        if (mysqli_num_rows($check_existing) > 0) {
            $message = "Guru tersebut sudah memiliki data izin pada tanggal yang dipilih!";
            $message_type = "warning";
        } else {
            $insert_query = "INSERT INTO izin_guru (guru_id, tanggal, jenis_izin, keterangan";
            
            $check_status_column = mysqli_query($conn, "SHOW COLUMNS FROM izin_guru LIKE 'status'");
            if (mysqli_num_rows($check_status_column) > 0) {
                $insert_query .= ", status) VALUES ($guru_id, '$tanggal', '$jenis_izin', '$keterangan', 'disetujui')";
            } else {
                $insert_query .= ") VALUES ($guru_id, '$tanggal', '$jenis_izin', '$keterangan')";
            }
            
            if (mysqli_query($conn, $insert_query)) {
                $message = "Data izin berhasil disimpan!";
                $message_type = "success";
                
                $bulan = date('m', strtotime($tanggal));
                $tahun = date('Y', strtotime($tanggal));
                echo "<script>
                    setTimeout(function() {
                        window.location.href = 'rekap_bulanan_guru.php?bulan=$bulan&tahun=$tahun';
                    }, 2000);
                </script>";
            } else {
                $message = "Error: " . mysqli_error($conn);
                $message_type = "danger";
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_kehadiran'])) {
    $guru_id = (int)$_POST['guru_id'];
    $tanggal = $_POST['tanggal'];
    $jam_masuk = $_POST['jam_masuk'];
    $jam_pulang = $_POST['jam_pulang'];
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
    $status_kehadiran = $_POST['status_kehadiran'];
    
    if (empty($guru_id) || empty($tanggal)) {
        $message = "Guru dan tanggal wajib diisi!";
        $message_type = "danger";
    } else {
        $check_existing = mysqli_query($conn, "SELECT id FROM kehadiran_guru WHERE guru_id = $guru_id AND tanggal = '$tanggal'");
        
        if (mysqli_num_rows($check_existing) > 0) {
            $message = "Guru tersebut sudah memiliki data kehadiran pada tanggal yang dipilih!";
            $message_type = "warning";
        } else {
            $insert_query = "INSERT INTO kehadiran_guru (guru_id, tanggal, jam_masuk, jam_pulang, keterangan, status) 
                            VALUES ($guru_id, '$tanggal', '$jam_masuk', '$jam_pulang', '$keterangan', '$status_kehadiran')";
            
            if (mysqli_query($conn, $insert_query)) {
                $message = "Data kehadiran berhasil disimpan!";
                $message_type = "success";
                
                $bulan = date('m', strtotime($tanggal));
                $tahun = date('Y', strtotime($tanggal));
                echo "<script>
                    setTimeout(function() {
                        window.location.href = 'rekap_bulanan_guru.php?bulan=$bulan&tahun=$tahun';
                    }, 2000);
                </script>";
            } else {
                $message = "Error: " . mysqli_error($conn);
                $message_type = "danger";
            }
        }
    }
}

if (isset($_GET['hapus_izin'])) {
    $id = (int)$_GET['hapus_izin'];
    
    if ($id > 0) {
        $delete_query = "DELETE FROM izin_guru WHERE id = $id";
        
        if (mysqli_query($conn, $delete_query)) {
            $_SESSION['message'] = "Data izin berhasil dihapus!";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Error: " . mysqli_error($conn);
            $_SESSION['message_type'] = "danger";
        }
        
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

if (isset($_GET['hapus_kehadiran'])) {
    $id = (int)$_GET['hapus_kehadiran'];
    
    if ($id > 0) {
        $delete_query = "DELETE FROM kehadiran_guru WHERE id = $id";
        
        if (mysqli_query($conn, $delete_query)) {
            $_SESSION['message'] = "Data kehadiran berhasil dihapus!";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Error: " . mysqli_error($conn);
            $_SESSION['message_type'] = "danger";
        }
        
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_izin'])) {
    $id = (int)$_POST['id'];
    $guru_id = (int)$_POST['guru_id'];
    $tanggal = $_POST['tanggal'];
    $jenis_izin = $_POST['jenis_izin'];
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
    
    if (empty($guru_id) || empty($tanggal) || empty($jenis_izin)) {
        $message = "Semua field wajib diisi!";
        $message_type = "danger";
    } else {
        $check_existing = mysqli_query($conn, "SELECT id FROM izin_guru WHERE guru_id = $guru_id AND tanggal = '$tanggal' AND id != $id");
        
        if (mysqli_num_rows($check_existing) > 0) {
            $message = "Guru tersebut sudah memiliki data izin pada tanggal yang dipilih!";
            $message_type = "warning";
        } else {
            $update_query = "UPDATE izin_guru SET 
                            guru_id = $guru_id, 
                            tanggal = '$tanggal', 
                            jenis_izin = '$jenis_izin', 
                            keterangan = '$keterangan' 
                            WHERE id = $id";
            
            if (mysqli_query($conn, $update_query)) {
                $message = "Data izin berhasil diupdate!";
                $message_type = "success";
                
                $bulan = date('m', strtotime($tanggal));
                $tahun = date('Y', strtotime($tanggal));
                echo "<script>
                    setTimeout(function() {
                        window.location.href = 'rekap_bulanan_guru.php?bulan=$bulan&tahun=$tahun';
                    }, 2000);
                </script>";
            } else {
                $message = "Error: " . mysqli_error($conn);
                $message_type = "danger";
            }
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_kehadiran'])) {
    $id = (int)$_POST['id'];
    $guru_id = (int)$_POST['guru_id'];
    $tanggal = $_POST['tanggal'];
    $jam_masuk = $_POST['jam_masuk'];
    $jam_pulang = $_POST['jam_pulang'];
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
    $status_kehadiran = $_POST['status_kehadiran'];
    
    if (empty($guru_id) || empty($tanggal)) {
        $message = "Guru dan tanggal wajib diisi!";
        $message_type = "danger";
    } else {
        $check_existing = mysqli_query($conn, "SELECT id FROM kehadiran_guru WHERE guru_id = $guru_id AND tanggal = '$tanggal' AND id != $id");
        
        if (mysqli_num_rows($check_existing) > 0) {
            $message = "Guru tersebut sudah memiliki data kehadiran pada tanggal yang dipilih!";
            $message_type = "warning";
        } else {
            $update_query = "UPDATE kehadiran_guru SET 
                            guru_id = $guru_id, 
                            tanggal = '$tanggal', 
                            jam_masuk = '$jam_masuk', 
                            jam_pulang = '$jam_pulang', 
                            keterangan = '$keterangan',
                            status = '$status_kehadiran' 
                            WHERE id = $id";
            
            if (mysqli_query($conn, $update_query)) {
                $message = "Data kehadiran berhasil diupdate!";
                $message_type = "success";
                
                $bulan = date('m', strtotime($tanggal));
                $tahun = date('Y', strtotime($tanggal));
                echo "<script>
                    setTimeout(function() {
                        window.location.href = 'rekap_bulanan_guru.php?bulan=$bulan&tahun=$tahun';
                    }, 2000);
                </script>";
            } else {
                $message = "Error: " . mysqli_error($conn);
                $message_type = "danger";
            }
        }
    }
}

$edit_izin = null;
if (isset($_GET['edit_izin'])) {
    $id_edit = (int)$_GET['edit_izin'];
    $edit_query = mysqli_query($conn, "SELECT * FROM izin_guru WHERE id = $id_edit");
    
    if (mysqli_num_rows($edit_query) > 0) {
        $edit_izin = mysqli_fetch_assoc($edit_query);
    }
}

$edit_kehadiran = null;
if (isset($_GET['edit_kehadiran'])) {
    $id_edit = (int)$_GET['edit_kehadiran'];
    $edit_query = mysqli_query($conn, "SELECT * FROM kehadiran_guru WHERE id = $id_edit");
    
    if (mysqli_num_rows($edit_query) > 0) {
        $edit_kehadiran = mysqli_fetch_assoc($edit_query);
    }
}

$guru_list = [];
if ($guru_table_exists) {
    $guru_query = mysqli_query($conn, "SELECT id, nip, nama FROM guru WHERE status = 'aktif' ORDER BY nama");
    while ($row = mysqli_fetch_assoc($guru_query)) {
        $guru_list[] = $row;
    }
}

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $message_type = $_SESSION['message_type'];
    unset($_SESSION['message']);
    unset($_SESSION['message_type']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Absensi QR - Input Data Guru</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        :root{
            --bg:#f6f8fb;
            --surface:#ffffff;
            --surface-2:#f9fafb;
            --line:#e8edf3;
            --line-strong:#dbe3ec;
            --ink:#0f172a;
            --ink-2:#334155;
            --muted:#64748b;
            --muted-2:#94a3b8;
            --brand:#2a5298;
            --brand-2:#1e3c72;
            --brand-soft:rgba(42,82,152,.08);
            --accent:#ffb020;
            --success:#10b981;
            --warning:#f59e0b;
            --danger:#ef4444;
            --info:#3b82f6;
            --purple:#8b5cf6;
            --radius-lg:16px;
            --radius-md:12px;
            --radius-sm:10px;
            --shadow-sm:0 1px 2px rgba(15,23,42,.05);
            --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
            --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
            --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
        }

        *{box-sizing:border-box;}

        body{
            font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
            background:
                radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
                radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
                var(--bg);
            min-height:100vh;
            color:var(--ink);
            margin:0;
            padding:0;
            -webkit-font-smoothing:antialiased;
            -moz-osx-font-smoothing:grayscale;
        }

        .topbar{
            background:rgba(255,255,255,.88);
            backdrop-filter:blur(14px);
            -webkit-backdrop-filter:blur(14px);
            border-bottom:1px solid var(--line);
            position:sticky;
            top:0;
            z-index:100;
            padding:14px 0;
        }

        .topbar-inner{
            max-width:1100px;
            margin:0 auto;
            padding:0 24px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:16px;
            flex-wrap:wrap;
        }

        .brand-block{
            display:flex;
            align-items:center;
            gap:14px;
            min-width:0;
        }

        .brand-mark{
            width:44px;
            height:44px;
            border-radius:var(--radius-md);
            background:linear-gradient(135deg, var(--brand), var(--brand-2));
            color:#fff;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:18px;
            box-shadow:var(--shadow-brand);
            flex-shrink:0;
        }

        .brand-titles h1{
            font-size:17px;
            font-weight:600;
            letter-spacing:-.2px;
            color:var(--ink);
            margin:0;
            line-height:1.25;
        }

        .brand-titles span{
            display:block;
            font-size:12.5px;
            color:var(--muted);
            margin-top:2px;
        }

        .topbar-actions{
            display:flex;
            align-items:center;
            gap:10px;
            flex-wrap:wrap;
        }

        .btn-back{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding:9px 16px;
            font-size:13.5px;
            font-weight:500;
            color:var(--ink-2);
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-sm);
            text-decoration:none;
            transition:border-color .2s ease, background .2s ease, transform .2s ease;
            box-shadow:var(--shadow-sm);
        }

        .btn-back:hover{
            background:var(--surface-2);
            border-color:var(--line-strong);
            color:var(--ink);
            transform:translateX(-2px);
        }

        .btn-info-top{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding:9px 16px;
            font-size:13.5px;
            font-weight:500;
            color:#fff;
            background:linear-gradient(135deg,#3b82f6,#2563eb);
            border:1px solid transparent;
            border-radius:var(--radius-sm);
            text-decoration:none;
            transition:filter .2s ease, transform .2s ease, box-shadow .2s ease;
            box-shadow:0 10px 22px -12px rgba(37,99,235,.7);
        }

        .btn-info-top:hover{
            color:#fff;
            transform:translateY(-1px);
            filter:brightness(1.08);
        }

        .page-wrap{
            max-width:1100px;
            margin:0 auto;
            padding:32px 24px 60px;
        }

        .page-head{
            margin-bottom:22px;
        }

        .page-eyebrow{
            font-size:11.5px;
            font-weight:600;
            letter-spacing:1.2px;
            text-transform:uppercase;
            color:var(--brand);
            display:block;
            margin-bottom:6px;
        }

        .page-head h2{
            font-size:24px;
            font-weight:600;
            letter-spacing:-.4px;
            color:var(--ink);
            margin:0;
        }

        .page-head p{
            font-size:13.5px;
            color:var(--muted);
            margin:6px 0 0;
        }

        .card-panel{
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-lg);
            box-shadow:var(--shadow-sm);
            margin-bottom:20px;
            overflow:hidden;
            transition:box-shadow .25s ease;
        }

        .card-panel:hover{
            box-shadow:var(--shadow-md);
        }

        .card-panel-header{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:12px;
            padding:18px 24px;
            border-bottom:1px solid var(--line);
            background:var(--surface-2);
            flex-wrap:wrap;
        }

        .card-panel-title{
            display:flex;
            align-items:center;
            gap:10px;
            font-size:14.5px;
            font-weight:600;
            color:var(--ink);
        }

        .card-panel-title i{
            width:32px;
            height:32px;
            border-radius:var(--radius-sm);
            background:var(--brand-soft);
            color:var(--brand);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:14px;
        }

        .card-panel-body{
            padding:24px;
        }

        .info-box{
            background:rgba(59,130,246,.08);
            border:1px solid rgba(59,130,246,.2);
            border-left:4px solid var(--info);
            padding:14px 18px;
            margin-bottom:20px;
            border-radius:var(--radius-md);
            font-size:13px;
            color:#1e40af;
            line-height:1.65;
        }

        .info-box strong{
            color:#1d4ed8;
            font-weight:600;
        }

        .info-box a{
            color:var(--brand);
            font-weight:600;
            text-decoration:none;
        }

        .info-box a:hover{
            text-decoration:underline;
        }

        .alert{
            padding:14px 18px;
            border-radius:var(--radius-md);
            font-size:13.5px;
            font-weight:500;
            border:1px solid transparent;
            margin-bottom:20px;
            display:flex;
            align-items:flex-start;
            gap:10px;
            line-height:1.55;
        }

        .alert-success{
            background:rgba(16,185,129,.08);
            color:#047857;
            border-color:rgba(16,185,129,.28);
        }

        .alert-warning{
            background:rgba(245,158,11,.08);
            color:#b45309;
            border-color:rgba(245,158,11,.3);
        }

        .alert-danger{
            background:rgba(239,68,68,.08);
            color:#b91c1c;
            border-color:rgba(239,68,68,.28);
        }

        .tab-nav{
            display:flex;
            gap:6px;
            padding:6px;
            background:var(--surface-2);
            border:1px solid var(--line);
            border-radius:var(--radius-md);
            margin-bottom:22px;
            flex-wrap:wrap;
        }

        .tab-nav button{
            flex:1;
            min-width:140px;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:8px;
            padding:11px 18px;
            font-family:inherit;
            font-size:13.5px;
            font-weight:500;
            color:var(--ink-2);
            background:transparent;
            border:1px solid transparent;
            border-radius:var(--radius-sm);
            cursor:pointer;
            transition:background .2s ease, color .2s ease, box-shadow .2s ease, border-color .2s ease;
        }

        .tab-nav button:hover{
            background:rgba(42,82,152,.06);
            color:var(--ink);
        }

        .tab-nav button.active{
            background:var(--surface);
            color:var(--brand);
            border-color:var(--line);
            box-shadow:var(--shadow-sm);
        }

        .tab-nav button i{
            font-size:14px;
        }

        .legend-row{
            display:flex;
            flex-wrap:wrap;
            gap:8px;
            margin-bottom:18px;
        }

        .legend-item{
            display:inline-flex;
            align-items:center;
            gap:7px;
            padding:6px 12px;
            font-size:12.5px;
            font-weight:500;
            color:var(--ink-2);
            background:var(--surface-2);
            border:1px solid var(--line);
            border-radius:999px;
        }

        .legend-color{
            width:12px;
            height:12px;
            border-radius:4px;
            flex-shrink:0;
        }

        .legend-izin{background:#f59e0b;}
        .legend-sakit{background:#8b5cf6;}
        .legend-alpha{background:#ef4444;}
        .legend-hadir{background:#10b981;}
        .legend-terlambat{background:#f59e0b;}
        .legend-pulang_awal{background:#ef4444;}

        .form-label{
            display:block;
            font-size:12.5px;
            font-weight:500;
            color:var(--ink-2);
            margin-bottom:7px;
        }

        .form-control,
        .form-select{
            font-family:inherit;
            font-size:14px;
            color:var(--ink);
            background:var(--surface-2);
            border:1px solid var(--line);
            border-radius:var(--radius-sm);
            padding:10px 14px;
            transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
            box-shadow:none;
            width:100%;
            outline:none;
        }

        .form-control::placeholder{
            color:var(--muted-2);
        }

        .form-control:hover,
        .form-select:hover{
            border-color:var(--line-strong);
        }

        .form-control:focus,
        .form-select:focus{
            background:#fff;
            border-color:var(--brand);
            box-shadow:0 0 0 4px var(--brand-soft);
        }

        textarea.form-control{
            resize:vertical;
            min-height:90px;
        }

        .form-block{
            margin-bottom:18px;
        }

        .time-input-group{
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:14px;
        }

        .time-input-group label{
            display:block;
            font-size:12px;
            font-weight:500;
            color:var(--muted);
            margin-bottom:6px;
        }

        .radio-group{
            display:flex;
            flex-wrap:wrap;
            gap:10px;
        }

        .radio-option{
            position:relative;
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding:9px 16px;
            font-size:13.5px;
            font-weight:500;
            color:var(--ink-2);
            background:var(--surface-2);
            border:1px solid var(--line);
            border-radius:var(--radius-sm);
            cursor:pointer;
            transition:border-color .2s ease, background .2s ease, color .2s ease;
        }

        .radio-option:hover{
            border-color:var(--line-strong);
        }

        .radio-option input[type="radio"]{
            position:absolute;
            opacity:0;
            pointer-events:none;
        }

        .radio-option::before{
            content:"";
            width:16px;
            height:16px;
            border-radius:50%;
            border:2px solid var(--line-strong);
            background:#fff;
            transition:border-color .2s ease;
            flex-shrink:0;
        }

        .radio-option input[type="radio"]:checked ~ .radio-text{
            color:var(--brand);
            font-weight:600;
        }

        .radio-option:has(input[type="radio"]:checked){
            border-color:var(--brand);
            background:var(--brand-soft);
            color:var(--brand);
        }

        .radio-option:has(input[type="radio"]:checked)::before{
            border-color:var(--brand);
            background:
                radial-gradient(circle, var(--brand) 0 4px, transparent 4px),
                #fff;
        }

        .radio-text{
            font-size:13.5px;
        }

        .btn{
            font-family:inherit;
            font-size:13.5px;
            font-weight:500;
            border-radius:var(--radius-sm);
            padding:11px 18px;
            transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:8px;
            border:1px solid transparent;
            cursor:pointer;
            line-height:1.2;
            text-decoration:none;
        }

        .btn:active{transform:translateY(1px);}
        .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

        .btn-primary{
            background:linear-gradient(135deg, var(--brand), var(--brand-2));
            color:#fff;
            box-shadow:var(--shadow-brand);
        }
        .btn-primary:hover{
            filter:brightness(1.08);
            transform:translateY(-1px);
            color:#fff;
            box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
        }

        .btn-success{
            background:linear-gradient(135deg,#10b981,#059669);
            color:#fff;
            box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
        }
        .btn-success:hover{
            filter:brightness(1.08);
            transform:translateY(-1px);
            color:#fff;
        }

        .btn-outline-secondary{
            background:var(--surface);
            color:var(--ink-2);
            border:1px solid var(--line);
            box-shadow:var(--shadow-sm);
        }
        .btn-outline-secondary:hover{
            background:var(--surface-2);
            border-color:var(--line-strong);
            color:var(--ink);
        }

        .btn-outline-primary{
            background:transparent;
            color:var(--brand);
            border:1px solid rgba(42,82,152,.32);
        }
        .btn-outline-primary:hover{
            background:var(--brand-soft);
            border-color:var(--brand);
            color:var(--brand);
        }

        .btn-outline-danger{
            background:transparent;
            color:var(--danger);
            border:1px solid rgba(239,68,68,.35);
        }
        .btn-outline-danger:hover{
            background:rgba(239,68,68,.06);
            border-color:var(--danger);
            color:var(--danger);
        }

        .btn-sm{
            padding:6px 12px;
            font-size:12.5px;
            border-radius:8px;
        }

        .d-grid{
            display:grid !important;
            gap:10px;
        }

        .form-actions{
            display:flex;
            flex-direction:column;
            gap:10px;
            margin-top:6px;
        }

        .pill-nav{
            display:flex;
            gap:6px;
            padding:5px;
            background:var(--surface-2);
            border:1px solid var(--line);
            border-radius:var(--radius-md);
            margin-bottom:18px;
            flex-wrap:wrap;
        }

        .pill-nav button{
            display:inline-flex;
            align-items:center;
            gap:7px;
            padding:8px 16px;
            font-family:inherit;
            font-size:12.5px;
            font-weight:500;
            color:var(--ink-2);
            background:transparent;
            border:1px solid transparent;
            border-radius:var(--radius-sm);
            cursor:pointer;
            transition:background .2s ease, color .2s ease, box-shadow .2s ease;
        }

        .pill-nav button:hover{
            background:rgba(42,82,152,.06);
            color:var(--ink);
        }

        .pill-nav button.active{
            background:linear-gradient(135deg, var(--brand), var(--brand-2));
            color:#fff;
            box-shadow:var(--shadow-brand);
        }

        .table-wrapper{
            border:1px solid var(--line);
            border-radius:var(--radius-md);
            overflow:hidden;
            background:var(--surface);
        }

        .table-responsive{
            overflow-x:auto;
            scrollbar-width:thin;
            scrollbar-color:#cbd5e1 transparent;
            margin:0;
        }

        .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
        .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
        .table-responsive::-webkit-scrollbar-track{background:transparent;}

        .table{
            margin:0;
            --bs-table-bg:transparent;
            --bs-table-border-color:var(--line);
            --bs-table-striped-bg:transparent;
            --bs-table-hover-bg:rgba(42,82,152,.04);
            font-size:13.5px;
            color:var(--ink-2);
            width:100%;
        }

        .table thead th{
            background:var(--surface-2);
            color:var(--muted);
            font-weight:600;
            font-size:11.5px;
            letter-spacing:.6px;
            text-transform:uppercase;
            padding:13px 16px;
            border-bottom:1px solid var(--line);
            white-space:nowrap;
            text-align:left;
            vertical-align:middle;
        }

        .table tbody td{
            padding:13px 16px;
            vertical-align:middle;
            border-bottom:1px solid var(--line);
            color:var(--ink-2);
        }

        .table tbody tr:hover{
            background:rgba(42,82,152,.04);
        }

        .table tbody tr:last-child td{
            border-bottom:0;
        }

        .badge-nip{
            display:inline-block;
            padding:4px 10px;
            font-size:12px;
            font-weight:500;
            background:var(--brand-soft);
            color:var(--brand);
            border-radius:6px;
            letter-spacing:.3px;
        }

        .badge-pill{
            display:inline-flex;
            align-items:center;
            gap:5px;
            padding:5px 11px;
            font-size:12px;
            font-weight:500;
            border-radius:999px;
            line-height:1;
        }

        .badge-izin{
            background:rgba(245,158,11,.12);
            color:#b45309;
        }
        .badge-sakit{
            background:rgba(139,92,246,.12);
            color:#6d28d9;
        }
        .badge-alpha{
            background:rgba(239,68,68,.12);
            color:#b91c1c;
        }
        .badge-hadir{
            background:rgba(16,185,129,.12);
            color:#047857;
        }
        .badge-terlambat{
            background:rgba(245,158,11,.12);
            color:#b45309;
        }
        .badge-pulang_awal{
            background:rgba(239,68,68,.12);
            color:#b91c1c;
        }

        .empty-cell{
            text-align:center;
            padding:32px 16px;
            color:var(--muted);
            font-size:13.5px;
        }

        .action-btns{
            display:inline-flex;
            gap:6px;
            flex-wrap:wrap;
            justify-content:center;
        }

        .tab-content-custom > .tab-pane{
            display:none;
        }

        .tab-content-custom > .tab-pane.active{
            display:block;
            animation:fadeIn .3s ease;
        }

        @keyframes fadeIn{
            from{opacity:0;transform:translateY(6px);}
            to{opacity:1;transform:translateY(0);}
        }

        @media (max-width:900px){
            .topbar-inner{padding:0 18px;}
            .page-wrap{padding:24px 18px 48px;}
            .page-head h2{font-size:21px;}
            .card-panel-body{padding:20px;}
            .card-panel-header{padding:16px 20px;}
        }

        @media (max-width:640px){
            .topbar{padding:12px 0;}
            .topbar-inner{padding:0 14px;}
            .brand-mark{width:38px;height:38px;font-size:15px;}
            .brand-titles h1{font-size:15px;}
            .brand-titles span{font-size:11.5px;}
            .btn-back{padding:8px 12px;font-size:12.5px;}
            .btn-back span{display:none;}
            .btn-info-top{padding:8px 12px;font-size:12.5px;}
            .btn-info-top span{display:none;}
            .page-wrap{padding:20px 14px 40px;}
            .page-head h2{font-size:19px;}
            .page-head p{font-size:12.5px;}
            .card-panel{border-radius:var(--radius-md);}
            .card-panel-body{padding:16px;}
            .card-panel-header{padding:14px 16px;}
            .card-panel-title{font-size:13.5px;}
            .tab-nav button{min-width:0;padding:10px 12px;font-size:12.5px;}
            .time-input-group{grid-template-columns:1fr;}
            .radio-group{gap:8px;}
            .radio-option{padding:8px 12px;font-size:12.5px;}
            .btn{padding:10px 14px;font-size:13px;}
            .table thead th,
            .table tbody td{padding:10px 12px;font-size:12.5px;}
            .action-btns{flex-direction:column;}
            .action-btns .btn{width:100%;}
        }

        @media (prefers-reduced-motion:reduce){
            *{animation:none !important;transition:none !important;}
        }
    </style>
</head>
<body>

    <div class="topbar">
        <div class="topbar-inner">
            <div class="brand-block">
                <div class="brand-mark"><i class="bi bi-pencil-square"></i></div>
                <div class="brand-titles">
                    <h1>Input Data Guru Manual</h1>
                    <span>Catat izin, sakit, alpha, dan kehadiran manual</span>
                </div>
            </div>
            <div class="topbar-actions">
                <a href="rekap_bulanan_guru.php" class="btn-info-top">
                    <i class="bi bi-list-check"></i>
                    <span>Rekap Bulanan</span>
                </a>
                <a href="dashboard.php" class="btn-back">
                    <i class="bi bi-arrow-left"></i>
                    <span>Kembali</span>
                </a>
            </div>
        </div>
    </div>

    <div class="page-wrap">

        <div class="page-head">
            <span class="page-eyebrow">Input Manual</span>
            <h2>Input Data Guru</h2>
            <p>Tambah atau perbarui data izin, sakit, alpha, dan kehadiran guru secara manual.</p>
        </div>

        <div class="card-panel">
            <div class="card-panel-header">
                <div class="card-panel-title">
                    <i class="bi bi-clipboard-plus"></i>
                    Formulir Input Data
                </div>
            </div>
            <div class="card-panel-body">

                <div class="info-box">
                    <strong><i class="bi bi-info-circle"></i> Info:</strong> Data yang diinput di sini akan langsung muncul di 
                    <a href="rekap_bulanan_guru.php">Rekap Bulanan Guru</a>. Pastikan memilih tanggal yang benar.
                </div>

                <?php if (!empty($message)): ?>
                    <div class="alert alert-<?= $message_type ?> alert-dismissible fade show" role="alert">
                        <i class="bi bi-<?= $message_type === 'success' ? 'check-circle-fill' : ($message_type === 'warning' ? 'exclamation-triangle-fill' : 'x-circle-fill') ?>"></i>
                        <span><?= $message ?></span>
                        <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close" style="background:none;border:0;opacity:.5;"></button>
                    </div>
                <?php endif; ?>

                <ul class="nav tab-nav" id="myTab" role="tablist">
                    <li style="display:contents;" role="presentation">
                        <button class="<?= !$edit_kehadiran ? 'active' : '' ?>" id="izin-tab" data-bs-toggle="tab" data-bs-target="#izin" type="button" role="tab">
                            <i class="bi bi-clipboard-x"></i> Input Izin
                        </button>
                    </li>
                    <li style="display:contents;" role="presentation">
                        <button class="<?= $edit_kehadiran ? 'active' : '' ?>" id="kehadiran-tab" data-bs-toggle="tab" data-bs-target="#kehadiran" type="button" role="tab">
                            <i class="bi bi-person-check"></i> Input Kehadiran
                        </button>
                    </li>
                </ul>

                <div class="tab-content tab-content-custom" id="myTabContent">
                    <div class="tab-pane fade <?= !$edit_kehadiran ? 'show active' : '' ?>" id="izin" role="tabpanel">
                        <div class="legend-row">
                            <div class="legend-item"><div class="legend-color legend-izin"></div> Izin (I)</div>
                            <div class="legend-item"><div class="legend-color legend-sakit"></div> Sakit (S)</div>
                            <div class="legend-item"><div class="legend-color legend-alpha"></div> Alpha (A)</div>
                        </div>

                        <form method="POST">
                            <?php if ($edit_izin): ?>
                                <input type="hidden" name="id" value="<?= $edit_izin['id'] ?>">
                            <?php endif; ?>

                            <div class="form-block">
                                <label for="guru_id_izin" class="form-label">Pilih Guru</label>
                                <select class="form-select" id="guru_id_izin" name="guru_id" required>
                                    <option value="">-- Pilih Guru --</option>
                                    <?php foreach ($guru_list as $guru): ?>
                                        <option value="<?= $guru['id'] ?>" 
                                            <?= ($edit_izin && $edit_izin['guru_id'] == $guru['id']) || (isset($_POST['guru_id']) && $_POST['guru_id'] == $guru['id']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($guru['nip'] . ' - ' . $guru['nama']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-block">
                                <label for="tanggal_izin" class="form-label">Tanggal Izin</label>
                                <input type="date" class="form-control" id="tanggal_izin" name="tanggal" 
                                       value="<?= $edit_izin ? $edit_izin['tanggal'] : (isset($_POST['tanggal']) ? $_POST['tanggal'] : date('Y-m-d')) ?>" required>
                            </div>

                            <div class="form-block">
                                <label class="form-label">Jenis Izin</label>
                                <div class="radio-group">
                                    <label class="radio-option">
                                        <input type="radio" name="jenis_izin" id="izin" value="I" 
                                               <?= ($edit_izin && $edit_izin['jenis_izin'] == 'I') || (isset($_POST['jenis_izin']) && $_POST['jenis_izin'] == 'I') || (!$edit_izin && !isset($_POST['jenis_izin'])) ? 'checked' : '' ?>>
                                        <span class="radio-text">Izin (I)</span>
                                    </label>
                                    <label class="radio-option">
                                        <input type="radio" name="jenis_izin" id="sakit" value="S"
                                               <?= ($edit_izin && $edit_izin['jenis_izin'] == 'S') || (isset($_POST['jenis_izin']) && $_POST['jenis_izin'] == 'S') ? 'checked' : '' ?>>
                                        <span class="radio-text">Sakit (S)</span>
                                    </label>
                                    <label class="radio-option">
                                        <input type="radio" name="jenis_izin" id="alpha" value="A"
                                               <?= ($edit_izin && $edit_izin['jenis_izin'] == 'A') || (isset($_POST['jenis_izin']) && $_POST['jenis_izin'] == 'A') ? 'checked' : '' ?>>
                                        <span class="radio-text">Alpha (A)</span>
                                    </label>
                                </div>
                            </div>

                            <div class="form-block">
                                <label for="keterangan_izin" class="form-label">Keterangan</label>
                                <textarea class="form-control" id="keterangan_izin" name="keterangan" rows="3" 
                                          placeholder="Alasan izin/sakit/alpha"><?= $edit_izin ? htmlspecialchars($edit_izin['keterangan']) : (isset($_POST['keterangan']) ? htmlspecialchars($_POST['keterangan']) : '') ?></textarea>
                            </div>

                            <div class="form-actions">
                                <?php if ($edit_izin): ?>
                                    <button type="submit" name="update_izin" class="btn btn-primary">
                                        <i class="bi bi-check-circle"></i> Update Data Izin
                                    </button>
                                    <a href="input_izin_guru.php" class="btn btn-outline-secondary">
                                        <i class="bi bi-x-circle"></i> Batal Edit
                                    </a>
                                <?php else: ?>
                                    <button type="submit" name="submit_izin" class="btn btn-primary">
                                        <i class="bi bi-check-circle"></i> Simpan Data Izin
                                    </button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>

                    <div class="tab-pane fade <?= $edit_kehadiran ? 'show active' : '' ?>" id="kehadiran" role="tabpanel">
                        <div class="legend-row">
                            <div class="legend-item"><div class="legend-color legend-hadir"></div> Hadir</div>
                            <div class="legend-item"><div class="legend-color legend-terlambat"></div> Terlambat</div>
                            <div class="legend-item"><div class="legend-color legend-pulang_awal"></div> Pulang Awal</div>
                        </div>

                        <form method="POST">
                            <?php if ($edit_kehadiran): ?>
                                <input type="hidden" name="id" value="<?= $edit_kehadiran['id'] ?>">
                            <?php endif; ?>

                            <div class="form-block">
                                <label for="guru_id_kehadiran" class="form-label">Pilih Guru</label>
                                <select class="form-select" id="guru_id_kehadiran" name="guru_id" required>
                                    <option value="">-- Pilih Guru --</option>
                                    <?php foreach ($guru_list as $guru): ?>
                                        <option value="<?= $guru['id'] ?>" 
                                            <?= ($edit_kehadiran && $edit_kehadiran['guru_id'] == $guru['id']) || (isset($_POST['guru_id']) && $_POST['guru_id'] == $guru['id']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($guru['nip'] . ' - ' . $guru['nama']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-block">
                                <label for="tanggal_kehadiran" class="form-label">Tanggal Kehadiran</label>
                                <input type="date" class="form-control" id="tanggal_kehadiran" name="tanggal" 
                                       value="<?= $edit_kehadiran ? $edit_kehadiran['tanggal'] : (isset($_POST['tanggal']) ? $_POST['tanggal'] : date('Y-m-d')) ?>" required>
                            </div>

                            <div class="form-block">
                                <label class="form-label">Waktu Kehadiran</label>
                                <div class="time-input-group">
                                    <div>
                                        <label for="jam_masuk">Jam Masuk</label>
                                        <input type="time" class="form-control" id="jam_masuk" name="jam_masuk" 
                                               value="<?= $edit_kehadiran ? $edit_kehadiran['jam_masuk'] : (isset($_POST['jam_masuk']) ? $_POST['jam_masuk'] : '07:00') ?>">
                                    </div>
                                    <div>
                                        <label for="jam_pulang">Jam Pulang</label>
                                        <input type="time" class="form-control" id="jam_pulang" name="jam_pulang" 
                                               value="<?= $edit_kehadiran ? $edit_kehadiran['jam_pulang'] : (isset($_POST['jam_pulang']) ? $_POST['jam_pulang'] : '15:00') ?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-block">
                                <label class="form-label">Status Kehadiran</label>
                                <div class="radio-group">
                                    <label class="radio-option">
                                        <input type="radio" name="status_kehadiran" id="hadir" value="hadir" 
                                               <?= ($edit_kehadiran && $edit_kehadiran['status'] == 'hadir') || (isset($_POST['status_kehadiran']) && $_POST['status_kehadiran'] == 'hadir') || (!$edit_kehadiran && !isset($_POST['status_kehadiran'])) ? 'checked' : '' ?>>
                                        <span class="radio-text">Hadir</span>
                                    </label>
                                    <label class="radio-option">
                                        <input type="radio" name="status_kehadiran" id="terlambat" value="terlambat"
                                               <?= ($edit_kehadiran && $edit_kehadiran['status'] == 'terlambat') || (isset($_POST['status_kehadiran']) && $_POST['status_kehadiran'] == 'terlambat') ? 'checked' : '' ?>>
                                        <span class="radio-text">Terlambat</span>
                                    </label>
                                    <label class="radio-option">
                                        <input type="radio" name="status_kehadiran" id="pulang_awal" value="pulang_awal"
                                               <?= ($edit_kehadiran && $edit_kehadiran['status'] == 'pulang_awal') || (isset($_POST['status_kehadiran']) && $_POST['status_kehadiran'] == 'pulang_awal') ? 'checked' : '' ?>>
                                        <span class="radio-text">Pulang Awal</span>
                                    </label>
                                </div>
                            </div>

                            <div class="form-block">
                                <label for="keterangan_kehadiran" class="form-label">Keterangan</label>
                                <textarea class="form-control" id="keterangan_kehadiran" name="keterangan" rows="3" 
                                          placeholder="Keterangan tambahan"><?= $edit_kehadiran ? htmlspecialchars($edit_kehadiran['keterangan']) : (isset($_POST['keterangan']) ? htmlspecialchars($_POST['keterangan']) : '') ?></textarea>
                            </div>

                            <div class="form-actions">
                                <?php if ($edit_kehadiran): ?>
                                    <button type="submit" name="update_kehadiran" class="btn btn-success">
                                        <i class="bi bi-check-circle"></i> Update Data Kehadiran
                                    </button>
                                    <a href="input_izin_guru.php" class="btn btn-outline-secondary">
                                        <i class="bi bi-x-circle"></i> Batal Edit
                                    </a>
                                <?php else: ?>
                                    <button type="submit" name="submit_kehadiran" class="btn btn-success">
                                        <i class="bi bi-check-circle"></i> Simpan Data Kehadiran
                                    </button>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="d-grid" style="margin-top:20px;">
                    <a href="rekap_bulanan_guru.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Kembali ke Rekap Bulanan
                    </a>
                </div>
            </div>
        </div>

        <?php if ($izin_table_exists && $guru_table_exists && $kehadiran_table_exists): ?>
        <div class="card-panel">
            <div class="card-panel-header">
                <div class="card-panel-title">
                    <i class="bi bi-clock-history"></i>
                    Data Terbaru
                </div>
            </div>
            <div class="card-panel-body">

                <ul class="nav pill-nav" id="pills-tab" role="tablist">
                    <li style="display:contents;" role="presentation">
                        <button class="active" id="pills-izin-tab" data-bs-toggle="pill" data-bs-target="#pills-izin" type="button" role="tab">
                            <i class="bi bi-clipboard-x"></i> Izin Terbaru
                        </button>
                    </li>
                    <li style="display:contents;" role="presentation">
                        <button id="pills-kehadiran-tab" data-bs-toggle="pill" data-bs-target="#pills-kehadiran" type="button" role="tab">
                            <i class="bi bi-person-check"></i> Kehadiran Terbaru
                        </button>
                    </li>
                </ul>

                <div class="tab-content tab-content-custom" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-izin" role="tabpanel">
                        <div class="table-wrapper">
                            <div class="table-responsive">
                                <table class="table align-middle">
                                    <thead>
                                        <tr>
                                            <th>Tanggal</th>
                                            <th>NIP</th>
                                            <th>Nama Guru</th>
                                            <th>Jenis</th>
                                            <th>Keterangan</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $recent_izin_query = "
                                            SELECT i.id, i.tanggal, i.jenis_izin, i.keterangan, g.nip, g.nama 
                                            FROM izin_guru i 
                                            JOIN guru g ON i.guru_id = g.id 
                                            ORDER BY i.tanggal DESC, i.created_at DESC 
                                            LIMIT 5
                                        ";
                                        $recent_izin_result = mysqli_query($conn, $recent_izin_query);
                                        
                                        if (mysqli_num_rows($recent_izin_result) > 0) {
                                            while ($row = mysqli_fetch_assoc($recent_izin_result)) {
                                                $badge_class = '';
                                                $jenis_label = '';
                                                if ($row['jenis_izin'] == 'I') { $badge_class = 'badge-izin'; $jenis_label = 'Izin'; }
                                                if ($row['jenis_izin'] == 'S') { $badge_class = 'badge-sakit'; $jenis_label = 'Sakit'; }
                                                if ($row['jenis_izin'] == 'A') { $badge_class = 'badge-alpha'; $jenis_label = 'Alpha'; }
                                                
                                                echo "<tr>";
                                                echo "<td>" . date("d/m/Y", strtotime($row['tanggal'])) . "</td>";
                                                echo "<td><span class='badge-nip'>" . htmlspecialchars($row['nip']) . "</span></td>";
                                                echo "<td style='font-weight:500;color:var(--ink);'>" . htmlspecialchars($row['nama']) . "</td>";
                                                echo "<td><span class='badge-pill $badge_class'>$jenis_label</span></td>";
                                                echo "<td>" . (!empty($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-') . "</td>";
                                                echo "<td class='text-center'>
                                                    <div class='action-btns'>
                                                        <a href='input_izin_guru.php?edit_izin={$row['id']}' class='btn btn-sm btn-outline-primary'>
                                                            <i class='bi bi-pencil'></i> Edit
                                                        </a>
                                                        <a href='input_izin_guru.php?hapus_izin={$row['id']}' class='btn btn-sm btn-outline-danger' onclick='return confirm(\"Yakin ingin menghapus data ini?\")'>
                                                            <i class='bi bi-trash'></i> Hapus
                                                        </a>
                                                    </div>
                                                </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='6' class='empty-cell'>Belum ada data izin</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="pills-kehadiran" role="tabpanel">
                        <div class="table-wrapper">
                            <div class="table-responsive">
                                <table class="table align-middle">
                                    <thead>
                                        <tr>
                                            <th>Tanggal</th>
                                            <th>NIP</th>
                                            <th>Nama Guru</th>
                                            <th>Jam Masuk</th>
                                            <th>Jam Pulang</th>
                                            <th>Status</th>
                                            <th class="text-center">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $recent_kehadiran_query = "
                                            SELECT k.id, k.tanggal, k.jam_masuk, k.jam_pulang, k.status, k.keterangan, g.nip, g.nama 
                                            FROM kehadiran_guru k 
                                            JOIN guru g ON k.guru_id = g.id 
                                            ORDER BY k.tanggal DESC, k.created_at DESC 
                                            LIMIT 5
                                        ";
                                        $recent_kehadiran_result = mysqli_query($conn, $recent_kehadiran_query);
                                        
                                        if (mysqli_num_rows($recent_kehadiran_result) > 0) {
                                            while ($row = mysqli_fetch_assoc($recent_kehadiran_result)) {
                                                $badge_class = '';
                                                $status_label = '';
                                                if ($row['status'] == 'hadir') { $badge_class = 'badge-hadir'; $status_label = 'Hadir'; }
                                                if ($row['status'] == 'terlambat') { $badge_class = 'badge-terlambat'; $status_label = 'Terlambat'; }
                                                if ($row['status'] == 'pulang_awal') { $badge_class = 'badge-pulang_awal'; $status_label = 'Pulang Awal'; }
                                                
                                                $jam_masuk = !empty($row['jam_masuk']) ? date("H:i", strtotime($row['jam_masuk'])) : '-';
                                                $jam_pulang = !empty($row['jam_pulang']) ? date("H:i", strtotime($row['jam_pulang'])) : '-';
                                                
                                                echo "<tr>";
                                                echo "<td>" . date("d/m/Y", strtotime($row['tanggal'])) . "</td>";
                                                echo "<td><span class='badge-nip'>" . htmlspecialchars($row['nip']) . "</span></td>";
                                                echo "<td style='font-weight:500;color:var(--ink);'>" . htmlspecialchars($row['nama']) . "</td>";
                                                echo "<td>" . $jam_masuk . "</td>";
                                                echo "<td>" . $jam_pulang . "</td>";
                                                echo "<td><span class='badge-pill $badge_class'>$status_label</span></td>";
                                                echo "<td class='text-center'>
                                                    <div class='action-btns'>
                                                        <a href='input_izin_guru.php?edit_kehadiran={$row['id']}' class='btn btn-sm btn-outline-primary'>
                                                            <i class='bi bi-pencil'></i> Edit
                                                        </a>
                                                        <a href='input_izin_guru.php?hapus_kehadiran={$row['id']}' class='btn btn-sm btn-outline-danger' onclick='return confirm(\"Yakin ingin menghapus data ini?\")'>
                                                            <i class='bi bi-trash'></i> Hapus
                                                        </a>
                                                    </div>
                                                </td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='7' class='empty-cell'>Belum ada data kehadiran</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <?php endif; ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const tanggalIzin = document.getElementById('tanggal_izin');
            const tanggalKehadiran = document.getElementById('tanggal_kehadiran');
            
            if (tanggalIzin && !tanggalIzin.value) {
                tanggalIzin.value = new Date().toISOString().substr(0, 10);
            }
            
            if (tanggalKehadiran && !tanggalKehadiran.value) {
                tanggalKehadiran.value = new Date().toISOString().substr(0, 10);
            }
            
            <?php if ($edit_kehadiran): ?>
                const kehadiranTab = new bootstrap.Tab(document.getElementById('kehadiran-tab'));
                kehadiranTab.show();
            <?php endif; ?>
        });
    </script>
</body>
</html>