<?php
session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include "config.php";
date_default_timezone_set("Asia/Jakarta");

$limit = 20;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : date("Y-m-d");
$tanggal_akhir = isset($_GET['tanggal_akhir']) ? $_GET['tanggal_akhir'] : $tanggal;
$filter_tanggal = isset($_GET['filter_tanggal']) ? $_GET['filter_tanggal'] : 'hari';
$kelasFilter = isset($_GET['kelas']) ? $_GET['kelas'] : "";
$namaFilter = isset($_GET['nama']) ? $_GET['nama'] : "";
$statusFilter = isset($_GET['status']) ? $_GET['status'] : "";

$tanggalTampil = date("d/m/Y", strtotime($tanggal));
$tanggalAkhirTampil = date("d/m/Y", strtotime($tanggal_akhir));

$kelasList = [];
$qKelas = mysqli_query($conn, "SELECT DISTINCT kelas FROM siswa WHERE status = 'aktif' ORDER BY kelas ASC");
if ($qKelas) {
    while ($row = mysqli_fetch_assoc($qKelas)) {
        $kelasList[] = $row['kelas'];
    }
}

$check_jam_pulang = mysqli_query($conn, "SHOW COLUMNS FROM absensi LIKE 'jam_pulang'");
$jam_pulang_exists = (mysqli_num_rows($check_jam_pulang) > 0);

if (!$jam_pulang_exists) {
    echo "<div class='alert alert-warning'>Kolom jam_pulang belum tersedia di tabel absensi. Silakan buat kolom terlebih dahulu.</div>";
    
    echo "<form method='POST' class='mb-4'>";
    echo "<button type='submit' name='create_column' class='btn btn-primary btn-create-table'><i class='bi bi-database-add'></i> Buat Kolom Jam Pulang</button>";
    echo "</form>";
    
    if (isset($_POST['create_column'])) {
        $alter_query = mysqli_query($conn, "ALTER TABLE absensi ADD COLUMN jam_pulang TIME NULL AFTER jam");
        if ($alter_query) {
            echo "<div class='alert alert-success'>Kolom jam_pulang berhasil dibuat!</div>";
            $jam_pulang_exists = true;
            echo "<script>setTimeout(function(){ window.location.reload(); }, 2000);</script>";
        } else {
            echo "<div class='alert alert-danger'>Gagal membuat kolom: " . mysqli_error($conn) . "</div>";
        }
    }
}

if (isset($_POST['manual_pulang'])) {
    $absensi_id = (int)$_POST['absensi_id'];
    $jam_pulang = date("H:i:s");
    
    if ($absensi_id > 0) {
        $update_query = mysqli_query($conn, "UPDATE absensi SET jam_pulang='$jam_pulang' WHERE id=$absensi_id");
        
        if ($update_query) {
            echo "<div class='alert alert-success'>Absensi pulang berhasil dicatat.</div>";
            echo "<script>setTimeout(function(){ window.location.reload(); }, 1000);</script>";
        } else {
            echo "<div class='alert alert-danger'>Gagal mencatat absensi pulang: " . mysqli_error($conn) . "</div>";
        }
    } else {
        echo "<div class='alert alert-danger'>Data tidak valid.</div>";
    }
}

if (isset($_POST['hapus_absensi']) && $_SESSION['role'] == 'admin') {
    $absensi_id = (int)$_POST['absensi_id'];
    
    if ($absensi_id > 0) {
        $delete_query = mysqli_query($conn, "DELETE FROM absensi WHERE id = $absensi_id");
        
        if ($delete_query) {
            echo "<div class='alert alert-success'>Data absensi berhasil dihapus.</div>";
            echo "<script>setTimeout(function(){ window.location.reload(); }, 1000);</script>";
        } else {
            echo "<div class='alert alert-danger'>Gagal menghapus data: " . mysqli_error($conn) . "</div>";
        }
    }
}

$data = null;
$total_rows = 0;
if ($jam_pulang_exists) {
    $sql = "
        SELECT 
            a.id, 
            s.id AS siswa_id, 
            s.nis,
            s.nama, 
            s.kelas, 
            a.jam AS jam_masuk, 
            a.jam_pulang,
            a.status,
            a.keterangan,
            a.tanggal
        FROM absensi a
        JOIN siswa s ON a.siswa_id = s.id
        WHERE s.status = 'aktif'
    ";
    
    if ($filter_tanggal == 'hari') {
        $sql .= " AND a.tanggal = '" . mysqli_real_escape_string($conn, $tanggal) . "'";
    } else {
        $sql .= " AND a.tanggal BETWEEN '" . mysqli_real_escape_string($conn, $tanggal) . "' AND '" . mysqli_real_escape_string($conn, $tanggal_akhir) . "'";
    }
    
    if ($kelasFilter !== "") {
        $sql .= " AND s.kelas = '" . mysqli_real_escape_string($conn, $kelasFilter) . "'";
    }
    if ($namaFilter !== "") {
        $sql .= " AND s.nama LIKE '%" . mysqli_real_escape_string($conn, $namaFilter) . "%'";
    }
    if ($statusFilter !== "") {
        $sql .= " AND a.status = '" . mysqli_real_escape_string($conn, $statusFilter) . "'";
    }
    
    $count_sql = "SELECT COUNT(*) as total FROM ($sql) as count_table";
    $count_result = mysqli_query($conn, $count_sql);
    if ($count_result) {
        $count_row = mysqli_fetch_assoc($count_result);
        $total_rows = $count_row['total'];
    }
    
    $sql .= " ORDER BY a.tanggal DESC, s.kelas, s.nama LIMIT $limit OFFSET $offset";
    
    $data = mysqli_query($conn, $sql);
    if (!$data) {
        echo "<div class='alert alert-danger'>Error dalam query: " . mysqli_error($conn) . "</div>";
        $data = null;
    }
}

function getStatusText($status) {
    switch($status) {
        case 'H': return 'Hadir';
        case 'I': return 'Izin';
        case 'S': return 'Sakit';
        case 'A': return 'Alpa';
        default: return $status;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Sistem Absensi QR - Rekap Kehadiran</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --purple:#8b5cf6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1280px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .topbar-actions{
      display:flex;
      align-items:center;
      gap:10px;
      flex-wrap:wrap;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .btn-outline-primary-top{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--brand);
      background:var(--surface);
      border:1px solid rgba(42,82,152,.32);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:background .2s ease, border-color .2s ease, color .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-outline-primary-top:hover{
      background:var(--brand-soft);
      border-color:var(--brand);
      color:var(--brand);
      transform:translateY(-1px);
    }

    .page-wrap{
      max-width:1280px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .info-banner{
      display:flex;
      align-items:flex-start;
      gap:12px;
      padding:14px 18px;
      border-radius:var(--radius-md);
      background:rgba(59,130,246,.08);
      border:1px solid rgba(59,130,246,.2);
      border-left:4px solid var(--info);
      color:#1e40af;
      font-size:13px;
      line-height:1.65;
      margin-bottom:20px;
    }

    .info-banner i{
      margin-top:2px;
      font-size:15px;
      flex-shrink:0;
      color:var(--info);
    }

    .info-banner strong{
      font-weight:600;
      color:#1d4ed8;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      margin-bottom:20px;
      overflow:hidden;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:18px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .card-panel-body{
      padding:22px 24px;
    }

    .form-label{
      display:block;
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
      margin-bottom:7px;
    }

    .form-control,
    .form-select{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
      width:100%;
      outline:none;
    }

    .form-control::placeholder{
      color:var(--muted-2);
    }

    .form-control:hover,
    .form-select:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus,
    .form-select:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-outline-secondary{
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      box-shadow:var(--shadow-sm);
    }
    .btn-outline-secondary:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .btn-info{
      background:linear-gradient(135deg,#3b82f6,#2563eb);
      color:#fff;
      box-shadow:0 10px 20px -10px rgba(37,99,235,.6);
    }
    .btn-info:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-warning{
      background:linear-gradient(135deg,#f59e0b,#d97706);
      color:#fff;
      box-shadow:0 10px 20px -10px rgba(217,119,6,.6);
    }
    .btn-warning:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-danger{
      background:linear-gradient(135deg,#ef4444,#dc2626);
      color:#fff;
      box-shadow:0 10px 20px -10px rgba(220,38,38,.6);
    }
    .btn-danger:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-secondary{
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
    }
    .btn-secondary:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .btn-sm{
      padding:6px 10px;
      font-size:12.5px;
      border-radius:8px;
    }

    .alert{
      padding:14px 18px;
      border-radius:var(--radius-md);
      font-size:13.5px;
      font-weight:500;
      border:1px solid transparent;
      margin-bottom:20px;
      display:flex;
      align-items:flex-start;
      gap:10px;
      line-height:1.55;
    }

    .alert-success{
      background:rgba(16,185,129,.08);
      color:#047857;
      border-color:rgba(16,185,129,.28);
    }

    .alert-warning{
      background:rgba(245,158,11,.08);
      color:#b45309;
      border-color:rgba(245,158,11,.3);
    }

    .alert-danger{
      background:rgba(239,68,68,.08);
      color:#b91c1c;
      border-color:rgba(239,68,68,.28);
    }

    .alert-info{
      background:rgba(59,130,246,.08);
      color:#1d4ed8;
      border-color:rgba(59,130,246,.28);
    }

    .stats-row{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:18px;
    }

    .stat-chip{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:8px 14px;
      font-size:12.5px;
      font-weight:500;
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:999px;
      color:var(--ink-2);
    }

    .stat-chip i{
      color:var(--brand);
      font-size:12px;
    }

    .stat-chip strong{
      color:var(--ink);
      font-weight:600;
    }

    .table-wrapper{
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      overflow:hidden;
      background:var(--surface);
    }

    .table-responsive{
      overflow-x:auto;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
      margin:0;
    }

    .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
    .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-responsive::-webkit-scrollbar-track{background:transparent;}

    .table{
      margin:0;
      --bs-table-bg:transparent;
      --bs-table-border-color:var(--line);
      --bs-table-hover-bg:rgba(42,82,152,.04);
      font-size:13.5px;
      color:var(--ink-2);
      width:100%;
    }

    .table thead th{
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:14px 16px;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    .table tbody td{
      padding:14px 16px;
      vertical-align:middle;
      border-bottom:1px solid var(--line);
      color:var(--ink-2);
    }

    .table tbody tr:hover{
      background:rgba(42,82,152,.04);
    }

    .table tbody tr:last-child td{
      border-bottom:0;
    }

    .cell-strong{
      font-weight:600;
      color:var(--ink);
    }

    .badge-nis{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(16,185,129,.1);
      color:#047857;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-kelas{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(139,92,246,.1);
      color:#6d28d9;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-status{
      display:inline-flex;
      align-items:center;
      gap:5px;
      padding:5px 11px;
      font-size:12px;
      font-weight:500;
      border-radius:999px;
      line-height:1;
    }

    .badge-status.status-hadir{
      background:rgba(16,185,129,.12);
      color:#047857;
    }
    .badge-status.status-izin{
      background:rgba(245,158,11,.14);
      color:#b45309;
    }
    .badge-status.status-sakit{
      background:rgba(139,92,246,.12);
      color:#6d28d9;
    }
    .badge-status.status-tanpa-keterangan{
      background:rgba(239,68,68,.12);
      color:#b91c1c;
    }

    .empty-state{
      text-align:center;
      padding:56px 24px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:42px;
      opacity:.35;
      margin-bottom:14px;
      display:block;
      color:var(--brand);
    }

    .empty-state h4{
      font-size:16px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 6px;
    }

    .empty-state p{
      font-size:13.5px;
      margin:0;
    }

    .pagination{
      display:flex;
      flex-wrap:wrap;
      gap:6px;
      padding:0;
      margin:24px 0 0;
      list-style:none;
      justify-content:center;
    }

    .page-item{
      display:inline-flex;
    }

    .page-link{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      min-width:38px;
      height:38px;
      padding:0 12px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:background .2s ease, border-color .2s ease, color .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .page-link:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .page-item.active .page-link{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      border-color:transparent;
      box-shadow:var(--shadow-brand);
    }

    .modal-content{
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-lg);
      overflow:hidden;
      font-family:'Rubik', sans-serif;
    }

    .modal-header{
      padding:18px 22px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
    }

    .modal-title{
      font-size:15px;
      font-weight:600;
      color:var(--ink);
    }

    .modal-body{
      padding:22px;
      font-size:13.5px;
      color:var(--ink-2);
      line-height:1.6;
    }

    .modal-footer{
      padding:14px 22px;
      border-top:1px solid var(--line);
      background:var(--surface-2);
      gap:8px;
    }

    .modal-body h5{
      font-size:15px;
      font-weight:600;
      color:var(--ink);
      margin:8px 0 16px;
    }

    .modal-body .alert-warning{
      background:rgba(245,158,11,.08);
      color:#b45309;
      border:1px solid rgba(245,158,11,.3);
      padding:12px 14px;
      border-radius:var(--radius-md);
      font-size:13px;
      margin:0;
    }

    .btn-close{
      background:transparent;
      border:0;
      font-size:14px;
      opacity:.5;
      width:auto;
      height:auto;
      padding:4px;
    }

    .btn-close:hover{opacity:.9;}

    .d-grid{display:grid !important;gap:10px;}

    .date-range{display:none;}

    .btn-create-table{
      margin-bottom:16px;
    }

    .action-btns{
      display:inline-flex;
      gap:6px;
      flex-wrap:wrap;
      justify-content:center;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .card-panel-body{padding:18px;}
      .card-panel-header{padding:16px 20px;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .btn-outline-primary-top{padding:8px 12px;font-size:12.5px;}
      .btn-outline-primary-top span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .card-panel{border-radius:var(--radius-md);}
      .card-panel-body{padding:16px;}
      .card-panel-header{padding:14px 16px;}
      .card-panel-title{font-size:13.5px;}
      .btn{padding:9px 14px;font-size:13px;}
      .table thead th,
      .table tbody td{padding:11px 12px;font-size:12.5px;}
      .action-btns{flex-direction:column;gap:5px;}
      .action-btns .btn{width:100%;}
      .stats-row{gap:6px;}
      .stat-chip{padding:6px 12px;font-size:11.5px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="bi bi-clock-history"></i></div>
        <div class="brand-titles">
          <h1>Rekap Kehadiran</h1>
          <span>Laporan absensi siswa dan jam pulang</span>
        </div>
      </div>
      <div class="topbar-actions">
        <a href="absensi.php" class="btn-outline-primary-top">
          <i class="bi bi-qr-code"></i>
          <span>Absensi</span>
        </a>
        <a href="dashboard.php" class="btn-back">
          <i class="bi bi-arrow-left"></i>
          <span>Kembali</span>
        </a>
      </div>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Laporan</span>
      <h2>Rekap Kehadiran</h2>
      <p>Filter, tinjau, dan kelola data kehadiran siswa termasuk jam masuk dan jam pulang.</p>
    </div>

    <div class="info-banner">
      <i class="bi bi-info-circle"></i>
      <div>
        <strong>Info:</strong> Data diambil dari tabel absensi dan siswa aktif. Anda dapat memfilter berdasarkan tanggal, kelas, nama, dan status kehadiran.
      </div>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="bi bi-funnel"></i>
          Filter Data
        </div>
      </div>
      <div class="card-panel-body">
        <form method="GET" class="row g-3">
          <div class="col-12 col-md-3">
            <label class="form-label">Jenis Filter Tanggal</label>
            <select name="filter_tanggal" id="filter_tanggal" class="form-select" onchange="toggleDateRange()">
              <option value="hari" <?= $filter_tanggal == 'hari' ? 'selected' : '' ?>>Hari Ini</option>
              <option value="rentang" <?= $filter_tanggal == 'rentang' ? 'selected' : '' ?>>Rentang Tanggal</option>
            </select>
          </div>
          <div class="col-12 col-md-3" id="tanggal_mulai_container">
            <label class="form-label">Tanggal</label>
            <input type="date" name="tanggal" value="<?= htmlspecialchars($tanggal) ?>" class="form-control">
          </div>
          <div class="col-12 col-md-3 date-range" id="tanggal_akhir_container">
            <label class="form-label">Tanggal Akhir</label>
            <input type="date" name="tanggal_akhir" value="<?= htmlspecialchars($tanggal_akhir) ?>" class="form-control">
          </div>
          <div class="col-12 col-md-3">
            <label class="form-label">Kelas</label>
            <select name="kelas" class="form-select">
              <option value="">Semua Kelas</option>
              <?php foreach ($kelasList as $kelas): ?>
                <option value="<?= htmlspecialchars($kelas) ?>" <?= ($kelas == $kelasFilter) ? "selected" : "" ?>>
                  <?= htmlspecialchars($kelas) ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-12 col-md-3">
            <label class="form-label">Nama Siswa</label>
            <input type="text" name="nama" value="<?= htmlspecialchars($namaFilter) ?>" class="form-control" placeholder="Cari nama...">
          </div>
          <div class="col-12 col-md-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
              <option value="">Semua Status</option>
              <option value="H" <?= $statusFilter == 'H' ? 'selected' : '' ?>>Hadir</option>
              <option value="I" <?= $statusFilter == 'I' ? 'selected' : '' ?>>Izin</option>
              <option value="S" <?= $statusFilter == 'S' ? 'selected' : '' ?>>Sakit</option>
              <option value="A" <?= $statusFilter == 'A' ? 'selected' : '' ?>>Alpa</option>
            </select>
          </div>
          <div class="col-12 d-flex justify-content-end gap-2 flex-wrap">
            <button type="submit" class="btn btn-primary">
              <i class="bi bi-search"></i> Tampilkan
            </button>
            <a href="rekap.php" class="btn btn-outline-secondary">
              <i class="bi bi-arrow-counterclockwise"></i> Reset
            </a>
          </div>
        </form>
      </div>
    </div>

    <?php if ($jam_pulang_exists): ?>
    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="bi bi-list-check"></i>
          Hasil Rekap Kehadiran
        </div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
          <span class="stat-chip">
            <i class="bi bi-database"></i> Total: <strong><?= (int)$total_rows ?></strong> Data
          </span>
          <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#exportModal">
            <i class="bi bi-download"></i> Ekspor
          </button>
        </div>
      </div>
      <div class="card-panel-body">

        <div class="stats-row">
          <span class="stat-chip">
            <i class="bi bi-calendar-week"></i>
            Periode: <strong><?= $filter_tanggal == 'hari' ? $tanggalTampil : $tanggalTampil . ' — ' . $tanggalAkhirTampil ?></strong>
          </span>
          <span class="stat-chip">
            <i class="bi bi-chalkboard"></i>
            Kelas: <strong><?= $kelasFilter ? htmlspecialchars($kelasFilter) : 'Semua Kelas' ?></strong>
          </span>
          <span class="stat-chip">
            <i class="bi bi-tag"></i>
            Status: <strong><?= $statusFilter ? htmlspecialchars(getStatusText($statusFilter)) : 'Semua Status' ?></strong>
          </span>
        </div>

        <?php if ($data && mysqli_num_rows($data) > 0): ?>
          <div class="table-wrapper">
            <div class="table-responsive">
              <table class="table align-middle">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Jam Masuk</th>
                    <th>Jam Pulang</th>
                    <th>Status</th>
                    <th>Keterangan</th>
                    <th class="text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $no = $offset + 1; while($row = mysqli_fetch_assoc($data)): ?>
                    <tr>
                      <td><?= $no++ ?></td>
                      <td><?= date("d/m/Y", strtotime($row['tanggal'])) ?></td>
                      <td><span class="badge-nis"><?= htmlspecialchars($row['nis']) ?></span></td>
                      <td class="cell-strong"><?= htmlspecialchars($row['nama']) ?></td>
                      <td><span class="badge-kelas"><?= htmlspecialchars($row['kelas']) ?></span></td>
                      <td><?= !empty($row['jam_masuk']) ? htmlspecialchars($row['jam_masuk']) : '-' ?></td>
                      <td>
                        <?php if (!empty($row['jam_pulang'])): ?>
                          <span style="color:#047857;font-weight:600;"><i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($row['jam_pulang']) ?></span>
                        <?php else: ?>
                          <span style="color:#b91c1c;font-weight:500;">Belum absen</span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php 
                        $status_class = '';
                        $status_text = '';
                        switch($row['status']) {
                          case 'H': 
                            $status_class = 'status-hadir'; 
                            $status_text = 'Hadir';
                            break;
                          case 'I': 
                            $status_class = 'status-izin'; 
                            $status_text = 'Izin';
                            break;
                          case 'S': 
                            $status_class = 'status-sakit'; 
                            $status_text = 'Sakit';
                            break;
                          case 'A': 
                            $status_class = 'status-tanpa-keterangan'; 
                            $status_text = 'Alpa';
                            break;
                          default: 
                            $status_text = $row['status'];
                        }
                        ?>
                        <span class="badge-status <?= $status_class ?>"><?= $status_text ?></span>
                      </td>
                      <td><?= !empty($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?></td>
                      <td class="text-center">
                        <div class="action-btns">
                          <a href="riwayat.php?id=<?= $row['siswa_id'] ?>" class="btn btn-info btn-sm" title="Riwayat">
                            <i class="bi bi-clock-history"></i>
                          </a>
                          <?php if (empty($row['jam_pulang']) && $row['status'] == 'H'): ?>
                          <button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#pulangModal" 
                                  data-id="<?= $row['id'] ?>" data-nama="<?= htmlspecialchars($row['nama']) ?>"
                                  title="Input Absensi Pulang Manual">
                            <i class="bi bi-pencil"></i>
                          </button>
                          <?php endif; ?>
                          <?php if ($_SESSION['role'] == 'admin'): ?>
                          <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#hapusModal" 
                                  data-id="<?= $row['id'] ?>" data-nama="<?= htmlspecialchars($row['nama']) ?>" data-tanggal="<?= date('d/m/Y', strtotime($row['tanggal'])) ?>"
                                  title="Hapus Absensi">
                            <i class="bi bi-trash"></i>
                          </button>
                          <?php endif; ?>
                        </div>
                      </td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>

          <?php if ($total_rows > $limit): ?>
          <nav aria-label="Page navigation">
            <ul class="pagination">
              <?php if ($page > 1): ?>
              <li class="page-item">
                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" aria-label="Previous">
                  <span aria-hidden="true">&laquo;</span>
                </a>
              </li>
              <?php endif; ?>

              <?php
              $total_pages = ceil($total_rows / $limit);
              $start_page = max(1, $page - 2);
              $end_page = min($total_pages, $start_page + 4);
              
              if ($end_page - $start_page < 4) {
                  $start_page = max(1, $end_page - 4);
              }
              
              for ($i = $start_page; $i <= $end_page; $i++): 
              ?>
              <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
              </li>
              <?php endfor; ?>

              <?php if ($page < $total_pages): ?>
              <li class="page-item">
                <a class="page-link" href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" aria-label="Next">
                  <span aria-hidden="true">&raquo;</span>
                </a>
              </li>
              <?php endif; ?>
            </ul>
          </nav>
          <?php endif; ?>

        <?php else: ?>
          <div class="empty-state">
            <i class="bi bi-inbox"></i>
            <h4>Tidak ada data absensi</h4>
            <p>Tidak ada data absensi untuk kriteria yang dipilih.</p>
          </div>
        <?php endif; ?>

      </div>
    </div>
    <?php endif; ?>

  </div>

  <div class="modal fade" id="pulangModal" tabindex="-1" aria-labelledby="pulangModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="pulangModalLabel">
            <i class="bi bi-pencil-square me-2" style="color:var(--warning);"></i>
            Input Absensi Pulang Manual
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x-lg"></i></button>
        </div>
        <form method="POST">
          <div class="modal-body">
            <input type="hidden" name="absensi_id" id="modal_absensi_id">
            <p>Anda akan mencatat absensi pulang untuk:</p>
            <h5 id="modal_nama_siswa" class="text-center mb-3"></h5>
            <div class="mb-3">
              <label class="form-label">Waktu Pulang</label>
              <input type="time" class="form-control" value="<?= date('H:i') ?>" disabled>
              <div class="form-text" style="font-size:12px;color:var(--muted);margin-top:8px;">Waktu saat ini akan dicatat sebagai jam pulang</div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="manual_pulang" class="btn btn-primary">
              <i class="bi bi-check-lg"></i> Simpan Absensi Pulang
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="modal fade" id="hapusModal" tabindex="-1" aria-labelledby="hapusModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="hapusModalLabel">
            <i class="bi bi-trash me-2" style="color:var(--danger);"></i>
            Hapus Data Absensi
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x-lg"></i></button>
        </div>
        <form method="POST">
          <div class="modal-body">
            <input type="hidden" name="absensi_id" id="hapus_absensi_id">
            <p>Anda yakin ingin menghapus data absensi ini?</p>
            <div class="alert alert-warning">
              <strong>Detail:</strong><br>
              Nama: <span id="hapus_nama_siswa"></span><br>
              Tanggal: <span id="hapus_tanggal"></span>
            </div>
            <p class="text-danger" style="margin-top:12px;font-size:13px;"><i class="bi bi-exclamation-circle me-1"></i> <strong>Peringatan:</strong> Tindakan ini tidak dapat dibatalkan!</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="hapus_absensi" class="btn btn-danger">
              <i class="bi bi-trash"></i> Hapus Data
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="modal fade" id="exportModal" tabindex="-1" aria-labelledby="exportModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exportModalLabel">
            <i class="bi bi-download me-2" style="color:var(--brand);"></i>
            Ekspor Data
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="bi bi-x-lg"></i></button>
        </div>
        <div class="modal-body">
          <p>Pilih format ekspor:</p>
          <div class="d-grid">
            <a href="export.php?<?= http_build_query(array_merge($_GET, ['format' => 'excel'])) ?>" class="btn btn-success">
              <i class="bi bi-file-earmark-excel"></i> Excel
            </a>
            <a href="export.php?<?= http_build_query(array_merge($_GET, ['format' => 'pdf'])) ?>" class="btn btn-danger">
              <i class="bi bi-file-earmark-pdf"></i> PDF
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    var pulangModal = document.getElementById('pulangModal');
    if (pulangModal) {
      pulangModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        var absensiId = button.getAttribute('data-id');
        var namaSiswa = button.getAttribute('data-nama');
        
        document.getElementById('modal_absensi_id').value = absensiId;
        document.getElementById('modal_nama_siswa').textContent = namaSiswa;
      });
    }

    var hapusModal = document.getElementById('hapusModal');
    if (hapusModal) {
      hapusModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        var absensiId = button.getAttribute('data-id');
        var namaSiswa = button.getAttribute('data-nama');
        var tanggal = button.getAttribute('data-tanggal');
        
        document.getElementById('hapus_absensi_id').value = absensiId;
        document.getElementById('hapus_nama_siswa').textContent = namaSiswa;
        document.getElementById('hapus_tanggal').textContent = tanggal;
      });
    }

    function toggleDateRange() {
      var filterType = document.getElementById('filter_tanggal').value;
      var tanggalAkhirContainer = document.getElementById('tanggal_akhir_container');
      var tanggalMulaiLabel = document.querySelector('#tanggal_mulai_container label');
      
      if (filterType === 'rentang') {
        tanggalAkhirContainer.style.display = 'block';
        tanggalMulaiLabel.textContent = 'Tanggal Mulai';
      } else {
        tanggalAkhirContainer.style.display = 'none';
        tanggalMulaiLabel.textContent = 'Tanggal';
      }
    }

    document.addEventListener('DOMContentLoaded', function() {
      toggleDateRange();
    });
  </script>

</body>
</html>