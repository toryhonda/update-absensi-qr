<?php

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

$pesan_notif = $_SESSION['flash_jam_sesi'] ?? "";
unset($_SESSION['flash_jam_sesi']);

$cek_col = mysqli_query($conn, "SHOW COLUMNS FROM pengaturan_jam_sesi LIKE 'is_active'");
if ($cek_col && mysqli_num_rows($cek_col) == 0) {
    @mysqli_query($conn, "ALTER TABLE pengaturan_jam_sesi ADD COLUMN is_active TINYINT(1) DEFAULT 1 AFTER jam_selesai");
}

if (isset($_POST['cleanup_duplikat'])) {
    $q_dup = mysqli_query($conn, "SELECT sesi, COUNT(*) AS jml FROM pengaturan_jam_sesi GROUP BY sesi HAVING jml > 1");
    $total_dup = 0;
    if ($q_dup) {
        while ($r = mysqli_fetch_assoc($q_dup)) {
            $total_dup += ($r['jml'] - 1);
        }
    }

    if ($total_dup == 0) {
        $_SESSION['flash_jam_sesi'] = "<div class='alert alert-info'>Tidak ada duplikat. Tabel sudah bersih.</div>";
    } else {
        $hapus = mysqli_query($conn, "DELETE t1 FROM pengaturan_jam_sesi t1
            INNER JOIN pengaturan_jam_sesi t2
            WHERE t1.sesi = t2.sesi AND t1.id < t2.id");

        if ($hapus) {
            $cek_key = mysqli_query($conn, "SHOW INDEX FROM pengaturan_jam_sesi WHERE Key_name='unique_sesi'");
            if ($cek_key && mysqli_num_rows($cek_key) == 0) {
                @mysqli_query($conn, "ALTER TABLE pengaturan_jam_sesi ADD UNIQUE KEY unique_sesi (sesi)");
            }
            $_SESSION['flash_jam_sesi'] = "<div class='alert alert-success'>Berhasil! <strong>$total_dup baris ganda</strong> dihapus. Sekarang hanya tersisa satu baris per sesi.</div>";
        } else {
            $_SESSION['flash_jam_sesi'] = "<div class='alert alert-danger'>Gagal menghapus data ganda: " . mysqli_error($conn) . "</div>";
        }
    }

    header("Location: jam_absensi_multi.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['simpan_sesi'])) {
    $sesi_list    = $_POST['sesi'] ?? [];
    $mulai_list   = $_POST['jam_mulai'] ?? [];
    $selesai_list = $_POST['jam_selesai'] ?? [];
    $aktif_list   = $_POST['is_active'] ?? [];

    if (count($sesi_list) != count($mulai_list) || count($sesi_list) != count($selesai_list)) {
        $_SESSION['flash_jam_sesi'] = "<div class='alert alert-danger'>Data form tidak valid. Silakan refresh halaman.</div>";
        header("Location: jam_absensi_multi.php");
        exit;
    }

    $ranges = [];
    for ($i = 0; $i < count($sesi_list); $i++) {
        $aktif = isset($aktif_list[$i]) && $aktif_list[$i] == '1' ? 1 : 0;
        if ($aktif) {
            $ranges[] = ['sesi' => $sesi_list[$i], 'mulai' => $mulai_list[$i], 'selesai' => $selesai_list[$i]];
        }
    }
    $overlap = false;
    $n = count($ranges);
    for ($i = 0; $i < $n; $i++) {
        for ($j = $i + 1; $j < $n; $j++) {
            if ($ranges[$i]['mulai'] < $ranges[$j]['selesai'] &&
                $ranges[$i]['selesai'] > $ranges[$j]['mulai']) {
                $overlap = true;
                break 2;
            }
        }
    }

    if ($overlap) {
        $_SESSION['flash_jam_sesi'] = "<div class='alert alert-danger'>Rentang waktu antar sesi <strong>yang aktif</strong> saling bertabrakan. Perbaiki dulu sebelum menyimpan.</div>";
        header("Location: jam_absensi_multi.php");
        exit;
    }

    $success = true;
    $total_aktif = 0;
    for ($i = 0; $i < count($sesi_list); $i++) {
        $sesi    = mysqli_real_escape_string($conn, $sesi_list[$i]);
        $mulai   = mysqli_real_escape_string($conn, $mulai_list[$i]);
        $selesai = mysqli_real_escape_string($conn, $selesai_list[$i]);
        $aktif   = isset($aktif_list[$i]) && $aktif_list[$i] == '1' ? 1 : 0;
        if ($aktif) $total_aktif++;

        $query = "INSERT INTO pengaturan_jam_sesi (sesi, jam_mulai, jam_selesai, is_active)
                  VALUES ('$sesi', '$mulai', '$selesai', $aktif)
                  ON DUPLICATE KEY UPDATE jam_mulai='$mulai', jam_selesai='$selesai', is_active=$aktif";

        if (!mysqli_query($conn, $query)) {
            $success = false;
        }
    }

    if ($success) {
        if ($total_aktif == 0) {
            $_SESSION['flash_jam_sesi'] = "<div class='alert alert-warning'>Pengaturan disimpan, tetapi <strong>belum ada sesi yang aktif</strong>. Siswa tidak dapat melakukan absensi sampai Anda mengaktifkan minimal satu sesi.</div>";
        } else {
            $_SESSION['flash_jam_sesi'] = "<div class='alert alert-success'>Pengaturan berhasil disimpan. <strong>$total_aktif sesi aktif</strong> saat ini.</div>";
        }
    } else {
        $_SESSION['flash_jam_sesi'] = "<div class='alert alert-danger'>Terjadi kesalahan saat menyimpan data: " . mysqli_error($conn) . "</div>";
    }

    header("Location: jam_absensi_multi.php");
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM pengaturan_jam_sesi ORDER BY id DESC");
$jadwalSesi = [];
$jumlahBaris = 0;
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        if (!isset($jadwalSesi[$row['sesi']])) {
            $jadwalSesi[$row['sesi']] = $row;
        }
        $jumlahBaris++;
    }
}

$q_total = mysqli_query($conn, "SELECT COUNT(*) AS total FROM pengaturan_jam_sesi");
$totalRows = ($q_total) ? (int)mysqli_fetch_assoc($q_total)['total'] : 0;
$totalDuplikat = $totalRows - count($jadwalSesi);

$totalAktif = 0;
foreach ($jadwalSesi as $s) {
    if (!empty($s['is_active'])) $totalAktif++;
}

$sesiDefault = ['Masuk', 'Sholat Dhuha', 'Sholat Dhuhur', 'Pulang'];

// Cari sesi yang sedang berlangsung atau sesi aktif berikutnya
$jamNow = date("H:i:s");

$qCurrent = mysqli_query($conn, "SELECT sesi, jam_mulai, jam_selesai FROM pengaturan_jam_sesi 
    WHERE is_active = 1 AND '$jamNow' BETWEEN jam_mulai AND jam_selesai LIMIT 1");
$currentSesi = ($qCurrent && mysqli_num_rows($qCurrent) > 0) ? mysqli_fetch_assoc($qCurrent) : null;

$nextSesi = null;
if (!$currentSesi) {
    $qNext = mysqli_query($conn, "SELECT sesi, jam_mulai, jam_selesai FROM pengaturan_jam_sesi 
        WHERE is_active = 1 AND jam_mulai > '$jamNow'
        ORDER BY jam_mulai ASC LIMIT 1");
    if ($qNext && mysqli_num_rows($qNext) > 0) {
        $nextSesi = mysqli_fetch_assoc($qNext);
    }
}

function formatJamShort($time) {
    return substr($time, 0, 5);
}
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pengaturan Jam Sesi Absensi</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    :root{
      --bg:#f6f8fb;--surface:#ffffff;--surface-2:#f9fafb;--line:#e8edf3;--line-strong:#dbe3ec;
      --ink:#0f172a;--ink-2:#334155;--muted:#64748b;--muted-2:#94a3b8;
      --brand:#2a5298;--brand-2:#1e3c72;--brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;--success:#10b981;--warning:#f59e0b;--danger:#ef4444;--info:#3b82f6;--purple:#8b5cf6;
      --radius-lg:16px;--radius-md:12px;--radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12),0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22),0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }
    *{box-sizing:border-box;}
    body{font-family:'Rubik',sans-serif!important;background:radial-gradient(circle at 0% 0%,rgba(42,82,152,.06),transparent 40%),radial-gradient(circle at 100% 100%,rgba(255,176,32,.05),transparent 40%),var(--bg);min-height:100vh;color:var(--ink);margin:0;padding:0;}
    .topbar{background:rgba(255,255,255,.88);backdrop-filter:blur(14px);border-bottom:1px solid var(--line);position:sticky;top:0;z-index:100;padding:14px 0;}
    .topbar-inner{max-width:900px;margin:0 auto;padding:0 24px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;}
    .brand-block{display:flex;align-items:center;gap:14px;min-width:0;}
    .brand-mark{width:44px;height:44px;border-radius:var(--radius-md);background:linear-gradient(135deg,var(--brand),var(--brand-2));color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:var(--shadow-brand);flex-shrink:0;}
    .brand-titles h1{font-size:17px;font-weight:600;color:var(--ink);margin:0;line-height:1.25;}
    .brand-titles span{display:block;font-size:12.5px;color:var(--muted);margin-top:2px;}
    .btn-back{display:inline-flex;align-items:center;gap:8px;padding:9px 16px;font-size:13.5px;font-weight:500;color:var(--ink-2);background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-sm);text-decoration:none;box-shadow:var(--shadow-sm);transition:all .2s;}
    .btn-back:hover{background:var(--surface-2);color:var(--ink);transform:translateX(-2px);}
    .page-wrap{max-width:900px;margin:0 auto;padding:32px 24px 60px;}
    .page-head{margin-bottom:22px;}
    .page-eyebrow{font-size:11.5px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;color:var(--brand);display:block;margin-bottom:6px;}
    .page-head h2{font-size:24px;font-weight:600;color:var(--ink);margin:0;line-height:1.25;}
    .page-head p{font-size:13.5px;color:var(--muted);margin:8px 0 0;line-height:1.6;max-width:60ch;}
    .info-banner{display:flex;align-items:flex-start;gap:12px;padding:14px 18px;border-radius:var(--radius-md);background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.2);border-left:4px solid var(--info);color:#1e40af;font-size:13px;line-height:1.65;margin-bottom:20px;}
    .info-banner i{margin-top:2px;font-size:15px;flex-shrink:0;color:var(--info);}
    .info-banner strong{font-weight:600;color:#1d4ed8;}
    .card-panel{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);margin-bottom:20px;overflow:hidden;transition:box-shadow .25s ease;}
    .card-panel:hover{box-shadow:var(--shadow-md);}
    .card-panel-header{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 24px;border-bottom:1px solid var(--line);background:var(--surface-2);flex-wrap:wrap;}
    .card-panel-title{display:flex;align-items:center;gap:10px;font-size:14.5px;font-weight:600;color:var(--ink);}
    .card-panel-title i{width:32px;height:32px;border-radius:var(--radius-sm);background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;font-size:14px;}
    .card-panel-title.warning i{background:rgba(245,158,11,.12);color:var(--warning);}
    .card-panel-body{padding:24px;}
    .session-count-badge{display:inline-flex;align-items:center;gap:6px;padding:5px 12px;border-radius:999px;background:var(--brand-soft);color:var(--brand);font-size:12px;font-weight:600;letter-spacing:.2px;}
    .session-count-badge i{font-size:11px;}
    .session-header{display:grid;grid-template-columns:1fr 1fr 1fr 90px;gap:14px;padding:12px 16px;background:var(--surface-2);border:1px solid var(--line);border-radius:var(--radius-md);margin-bottom:12px;font-size:11.5px;font-weight:600;letter-spacing:.6px;text-transform:uppercase;color:var(--muted);}
    .session-row{display:grid;grid-template-columns:1fr 1fr 1fr 90px;gap:14px;padding:14px 16px;background:var(--surface-2);border:1px solid var(--line);border-radius:var(--radius-md);margin-bottom:10px;align-items:center;transition:all .2s;}
    .session-row:hover{border-color:var(--line-strong);box-shadow:var(--shadow-sm);}
    .session-row.disabled{opacity:.55;background:#f1f5f9;}
    .session-row:last-child{margin-bottom:0;}
    .session-name{display:flex;align-items:center;gap:10px;font-size:14px;font-weight:600;color:var(--ink);}
    .session-name i{width:32px;height:32px;border-radius:var(--radius-sm);background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;font-size:13px;flex-shrink:0;}
    .session-row[data-session="Masuk"] .session-name i{background:rgba(16,185,129,.12);color:var(--success);}
    .session-row[data-session="Sholat Dhuha"] .session-name i{background:rgba(245,158,11,.12);color:var(--warning);}
    .session-row[data-session="Sholat Dhuhur"] .session-name i{background:rgba(139,92,246,.12);color:var(--purple);}
    .session-row[data-session="Pulang"] .session-name i{background:rgba(239,68,68,.12);color:var(--danger);}
    .time-field-label{display:none;font-size:11px;font-weight:500;color:var(--muted);margin-bottom:5px;}
    .form-control{font-family:'Rubik',monospace;font-size:14px;color:var(--ink);background:#fff;border:1px solid var(--line);border-radius:var(--radius-sm);padding:10px 14px;transition:all .2s;width:100%;outline:none;font-weight:500;letter-spacing:.5px;}
    .form-control:hover{border-color:var(--line-strong);}
    .form-control:focus{border-color:var(--brand);box-shadow:0 0 0 4px var(--brand-soft);}
    .toggle-cell{display:flex;flex-direction:column;align-items:center;gap:4px;}
    .toggle-label-mini{display:none;font-size:10.5px;font-weight:600;color:var(--muted);letter-spacing:.4px;text-transform:uppercase;}
    .switch{position:relative;display:inline-block;width:52px;height:28px;cursor:pointer;}
    .switch input{opacity:0;width:0;height:0;}
    .slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background:#cbd5e1;transition:.3s;border-radius:999px;box-shadow:inset 0 2px 4px rgba(15,23,42,.1);}
    .slider:before{position:absolute;content:"";height:22px;width:22px;left:3px;bottom:3px;background:#fff;transition:.3s;border-radius:50%;box-shadow:0 2px 4px rgba(15,23,42,.25);}
    .switch input:checked + .slider{background:linear-gradient(135deg,#10b981,#059669);}
    .switch input:checked + .slider:before{transform:translateX(24px);}
    .switch input:focus-visible + .slider{box-shadow:0 0 0 4px var(--brand-soft);}
    .status-text{font-size:10.5px;font-weight:600;color:var(--muted);letter-spacing:.3px;text-transform:uppercase;}
    .status-text.on{color:var(--success);}
    .status-text.off{color:var(--muted-2);}
    .btn{font-family:inherit;font-size:13.5px;font-weight:500;border-radius:var(--radius-sm);padding:11px 18px;transition:all .2s;display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;cursor:pointer;line-height:1.2;text-decoration:none;}
    .btn-primary{background:linear-gradient(135deg,var(--brand),var(--brand-2));color:#fff;box-shadow:var(--shadow-brand);}
    .btn-primary:hover{filter:brightness(1.08);transform:translateY(-1px);color:#fff;}
    .btn-warning{background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;box-shadow:0 12px 24px -12px rgba(217,119,6,.7);}
    .btn-warning:hover{filter:brightness(1.08);transform:translateY(-1px);color:#fff;}
    .btn-lg-full{width:100%;padding:14px 20px;font-size:14.5px;}
    .tips-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-top:18px;}
    .tip-card{padding:16px 18px;border-radius:var(--radius-md);background:var(--surface-2);border:1px solid var(--line);display:flex;gap:12px;align-items:flex-start;}
    .tip-card i{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:13px;flex-shrink:0;}
    .tip-card.tip-info i{background:rgba(59,130,246,.12);color:var(--info);}
    .tip-card.tip-warning i{background:rgba(245,158,11,.12);color:var(--warning);}
    .tip-card.tip-success i{background:rgba(16,185,129,.12);color:var(--success);}
    .tip-text{font-size:12.5px;color:var(--muted);line-height:1.6;}
    .tip-text strong{display:block;color:var(--ink);font-weight:600;font-size:13px;margin-bottom:3px;}
    .duplikat-warning{display:flex;align-items:center;gap:12px;padding:14px 18px;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.3);border-left:4px solid var(--warning);border-radius:var(--radius-md);margin-bottom:16px;font-size:13.5px;color:#b45309;line-height:1.55;}
    .duplikat-warning i{font-size:20px;color:var(--warning);flex-shrink:0;}
    .duplikat-warning strong{color:#92400e;font-weight:600;}

    .info-strip{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:22px;}
    .info-tile{padding:18px 20px;background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-md);display:flex;align-items:flex-start;gap:14px;box-shadow:var(--shadow-sm);transition:transform .2s ease, box-shadow .2s ease;}
    .info-tile:hover{transform:translateY(-2px);box-shadow:var(--shadow-md);}
    .info-tile .tile-icon{width:44px;height:44px;border-radius:var(--radius-sm);display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0;}
    .info-tile.scan-running .tile-icon{background:rgba(16,185,129,.12);color:var(--success);}
    .info-tile.scan-next .tile-icon{background:rgba(59,130,246,.12);color:var(--info);}
    .info-tile.scan-none .tile-icon{background:rgba(148,163,184,.15);color:var(--muted);}
    .info-tile.data-clean .tile-icon{background:rgba(16,185,129,.12);color:var(--success);}
    .info-tile.data-dup .tile-icon{background:rgba(245,158,11,.12);color:var(--warning);}
    .info-tile .tile-content{flex:1;min-width:0;}
    .info-tile .tile-label{font-size:11px;font-weight:600;letter-spacing:.6px;text-transform:uppercase;color:var(--muted);display:block;margin-bottom:4px;}
    .info-tile .tile-value{font-size:16px;font-weight:600;color:var(--ink);letter-spacing:-.2px;line-height:1.3;}
    .info-tile .tile-sub{font-size:12.5px;color:var(--muted);margin-top:3px;line-height:1.45;}

    @media (max-width:900px){.topbar-inner{padding:0 18px;}.page-wrap{padding:24px 18px 48px;}.page-head h2{font-size:21px;}.card-panel-body{padding:20px;}.card-panel-header{padding:16px 20px;}}
    @media (max-width:640px){
      .topbar{padding:12px 0;}.topbar-inner{padding:0 14px;}.brand-mark{width:38px;height:38px;}.brand-titles h1{font-size:15px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}.btn-back span{display:none;}.page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}.card-panel-body{padding:16px;}.card-panel-header{padding:14px 16px;}
      .session-header{display:none;}
      .session-row{grid-template-columns:1fr;gap:10px;padding:16px;}
      .session-name{margin-bottom:4px;}.time-field-label{display:block;}
      .toggle-cell{flex-direction:row;justify-content:flex-start;gap:10px;}
      .toggle-label-mini{display:inline-block;}
      .btn-lg-full{padding:13px 18px;font-size:14px;}.tips-grid{grid-template-columns:1fr;}
      .info-strip{grid-template-columns:1fr;}
    }
    @media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important;}}
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-clock"></i></div>
        <div class="brand-titles">
          <h1>Pengaturan Jam Sesi</h1>
          <span>Atur rentang waktu &amp; aktifkan sesi absensi</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Konfigurasi</span>
      <h2>Pengaturan Jam Sesi Absensi</h2>
      <p>Aktifkan sesi yang dipakai hari ini. Sesi nonaktif dilewati saat scan QR.</p>
    </div>

    <div class="info-banner">
      <i class="fas fa-info-circle"></i>
      <div>
        Sesi nonaktif dilewati sistem. Jam tetap tersimpan dan bisa diaktifkan kembali kapan saja.
      </div>
    </div>

    <div class="info-strip">
      <div class="info-tile <?= $currentSesi ? 'scan-running' : ($nextSesi ? 'scan-next' : 'scan-none') ?>">
        <div class="tile-icon">
          <i class="fas <?= $currentSesi ? 'fa-play-circle' : ($nextSesi ? 'fa-hourglass-half' : 'fa-moon') ?>"></i>
        </div>
        <div class="tile-content">
          <span class="tile-label">Scan Berikutnya</span>
          <?php if ($currentSesi): ?>
            <div class="tile-value">Sedang Berlangsung</div>
            <div class="tile-sub">
              <?= htmlspecialchars($currentSesi['sesi']) ?> &middot;
              sampai <?= formatJamShort($currentSesi['jam_selesai']) ?>
            </div>
          <?php elseif ($nextSesi): ?>
            <div class="tile-value"><?= htmlspecialchars($nextSesi['sesi']) ?></div>
            <div class="tile-sub">
              <?= formatJamShort($nextSesi['jam_mulai']) ?> &ndash; <?= formatJamShort($nextSesi['jam_selesai']) ?>
            </div>
          <?php else: ?>
            <div class="tile-value">Tidak Ada</div>
            <div class="tile-sub">Tidak ada sesi aktif berikutnya hari ini</div>
          <?php endif; ?>
        </div>
      </div>

      <div class="info-tile <?= $totalDuplikat > 0 ? 'data-dup' : 'data-clean' ?>">
        <div class="tile-icon">
          <i class="fas <?= $totalDuplikat > 0 ? 'fa-exclamation-triangle' : 'fa-database' ?>"></i>
        </div>
        <div class="tile-content">
          <span class="tile-label">Data Ganda</span>
          <?php if ($totalDuplikat > 0): ?>
            <div class="tile-value"><?= $totalDuplikat ?> Baris</div>
            <div class="tile-sub">Perlu dirapikan agar sesi terdeteksi tepat</div>
          <?php else: ?>
            <div class="tile-value">Tidak Ada</div>
            <div class="tile-sub"><?= $totalAktif ?> dari <?= count($jadwalSesi) ?> sesi aktif</div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <?php if ($totalDuplikat > 0): ?>
      <div class="duplikat-warning">
        <i class="fas fa-exclamation-triangle"></i>
        <div>
          <strong>Data ganda ditemukan.</strong> Klik tombol di bawah untuk menghapus versi lama — sistem menyimpan versi terbaru setiap sesi.
        </div>
      </div>

      <div class="card-panel">
        <div class="card-panel-header">
          <div class="card-panel-title warning">
            <i class="fas fa-broom"></i>
            Pembersihan Data
          </div>
        </div>
        <div class="card-panel-body">
          <p style="margin:0 0 14px;font-size:13.5px;color:var(--muted);line-height:1.6;">
            Baris lama akan dihapus, hanya <strong>versi terbaru</strong> yang disimpan untuk setiap sesi. Kunci unik ditambahkan otomatis agar masalah serupa tidak terulang.
          </p>
          <form method="POST">
            <button type="submit" name="cleanup_duplikat" class="btn btn-warning btn-lg-full" onclick="return konfirmasiCleanup();">
              <i class="fas fa-broom"></i> Hapus Versi Lama (<?= $totalDuplikat ?> baris ganda)
            </button>
          </form>
        </div>
      </div>
    <?php endif; ?>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-sliders-h"></i>
          Daftar Sesi Absensi
        </div>
        <span class="session-count-badge">
          <i class="fas fa-toggle-on"></i> <?= $totalAktif ?> dari <?= count($jadwalSesi) ?> aktif
        </span>
      </div>
      <div class="card-panel-body">

        <form method="POST" action="" id="formSesi">

          <div class="session-header">
            <div>Sesi Absensi</div>
            <div>Jam Mulai</div>
            <div>Jam Selesai</div>
            <div style="text-align:center;">Aktif</div>
          </div>

          <?php foreach ($sesiDefault as $i => $sesi):
            $mulai = $jadwalSesi[$sesi]['jam_mulai'] ?? '00:00:00';
            $selesai = $jadwalSesi[$sesi]['jam_selesai'] ?? '00:00:00';
            $is_active = isset($jadwalSesi[$sesi]['is_active']) ? (int)$jadwalSesi[$sesi]['is_active'] : 1;

            $icon = 'fa-clock';
            if ($sesi === 'Masuk') $icon = 'fa-sign-in-alt';
            if ($sesi === 'Sholat Dhuha') $icon = 'fa-sun';
            if ($sesi === 'Sholat Dhuhur') $icon = 'fa-mosque';
            if ($sesi === 'Pulang') $icon = 'fa-sign-out-alt';
          ?>
          <div class="session-row <?= $is_active ? '' : 'disabled' ?>" data-session="<?= htmlspecialchars($sesi) ?>">
            <div class="session-name">
              <i class="fas <?= $icon ?>"></i>
              <span><?= htmlspecialchars($sesi) ?></span>
              <input type="hidden" name="sesi[]" value="<?= htmlspecialchars($sesi) ?>">
            </div>
            <div class="time-field">
              <label class="time-field-label">Jam Mulai</label>
              <input type="time" name="jam_mulai[]" step="1" class="form-control" value="<?= htmlspecialchars($mulai) ?>" required>
            </div>
            <div class="time-field">
              <label class="time-field-label">Jam Selesai</label>
              <input type="time" name="jam_selesai[]" step="1" class="form-control" value="<?= htmlspecialchars($selesai) ?>" required>
            </div>
            <div class="toggle-cell">
              <label class="toggle-label-mini">Aktif</label>
              <label class="switch" title="<?= $is_active ? 'Sesi aktif' : 'Sesi nonaktif' ?>">
                <input type="hidden" name="is_active[<?= $i ?>]" value="0">
                <input type="checkbox" name="is_active[<?= $i ?>]" value="1" <?= $is_active ? 'checked' : '' ?> onchange="toggleRow(this)">
                <span class="slider"></span>
              </label>
              <span class="status-text <?= $is_active ? 'on' : 'off' ?>"><?= $is_active ? 'Aktif' : 'Nonaktif' ?></span>
            </div>
          </div>
          <?php endforeach; ?>

          <div style="margin-top:22px;">
            <button type="submit" name="simpan_sesi" class="btn btn-primary btn-lg-full">
              <i class="fas fa-save"></i> Simpan Pengaturan
            </button>
          </div>

        </form>

      </div>
    </div>

    <div class="tips-grid">
      <div class="tip-card tip-info">
        <i class="fas fa-archive"></i>
        <div class="tip-text">
          <strong>Jam Nonaktif Tetap Tersimpan</strong>
          Sesi yang dinonaktifkan tidak kehilangan jam. Aktifkan kembali kapan saja tanpa set ulang.
        </div>
      </div>
      <div class="tip-card tip-warning">
        <i class="fas fa-shield-halved"></i>
        <div class="tip-text">
          <strong>Validasi Anti Bentrok</strong>
          Dua sesi aktif dengan jam tumpang-tindih akan ditolak sistem.
        </div>
      </div>
      <div class="tip-card tip-success">
        <i class="fas fa-bolt"></i>
        <div class="tip-text">
          <strong>Berlaku Langsung</strong>
          Perubahan berlaku pada scan berikutnya, tanpa perlu restart.
        </div>
      </div>
    </div>

  </div>

  <script>
    function toggleRow(checkbox) {
      const row = checkbox.closest('.session-row');
      const statusText = row.querySelector('.status-text');
      if (checkbox.checked) {
        row.classList.remove('disabled');
        statusText.textContent = 'Aktif';
        statusText.classList.remove('off');
        statusText.classList.add('on');
      } else {
        row.classList.add('disabled');
        statusText.textContent = 'Nonaktif';
        statusText.classList.remove('on');
        statusText.classList.add('off');
      }
    }

    function konfirmasiCleanup() {
      Swal.fire({
        icon: 'warning',
        title: 'Hapus Versi Lama?',
        html: 'Baris lama akan dihapus, hanya <b>versi terbaru</b> yang disimpan untuk setiap sesi.',
        showCancelButton: true,
        confirmButtonText: '<i class="fas fa-broom"></i> Ya, Hapus',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#f59e0b',
        cancelButtonColor: '#64748b',
        reverseButtons: true,
        customClass: {
          popup: 'swal-modern-popup',
          title: 'swal-modern-title',
          htmlContainer: 'swal-modern-text',
          confirmButton: 'swal-modern-confirm'
        }
      }).then(function(result) {
        if (result.isConfirmed) {
          document.querySelector('button[name="cleanup_duplikat"]').closest('form').submit();
        }
      });
      return false;
    }

    <?php if (!empty($pesan_notif)): ?>
      (function() {
        var pesanRaw = <?= json_encode($pesan_notif); ?>;
        var temp = document.createElement('div');
        temp.innerHTML = pesanRaw;
        var alertEl = temp.querySelector('.alert');

        var iconType = 'info';
        var titleText = 'Informasi';
        if (alertEl && alertEl.classList.contains('alert-success')) { iconType = 'success'; titleText = 'Berhasil'; }
        else if (alertEl && alertEl.classList.contains('alert-warning')) { iconType = 'warning'; titleText = 'Perhatian'; }
        else if (alertEl && alertEl.classList.contains('alert-danger')) { iconType = 'error'; titleText = 'Gagal'; }

        var bodyText = alertEl ? alertEl.innerHTML : pesanRaw;

        Swal.fire({
          icon: iconType,
          title: titleText,
          html: bodyText.replace(/<i class=['"]fas[^>]*><\/i>/g, '').trim(),
          confirmButtonColor: '#2a5298',
          confirmButtonText: 'Mengerti',
          customClass: {
            popup: 'swal-modern-popup',
            title: 'swal-modern-title',
            htmlContainer: 'swal-modern-text',
            confirmButton: 'swal-modern-confirm'
          }
        });
      })();
    <?php endif; ?>
  </script>

  <style>
    .swal-modern-popup{border-radius:20px !important;padding:28px 26px 22px !important;box-shadow:0 30px 60px -20px rgba(15,23,42,.35) !important;font-family:'Rubik',system-ui,sans-serif !important;border:1px solid #e8edf3 !important;}
    .swal-modern-title{font-size:19px !important;font-weight:600 !important;letter-spacing:-.25px !important;color:#0f172a !important;padding:0 !important;margin:14px 0 6px !important;}
    .swal-modern-text{font-size:14px !important;color:#64748b !important;line-height:1.6 !important;margin:0 !important;padding:0 !important;}
    .swal-modern-text strong{color:#0f172a;font-weight:600;}
    .swal-modern-confirm{border-radius:12px !important;font-family:'Rubik',system-ui,sans-serif !important;font-weight:500 !important;font-size:14px !important;padding:11px 26px !important;box-shadow:0 14px 26px -14px rgba(30,60,114,.75) !important;margin-top:18px !important;}
    .swal2-icon.swal2-warning{border-color:#f59e0b !important;color:#f59e0b !important;}
    .swal2-icon.swal2-success{border-color:#10b981 !important;color:#10b981 !important;}
    .swal2-icon.swal2-error{border-color:#ef4444 !important;color:#ef4444 !important;}
    .swal2-icon.swal2-info{border-color:#3b82f6 !important;color:#3b82f6 !important;}
    .swal2-cancel{border-radius:12px !important;font-family:'Rubik',sans-serif !important;font-weight:500 !important;font-size:14px !important;padding:11px 22px !important;margin-top:18px !important;}
    .swal2-actions{gap:8px !important;}
  </style>

</body>
</html>