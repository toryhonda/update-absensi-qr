<?php

session_start();
include 'config.php';

if (!defined('APP_VERSION')) {
    define('APP_VERSION', '4.00');
}

$qProfil = mysqli_query($conn, "SELECT nama_sekolah FROM profil_sekolah LIMIT 1");
$profil  = mysqli_fetch_assoc($qProfil);
$nama_sekolah = $profil['nama_sekolah'] ?? 'Sistem Absensi Digital';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kontak Developer - <?= htmlspecialchars($nama_sekolah); ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --success:#10b981;
      --success-dark:#047857;
      --success-soft:rgba(16,185,129,.08);
      --danger:#ef4444;
      --danger-dark:#b91c1c;
      --danger-soft:rgba(239,68,68,.08);
      --radius-xl:20px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 42%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 42%),
        var(--bg) !important;
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:32px 20px 48px;
      display:flex;
      align-items:center;
      justify-content:center;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .contact-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-xl);
      box-shadow:var(--shadow-lg);
      width:100%;
      max-width:520px;
      overflow:hidden;
      animation:fadeUp .5s ease both;
      position:relative;
    }

    @keyframes fadeUp{
      from{opacity:0; transform:translateY(10px);}
      to{opacity:1; transform:translateY(0);}
    }

    .card-hero{
      position:relative;
      padding:32px 28px 26px;
      text-align:center;
      background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
      color:#fff;
      overflow:hidden;
    }

    .card-hero::before{
      content:"";
      position:absolute;
      top:-90px;
      right:-70px;
      width:220px;
      height:220px;
      border-radius:50%;
      background:radial-gradient(circle, rgba(255,255,255,.16), transparent 65%);
      pointer-events:none;
    }

    .card-hero::after{
      content:"";
      position:absolute;
      bottom:-100px;
      left:-80px;
      width:200px;
      height:200px;
      border-radius:50%;
      background:radial-gradient(circle, rgba(255,176,32,.20), transparent 65%);
      pointer-events:none;
    }

    .developer-avatar{
      width:84px;
      height:84px;
      border-radius:50%;
      background:rgba(255,255,255,.16);
      border:2px solid rgba(255,255,255,.32);
      display:flex;
      align-items:center;
      justify-content:center;
      margin:0 auto 16px;
      font-size:34px;
      color:#fff;
      position:relative;
      z-index:1;
      box-shadow:0 10px 24px -10px rgba(0,0,0,.35);
    }

    .card-hero h1{
      font-size:22px;
      font-weight:600;
      letter-spacing:-.3px;
      margin:0 0 6px;
      color:#fff;
      position:relative;
      z-index:1;
      line-height:1.3;
    }

    .card-hero p{
      font-size:13px;
      color:rgba(255,255,255,.82);
      margin:0;
      position:relative;
      z-index:1;
      line-height:1.55;
    }

    .card-body-inner{
      padding:26px 28px 28px;
    }

    .contact-list{
      display:flex;
      flex-direction:column;
      gap:12px;
      margin-bottom:22px;
    }

    .contact-item{
      display:flex;
      align-items:center;
      gap:14px;
      padding:14px 16px;
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      text-decoration:none;
      color:var(--ink-2);
      transition:border-color .2s ease, background .2s ease, transform .2s ease, box-shadow .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .contact-item:hover{
      background:#fff;
      border-color:var(--brand);
      transform:translateY(-2px);
      box-shadow:var(--shadow-md);
      color:var(--ink);
    }

    .contact-item:focus-visible{
      outline:3px solid var(--brand-soft);
      outline-offset:2px;
    }

    .contact-icon{
      width:46px;
      height:46px;
      border-radius:var(--radius-sm);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:20px;
      flex-shrink:0;
      transition:transform .2s ease;
    }

    .contact-item:hover .contact-icon{
      transform:scale(1.06);
    }

    .contact-icon.wa{
      background:var(--success-soft);
      color:var(--success-dark);
    }

    .contact-icon.mail{
      background:var(--danger-soft);
      color:var(--danger-dark);
    }

    .contact-text{
      flex:1;
      min-width:0;
    }

    .contact-text .ct-label{
      font-size:13.5px;
      font-weight:600;
      color:var(--ink);
      display:block;
      margin-bottom:2px;
      line-height:1.35;
    }

    .contact-text .ct-value{
      font-size:12.5px;
      color:var(--muted);
      display:block;
      line-height:1.4;
      word-break:break-word;
    }

    .contact-arrow{
      font-size:12px;
      color:var(--muted-2);
      flex-shrink:0;
      transition:transform .2s ease, color .2s ease;
    }

    .contact-item:hover .contact-arrow{
      color:var(--brand);
      transform:translateX(3px);
    }

    .btn-back{
      display:flex;
      align-items:center;
      justify-content:center;
      gap:10px;
      width:100%;
      padding:13px 20px;
      font-family:inherit;
      font-size:14px;
      font-weight:600;
      letter-spacing:.2px;
      color:#fff !important;
      background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
      border:none;
      border-radius:var(--radius-md);
      text-decoration:none;
      box-shadow:var(--shadow-brand);
      transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
    }

    .btn-back i{font-size:13px;}

    .btn-back:hover{
      transform:translateY(-2px);
      filter:brightness(1.08);
      color:#fff;
      box-shadow:0 20px 36px -16px rgba(30,60,114,.75);
    }

    .btn-back:active{transform:translateY(0);}

    .btn-back:focus-visible{
      outline:3px solid rgba(42,82,152,.35);
      outline-offset:3px;
    }

    .card-foot{
      padding:14px 28px 20px;
      text-align:center;
      font-size:12px;
      color:var(--muted);
      border-top:1px solid var(--line);
      background:var(--surface-2);
      letter-spacing:.2px;
      line-height:1.55;
    }

    .card-foot strong{
      color:var(--ink-2);
      font-weight:600;
    }

    @media (max-width:520px){
      body{padding:20px 14px 32px;}
      .card-hero{padding:26px 22px 22px;}
      .developer-avatar{width:72px;height:72px;font-size:28px;}
      .card-hero h1{font-size:19px;}
      .card-hero p{font-size:12.5px;}
      .card-body-inner{padding:22px 22px 24px;}
      .contact-item{padding:12px 14px;}
      .contact-icon{width:42px;height:42px;font-size:18px;}
      .contact-text .ct-label{font-size:13px;}
      .contact-text .ct-value{font-size:12px;}
      .btn-back{font-size:13.5px;padding:12px 18px;}
      .card-foot{padding:12px 22px 16px;font-size:11.5px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="contact-card">

    <div class="card-hero">
      <div class="developer-avatar">
        <i class="fas fa-code"></i>
      </div>
      <h1>Kontak Developer</h1>
      <p>Butuh bantuan teknis atau pengembangan sistem?</p>
    </div>

    <div class="card-body-inner">
      <div class="contact-list">

        <a href="https://wa.me/6289654630099" target="_blank" rel="noopener" class="contact-item">
          <span class="contact-icon wa">
            <i class="fab fa-whatsapp"></i>
          </span>
          <span class="contact-text">
            <span class="ct-label">WhatsApp</span>
            <span class="ct-value">+62 896-5463-0099</span>
          </span>
          <i class="fas fa-arrow-right contact-arrow"></i>
        </a>

        <a href="mailto:admin@rafazmalik.my.id" class="contact-item">
          <span class="contact-icon mail">
            <i class="fas fa-envelope"></i>
          </span>
          <span class="contact-text">
            <span class="ct-label">Email Resmi</span>
            <span class="ct-value">tory@autowebportal.com</span>
          </span>
          <i class="fas fa-arrow-right contact-arrow"></i>
        </a>

      </div>

      <a href="index.php" class="btn-back">
        <i class="fas fa-arrow-left"></i> Kembali ke Halaman Login
      </a>
    </div>

    <div class="card-foot">
      <strong>Aplikasi versi <?= htmlspecialchars(APP_VERSION); ?></strong> &middot; Sistem Absensi QR
    </div>

  </div>

</body>
</html>