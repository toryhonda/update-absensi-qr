<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

if (!isset($_GET['confirm']) || $_GET['confirm'] != 'yes') {
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Konfirmasi Hapus Data</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
        <style>
            :root{
                --bg:#f6f8fb;
                --surface:#ffffff;
                --surface-2:#f9fafb;
                --line:#e8edf3;
                --line-strong:#dbe3ec;
                --ink:#0f172a;
                --ink-2:#334155;
                --muted:#64748b;
                --muted-2:#94a3b8;
                --brand:#2a5298;
                --brand-2:#1e3c72;
                --brand-soft:rgba(42,82,152,.08);
                --danger:#ef4444;
                --danger-dark:#b91c1c;
                --danger-soft:rgba(239,68,68,.08);
                --danger-line:rgba(239,68,68,.22);
                --warning:#f59e0b;
                --radius-xl:22px;
                --radius-lg:16px;
                --radius-md:12px;
                --radius-sm:10px;
                --shadow-sm:0 1px 2px rgba(15,23,42,.05);
                --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
                --shadow-lg:0 24px 50px -22px rgba(15,23,42,.28), 0 10px 22px -14px rgba(15,23,42,.14);
                --shadow-danger:0 14px 30px -14px rgba(239,68,68,.55);
            }

            *{box-sizing:border-box;}

            html,body{margin:0;padding:0;}

            body{
                font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
                background:
                    radial-gradient(circle at 0% 0%, rgba(239,68,68,.06), transparent 42%),
                    radial-gradient(circle at 100% 100%, rgba(42,82,152,.06), transparent 42%),
                    var(--bg);
                min-height:100vh;
                display:flex;
                justify-content:center;
                align-items:center;
                padding:28px 20px;
                color:var(--ink);
                -webkit-font-smoothing:antialiased;
                -moz-osx-font-smoothing:grayscale;
            }

            .confirm-shell{
                background:var(--surface);
                border:1px solid var(--line);
                border-radius:var(--radius-xl);
                box-shadow:var(--shadow-lg);
                max-width:540px;
                width:100%;
                overflow:hidden;
                position:relative;
                animation:fadeUp .5s ease both;
            }

            .confirm-shell::before{
                content:"";
                position:absolute;
                top:0;left:0;right:0;
                height:4px;
                background:linear-gradient(90deg, #f59e0b, #ef4444);
            }

            @keyframes fadeUp{
                from{opacity:0; transform:translateY(10px);}
                to{opacity:1; transform:translateY(0);}
            }

            .confirm-head{
                padding:32px 32px 22px;
                text-align:center;
                background:linear-gradient(180deg, #fef7f7 0%, #ffffff 100%);
                border-bottom:1px solid var(--line);
            }

            .warn-icon{
                width:64px;
                height:64px;
                border-radius:50%;
                display:inline-flex;
                align-items:center;
                justify-content:center;
                background:linear-gradient(135deg, #fef3c7, #fee2e2);
                border:1px solid var(--danger-line);
                color:var(--danger);
                font-size:26px;
                margin-bottom:16px;
                box-shadow:0 10px 22px -12px rgba(239,68,68,.45);
            }

            .confirm-head h2{
                margin:0 0 8px;
                font-size:20px;
                font-weight:600;
                letter-spacing:-.3px;
                color:var(--ink);
                line-height:1.3;
            }

            .confirm-head p{
                margin:0;
                font-size:13.5px;
                color:var(--muted);
                line-height:1.55;
            }

            .confirm-body{
                padding:26px 32px 28px;
            }

            .target-list{
                display:grid;
                grid-template-columns:repeat(2, 1fr);
                gap:10px;
                margin-bottom:18px;
            }

            .target-item{
                display:flex;
                align-items:center;
                gap:10px;
                padding:11px 14px;
                border-radius:var(--radius-md);
                background:var(--surface-2);
                border:1px solid var(--line);
                font-size:13px;
                font-weight:500;
                color:var(--ink-2);
                transition:border-color .2s ease, background .2s ease;
            }

            .target-item i{
                width:26px;
                height:26px;
                border-radius:8px;
                display:inline-flex;
                align-items:center;
                justify-content:center;
                font-size:12px;
                color:var(--danger);
                background:var(--danger-soft);
                flex-shrink:0;
            }

            .warning-box{
                display:flex;
                align-items:flex-start;
                gap:12px;
                padding:14px 16px;
                border-radius:var(--radius-md);
                background:var(--danger-soft);
                border:1px solid var(--danger-line);
                border-left:4px solid var(--danger);
                margin-bottom:14px;
            }

            .warning-box i{
                color:var(--danger);
                font-size:15px;
                margin-top:2px;
                flex-shrink:0;
            }

            .warning-box p{
                margin:0;
                font-size:13px;
                font-weight:500;
                color:var(--danger-dark);
                line-height:1.6;
            }

            .backup-note{
                display:flex;
                align-items:center;
                gap:10px;
                padding:12px 14px;
                border-radius:var(--radius-md);
                background:var(--brand-soft);
                border:1px solid rgba(42,82,152,.16);
                font-size:12.5px;
                color:var(--brand-2);
                margin-bottom:22px;
                line-height:1.55;
            }

            .backup-note i{
                color:var(--brand);
                font-size:14px;
                flex-shrink:0;
            }

            .backup-note a{
                color:var(--brand);
                font-weight:600;
                text-decoration:none;
                border-bottom:1px solid rgba(42,82,152,.35);
                transition:color .2s ease, border-color .2s ease;
            }

            .backup-note a:hover{
                color:var(--brand-2);
                border-bottom-color:var(--brand-2);
            }

            .action-row{
                display:flex;
                flex-direction:column;
                gap:10px;
            }

            .btn{
                display:inline-flex;
                align-items:center;
                justify-content:center;
                gap:9px;
                padding:13px 20px;
                font-family:inherit;
                font-size:14.5px;
                font-weight:600;
                letter-spacing:.2px;
                border-radius:var(--radius-md);
                text-decoration:none;
                border:1px solid transparent;
                cursor:pointer;
                transition:transform .2s ease, box-shadow .2s ease, filter .2s ease, background .2s ease, border-color .2s ease, color .2s ease;
            }

            .btn i{font-size:13px;}

            .btn-danger{
                color:#fff;
                background:linear-gradient(135deg, #ef4444, #b91c1c);
                box-shadow:var(--shadow-danger);
            }

            .btn-danger:hover{
                transform:translateY(-2px);
                filter:brightness(1.06);
                box-shadow:0 20px 36px -16px rgba(239,68,68,.65);
                color:#fff;
            }

            .btn-danger:active{transform:translateY(0);}

            .btn-secondary{
                color:var(--ink-2);
                background:var(--surface-2);
                border-color:var(--line);
            }

            .btn-secondary:hover{
                background:#fff;
                border-color:var(--line-strong);
                color:var(--ink);
                transform:translateY(-2px);
                box-shadow:var(--shadow-md);
            }

            .btn:focus-visible{
                outline:3px solid var(--brand-soft);
                outline-offset:3px;
            }

            .btn-danger:focus-visible{
                outline-color:rgba(239,68,68,.30);
            }

            @media (max-width:520px){
                body{padding:20px 14px;}
                .confirm-head{padding:26px 22px 20px;}
                .confirm-head h2{font-size:18px;}
                .confirm-body{padding:22px 22px 24px;}
                .warn-icon{width:56px;height:56px;font-size:22px;}
                .target-list{grid-template-columns:1fr;}
                .btn{font-size:14px;padding:12px 18px;}
            }

            @media (prefers-reduced-motion:reduce){
                *{animation:none !important;transition:none !important;}
            }
        </style>
    </head>
    <body>
        <div class="confirm-shell">
            <div class="confirm-head">
                <div class="warn-icon">
                    <i class="fas fa-triangle-exclamation"></i>
                </div>
                <h2>Konfirmasi Hapus Semua Data</h2>
                <p>Tindakan ini akan mengosongkan seluruh data operasional sistem.</p>
            </div>

            <div class="confirm-body">
                <div class="target-list">
                    <div class="target-item">
                        <i class="fas fa-clipboard-check"></i>
                        <span>Tabel Absensi</span>
                    </div>
                    <div class="target-item">
                        <i class="fas fa-plane"></i>
                        <span>Tabel Hari Libur</span>
                    </div>
                    <div class="target-item">
                        <i class="fas fa-user-graduate"></i>
                        <span>Tabel Siswa</span>
                    </div>
                    <div class="target-item">
                        <i class="fas fa-chalkboard-teacher"></i>
                        <span>Tabel Guru</span>
                    </div>
                </div>

                <div class="warning-box">
                    <i class="fas fa-circle-exclamation"></i>
                    <p>Tindakan ini tidak dapat dibatalkan. Pastikan Anda telah memiliki cadangan data sebelum melanjutkan.</p>
                </div>

                <div class="backup-note">
                    <i class="fas fa-circle-info"></i>
                    <span>Disarankan untuk <a href="backup_restore.php">melakukan backup data</a> terlebih dahulu.</span>
                </div>

                <div class="action-row">
                    <a href="?confirm=yes" class="btn btn-danger">
                        <i class="fas fa-trash-can"></i> Ya, Hapus Semua Data
                    </a>
                    <a href="dashboard.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Batal &amp; Kembali
                    </a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}

require_once 'config.php';

$conn->query("SET FOREIGN_KEY_CHECKS=0");

$conn->query("TRUNCATE TABLE absensi");
$conn->query("TRUNCATE TABLE hari_libur");
$conn->query("TRUNCATE TABLE siswa");
$conn->query("TRUNCATE TABLE guru");

$conn->query("SET FOREIGN_KEY_CHECKS=1");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Terhapus</title>
    <meta http-equiv="refresh" content="4;url=dashboard.php">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root{
            --bg:#f6f8fb;
            --surface:#ffffff;
            --line:#e8edf3;
            --ink:#0f172a;
            --ink-2:#334155;
            --muted:#64748b;
            --success:#10b981;
            --brand:#2a5298;
            --brand-2:#1e3c72;
            --brand-soft:rgba(42,82,152,.08);
            --radius-xl:22px;
            --radius-md:12px;
            --shadow-lg:0 24px 50px -22px rgba(15,23,42,.28), 0 10px 22px -14px rgba(15,23,42,.14);
        }

        *{box-sizing:border-box;}

        html,body{margin:0;padding:0;}

        body{
            font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(circle at 0% 0%, rgba(16,185,129,.06), transparent 42%),
                radial-gradient(circle at 100% 100%, rgba(42,82,152,.06), transparent 42%),
                var(--bg);
            min-height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
            padding:28px 20px;
            color:var(--ink);
            -webkit-font-smoothing:antialiased;
            -moz-osx-font-smoothing:grayscale;
        }

        .success-shell{
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-xl);
            box-shadow:var(--shadow-lg);
            max-width:520px;
            width:100%;
            overflow:hidden;
            position:relative;
            text-align:center;
            padding:40px 32px 36px;
            animation:fadeUp .5s ease both;
        }

        .success-shell::before{
            content:"";
            position:absolute;
            top:0;left:0;right:0;
            height:4px;
            background:linear-gradient(90deg, #10b981, #047857);
        }

        @keyframes fadeUp{
            from{opacity:0; transform:translateY(10px);}
            to{opacity:1; transform:translateY(0);}
        }

        .success-icon{
            width:72px;
            height:72px;
            border-radius:50%;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            background:linear-gradient(135deg, #d1fae5, #a7f3d0);
            color:#047857;
            font-size:30px;
            margin-bottom:20px;
            box-shadow:0 14px 30px -14px rgba(16,185,129,.55);
            animation:pop .5s ease .1s both;
        }

        @keyframes pop{
            0%{transform:scale(.7);opacity:0;}
            60%{transform:scale(1.08);}
            100%{transform:scale(1);opacity:1;}
        }

        .success-shell h2{
            margin:0 0 10px;
            font-size:22px;
            font-weight:600;
            letter-spacing:-.3px;
            color:var(--ink);
            line-height:1.3;
        }

        .success-shell p{
            margin:0 0 6px;
            font-size:13.5px;
            color:var(--muted);
            line-height:1.6;
        }

        .success-shell p strong{
            color:var(--ink-2);
            font-weight:600;
        }

        .progress-track{
            width:100%;
            height:5px;
            border-radius:999px;
            background:var(--line);
            overflow:hidden;
            margin:24px 0 18px;
        }

        .progress-bar{
            height:100%;
            width:100%;
            border-radius:999px;
            background:linear-gradient(90deg, var(--success), #047857);
            transform-origin:left;
            animation:progressFill 4s linear forwards;
        }

        @keyframes progressFill{
            from{transform:scaleX(0);}
            to{transform:scaleX(1);}
        }

        .countdown{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding:9px 16px;
            border-radius:999px;
            background:var(--brand-soft);
            color:var(--brand-2);
            font-size:12.5px;
            font-weight:500;
            margin-bottom:20px;
            border:1px solid rgba(42,82,152,.16);
        }

        .countdown i{
            color:var(--brand);
            font-size:12px;
        }

        .countdown b{
            color:var(--brand-2);
            font-weight:700;
            min-width:14px;
            text-align:center;
        }

        .btn-brand{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:9px;
            padding:12px 22px;
            font-family:inherit;
            font-size:14px;
            font-weight:600;
            letter-spacing:.2px;
            color:#fff;
            background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
            border:none;
            border-radius:var(--radius-md);
            text-decoration:none;
            cursor:pointer;
            box-shadow:0 14px 30px -14px rgba(30,60,114,.55);
            transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
        }

        .btn-brand i{font-size:12px;}

        .btn-brand:hover{
            transform:translateY(-2px);
            filter:brightness(1.08);
            box-shadow:0 20px 36px -16px rgba(30,60,114,.85);
            color:#fff;
        }

        .btn-brand:focus-visible{
            outline:3px solid rgba(42,82,152,.35);
            outline-offset:3px;
        }

        @media (max-width:520px){
            body{padding:20px 14px;}
            .success-shell{padding:32px 22px 28px;}
            .success-shell h2{font-size:19px;}
            .success-icon{width:62px;height:62px;font-size:26px;}
        }

        @media (prefers-reduced-motion:reduce){
            *{animation:none !important;transition:none !important;}
        }
    </style>
</head>
<body>
    <div class="success-shell">
        <div class="success-icon">
            <i class="fas fa-circle-check"></i>
        </div>
        <h2>Semua Data Berhasil Dihapus</h2>
        <p>Data <strong>absensi</strong>, <strong>hari libur</strong>, <strong>siswa</strong>, dan <strong>guru</strong> telah dikosongkan.</p>
        <p>Anda akan diarahkan ke Dashboard secara otomatis.</p>

        <div class="progress-track">
            <div class="progress-bar"></div>
        </div>

        <div class="countdown">
            <i class="fas fa-clock"></i>
            <span>Mengalihkan dalam <b id="countdownValue">4</b> detik</span>
        </div>

        <div>
            <a href="dashboard.php" class="btn-brand">
                <i class="fas fa-gauge-high"></i> Buka Dashboard Sekarang
            </a>
        </div>
    </div>

    <script>
        let seconds = 4;
        const el = document.getElementById('countdownValue');
        const timer = setInterval(() => {
            seconds--;
            if (el) el.textContent = seconds > 0 ? seconds : 0;
            if (seconds <= 0) clearInterval(timer);
        }, 1000);
    </script>
</body>
</html>