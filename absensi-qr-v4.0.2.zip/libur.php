<?php
session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include "config.php";

if (isset($_POST['simpan'])) {
  $tgl = $_POST['tanggal'];
  $desc = $_POST['deskripsi'];
  mysqli_query($conn, "INSERT INTO hari_libur (tanggal, deskripsi) VALUES ('$tgl', '$desc')");
  header("Location: libur.php");
}

if (isset($_GET['hapus'])) {
  $id = $_GET['hapus'];
  mysqli_query($conn, "DELETE FROM hari_libur WHERE id=$id");
  header("Location: libur.php");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pengaturan Hari Libur</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1100px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, #90be6d, #43aa8b);
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:0 14px 30px -14px rgba(67,170,139,.6);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1100px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:#43aa8b;
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .info-banner{
      display:flex;
      align-items:flex-start;
      gap:12px;
      padding:14px 18px;
      border-radius:var(--radius-md);
      background:rgba(245,158,11,.07);
      border:1px solid rgba(245,158,11,.22);
      border-left:4px solid var(--warning);
      color:#b45309;
      font-size:13px;
      line-height:1.65;
      margin-bottom:20px;
    }

    .info-banner i{
      margin-top:2px;
      font-size:15px;
      flex-shrink:0;
      color:var(--warning);
    }

    .info-banner strong{
      font-weight:600;
      color:#92400e;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      margin-bottom:20px;
      overflow:hidden;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:18px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .card-panel-title.accent i{
      background:rgba(144,190,109,.15);
      color:#43aa8b;
    }

    .card-panel-body{
      padding:22px 24px;
    }

    .form-grid{
      display:grid;
      grid-template-columns:1fr 2fr auto;
      gap:14px;
      align-items:end;
    }

    .form-item{
      display:flex;
      flex-direction:column;
      gap:7px;
    }

    .form-label{
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
    }

    .form-control{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
      width:100%;
      outline:none;
    }

    .form-control::placeholder{
      color:var(--muted-2);
    }

    .form-control:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-danger{
      background:linear-gradient(135deg,#ef4444,#dc2626);
      color:#fff;
      box-shadow:0 10px 20px -10px rgba(220,38,38,.6);
    }
    .btn-danger:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-sm{
      padding:6px 12px;
      font-size:12.5px;
      border-radius:8px;
    }

    .table-wrapper{
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      overflow:hidden;
      background:var(--surface);
    }

    .table-responsive{
      overflow-x:auto;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
      margin:0;
    }

    .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
    .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-responsive::-webkit-scrollbar-track{background:transparent;}

    table{
      margin:0;
      border-collapse:separate;
      border-spacing:0;
      width:100%;
      font-size:13.5px;
      color:var(--ink-2);
      font-family:'Rubik', sans-serif;
    }

    table thead th{
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:13px 16px;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    table tbody td{
      padding:13px 16px;
      vertical-align:middle;
      border-bottom:1px solid var(--line);
      color:var(--ink-2);
    }

    table tbody tr:hover td{
      background:rgba(42,82,152,.04);
    }

    table tbody tr:last-child td{
      border-bottom:0;
    }

    .badge-tanggal{
      display:inline-flex;
      align-items:center;
      gap:6px;
      padding:5px 11px;
      font-size:12px;
      font-weight:500;
      background:rgba(245,158,11,.12);
      color:#b45309;
      border-radius:6px;
      letter-spacing:.2px;
    }

    .badge-tanggal i{
      font-size:11px;
    }

    .cell-strong{
      font-weight:500;
      color:var(--ink);
    }

    .empty-state{
      text-align:center;
      padding:56px 24px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:42px;
      opacity:.4;
      margin-bottom:14px;
      display:block;
      color:#43aa8b;
    }

    .empty-state h4{
      font-size:16px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 6px;
    }

    .empty-state p{
      font-size:13.5px;
      margin:0;
    }

    .stats-row{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:18px;
    }

    .stat-chip{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:8px 14px;
      font-size:12.5px;
      font-weight:500;
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:999px;
      color:var(--ink-2);
    }

    .stat-chip i{
      color:#43aa8b;
      font-size:12px;
    }

    .stat-chip strong{
      color:var(--ink);
      font-weight:600;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .card-panel-body{padding:18px;}
      .card-panel-header{padding:16px 20px;}
      .form-grid{grid-template-columns:1fr 1fr;}
      .form-grid .form-submit{grid-column:1 / -1;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .card-panel{border-radius:var(--radius-md);}
      .card-panel-body{padding:16px;}
      .card-panel-header{padding:14px 16px;}
      .card-panel-title{font-size:13.5px;}
      .form-grid{grid-template-columns:1fr;gap:12px;}
      .form-grid .form-submit{grid-column:auto;}
      .form-grid .form-submit .btn{width:100%;}
      .btn{padding:9px 14px;font-size:13px;}
      .table thead th,
      .table tbody td{padding:11px 12px;font-size:12.5px;}
      .stat-chip{padding:6px 12px;font-size:11.5px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-plane"></i></div>
        <div class="brand-titles">
          <h1>Hari Libur</h1>
          <span>Kelola hari libur dan cuti bersama</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Kalender</span>
      <h2>Pengaturan Hari Libur</h2>
      <p>Tambahkan hari libur atau cuti bersama untuk kalender akademik sekolah.</p>
    </div>

    <div class="info-banner">
      <i class="fas fa-circle-info"></i>
      <div>
        <strong>Info:</strong> Hari <strong>Minggu</strong> sudah otomatis dianggap LIBUR / tanggal merah. Tambahkan entri di bawah untuk hari libur lainnya.
      </div>
    </div>

    <?php
    $qCount = mysqli_query($conn, "SELECT COUNT(*) AS total FROM hari_libur");
    $totalLibur = 0;
    if ($qCount) {
      $row = mysqli_fetch_assoc($qCount);
      $totalLibur = (int)$row['total'];
    }
    ?>

    <div class="stats-row">
      <span class="stat-chip">
        <i class="fas fa-calendar-check"></i>
        Total Hari Libur: <strong><?= $totalLibur ?></strong>
      </span>
      <span class="stat-chip">
        <i class="fas fa-circle-check"></i>
        Minggu otomatis libur
      </span>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title accent">
          <i class="fas fa-plus"></i>
          Tambah Hari Libur
        </div>
      </div>
      <div class="card-panel-body">
        <form method="post" class="form-grid">
          <div class="form-item">
            <label class="form-label" for="tanggal">Tanggal Libur</label>
            <input type="date" id="tanggal" name="tanggal" class="form-control" required>
          </div>
          <div class="form-item">
            <label class="form-label" for="deskripsi">Keterangan</label>
            <input type="text" id="deskripsi" name="deskripsi" class="form-control" placeholder="Contoh: Libur Nasional, Cuti Bersama" required>
          </div>
          <div class="form-item form-submit">
            <label class="form-label">&nbsp;</label>
            <button name="simpan" class="btn btn-primary">
              <i class="fas fa-floppy-disk"></i> Simpan
            </button>
          </div>
        </form>
      </div>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-list-check"></i>
          Daftar Hari Libur
        </div>
      </div>
      <div class="card-panel-body" style="padding:0;">
        <div class="table-wrapper">
          <div class="table-responsive">
            <table>
              <thead>
                <tr>
                  <th>Tanggal</th>
                  <th>Deskripsi</th>
                  <th class="text-center">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $q = mysqli_query($conn, "SELECT * FROM hari_libur ORDER BY tanggal DESC");
                if ($q && mysqli_num_rows($q) > 0) {
                  while ($r = mysqli_fetch_assoc($q)) {
                    $tgl_formatted = date('d/m/Y', strtotime($r['tanggal']));
                    $hari = date('l', strtotime($r['tanggal']));
                    $hari_map = ['Sunday'=>'Minggu','Monday'=>'Senin','Tuesday'=>'Selasa','Wednesday'=>'Rabu','Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu'];
                    $hari_id = $hari_map[$hari] ?? $hari;
                    echo "<tr>
                      <td>
                        <span class='badge-tanggal'>
                          <i class='fas fa-calendar-day'></i> $tgl_formatted
                        </span>
                        <small style='color:var(--muted);margin-left:6px;'>$hari_id</small>
                      </td>
                      <td class='cell-strong'>" . htmlspecialchars($r['deskripsi']) . "</td>
                      <td class='text-center'>
                        <a href='libur.php?hapus={$r['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Yakin hapus?\")'>
                          <i class='fas fa-trash'></i> Hapus
                        </a>
                      </td>
                    </tr>";
                  }
                } else {
                  echo "<tr><td colspan='3'>
                    <div class='empty-state'>
                      <i class='fas fa-calendar-xmark'></i>
                      <h4>Belum ada hari libur</h4>
                      <p>Tambahkan hari libur melalui formulir di atas.</p>
                    </div>
                  </td></tr>";
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

  </div>

</body>
</html>