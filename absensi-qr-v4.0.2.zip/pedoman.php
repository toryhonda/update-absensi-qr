<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panduan & Pedoman Penggunaan Sistem</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --purple:#8b5cf6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
      line-height:1.65;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:960px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:960px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .info-banner{
      display:flex;
      align-items:flex-start;
      gap:14px;
      padding:18px 22px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, rgba(42,82,152,.06), rgba(59,130,246,.05));
      border:1px solid rgba(42,82,152,.15);
      border-left:4px solid var(--brand);
      color:var(--ink-2);
      font-size:13.5px;
      line-height:1.7;
      margin-bottom:22px;
    }

    .info-banner i{
      margin-top:3px;
      font-size:18px;
      flex-shrink:0;
      color:var(--brand);
      width:36px;
      height:36px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      display:flex;
      align-items:center;
      justify-content:center;
    }

    .info-banner strong{
      font-weight:600;
      color:var(--ink);
      display:block;
      margin-bottom:2px;
      font-size:14px;
    }

    .section-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      margin-bottom:18px;
      overflow:hidden;
      transition:box-shadow .25s ease, transform .25s ease;
    }

    .section-card:hover{
      box-shadow:var(--shadow-md);
      transform:translateY(-1px);
    }

    .section-header{
      display:flex;
      align-items:center;
      gap:14px;
      padding:20px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
    }

    .section-number{
      width:40px;
      height:40px;
      border-radius:var(--radius-sm);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:15px;
      font-weight:600;
      flex-shrink:0;
      box-shadow:var(--shadow-brand);
    }

    .section-title{
      display:flex;
      flex-direction:column;
      gap:2px;
      min-width:0;
    }

    .section-title h3{
      font-size:15px;
      font-weight:600;
      color:var(--ink);
      margin:0;
      letter-spacing:-.15px;
      line-height:1.3;
    }

    .section-title span{
      font-size:12.5px;
      color:var(--muted);
      font-weight:400;
    }

    .section-body{
      padding:22px 24px;
      font-size:13.5px;
      color:var(--ink-2);
    }

    .section-body p{
      margin:0 0 14px;
      line-height:1.7;
    }

    .section-body p:last-child{
      margin-bottom:0;
    }

    .code-box{
      background:#0f172a;
      color:#e2e8f0;
      border:1px solid #1e293b;
      padding:14px 16px;
      border-radius:var(--radius-sm);
      font-family:'Rubik', monospace;
      font-size:12.5px;
      word-break:break-all;
      margin:12px 0;
      letter-spacing:.2px;
      line-height:1.65;
      position:relative;
      overflow-x:auto;
    }

    .code-box::before{
      content:"URL";
      position:absolute;
      top:6px;
      right:10px;
      font-size:10px;
      font-weight:600;
      letter-spacing:1px;
      color:#64748b;
      opacity:.7;
    }

    ol, ul{
      padding-left:0;
      margin:8px 0 0;
      list-style:none;
      counter-reset:step;
    }

    ol li, ul li{
      position:relative;
      padding-left:36px;
      margin-bottom:12px;
      font-size:13.5px;
      color:var(--ink-2);
      line-height:1.65;
    }

    ol li:last-child, ul li:last-child{
      margin-bottom:0;
    }

    ol li::before{
      counter-increment:step;
      content:counter(step);
      position:absolute;
      left:0;
      top:1px;
      width:24px;
      height:24px;
      border-radius:50%;
      background:var(--brand-soft);
      color:var(--brand);
      font-size:11.5px;
      font-weight:600;
      display:flex;
      align-items:center;
      justify-content:center;
    }

    ul li::before{
      content:"";
      position:absolute;
      left:8px;
      top:9px;
      width:8px;
      height:8px;
      border-radius:50%;
      background:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    ol li strong, ul li strong{
      color:var(--ink);
      font-weight:600;
    }

    ol li em, ul li em{
      color:var(--brand);
      font-style:normal;
      font-weight:500;
    }

    .feature-badge{
      display:inline-flex;
      align-items:center;
      gap:6px;
      padding:4px 10px;
      font-size:11.5px;
      font-weight:500;
      border-radius:999px;
      background:var(--brand-soft);
      color:var(--brand);
      margin-right:6px;
      margin-bottom:2px;
    }

    .feature-badge.wa{
      background:rgba(37,211,102,.1);
      color:#047857;
    }

    .feature-badge.info{
      background:rgba(59,130,246,.12);
      color:#1d4ed8;
    }

    .feature-badge.success{
      background:rgba(16,185,129,.12);
      color:#047857;
    }

    .feature-badge.warning{
      background:rgba(245,158,11,.14);
      color:#b45309;
    }

    .tip-grid{
      display:grid;
      grid-template-columns:repeat(auto-fit, minmax(220px, 1fr));
      gap:12px;
      margin-top:18px;
    }

    .tip-card{
      padding:16px;
      border-radius:var(--radius-md);
      background:var(--surface-2);
      border:1px solid var(--line);
      display:flex;
      gap:12px;
      align-items:flex-start;
      transition:border-color .2s ease, box-shadow .2s ease;
    }

    .tip-card:hover{
      border-color:var(--line-strong);
      box-shadow:var(--shadow-sm);
    }

    .tip-card i{
      width:34px;
      height:34px;
      border-radius:var(--radius-sm);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:13px;
      flex-shrink:0;
    }

    .tip-card.tip-info i{
      background:rgba(59,130,246,.12);
      color:var(--info);
    }

    .tip-card.tip-warning i{
      background:rgba(245,158,11,.12);
      color:var(--warning);
    }

    .tip-card.tip-success i{
      background:rgba(16,185,129,.12);
      color:var(--success);
    }

    .tip-card.tip-brand i{
      background:var(--brand-soft);
      color:var(--brand);
    }

    .tip-text{
      font-size:12.5px;
      color:var(--muted);
      line-height:1.6;
    }

    .tip-text strong{
      display:block;
      color:var(--ink);
      font-weight:600;
      font-size:13px;
      margin-bottom:3px;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .info-banner{padding:14px 16px;font-size:12.5px;}
      .info-banner i{width:32px;height:32px;font-size:16px;}
      .section-header{padding:16px 18px;gap:12px;}
      .section-number{width:36px;height:36px;font-size:14px;}
      .section-title h3{font-size:14px;}
      .section-body{padding:18px;}
      .code-box{font-size:11.5px;padding:12px;}
      ol li, ul li{padding-left:32px;font-size:13px;}
      .tip-grid{grid-template-columns:1fr;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-book-open"></i></div>
        <div class="brand-titles">
          <h1>Panduan Sistem</h1>
          <span>Dokumentasi penggunaan aplikasi</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Dokumentasi</span>
      <h2>Pedoman Penggunaan &amp; Dokumentasi Fitur</h2>
      <p>Pelajari cara menggunakan setiap fitur sistem absensi digital secara lengkap.</p>
    </div>

    <div class="info-banner">
      <i class="fas fa-circle-info"></i>
      <div>
        <strong>Tentang Sistem</strong>
        Platform absensi digital terintegrasi WhatsApp Cloud API (WABA) yang dirancang untuk memudahkan pencatatan kehadiran siswa/guru serta komunikasi otomatis dengan orang tua.
      </div>
    </div>

    <div class="section-card">
      <div class="section-header">
        <div class="section-number">1</div>
        <div class="section-title">
          <h3>QR Code Aktivasi WhatsApp Wali Siswa</h3>
          <span>Menghubungkan orang tua ke sistem notifikasi WABA sekolah</span>
        </div>
      </div>
      <div class="section-body">
        <p>Fitur ini memudahkan orang tua/wali murid terhubung ke sistem notifikasi WABA sekolah secara instan sebelum siswa berangkat.</p>

        <div class="code-box">https://api.qrserver.com/v1/create-qr-code/?size=300x300&amp;data=https://wa.me/62896661xxxxx?text=Aktivasi%20Notifikasi%20Absensi</div>

        <ol style="margin-top:14px;">
          <li>Orang tua memindai QR Code via kamera ponsel pintar.</li>
          <li>Aplikasi WhatsApp terbuka otomatis dengan pesan bawaan: <em>"Aktivasi Notifikasi Absensi"</em>.</li>
          <li>Kirim pesan tersebut untuk mengaktifkan sesi komunikasi resmi dengan server WABA sekolah.</li>
        </ol>
      </div>
    </div>

    <div class="section-card">
      <div class="section-header">
        <div class="section-number">2</div>
        <div class="section-title">
          <h3>Pengaturan Jam Sesi Absensi Multi</h3>
          <span>Mencegah bentrok waktu antar sesi scan QR</span>
        </div>
      </div>
      <div class="section-body">
        <ul>
          <li>Digunakan untuk mengatur rentang waktu operasional spesifik (<strong>Masuk</strong>, <strong>Sholat Dhuha</strong>, <strong>Sholat Dhuhur</strong>, dan <strong>Pulang</strong>).</li>
          <li>Mencegah terjadinya bentrok waktu (<em>temporal collision</em>) saat siswa melakukan pemindaian kartu (<em>scan</em>).</li>
          <li>Atur jam mulai dan selesai melalui menu <strong>Pengaturan Jam Sesi Absensi</strong> di dashboard utama.</li>
        </ul>
      </div>
    </div>

    <div class="section-card">
      <div class="section-header">
        <div class="section-number">3</div>
        <div class="section-title">
          <h3>Konfigurasi WABA Cloud API</h3>
          <span>Menghubungkan sistem dengan WhatsApp Business Meta</span>
        </div>
      </div>
      <div class="section-body">
        <ul>
          <li>Pastikan <strong>Phone Number ID</strong>, <strong>WABA ID</strong>, dan <strong>Permanent Access Token</strong> dari Meta sudah diisi dengan benar pada menu <strong>Pengaturan Key API WA</strong>.</li>
          <li>Gunakan fitur <em>Tes Koneksi WABA</em> untuk memastikan pesan uji coba berhasil terkirim ke nomor tujuan.</li>
        </ul>
      </div>
    </div>

    <div class="section-card">
      <div class="section-header">
        <div class="section-number">4</div>
        <div class="section-title">
          <h3>Scan QR &amp; Rekapitulasi Kehadiran</h3>
          <span>Pencatatan kehadiran dan ekspor data absensi</span>
        </div>
      </div>
      <div class="section-body">
        <ul>
          <li><strong>Scan QR + WA API:</strong> Digunakan oleh guru piket untuk mencatat kehadiran sekaligus memicu pengiriman pesan otomatis ke orang tua.</li>
          <li><strong>Rekapitulasi:</strong> Data kehadiran harian, bulanan, serta rekap sholat dapat dipantau langsung melalui menu rekap dan diekspor ke format Excel.</li>
        </ul>
      </div>
    </div>

    <div class="tip-grid">
      <div class="tip-card tip-brand">
        <i class="fas fa-lightbulb"></i>
        <div class="tip-text">
          <strong>Tips Cepat</strong>
          Atur jam sesi sebelum memulai absensi harian agar deteksi sesi berjalan akurat.
        </div>
      </div>
      <div class="tip-card tip-success">
        <i class="fas fa-shield-halved"></i>
        <div class="tip-text">
          <strong>Keamanan Token</strong>
          Jangan bagikan Permanent Access Token WABA kepada pihak yang tidak berkepentingan.
        </div>
      </div>
      <div class="tip-card tip-warning">
        <i class="fas fa-circle-exclamation"></i>
        <div class="tip-text">
          <strong>Perhatian</strong>
          Pastikan nomor WhatsApp tujuan tes koneksi sudah aktif dan formatnya benar.
        </div>
      </div>
    </div>

  </div>

</body>
</html>