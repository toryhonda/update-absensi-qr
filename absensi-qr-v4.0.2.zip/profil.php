<?php

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
include "config.php";

$q = $conn->query("SELECT * FROM profil_sekolah LIMIT 1");
$profil = $q->fetch_assoc();

$msg = $_SESSION['msg'] ?? "";
unset($_SESSION['msg']);

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $kepala = $_POST['kepala'];
    $nip = $_POST['nip'];

    $logo = $profil['logo'];
    if (!empty($_FILES['logo']['name'])) {
        $ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
        $logo = "logo_" . time() . "." . $ext;
        move_uploaded_file($_FILES['logo']['tmp_name'], "uploads/" . $logo);
    }

    $conn->query("UPDATE profil_sekolah SET 
        nama_sekolah='$nama',
        alamat='$alamat',
        kepala_sekolah='$kepala',
        nip_kepala='$nip',
        logo='$logo'
    WHERE id=" . $profil['id']);

    $_SESSION['msg'] = "Profil sekolah berhasil diperbarui!";
    header("Location: profil.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Sekolah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root{
            --bg:#f6f8fb;
            --surface:#ffffff;
            --surface-2:#f9fafb;
            --line:#e8edf3;
            --line-strong:#dbe3ec;
            --ink:#0f172a;
            --ink-2:#334155;
            --muted:#64748b;
            --muted-2:#94a3b8;
            --brand:#2a5298;
            --brand-2:#1e3c72;
            --brand-soft:rgba(42,82,152,.08);
            --success:#10b981;
            --danger:#ef4444;
            --radius-xl:20px;
            --radius-lg:16px;
            --radius-md:12px;
            --radius-sm:10px;
            --shadow-sm:0 1px 2px rgba(15,23,42,.05);
            --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
            --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
            --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
        }

        *{box-sizing:border-box;}

        html{scroll-behavior:smooth;}

        body{
            font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
                radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
                var(--bg);
            min-height:100vh;
            color:var(--ink);
            margin:0;
            padding:32px 20px 56px;
            -webkit-font-smoothing:antialiased;
            -moz-osx-font-smoothing:grayscale;
        }

        .page-shell{
            max-width:760px;
            margin:0 auto;
        }

        .top-nav{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:16px;
            margin-bottom:24px;
            flex-wrap:wrap;
        }

        .btn-back{
            display:inline-flex;
            align-items:center;
            gap:8px;
            padding:9px 16px;
            background:var(--surface);
            color:var(--ink-2);
            border:1px solid var(--line);
            border-radius:999px;
            font-size:13.5px;
            font-weight:500;
            text-decoration:none;
            box-shadow:var(--shadow-sm);
            transition:border-color .2s ease, color .2s ease, transform .2s ease, box-shadow .2s ease;
        }

        .btn-back i{
            font-size:11px;
            color:var(--muted);
            transition:color .2s ease, transform .2s ease;
        }

        .btn-back:hover{
            color:var(--ink);
            border-color:var(--line-strong);
            box-shadow:var(--shadow-md);
            transform:translateY(-1px);
        }

        .btn-back:hover i{
            color:var(--brand);
            transform:translateX(-2px);
        }

        .btn-back:focus-visible{
            outline:3px solid var(--brand-soft);
            outline-offset:2px;
        }

        .page-head{
            display:flex;
            flex-direction:column;
            gap:6px;
            margin-bottom:24px;
        }

        .page-eyebrow{
            font-size:11.5px;
            font-weight:600;
            letter-spacing:1.2px;
            text-transform:uppercase;
            color:var(--brand);
        }

        .page-head h1{
            font-size:26px;
            font-weight:600;
            letter-spacing:-.4px;
            color:var(--ink);
            margin:0;
            line-height:1.25;
        }

        .page-head p{
            margin:0;
            font-size:14px;
            color:var(--muted);
            line-height:1.55;
        }

        .alert{
            border-radius:var(--radius-md);
            border:1px solid transparent;
            padding:13px 16px;
            font-size:13.5px;
            font-weight:500;
            display:flex;
            align-items:flex-start;
            gap:10px;
            margin-bottom:22px;
            line-height:1.55;
            animation:fadeUp .35s ease both;
        }

        .alert span{color:inherit !important;}

        .alert-success{
            background:rgba(16,185,129,.08);
            border-color:rgba(16,185,129,.20);
            color:#047857;
        }

        .alert-danger{
            background:rgba(239,68,68,.08);
            border-color:rgba(239,68,68,.20);
            color:#b91c1c;
        }

        .alert::before{
            font-family:"Font Awesome 6 Free";
            font-weight:900;
            flex-shrink:0;
            margin-top:1px;
        }

        .alert-success::before{content:"\f058";}
        .alert-danger::before{content:"\f06a";}

        @keyframes fadeUp{
            from{opacity:0; transform:translateY(8px);}
            to{opacity:1; transform:translateY(0);}
        }

        .card{
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-xl);
            box-shadow:var(--shadow-md);
            overflow:hidden;
            animation:fadeUp .5s ease both;
        }

        .card-head{
            position:relative;
            padding:24px 28px 20px;
            border-bottom:1px solid var(--line);
            background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
        }

        .card-head::before{
            content:"";
            position:absolute;
            top:0;left:0;right:0;
            height:3px;
            background:linear-gradient(90deg, var(--brand), var(--brand-2));
        }

        .card-head-inner{
            display:flex;
            align-items:center;
            gap:14px;
        }

        .card-icon{
            width:44px;
            height:44px;
            border-radius:var(--radius-md);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:17px;
            color:var(--brand);
            background:var(--brand-soft);
            flex-shrink:0;
        }

        .card-title{
            font-size:16px;
            font-weight:600;
            letter-spacing:-.2px;
            color:var(--ink);
            margin:0 0 3px;
            line-height:1.35;
        }

        .card-sub{
            font-size:12.5px;
            color:var(--muted);
            margin:0;
            line-height:1.5;
        }

        .card-body-inner{
            padding:26px 28px 28px;
        }

        .field{
            margin-bottom:18px;
        }

        .field-label{
            display:flex;
            align-items:center;
            gap:8px;
            font-size:13px;
            font-weight:500;
            color:var(--ink-2);
            margin-bottom:8px;
        }

        .field-label i{
            font-size:11.5px;
            color:var(--brand);
            width:14px;
            text-align:center;
        }

        .form-control{
            width:100%;
            padding:12px 15px;
            font-family:inherit;
            font-size:14.5px;
            color:var(--ink);
            background:var(--surface-2);
            border:1px solid var(--line);
            border-radius:var(--radius-md);
            outline:none;
            transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
        }

        .form-control::placeholder{color:var(--muted-2);}

        .form-control:hover{border-color:var(--line-strong);}

        .form-control:focus{
            background:#fff;
            border-color:var(--brand);
            box-shadow:0 0 0 4px var(--brand-soft);
        }

        textarea.form-control{
            resize:vertical;
            min-height:90px;
            line-height:1.6;
        }

        input[type="file"].form-control{
            padding:10px 12px;
            font-size:13.5px;
            color:var(--muted);
            cursor:pointer;
        }

        input[type="file"].form-control::file-selector-button{
            font-family:inherit;
            font-size:13px;
            font-weight:500;
            color:var(--ink-2);
            background:#fff;
            border:1px solid var(--line);
            border-radius:8px;
            padding:7px 12px;
            margin-right:12px;
            cursor:pointer;
            transition:border-color .2s ease, background .2s ease;
        }

        input[type="file"].form-control::file-selector-button:hover{
            border-color:var(--line-strong);
            background:var(--surface-2);
        }

        .logo-preview{
            margin-top:14px;
            padding:14px;
            border:1px dashed var(--line-strong);
            border-radius:var(--radius-md);
            background:var(--surface-2);
            display:flex;
            align-items:center;
            gap:16px;
        }

        .logo-preview img{
            max-width:96px;
            max-height:96px;
            width:auto;
            height:auto;
            object-fit:contain;
            background:#fff;
            padding:6px;
            border-radius:10px;
            border:1px solid var(--line);
            box-shadow:var(--shadow-sm);
        }

        .logo-preview-info{
            display:flex;
            flex-direction:column;
            gap:4px;
            min-width:0;
        }

        .logo-preview-info strong{
            font-size:13px;
            font-weight:600;
            color:var(--ink-2);
        }

        .logo-preview-info span{
            font-size:12px;
            color:var(--muted);
            line-height:1.5;
        }

        .logo-empty{
            margin-top:14px;
            padding:14px 16px;
            border:1px dashed var(--line-strong);
            border-radius:var(--radius-md);
            background:var(--surface-2);
            font-size:12.5px;
            color:var(--muted);
            display:flex;
            align-items:center;
            gap:10px;
        }

        .logo-empty i{color:var(--muted-2);}

        .btn-primary{
            width:100%;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:10px;
            padding:13px 20px;
            font-family:inherit;
            font-size:14.5px;
            font-weight:600;
            letter-spacing:.2px;
            color:#fff;
            background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
            border:none;
            border-radius:var(--radius-md);
            cursor:pointer;
            box-shadow:var(--shadow-brand);
            transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
            margin-top:6px;
        }

        .btn-primary i{font-size:13px;}

        .btn-primary:hover{
            transform:translateY(-2px);
            filter:brightness(1.08);
            box-shadow:0 20px 36px -16px rgba(30,60,114,.85);
        }

        .btn-primary:active{transform:translateY(0);}

        .btn-primary:focus-visible{
            outline:3px solid rgba(42,82,152,.35);
            outline-offset:3px;
        }

        @media (max-width:640px){
            body{padding:20px 14px 40px;}
            .page-head h1{font-size:22px;}
            .card-head{padding:20px 20px 16px;}
            .card-body-inner{padding:20px 20px 22px;}
            .card-icon{width:40px;height:40px;font-size:15px;}
            .card-title{font-size:15px;}
            .form-control{font-size:14px;padding:11px 14px;}
            textarea.form-control{min-height:80px;}
            .btn-primary{font-size:14px;padding:12px 18px;}
            .logo-preview{flex-direction:column;align-items:flex-start;gap:12px;}
        }

        @media (prefers-reduced-motion:reduce){
            *{animation:none !important;transition:none !important;}
        }
    </style>
</head>
<body>
    <div class="page-shell">
        <div class="top-nav">
            <a href="dashboard.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
            </a>
        </div>

        <div class="page-head">
            <span class="page-eyebrow">Pengaturan</span>
            <h1>Profil Sekolah</h1>
            <p>Kelola identitas sekolah yang akan tampil di seluruh halaman sistem.</p>
        </div>

        <?php if ($msg): ?>
            <div class="alert <?= (strpos($msg, 'berhasil') !== false) ? 'alert-success' : 'alert-danger' ?>">
                <?= $msg; ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-head">
                <div class="card-head-inner">
                    <div class="card-icon">
                        <i class="fas fa-school"></i>
                    </div>
                    <div>
                        <h2 class="card-title">Informasi Sekolah</h2>
                        <p class="card-sub">Data ini akan tampil di seluruh halaman sistem.</p>
                    </div>
                </div>
            </div>
            <div class="card-body-inner">
                <form method="POST" enctype="multipart/form-data">
                    <div class="field">
                        <label class="field-label" for="nama">
                            <i class="fas fa-signature"></i> Nama Sekolah
                        </label>
                        <input type="text" id="nama" name="nama" class="form-control" value="<?= htmlspecialchars($profil['nama_sekolah']) ?>" required>
                    </div>

                    <div class="field">
                        <label class="field-label" for="alamat">
                            <i class="fas fa-location-dot"></i> Alamat
                        </label>
                        <textarea id="alamat" name="alamat" class="form-control" required><?= htmlspecialchars($profil['alamat']) ?></textarea>
                    </div>

                    <div class="field">
                        <label class="field-label" for="kepala">
                            <i class="fas fa-user-tie"></i> Nama Kepala Sekolah
                        </label>
                        <input type="text" id="kepala" name="kepala" class="form-control" value="<?= htmlspecialchars($profil['kepala_sekolah']) ?>" required>
                    </div>

                    <div class="field">
                        <label class="field-label" for="nip">
                            <i class="fas fa-id-badge"></i> NIP Kepala Sekolah
                        </label>
                        <input type="text" id="nip" name="nip" class="form-control" value="<?= htmlspecialchars($profil['nip_kepala']) ?>" required>
                    </div>

                    <div class="field">
                        <label class="field-label" for="logo">
                            <i class="fas fa-image"></i> Logo Sekolah
                        </label>
                        <input type="file" id="logo" name="logo" class="form-control" accept="image/*">

                        <?php
                        if ($profil['logo']) {
                            $logoPath = "uploads/" . $profil['logo'];
                            if (file_exists($logoPath)) {
                                $version = filemtime($logoPath);
                                echo "<div class='logo-preview'>";
                                echo "<img src='{$logoPath}?v={$version}' alt='Logo Sekolah'>";
                                echo "<div class='logo-preview-info'>";
                                echo "<strong>Logo saat ini</strong>";
                                echo "<span>Unggah file baru untuk mengganti logo.</span>";
                                echo "</div>";
                                echo "</div>";
                            } else {
                                echo "<div class='logo-empty'><i class='fas fa-circle-exclamation'></i> Logo tidak ditemukan di folder uploads.</div>";
                            }
                        } else {
                            echo "<div class='logo-empty'><i class='fas fa-circle-info'></i> Belum ada logo yang diunggah.</div>";
                        }
                        ?>
                    </div>

                    <button type="submit" name="simpan" class="btn-primary">
                        <i class="fas fa-floppy-disk"></i> Simpan Profil
                    </button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>