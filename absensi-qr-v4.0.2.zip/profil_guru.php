<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

$username_session = $_SESSION['username'];
$pesan = "";

$check_col = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'foto'");
if ($check_col && mysqli_num_rows($check_col) == 0) {
    @mysqli_query($conn, "ALTER TABLE users ADD COLUMN foto VARCHAR(255) DEFAULT NULL");
}

$q_user = mysqli_query($conn, "SELECT * FROM users WHERE username='$username_session' LIMIT 1");
$data_user = mysqli_fetch_assoc($q_user);
$id_user = $data_user['id'] ?? 0;
$nama_user = $data_user['nama'] ?? '';

if (isset($_POST['hapus_foto'])) {
    $foto_lama = $data_user['foto'] ?? '';
    if (!empty($foto_lama) && file_exists(__DIR__ . '/' . $foto_lama)) {
        @unlink(__DIR__ . '/' . $foto_lama);
    }
    mysqli_query($conn, "UPDATE users SET foto=NULL WHERE id=$id_user");
    $_SESSION['flash_profil'] = "<div class='alert alert-success'>Foto profil berhasil dihapus.</div>";
    header("Location: profil_guru.php");
    exit;
}

if (isset($_POST['update_profil'])) {
    $nama_baru          = trim($_POST['nama']);
    $username_baru      = trim($_POST['username']);
    $password_baru      = trim($_POST['password']);
    $konfirmasi_password = trim($_POST['konfirmasi_password']);

    $valid = true;
    $pesan_tmp = "";

    if (!empty($password_baru) && $password_baru !== $konfirmasi_password) {
        $pesan_tmp = "<div class='alert alert-danger'>Konfirmasi password baru tidak cocok!</div>";
        $valid = false;
    } else {
        $cek_username = mysqli_query($conn, "SELECT id FROM users WHERE username='$username_baru' AND id != $id_user LIMIT 1");
        if (mysqli_num_rows($cek_username) > 0) {
            $pesan_tmp = "<div class='alert alert-danger'>Username '$username_baru' sudah digunakan akun lain!</div>";
            $valid = false;
        }
    }

    $foto_path_baru = $data_user['foto'] ?? null;
    $upload_error = "";

    if ($valid && isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['foto'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $upload_error = "Gagal mengunggah file. Kode error: " . $file['error'];
        } else {
            $max_size = 2 * 1024 * 1024;
            $allowed_ext = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
            $allowed_mime = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $finfo = @finfo_open(FILEINFO_MIME_TYPE);
            $mime = $finfo ? finfo_file($finfo, $file['tmp_name']) : ($file['type'] ?? '');
            if ($finfo) finfo_close($finfo);

            if (!in_array($ext, $allowed_ext) || !in_array($mime, $allowed_mime)) {
                $upload_error = "Format file tidak didukung. Gunakan JPG, PNG, WEBP, atau GIF.";
            } elseif ($file['size'] > $max_size) {
                $upload_error = "Ukuran file terlalu besar. Maksimal 2 MB.";
            } else {
                $upload_dir = __DIR__ . '/uploads/profil/';
                if (!is_dir($upload_dir)) {
                    @mkdir($upload_dir, 0755, true);
                }

                $new_name = 'user_' . $id_user . '_' . time() . '.' . $ext;
                $dest_abs = $upload_dir . $new_name;
                $dest_rel = 'uploads/profil/' . $new_name;

                if (move_uploaded_file($file['tmp_name'], $dest_abs)) {
                    if (!empty($foto_path_baru) && file_exists(__DIR__ . '/' . $foto_path_baru)) {
                        @unlink(__DIR__ . '/' . $foto_path_baru);
                    }
                    $foto_path_baru = $dest_rel;
                } else {
                    $upload_error = "Gagal menyimpan file. Periksa izin folder uploads/profil/.";
                }
            }
        }
    }

    if (!$valid) {
        $pesan = $pesan_tmp;
    } elseif (!empty($upload_error)) {
        $pesan = "<div class='alert alert-danger'>" . htmlspecialchars($upload_error) . "</div>";
    } else {
        if (!empty($password_baru)) {
            $pass_md5 = md5($password_baru);
            $foto_sql = $foto_path_baru === null ? "NULL" : "'" . mysqli_real_escape_string($conn, $foto_path_baru) . "'";
            $update = mysqli_query($conn, "UPDATE users SET nama='$nama_baru', username='$username_baru', password='$pass_md5', foto=$foto_sql WHERE id=$id_user");
        } else {
            $foto_sql = $foto_path_baru === null ? "NULL" : "'" . mysqli_real_escape_string($conn, $foto_path_baru) . "'";
            $update = mysqli_query($conn, "UPDATE users SET nama='$nama_baru', username='$username_baru', foto=$foto_sql WHERE id=$id_user");
        }

        if ($update) {
            $_SESSION['username'] = $username_baru;
            $_SESSION['flash_profil'] = "<div class='alert alert-success'>Profil berhasil diperbarui!</div>";
            header("Location: profil_guru.php");
            exit;
        } else {
            $pesan = "<div class='alert alert-danger'>Gagal memperbarui profil!</div>";
        }
    }
}

if (isset($_SESSION['flash_profil'])) {
    $pesan = $_SESSION['flash_profil'];
    unset($_SESSION['flash_profil']);
}

$q_user = mysqli_query($conn, "SELECT * FROM users WHERE id=$id_user LIMIT 1");
$data_user = mysqli_fetch_assoc($q_user);

$foto_profil = $data_user['foto'] ?? '';
$has_foto = !empty($foto_profil) && file_exists(__DIR__ . '/' . $foto_profil);
$foto_url = $has_foto ? htmlspecialchars($foto_profil) . "?v=" . filemtime(__DIR__ . '/' . $foto_profil) : "";
$initial = strtoupper(substr(($data_user['nama'] ?? '') !== '' ? $data_user['nama'] : ($data_user['username'] ?? 'G'), 0, 1));
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pengaturan Profil Guru</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --success:#10b981;
      --success-dark:#047857;
      --success-soft:rgba(16,185,129,.08);
      --success-line:rgba(16,185,129,.22);
      --danger:#ef4444;
      --danger-dark:#b91c1c;
      --danger-soft:rgba(239,68,68,.08);
      --danger-line:rgba(239,68,68,.22);
      --radius-xl:20px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    html{scroll-behavior:smooth;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:32px 20px 56px;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .page-shell{
      max-width:640px;
      margin:0 auto;
    }

    .top-nav{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      margin-bottom:24px;
      flex-wrap:wrap;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      border-radius:999px;
      font-size:13.5px;
      font-weight:500;
      text-decoration:none;
      box-shadow:var(--shadow-sm);
      transition:border-color .2s ease, color .2s ease, transform .2s ease, box-shadow .2s ease;
    }

    .btn-back i{
      font-size:11px;
      color:var(--muted);
      transition:color .2s ease, transform .2s ease;
    }

    .btn-back:hover{
      color:var(--ink);
      border-color:var(--line-strong);
      box-shadow:var(--shadow-md);
      transform:translateY(-1px);
    }

    .btn-back:hover i{
      color:var(--brand);
      transform:translateX(-2px);
    }

    .btn-back:focus-visible{
      outline:3px solid var(--brand-soft);
      outline-offset:2px;
    }

    .page-head{
      display:flex;
      flex-direction:column;
      gap:6px;
      margin-bottom:24px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
    }

    .page-head h1{
      font-size:26px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .page-head p{
      margin:0;
      font-size:14px;
      color:var(--muted);
      line-height:1.55;
    }

    .profile-hero{
      display:flex;
      align-items:center;
      gap:16px;
      padding:20px 24px;
      border-radius:var(--radius-lg);
      background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
      color:#fff;
      box-shadow:var(--shadow-brand);
      margin-bottom:20px;
      position:relative;
      overflow:hidden;
      animation:fadeUp .5s ease both;
    }

    .profile-hero::before{
      content:"";
      position:absolute;
      top:-70px;
      right:-60px;
      width:200px;
      height:200px;
      border-radius:50%;
      background:radial-gradient(circle, rgba(255,255,255,.16), transparent 65%);
      pointer-events:none;
    }

    .hero-avatar{
      width:56px;
      height:56px;
      border-radius:50%;
      background:rgba(255,255,255,.16);
      border:1px solid rgba(255,255,255,.28);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:22px;
      font-weight:600;
      color:#fff;
      flex-shrink:0;
      position:relative;
      z-index:1;
      overflow:hidden;
    }

    .hero-avatar img{
      width:100%;
      height:100%;
      object-fit:cover;
      display:block;
    }

    .hero-info{
      position:relative;
      z-index:1;
      min-width:0;
      flex:1;
    }

    .hero-info .hero-name{
      font-size:16px;
      font-weight:600;
      letter-spacing:-.2px;
      margin:0 0 3px;
      line-height:1.3;
      color:#fff;
      overflow:hidden;
      text-overflow:ellipsis;
      white-space:nowrap;
    }

    .hero-info .hero-meta{
      font-size:12.5px;
      color:rgba(255,255,255,.82);
      margin:0;
      display:flex;
      align-items:center;
      gap:8px;
      flex-wrap:wrap;
    }

    .hero-meta .hero-pill{
      display:inline-flex;
      align-items:center;
      gap:6px;
      padding:3px 10px;
      border-radius:999px;
      background:rgba(255,255,255,.16);
      border:1px solid rgba(255,255,255,.24);
      font-size:11.5px;
      font-weight:500;
      letter-spacing:.3px;
    }

    @keyframes fadeUp{
      from{opacity:0; transform:translateY(8px);}
      to{opacity:1; transform:translateY(0);}
    }

    .card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-xl);
      box-shadow:var(--shadow-md);
      overflow:hidden;
      animation:fadeUp .5s ease both;
    }

    .card-head{
      position:relative;
      padding:22px 26px 18px;
      border-bottom:1px solid var(--line);
      background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
      display:flex;
      align-items:center;
      gap:14px;
    }

    .card-head::before{
      content:"";
      position:absolute;
      top:0;left:0;right:0;
      height:3px;
      background:linear-gradient(90deg, var(--brand), var(--brand-2));
    }

    .card-icon{
      width:42px;
      height:42px;
      border-radius:var(--radius-md);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:16px;
      color:var(--brand);
      background:var(--brand-soft);
      flex-shrink:0;
    }

    .card-title{
      font-size:15.5px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0 0 3px;
      line-height:1.35;
    }

    .card-sub{
      font-size:12.5px;
      color:var(--muted);
      margin:0;
      line-height:1.5;
    }

    .card-body-inner{
      padding:24px 26px 26px;
    }

    .alert{
      border-radius:var(--radius-md);
      border:1px solid transparent;
      padding:13px 16px;
      font-size:13.5px;
      font-weight:500;
      display:flex;
      align-items:flex-start;
      gap:10px;
      margin-bottom:20px;
      line-height:1.55;
      animation:fadeUp .35s ease both;
    }

    .alert::before{
      font-family:"Font Awesome 6 Free";
      font-weight:900;
      flex-shrink:0;
      margin-top:1px;
    }

    .alert-success{
      background:var(--success-soft);
      border-color:var(--success-line);
      color:var(--success-dark);
    }

    .alert-success::before{content:"\f058";}

    .alert-danger{
      background:var(--danger-soft);
      border-color:var(--danger-line);
      color:var(--danger-dark);
    }

    .alert-danger::before{content:"\f06a";}

    .field{
      margin-bottom:18px;
    }

    .field-label{
      display:flex;
      align-items:center;
      gap:8px;
      font-size:13px;
      font-weight:500;
      color:var(--ink-2);
      margin-bottom:8px;
    }

    .field-label i{
      font-size:11.5px;
      color:var(--brand);
      width:14px;
      text-align:center;
    }

    .field-hint{
      font-size:11.5px;
      color:var(--muted-2);
      font-weight:400;
      margin-left:auto;
    }

    .form-control{
      width:100%;
      padding:12px 15px;
      font-family:inherit;
      font-size:14.5px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      outline:none;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
    }

    .form-control::placeholder{color:var(--muted-2);}

    .form-control:hover{border-color:var(--line-strong);}

    .form-control:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .password-wrapper{
      position:relative;
      display:block;
    }

    .password-wrapper .form-control{
      padding-right:48px;
    }

    .password-toggle{
      position:absolute;
      top:50%;
      right:8px;
      transform:translateY(-50%);
      width:34px;
      height:34px;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      border:none;
      background:transparent;
      color:var(--muted-2);
      cursor:pointer;
      border-radius:8px;
      transition:color .2s ease, background .2s ease;
      font-size:14px;
    }

    .password-toggle:hover{
      color:var(--brand);
      background:var(--brand-soft);
    }

    .password-toggle:focus-visible{
      outline:3px solid var(--brand-soft);
      outline-offset:2px;
    }

    .foto-upload-box{
      display:flex;
      align-items:center;
      gap:16px;
      padding:16px;
      background:var(--surface-2);
      border:1px dashed var(--line-strong);
      border-radius:var(--radius-md);
      transition:border-color .2s ease, background .2s ease;
      flex-wrap:wrap;
    }

    .foto-upload-box:hover{
      border-color:var(--brand);
      background:#fff;
    }

    .foto-preview{
      width:72px;
      height:72px;
      border-radius:50%;
      overflow:hidden;
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:26px;
      font-weight:600;
      flex-shrink:0;
      border:2px solid #fff;
      box-shadow:var(--shadow-md);
    }

    .foto-preview img{
      width:100%;
      height:100%;
      object-fit:cover;
      display:block;
    }

    .foto-upload-info{
      flex:1;
      min-width:180px;
    }

    .foto-upload-info label{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:8px 14px;
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      font-size:12.5px;
      font-weight:500;
      cursor:pointer;
      transition:border-color .2s ease, background .2s ease, color .2s ease;
    }

    .foto-upload-info label:hover{
      border-color:var(--line-strong);
      background:var(--surface-2);
      color:var(--ink);
    }

    .foto-upload-info label i{
      color:var(--brand);
      font-size:12px;
    }

    .foto-upload-info input[type="file"]{
      display:none;
    }

    .foto-upload-hint{
      display:block;
      margin-top:8px;
      font-size:11.5px;
      color:var(--muted-2);
      line-height:1.5;
    }

    .btn-hapus-foto{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:8px 14px;
      background:var(--surface);
      color:var(--danger);
      border:1px solid var(--danger-line);
      border-radius:var(--radius-sm);
      font-size:12.5px;
      font-weight:500;
      cursor:pointer;
      transition:border-color .2s ease, background .2s ease, color .2s ease;
      font-family:inherit;
      margin-top:10px;
    }

    .btn-hapus-foto:hover{
      background:var(--danger-soft);
      border-color:var(--danger);
      color:var(--danger-dark);
    }

    .btn-hapus-foto:focus-visible{
      outline:3px solid var(--danger-soft);
      outline-offset:2px;
    }

    .btn-hapus-foto i{
      font-size:12px;
    }

    .section-divider{
      display:flex;
      align-items:center;
      gap:12px;
      margin:22px 0 18px;
      color:var(--muted-2);
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
    }

    .section-divider::before,
    .section-divider::after{
      content:"";
      flex:1;
      height:1px;
      background:var(--line);
    }

    .btn-primary{
      width:100%;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:10px;
      padding:13px 20px;
      font-family:inherit;
      font-size:14.5px;
      font-weight:600;
      letter-spacing:.2px;
      color:#fff;
      background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
      border:none;
      border-radius:var(--radius-md);
      cursor:pointer;
      box-shadow:var(--shadow-brand);
      transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
      margin-top:6px;
    }

    .btn-primary i{font-size:13px;}

    .btn-primary:hover{
      transform:translateY(-2px);
      filter:brightness(1.08);
      box-shadow:0 20px 36px -16px rgba(30,60,114,.85);
    }

    .btn-primary:active{transform:translateY(0);}

    .btn-primary:focus-visible{
      outline:3px solid rgba(42,82,152,.35);
      outline-offset:3px;
    }

    @media (max-width:640px){
      body{padding:22px 14px 40px;}
      .page-head h1{font-size:22px;}
      .card-head{padding:18px 20px 16px;}
      .card-body-inner{padding:20px 20px 22px;}
      .card-icon{width:38px;height:38px;font-size:15px;}
      .card-title{font-size:15px;}
      .profile-hero{padding:16px 18px;gap:14px;}
      .hero-avatar{width:48px;height:48px;font-size:19px;}
      .hero-info .hero-name{font-size:15px;}
      .form-control{font-size:14px;padding:11px 14px;}
      .password-wrapper .form-control{padding-right:44px;}
      .password-toggle{width:30px;height:30px;font-size:13px;}
      .foto-upload-box{padding:14px;gap:14px;}
      .foto-preview{width:60px;height:60px;font-size:22px;}
      .btn-primary{font-size:14px;padding:12px 18px;}
      .field-hint{font-size:11px;}
    }

    @media (max-width:420px){
      body{padding:16px 10px 32px;}
      .page-head h1{font-size:19px;}
      .page-eyebrow{font-size:10.5px;}
      .card-head{padding:16px 16px 14px;}
      .card-body-inner{padding:16px 16px 20px;}
      .alert{font-size:12.5px;padding:11px 14px;}
      .field-hint{display:none;}
      .foto-upload-box{flex-direction:column;text-align:center;align-items:center;}
      .foto-upload-info{text-align:center;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>
  <div class="page-shell">
    <div class="top-nav">
      <a href="dashboard_guru.php" class="btn-back">
        <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
      </a>
    </div>

    <div class="page-head">
      <span class="page-eyebrow">Akun</span>
      <h1>Pengaturan Profil Guru</h1>
      <p>Perbarui identitas, foto profil, dan kata sandi akun Anda.</p>
    </div>

    <div class="profile-hero">
      <div class="hero-avatar" id="heroAvatar">
        <?php if ($has_foto): ?>
          <img src="<?= $foto_url ?>" alt="Foto Profil">
        <?php else: ?>
          <?= htmlspecialchars($initial); ?>
        <?php endif; ?>
      </div>
      <div class="hero-info">
        <h3 class="hero-name"><?= htmlspecialchars($data_user['nama'] ?? $data_user['username'] ?? 'Guru'); ?></h3>
        <div class="hero-meta">
          <span>@<?= htmlspecialchars($data_user['username'] ?? 'guru'); ?></span>
          <span class="hero-pill"><i class="fas fa-chalkboard-teacher" style="font-size:10px;"></i> <?= htmlspecialchars(ucfirst($role)); ?></span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-icon">
          <i class="fas fa-user-pen"></i>
        </div>
        <div>
          <h2 class="card-title">Informasi Akun</h2>
          <p class="card-sub">Ubah foto, nama, username, atau password akun Anda.</p>
        </div>
      </div>
      <div class="card-body-inner">
        <?= $pesan; ?>

        <form method="POST" enctype="multipart/form-data">
          <div class="field">
            <label class="field-label">
              <i class="fas fa-image"></i> Foto Profil
              <span class="field-hint">Kosongkan jika tidak diubah</span>
            </label>
            <div class="foto-upload-box">
              <div class="foto-preview" id="fotoPreview">
                <?php if ($has_foto): ?>
                  <img src="<?= $foto_url ?>" alt="Foto Profil" id="fotoPreviewImg">
                <?php else: ?>
                  <span id="fotoPreviewInitial"><?= htmlspecialchars($initial); ?></span>
                <?php endif; ?>
              </div>
              <div class="foto-upload-info">
                <label for="foto">
                  <i class="fas fa-cloud-arrow-up"></i> Pilih Foto
                </label>
                <input type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/gif,image/webp">
                <span class="foto-upload-hint" id="fotoFileName">Format: JPG, PNG, GIF, WEBP &middot; Maks 2 MB</span>

                <?php if ($has_foto): ?>
                  <button type="submit" name="hapus_foto" class="btn-hapus-foto"
                          onclick="return confirm('Hapus foto profil saat ini?');">
                    <i class="fas fa-trash"></i> Hapus Foto
                  </button>
                <?php endif; ?>
              </div>
            </div>
          </div>

          <div class="field">
            <label class="field-label" for="nama">
              <i class="fas fa-signature"></i> Nama Lengkap
            </label>
            <input type="text" id="nama" name="nama" class="form-control" value="<?= htmlspecialchars($data_user['nama'] ?? ''); ?>" placeholder="Masukkan nama lengkap" required>
          </div>

          <div class="field">
            <label class="field-label" for="username">
              <i class="fas fa-at"></i> Username
            </label>
            <input type="text" id="username" name="username" class="form-control" value="<?= htmlspecialchars($data_user['username'] ?? ''); ?>" placeholder="Masukkan username" required>
          </div>

          <div class="section-divider">Ubah Password</div>

          <div class="field">
            <label class="field-label" for="password">
              <i class="fas fa-lock"></i> Password Baru
              <span class="field-hint">Kosongkan jika tidak diubah</span>
            </label>
            <div class="password-wrapper">
              <input type="password" id="password" name="password" class="form-control" placeholder="Masukkan password baru" autocomplete="new-password">
              <button type="button" class="password-toggle" data-target="password" aria-label="Lihat password">
                <i class="fas fa-eye"></i>
              </button>
            </div>
          </div>

          <div class="field">
            <label class="field-label" for="konfirmasi_password">
              <i class="fas fa-check-double"></i> Konfirmasi Password Baru
            </label>
            <div class="password-wrapper">
              <input type="password" id="konfirmasi_password" name="konfirmasi_password" class="form-control" placeholder="Ulangi password baru" autocomplete="new-password">
              <button type="button" class="password-toggle" data-target="konfirmasi_password" aria-label="Lihat password">
                <i class="fas fa-eye"></i>
              </button>
            </div>
          </div>

          <button type="submit" name="update_profil" class="btn-primary">
            <i class="fas fa-floppy-disk"></i> Simpan Perubahan
          </button>
        </form>
      </div>
    </div>
  </div>

  <script>
    document.querySelectorAll('.password-toggle').forEach(function(button) {
      button.addEventListener('click', function() {
        const targetId = this.getAttribute('data-target');
        const input = document.getElementById(targetId);
        if (!input) return;

        const isPassword = input.getAttribute('type') === 'password';
        input.setAttribute('type', isPassword ? 'text' : 'password');

        const icon = this.querySelector('i');
        if (icon) {
          icon.classList.toggle('fa-eye', !isPassword);
          icon.classList.toggle('fa-eye-slash', isPassword);
        }

        this.setAttribute('aria-label', isPassword ? 'Sembunyikan password' : 'Lihat password');
      });
    });

    const fotoInput = document.getElementById('foto');
    const fotoPreview = document.getElementById('fotoPreview');
    const fotoFileName = document.getElementById('fotoFileName');

    if (fotoInput) {
      fotoInput.addEventListener('change', function() {
        const file = this.files && this.files[0];
        if (!file) return;

        if (!file.type.startsWith('image/')) {
          fotoFileName.textContent = 'File bukan gambar!';
          this.value = '';
          return;
        }

        if (file.size > 2 * 1024 * 1024) {
          fotoFileName.textContent = 'Ukuran file terlalu besar (maks 2 MB)';
          this.value = '';
          return;
        }

        fotoFileName.textContent = file.name;

        const reader = new FileReader();
        reader.onload = function(e) {
          fotoPreview.innerHTML = '<img src="' + e.target.result + '" alt="Preview Foto">';
        };
        reader.readAsDataURL(file);
      });
    }
  </script>
</body>
</html>