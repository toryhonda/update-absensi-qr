<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
ob_start();

session_start();

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

include "config.php";
date_default_timezone_set("Asia/Jakarta");

function kirimPesanWhatsApp($tujuan, $pesan) {
    global $conn;
    $q = mysqli_query($conn, "SELECT wa_token, wa_phone_number_id FROM profil_sekolah LIMIT 1");
    $profil = mysqli_fetch_assoc($q);

    if (!$profil || empty($profil['wa_token']) || empty($profil['wa_phone_number_id'])) {
        return ["status" => false, "message" => "Kredensial belum lengkap di database."];
    }

    $tujuan = preg_replace('/[^0-9]/', '', $tujuan);
    if (substr($tujuan, 0, 1) === '0') {
        $tujuan = '62' . substr($tujuan, 1);
    }

    $url = "https://graph.facebook.com/v18.0/{$profil['wa_phone_number_id']}/messages";
    $payload = json_encode([
        "messaging_product" => "whatsapp",
        "to" => $tujuan,
        "type" => "text",
        "text" => ["body" => $pesan]
    ]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Bearer " . $profil['wa_token'],
        "Content-Type: application/json"
    ]);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $res_arr = json_decode($response, true);
    if ($http_code == 200) {
        return ["status" => true, "response" => $res_arr];
    } else {
        return ["status" => false, "code" => $http_code, "response" => $res_arr];
    }
}

function output_json($arr) {
    if (ob_get_length()) { ob_clean(); }
    echo json_encode($arr);
    exit;
}

$nisn = $_GET['code'] ?? $_GET['nisn'] ?? '';

if (empty($nisn)) {
    output_json(['status' => 'error', 'message' => 'Kode barcode/QR tidak ditemukan.']);
}

$tanggal = date("Y-m-d");
$jam     = date("H:i:s");

// 1. Cek Hari Libur
$cekLibur = mysqli_query($conn, "SELECT * FROM hari_libur WHERE tanggal='$tanggal'");
if ($cekLibur && mysqli_num_rows($cekLibur) > 0) {
    output_json(["status" => "warning", "message" => "⛔ Hari ini libur!"]);
}

// 2. Deteksi Sesi Berdasarkan Jam Sekarang — HANYA yang aktif
$cekSesi = mysqli_query($conn, "SELECT sesi FROM pengaturan_jam_sesi 
    WHERE '$jam' BETWEEN jam_mulai AND jam_selesai 
    AND is_active = 1
    ORDER BY FIELD(sesi, 'Masuk', 'Sholat Dhuha', 'Sholat Dhuhur', 'Pulang') ASC 
    LIMIT 1");

if (!$cekSesi || mysqli_num_rows($cekSesi) == 0) {
    output_json([
        "status"  => "warning",
        "message" => "⛔ Saat ini tidak ada sesi absensi yang aktif.<br>🕒 Jam sekarang: $jam"
    ]);
}
$sesiAktif = mysqli_fetch_assoc($cekSesi)['sesi'];

// 3. Ambil Data Siswa (cari berdasarkan NISN dulu, lalu NIS)
$nisn_esc = mysqli_real_escape_string($conn, $nisn);
$siswa = mysqli_query($conn, "SELECT * FROM siswa WHERE nisn='$nisn_esc' OR nis='$nisn_esc' LIMIT 1");
if (!$siswa || mysqli_num_rows($siswa) == 0) {
    output_json(["status" => "error", "message" => "❌ Siswa tidak ditemukan untuk kode: $nisn"]);
}
$s = mysqli_fetch_assoc($siswa);

// 4. Normalisasi Nomor WhatsApp
$no_wa = "";
if (!empty($s['no_wa'])) {
    $no_wa = preg_replace('/[^0-9]/', '', $s['no_wa']);
    if (substr($no_wa, 0, 1) == "0") {
        $no_wa = "62" . substr($no_wa, 1);
    }
}

// 5. Cek Absensi Berdasarkan Siswa, Tanggal, dan Sesi Aktif
$sesiEsc = mysqli_real_escape_string($conn, $sesiAktif);
$cekAbsen = mysqli_query($conn, "SELECT * FROM absensi WHERE siswa_id={$s['id']} AND tanggal='$tanggal' AND sesi='$sesiEsc'");

if (!$cekAbsen) {
    output_json([
        "status"  => "error",
        "message" => "⚠️ Gagal membaca tabel absensi: " . mysqli_error($conn) . "<br>Silakan jalankan <b>update_db.php</b> terlebih dahulu."
    ]);
}

if (mysqli_num_rows($cekAbsen) == 0) {
    $simpan = mysqli_query($conn, "INSERT INTO absensi (siswa_id, tanggal, jam, sesi, status) VALUES ({$s['id']}, '$tanggal', '$jam', '$sesiEsc', 'H')");

    if ($simpan) {
        $status = "success";
        $msg = "✅ Absen $sesiAktif berhasil: {$s['nama']} ({$s['kelas']})<br>🕒 Jam: $jam";

        $pesanWA = "Assalamualaikum Wr. Wb.\n\n"
                 . "Pemberitahuan: Putra/Putri Anda atas nama *{$s['nama']}* (Kelas: {$s['kelas']}) telah berhasil melakukan *Absensi {$sesiAktif}* pada tanggal {$tanggal} pukul {$jam}.\n\n"
                 . "Terima kasih.";

        if (!empty($no_wa)) {
            kirimPesanWhatsApp($no_wa, $pesanWA);
        }
    } else {
        $status = "error";
        $msg = "Gagal menyimpan absensi: " . mysqli_error($conn);
    }
} else {
    $row = mysqli_fetch_assoc($cekAbsen);
    $status = "warning";
    $msg = "ℹ️ {$s['nama']} sudah absen sesi *{$sesiAktif}* hari ini.<br>🕒 Jam: {$row['jam']}";
}

output_json([
    "status"  => $status,
    "message" => $msg
]);