<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

$kelas = $_GET['kelas'] ?? '';
$bulan = $_GET['bulan'] ?? date('m');
$tahun = $_GET['tahun'] ?? date('Y');

$hariIni = date('d');
$bulanIni = date('m');
$tahunIni = date('Y');

$kelasList = mysqli_query($conn, "SELECT DISTINCT kelas FROM siswa ORDER BY kelas");
$jumlahHari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);

$siswaQuery = "SELECT * FROM siswa WHERE status='aktif'";
if ($kelas != '') {
  $siswaQuery .= " AND kelas = '$kelas'";
}
$siswaQuery .= " ORDER BY nama";
$siswaResult = mysqli_query($conn, $siswaQuery);

$absensi = [];
$absensiQuery = "SELECT a.*, s.nis, s.nama FROM absensi a 
                 JOIN siswa s ON a.siswa_id = s.id 
                 WHERE MONTH(a.tanggal) = '$bulan' 
                   AND YEAR(a.tanggal) = '$tahun'
                   AND s.status='aktif'";
if ($kelas != '') {
  $absensiQuery .= " AND s.kelas = '$kelas'";
}
$resultAbsensi = mysqli_query($conn, $absensiQuery);

while ($row = mysqli_fetch_assoc($resultAbsensi)) {
  $sid = $row['siswa_id'];
  $tgl = (int)date('j', strtotime($row['tanggal']));
  $absensi[$sid][$tgl] = $row['status'];
}

$libur = [];
$queryLibur = mysqli_query($conn, "SELECT tanggal FROM hari_libur");
while ($row = mysqli_fetch_assoc($queryLibur)) {
  $libur[] = $row['tanggal'];
}

$profil = mysqli_fetch_assoc(mysqli_query($conn, "SELECT kepala_sekolah, nip_kepala FROM profil_sekolah LIMIT 1"));

$wali_nama = '....................................';
$wali_nip = '........................';
if ($kelas != '') {
    $qWali = mysqli_query($conn, "SELECT nama_wali, nip_wali FROM wali_kelas WHERE kelas = '$kelas' LIMIT 1");
    if ($w = mysqli_fetch_assoc($qWali)) {
        $wali_nama = $w['nama_wali'];
        $wali_nip = $w['nip_wali'];
    }
}

$tanggal_terakhir = date("j F Y", strtotime("$tahun-$bulan-" . cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun)));
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Rekap Absensi Bulanan Per Siswa</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --purple:#8b5cf6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1400px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1400px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      margin-bottom:20px;
      overflow:hidden;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:18px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .card-panel-body{
      padding:22px 24px;
    }

    .filter-grid{
      display:grid;
      grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));
      gap:14px;
      align-items:end;
    }

    .filter-item{
      display:flex;
      flex-direction:column;
      gap:7px;
    }

    .form-label{
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
    }

    .form-control,
    .form-select{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
      width:100%;
      outline:none;
    }

    .form-control:hover,
    .form-select:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus,
    .form-select:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-secondary{
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      box-shadow:var(--shadow-sm);
    }
    .btn-secondary:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .action-row{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:20px;
    }

    .legend{
      display:flex;
      flex-wrap:wrap;
      gap:8px;
      margin-bottom:16px;
    }

    .legend-item{
      display:inline-flex;
      align-items:center;
      gap:7px;
      padding:6px 12px;
      font-size:12px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:999px;
    }

    .legend-dot{
      width:12px;
      height:12px;
      border-radius:4px;
      flex-shrink:0;
    }

    .legend-h{background:#10b981;}
    .legend-s{background:#8b5cf6;}
    .legend-i{background:#f59e0b;}
    .legend-a{background:#ef4444;}
    .legend-off{background:#cbd5e1;}

    .stats-row{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:18px;
    }

    .stat-chip{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:8px 14px;
      font-size:12.5px;
      font-weight:500;
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:999px;
      color:var(--ink-2);
    }

    .stat-chip i{
      color:var(--brand);
      font-size:12px;
    }

    .stat-chip strong{
      color:var(--ink);
      font-weight:600;
    }

    .table-wrapper{
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      overflow:hidden;
      background:var(--surface);
    }

    .table-scroll{
      overflow-x:auto;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
    }

    .table-scroll::-webkit-scrollbar{width:8px;height:8px;}
    .table-scroll::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-scroll::-webkit-scrollbar-track{background:transparent;}

    table.rekap-table{
      border-collapse:separate;
      border-spacing:0;
      width:100%;
      font-size:12px;
      color:var(--ink-2);
      font-family:'Rubik', sans-serif;
    }

    .rekap-table thead th{
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11px;
      letter-spacing:.4px;
      text-transform:uppercase;
      padding:10px 8px;
      border-bottom:1px solid var(--line);
      border-right:1px solid var(--line);
      white-space:nowrap;
      text-align:center;
      position:sticky;
      top:0;
      z-index:2;
      vertical-align:middle;
    }

    .rekap-table thead tr:nth-child(2) th{
      top:36px;
    }

    .rekap-table tbody td{
      padding:8px;
      text-align:center;
      border-bottom:1px solid var(--line);
      border-right:1px solid var(--line);
      font-size:12px;
      color:var(--ink-2);
      background:var(--surface);
    }

    .rekap-table tbody tr:hover td{
      background:rgba(42,82,152,.03);
    }

    .rekap-table tbody td:last-child,
    .rekap-table thead th:last-child{
      border-right:0;
    }

    .rekap-table tbody td.cell-nama{
      text-align:left;
      font-weight:500;
      color:var(--ink);
      white-space:nowrap;
    }

    .rekap-table tbody td.cell-nis{
      text-align:left;
      font-size:11.5px;
      color:var(--muted);
      white-space:nowrap;
    }

    .rekap-table tbody td.minggu,
    .rekap-table tbody td.libur{
      background:rgba(239,68,68,.06);
      color:var(--danger);
      font-weight:600;
    }

    .rekap-table tbody td.hari-mendatang{
      background:var(--surface-2);
      color:#cbd5e1;
    }

    .rekap-table tbody td.alpa{
      color:#b91c1c;
      font-weight:600;
      background:rgba(239,68,68,.06);
    }

    .rekap-table tbody td.hadir-dot{
      color:#047857;
      font-weight:700;
      background:rgba(16,185,129,.05);
    }

    .rekap-table tbody td.sakit-cell{
      color:#6d28d9;
      font-weight:600;
      background:rgba(139,92,246,.05);
    }

    .rekap-table tbody td.izin-cell{
      color:#b45309;
      font-weight:600;
      background:rgba(245,158,11,.05);
    }

    .rekap-table .rekap-h{
      color:#047857;
      font-weight:700;
      background:rgba(16,185,129,.08);
    }

    .rekap-table .rekap-s{
      color:#6d28d9;
      font-weight:700;
      background:rgba(139,92,246,.08);
    }

    .rekap-table .rekap-i{
      color:#b45309;
      font-weight:700;
      background:rgba(245,158,11,.08);
    }

    .rekap-table .rekap-a{
      color:#b91c1c;
      font-weight:700;
      background:rgba(239,68,68,.08);
    }

    .signature-grid{
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:20px;
      margin-top:28px;
      padding-top:24px;
      border-top:1px solid var(--line);
    }

    .signature-block{
      padding:20px 18px;
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      text-align:center;
      font-size:13.5px;
      color:var(--ink-2);
    }

    .signature-block .sig-label{
      font-size:12.5px;
      color:var(--muted);
      line-height:1.6;
    }

    .signature-block .sig-space{
      height:70px;
      display:flex;
      align-items:center;
      justify-content:center;
      color:var(--muted-2);
      font-size:20px;
    }

    .signature-block .sig-name{
      font-weight:600;
      color:var(--ink);
      text-decoration:underline;
      text-underline-offset:3px;
    }

    .signature-block .sig-nip{
      font-size:12.5px;
      color:var(--muted);
      margin-top:4px;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .card-panel-body{padding:18px;}
      .card-panel-header{padding:16px 20px;}
      .signature-grid{grid-template-columns:1fr;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .card-panel{border-radius:var(--radius-md);}
      .card-panel-body{padding:16px;}
      .card-panel-header{padding:14px 16px;}
      .card-panel-title{font-size:13.5px;}
      .filter-grid{grid-template-columns:1fr;}
      .action-row{flex-direction:column;}
      .action-row .btn{width:100%;}
      .btn{padding:9px 14px;font-size:13px;}
      table.rekap-table{font-size:11px;}
      .rekap-table thead th,
      .rekap-table tbody td{padding:6px 4px;font-size:11px;}
      .legend{gap:6px;}
      .legend-item{padding:5px 10px;font-size:11.5px;}
      .stats-row{gap:6px;}
      .stat-chip{padding:6px 12px;font-size:11.5px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-calendar-days"></i></div>
        <div class="brand-titles">
          <h1>Rekap Absensi Bulanan</h1>
          <span>Laporan kehadiran siswa per bulan</span>
        </div>
      </div>
      <a href="dashboard_guru.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Laporan Bulanan</span>
      <h2>Rekap Absensi Bulanan Per Siswa</h2>
      <p>Ringkasan kehadiran siswa dalam satu bulan penuh dengan status H, S, I, dan A.</p>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-filter"></i>
          Filter Periode
        </div>
      </div>
      <div class="card-panel-body">
        <form method="get" class="filter-grid">
          <div class="filter-item">
            <label class="form-label" for="kelas">Kelas</label>
            <select name="kelas" id="kelas" class="form-select">
              <option value="">Semua Kelas</option>
              <?php 
              mysqli_data_seek($kelasList, 0);
              while ($k = mysqli_fetch_assoc($kelasList)) {
                $sel = ($k['kelas'] == $kelas) ? 'selected' : '';
                echo "<option value='" . htmlspecialchars($k['kelas']) . "' $sel>" . htmlspecialchars($k['kelas']) . "</option>";
              } ?>
            </select>
          </div>

          <div class="filter-item">
            <label class="form-label" for="bulan">Bulan</label>
            <select name="bulan" id="bulan" class="form-select">
              <?php for ($b = 1; $b <= 12; $b++) {
                $sel = ($b == $bulan) ? 'selected' : '';
                echo "<option value='$b' $sel>" . date('F', mktime(0, 0, 0, $b, 10)) . "</option>";
              } ?>
            </select>
          </div>

          <div class="filter-item">
            <label class="form-label" for="tahun">Tahun</label>
            <input type="number" name="tahun" id="tahun" value="<?= htmlspecialchars($tahun) ?>" class="form-control">
          </div>

          <div class="filter-item">
            <label class="form-label">&nbsp;</label>
            <button type="submit" class="btn btn-primary">
              <i class="fas fa-search"></i> Tampilkan
            </button>
          </div>
        </form>
      </div>
    </div>

    <div class="action-row">
      <a href="cetak_absen.php?kelas=<?= urlencode($kelas) ?>&bulan=<?= urlencode($bulan) ?>&tahun=<?= urlencode($tahun) ?>" target="_blank" class="btn btn-success">
        <i class="fas fa-print"></i> Cetak / Simpan PDF
      </a>
      <a href="dashboard_guru.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
      </a>
    </div>

    <div class="legend">
      <div class="legend-item"><span class="legend-dot legend-h"></span> H — Hadir</div>
      <div class="legend-item"><span class="legend-dot legend-s"></span> S — Sakit</div>
      <div class="legend-item"><span class="legend-dot legend-i"></span> I — Izin</div>
      <div class="legend-item"><span class="legend-dot legend-a"></span> A — Alpha</div>
      <div class="legend-item"><span class="legend-dot legend-off"></span> • — Libur / Minggu</div>
    </div>

    <div class="stats-row">
      <span class="stat-chip">
        <i class="fas fa-calendar-week"></i>
        Periode: <strong><?= date('F Y', mktime(0, 0, 0, $bulan, 10, $tahun)) ?></strong>
      </span>
      <span class="stat-chip">
        <i class="fas fa-chalkboard"></i>
        Kelas: <strong><?= $kelas ? htmlspecialchars($kelas) : 'Semua Kelas' ?></strong>
      </span>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-table"></i>
          Tabel Rekap Bulanan
        </div>
      </div>
      <div class="card-panel-body" style="padding:0;">
        <div class="table-wrapper">
          <div class="table-scroll">
            <table class="rekap-table">
              <thead>
                <tr>
                  <th rowspan="2">No</th>
                  <th rowspan="2">NIS</th>
                  <th rowspan="2" style="text-align:left;">Nama</th>
                  <th colspan="<?= $jumlahHari ?>">Tanggal</th>
                  <th colspan="4">Rekap</th>
                </tr>
                <tr>
                  <?php
                  for ($i = 1; $i <= $jumlahHari; $i++) {
                    $tanggal = "$tahun-" . str_pad($bulan, 2, '0', STR_PAD_LEFT) . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
                    $day = date('w', strtotime($tanggal));
                    $class = ($day == 0) ? 'minggu' : '';
                    echo "<th class='$class'>$i</th>";
                  }
                  ?>
                  <th>H</th><th>S</th><th>I</th><th>A</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $no = 1;
                mysqli_data_seek($siswaResult, 0);
                while ($siswa = mysqli_fetch_assoc($siswaResult)) {
                  $sid = $siswa['id'];
                  echo "<tr>";
                  echo "<td>$no</td>";
                  echo "<td class='cell-nis'>" . htmlspecialchars($siswa['nis']) . "</td>";
                  echo "<td class='cell-nama'>" . htmlspecialchars($siswa['nama']) . "</td>";

                  $countH = $countS = $countI = $countA = 0;

                  for ($i = 1; $i <= $jumlahHari; $i++) {
                    $tanggal = "$tahun-" . str_pad($bulan, 2, '0', STR_PAD_LEFT) . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
                    $day = date('w', strtotime($tanggal));
                    $isLibur = in_array($tanggal, $libur);
                    
                    $isHariMendatang = false;
                    if ($tahun == $tahunIni && $bulan == $bulanIni && $i > $hariIni) {
                      $isHariMendatang = true;
                    } elseif ($tahun == $tahunIni && $bulan > $bulanIni) {
                      $isHariMendatang = true;
                    } elseif ($tahun > $tahunIni) {
                      $isHariMendatang = true;
                    }
                    
                    $val = $absensi[$sid][$i] ?? '';
                    
                    if ($val == '') {
                      if ($day == 0 || $isLibur) {
                        echo "<td class='libur'><span class='dot-red'>&bull;</span></td>";
                      } 
                      elseif ($isHariMendatang) {
                        echo "<td class='hari-mendatang'></td>";
                      }
                      else {
                        echo "<td class='alpa'>A</td>";
                        $countA++;
                      }
                    } else {
                      if ($val == 'H') {
                        echo "<td class='hadir-dot'>&bull;</td>";
                        $countH++;
                      } elseif ($val == 'A') {
                        echo "<td class='alpa'>A</td>";
                        $countA++;
                      } elseif ($val == 'S') {
                        echo "<td class='sakit-cell'>S</td>";
                        $countS++;
                      } elseif ($val == 'I') {
                        echo "<td class='izin-cell'>I</td>";
                        $countI++;
                      } else {
                        echo "<td>" . htmlspecialchars($val) . "</td>";
                      }
                    }
                  }

                  echo "<td class='rekap-h'>$countH</td>";
                  echo "<td class='rekap-s'>$countS</td>";
                  echo "<td class='rekap-i'>$countI</td>";
                  echo "<td class='rekap-a'>$countA</td>";
                  echo "</tr>";
                  $no++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <div class="signature-grid">
      <div class="signature-block">
        <div class="sig-label">
          Mengetahui,<br>
          Kepala Sekolah
        </div>
        <div class="sig-space"><i class="fas fa-signature"></i></div>
        <div class="sig-name"><?= htmlspecialchars($profil['kepala_sekolah'] ?? '....................................') ?></div>
        <div class="sig-nip">NIP. <?= htmlspecialchars($profil['nip_kepala'] ?? '........................') ?></div>
      </div>

      <div class="signature-block">
        <div class="sig-label">
          <?= htmlspecialchars($tanggal_terakhir) ?><br>
          Wali Kelas <?= $kelas != '' ? htmlspecialchars($kelas) : '(Semua Kelas)' ?>
        </div>
        <div class="sig-space"><i class="fas fa-signature"></i></div>
        <div class="sig-name"><?= htmlspecialchars($wali_nama) ?></div>
        <div class="sig-nip">NIP. <?= htmlspecialchars($wali_nip) ?></div>
      </div>
    </div>

  </div>

</body>
</html>