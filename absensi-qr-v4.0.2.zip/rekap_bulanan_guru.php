<?php

include 'config.php';

$bulan = $_GET['bulan'] ?? date('m');
$tahun = $_GET['tahun'] ?? date('Y');

$jumlahHari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);

$guruQuery = "SELECT * FROM guru WHERE status='aktif' ORDER BY nama";
$guruResult = mysqli_query($conn, $guruQuery);

$absensiHadir = [];
$absensiQuery = "SELECT a.*, g.nip, g.nama FROM absensi_guru a 
                 JOIN guru g ON a.guru_id = g.id 
                 WHERE MONTH(a.tanggal) = '$bulan' 
                   AND YEAR(a.tanggal) = '$tahun'
                   AND g.status='aktif'";
$resultAbsensi = mysqli_query($conn, $absensiQuery);

if ($resultAbsensi) {
    while ($row = mysqli_fetch_assoc($resultAbsensi)) {
        $gid = $row['guru_id'];
        $tgl = (int)date('j', strtotime($row['tanggal']));
        $absensiHadir[$gid][$tgl] = 'H';
    }
}

$absensiIzin = [];
$izinQuery = "SELECT i.*, g.nip, g.nama FROM izin_guru i 
              JOIN guru g ON i.guru_id = g.id 
              WHERE MONTH(i.tanggal) = '$bulan' 
                AND YEAR(i.tanggal) = '$tahun'
                AND g.status='aktif'
                AND i.status = 'disetujui'";

$resultIzin = mysqli_query($conn, $izinQuery);

if ($resultIzin) {
    while ($row = mysqli_fetch_assoc($resultIzin)) {
        $gid = $row['guru_id'];
        $tgl = (int)date('j', strtotime($row['tanggal']));
        $absensiIzin[$gid][$tgl] = $row['jenis_izin'];
    }
}

$absensiKehadiranManual = [];
$kehadiranQuery = "SELECT k.*, g.nip, g.nama FROM kehadiran_guru k 
                   JOIN guru g ON k.guru_id = g.id 
                   WHERE MONTH(k.tanggal) = '$bulan' 
                     AND YEAR(k.tanggal) = '$tahun'
                     AND g.status='aktif'";

$resultKehadiran = mysqli_query($conn, $kehadiranQuery);

if ($resultKehadiran) {
    while ($row = mysqli_fetch_assoc($resultKehadiran)) {
        $gid = $row['guru_id'];
        $tgl = (int)date('j', strtotime($row['tanggal']));
        $absensiKehadiranManual[$gid][$tgl] = 'H';
    }
}

$absensi = $absensiIzin;

foreach ($absensiKehadiranManual as $gid => $hari) {
    foreach ($hari as $tgl => $status) {
        if (!isset($absensi[$gid][$tgl])) {
            $absensi[$gid][$tgl] = $status;
        }
    }
}

foreach ($absensiHadir as $gid => $hari) {
    foreach ($hari as $tgl => $status) {
        if (!isset($absensi[$gid][$tgl])) {
            $absensi[$gid][$tgl] = $status;
        }
    }
}

$libur = [];
$queryLibur = mysqli_query($conn, "SELECT tanggal FROM hari_libur");
if ($queryLibur) {
    while ($row = mysqli_fetch_assoc($queryLibur)) {
        $libur[] = $row['tanggal'];
    }
}

$profil = [];
$profilQuery = mysqli_query($conn, "SELECT kepala_sekolah, nip_kepala FROM profil_sekolah LIMIT 1");
if ($profilQuery) {
    $profil = mysqli_fetch_assoc($profilQuery);
}

$tanggal_terakhir = date("j F Y", strtotime("$tahun-$bulan-" . cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun)));

$hariKerja = [];
$jadwalQuery = @mysqli_query($conn, "SELECT DISTINCT DAYOFWEEK(tanggal) as hari FROM jadwal_guru");
if ($jadwalQuery && mysqli_num_rows($jadwalQuery) > 0) {
    while ($row = mysqli_fetch_assoc($jadwalQuery)) {
        $hariKerja[] = $row['hari'];
    }
} else {
    $hariKerja = [2, 3, 4, 5, 6];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Rekap Absensi Bulanan Guru</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --purple:#8b5cf6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    html{scroll-behavior:smooth;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1400px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1400px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .info-box{
      background:rgba(59,130,246,.08);
      border:1px solid rgba(59,130,246,.2);
      border-left:4px solid var(--info);
      padding:14px 18px;
      margin-bottom:20px;
      border-radius:var(--radius-md);
      font-size:13px;
      color:#1e40af;
      line-height:1.65;
    }

    .info-box strong{
      color:#1d4ed8;
      font-weight:600;
    }

    .info-box ul{
      margin:8px 0 0;
      padding-left:18px;
    }

    .info-box li{
      font-size:12.5px;
      color:#1e40af;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      margin-bottom:20px;
      overflow:hidden;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:18px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .card-panel-body{
      padding:22px 24px;
    }

    .filter-grid{
      display:grid;
      grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));
      gap:14px;
      align-items:end;
    }

    .filter-item{
      display:flex;
      flex-direction:column;
      gap:7px;
    }

    .filter-item label{
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
    }

    .form-control,
    .form-select{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
      width:100%;
      outline:none;
    }

    .form-control:hover,
    .form-select:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus,
    .form-select:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-secondary{
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      box-shadow:var(--shadow-sm);
    }
    .btn-secondary:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .action-buttons{
      display:flex;
      gap:10px;
      flex-wrap:wrap;
      margin-bottom:20px;
    }

    .legend{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:18px;
    }

    .legend-item{
      display:inline-flex;
      align-items:center;
      gap:7px;
      padding:6px 12px;
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:999px;
    }

    .legend-color{
      width:12px;
      height:12px;
      border-radius:4px;
      flex-shrink:0;
    }

    .legend-hadir{background:#10b981;}
    .legend-izin{background:#f59e0b;}
    .legend-sakit{background:#8b5cf6;}
    .legend-alpha{background:#ef4444;}
    .legend-minggu{background:#ef4444;}
    .legend-libur{background:#ef4444;}

    .table-wrapper{
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      overflow:hidden;
      background:var(--surface);
    }

    .table-scroll{
      overflow-x:auto;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
    }

    .table-scroll::-webkit-scrollbar{width:8px;height:8px;}
    .table-scroll::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-scroll::-webkit-scrollbar-track{background:transparent;}

    table.rekap-table{
      border-collapse:separate;
      border-spacing:0;
      width:100%;
      font-size:12px;
      color:var(--ink-2);
      font-family:'Rubik', sans-serif;
    }

    .rekap-table thead th{
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11px;
      letter-spacing:.4px;
      text-transform:uppercase;
      padding:10px 8px;
      border-bottom:1px solid var(--line);
      border-right:1px solid var(--line);
      white-space:nowrap;
      text-align:center;
      position:sticky;
      top:0;
      z-index:2;
    }

    .rekap-table thead tr:nth-child(2) th{
      top:36px;
    }

    .rekap-table tbody td{
      padding:8px;
      text-align:center;
      border-bottom:1px solid var(--line);
      border-right:1px solid var(--line);
      font-size:12px;
      color:var(--ink-2);
      background:var(--surface);
    }

    .rekap-table tbody tr:hover td{
      background:rgba(42,82,152,.03);
    }

    .rekap-table tbody td:last-child,
    .rekap-table thead th:last-child{
      border-right:0;
    }

    .rekap-table tbody td.cell-nama{
      text-align:left;
      font-weight:500;
      color:var(--ink);
      white-space:nowrap;
    }

    .rekap-table tbody td.cell-nip{
      text-align:left;
      font-size:11.5px;
      color:var(--muted);
      white-space:nowrap;
    }

    .rekap-table tbody td.minggu{
      background:rgba(239,68,68,.06);
      color:var(--danger);
      font-weight:600;
    }

    .rekap-table tbody td.libur{
      background:rgba(239,68,68,.06);
      color:var(--danger);
      font-weight:600;
    }

    .rekap-table tbody td.kosong{
      background:var(--surface-2);
    }

    .rekap-table tbody td.hadir{
      color:#047857;
      font-weight:600;
      background:rgba(16,185,129,.06);
    }

    .rekap-table tbody td.izin{
      color:#b45309;
      font-weight:600;
      background:rgba(245,158,11,.06);
    }

    .rekap-table tbody td.sakit{
      color:#6d28d9;
      font-weight:600;
      background:rgba(139,92,246,.06);
    }

    .rekap-table tbody td.alpha{
      color:#b91c1c;
      font-weight:600;
      background:rgba(239,68,68,.06);
    }

    .rekap-table .rekap-h{
      color:#047857;
      font-weight:700;
      background:rgba(16,185,129,.08);
    }

    .rekap-table .rekap-i{
      color:#b45309;
      font-weight:700;
      background:rgba(245,158,11,.08);
    }

    .rekap-table .rekap-s{
      color:#6d28d9;
      font-weight:700;
      background:rgba(139,92,246,.08);
    }

    .rekap-table .rekap-a{
      color:#b91c1c;
      font-weight:700;
      background:rgba(239,68,68,.08);
    }

    .footer-signature{
      margin-top:32px;
      padding-top:28px;
      border-top:1px solid var(--line);
    }

    .signature-grid{
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:20px;
      text-align:center;
      font-size:13.5px;
      color:var(--ink-2);
    }

    .signature-block{
      padding:20px 16px;
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
    }

    .signature-block .sig-label{
      font-size:12.5px;
      color:var(--muted);
      line-height:1.6;
    }

    .signature-block .sig-space{
      height:70px;
      display:flex;
      align-items:center;
      justify-content:center;
      color:var(--muted-2);
      font-size:20px;
    }

    .signature-block .sig-name{
      font-weight:600;
      color:var(--ink);
      text-decoration:underline;
      text-underline-offset:3px;
    }

    .signature-block .sig-nip{
      font-size:12.5px;
      color:var(--muted);
      margin-top:4px;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .card-panel-body{padding:18px;}
      .card-panel-header{padding:16px 20px;}
      .signature-grid{grid-template-columns:1fr;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .card-panel{border-radius:var(--radius-md);}
      .card-panel-body{padding:16px;}
      .card-panel-header{padding:14px 16px;}
      .card-panel-title{font-size:13.5px;}
      .filter-grid{grid-template-columns:1fr;}
      .action-buttons{gap:8px;}
      .action-buttons .btn{flex:1 1 auto;}
      .btn{padding:9px 14px;font-size:13px;}
      table.rekap-table{font-size:11px;}
      .rekap-table thead th,
      .rekap-table tbody td{padding:6px 4px;font-size:11px;}
      .legend{gap:6px;}
      .legend-item{padding:5px 10px;font-size:11.5px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;scroll-behavior:auto !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-calendar-days"></i></div>
        <div class="brand-titles">
          <h1>Rekap Absensi Bulanan Guru</h1>
          <span>Laporan kehadiran tenaga pendidik per bulan</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Laporan Bulanan</span>
      <h2>Rekap Absensi Bulanan Guru</h2>
      <p>Ringkasan kehadiran guru dalam satu bulan penuh dengan status H, I, S, dan A.</p>
    </div>

    <div class="info-box">
      <strong><i class="fas fa-circle-info"></i> Info:</strong> Data ini menggabungkan informasi dari:
      <ul>
        <li>Sistem absensi QR (H)</li>
        <li>Input izin manual (I/S/A)</li>
        <li>Input kehadiran manual (H)</li>
      </ul>
      Prioritas data: Izin/Sakit/Alpha &gt; Kehadiran Manual &gt; Absensi QR.
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-filter"></i>
          Filter Periode
        </div>
      </div>
      <div class="card-panel-body">
        <div class="filter-grid">
          <div class="filter-item">
            <label for="bulan">Bulan</label>
            <select name="bulan" id="bulan" class="form-select">
              <?php for ($b = 1; $b <= 12; $b++) {
                $sel = ($b == $bulan) ? 'selected' : '';
                echo "<option value='$b' $sel>" . date('F', mktime(0, 0, 0, $b, 10)) . "</option>";
              } ?>
            </select>
          </div>

          <div class="filter-item">
            <label for="tahun">Tahun</label>
            <input type="number" name="tahun" id="tahun" value="<?= $tahun ?>" class="form-control">
          </div>

          <div class="filter-item">
            <label>&nbsp;</label>
            <button type="button" onclick="filterData()" class="btn btn-primary">
              <i class="fas fa-search"></i> Tampilkan
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="action-buttons">
      <a href="cetak_absen_guru.php?bulan=<?= $bulan ?>&tahun=<?= $tahun ?>" target="_blank" class="btn btn-success">
        <i class="fas fa-print"></i> Cetak
      </a>
      <a href="input_izin_guru.php" class="btn btn-primary">
        <i class="fas fa-pen-to-square"></i> Input Izin / Kehadiran
      </a>
      <a href="dashboard.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
      </a>
    </div>

    <div class="legend">
      <div class="legend-item"><div class="legend-color legend-hadir"></div><span>Hadir (H)</span></div>
      <div class="legend-item"><div class="legend-color legend-izin"></div><span>Izin (I)</span></div>
      <div class="legend-item"><div class="legend-color legend-sakit"></div><span>Sakit (S)</span></div>
      <div class="legend-item"><div class="legend-color legend-alpha"></div><span>Alpha (A) — Manual</span></div>
      <div class="legend-item"><div class="legend-color legend-minggu"></div><span>Minggu</span></div>
      <div class="legend-item"><div class="legend-color legend-libur"></div><span>Libur</span></div>
    </div>

    <div class="table-wrapper">
      <div class="table-scroll">
        <table class="rekap-table">
          <thead>
            <tr>
              <th rowspan="2">No</th>
              <th rowspan="2">NIP</th>
              <th rowspan="2" style="text-align:left;">Nama</th>
              <th colspan="<?= $jumlahHari ?>">Tanggal</th>
              <th colspan="4">Rekap</th>
            </tr>
            <tr>
              <?php
              for ($i = 1; $i <= $jumlahHari; $i++) {
                $tanggal = "$tahun-" . str_pad($bulan, 2, '0', STR_PAD_LEFT) . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
                $day = date('w', strtotime($tanggal));
                $class = ($day == 0) ? 'minggu' : '';
                echo "<th class='$class'>$i</th>";
              }
              ?>
              <th>H</th><th>I</th><th>S</th><th>A</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $no = 1;
            mysqli_data_seek($guruResult, 0);
            while ($guru = mysqli_fetch_assoc($guruResult)) {
              $gid = $guru['id'];
              echo "<tr>";
              echo "<td>$no</td>";
              echo "<td class='cell-nip'>" . htmlspecialchars($guru['nip']) . "</td>";
              echo "<td class='cell-nama'>" . htmlspecialchars($guru['nama']) . "</td>";

              $countH = $countI = $countS = $countA = 0;

              for ($i = 1; $i <= $jumlahHari; $i++) {
                $val = $absensi[$gid][$i] ?? '';
                $tanggal = "$tahun-" . str_pad($bulan, 2, '0', STR_PAD_LEFT) . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
                $day = date('w', strtotime($tanggal));
                $dayOfWeek = $day + 1;

                if ($val == '') {
                  if ($day == 0) {
                    echo "<td class='minggu'>M</td>";
                  } elseif (in_array($tanggal, $libur)) {
                    echo "<td class='libur'>L</td>";
                  } else {
                    echo "<td class='kosong'></td>";
                  }
                } else {
                  if ($val == 'H') {
                    echo "<td class='hadir'>H</td>";
                    $countH++;
                  } elseif ($val == 'I') {
                    echo "<td class='izin'>I</td>";
                    $countI++;
                  } elseif ($val == 'S') {
                    echo "<td class='sakit'>S</td>";
                    $countS++;
                  } elseif ($val == 'A') {
                    echo "<td class='alpha'>A</td>";
                    $countA++;
                  } else {
                    echo "<td>" . htmlspecialchars($val) . "</td>";
                  }
                }
              }

              echo "<td class='rekap-h'>$countH</td>";
              echo "<td class='rekap-i'>$countI</td>";
              echo "<td class='rekap-s'>$countS</td>";
              echo "<td class='rekap-a'>$countA</td>";
              echo "</tr>";
              $no++;
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="footer-signature">
      <div class="signature-grid">
        <div class="signature-block">
          <div class="sig-label">
            Mengetahui,<br>
            Kepala Sekolah
          </div>
          <div class="sig-space"><i class="fas fa-signature"></i></div>
          <div class="sig-name"><?= $profil['kepala_sekolah'] ?? '....................................' ?></div>
          <div class="sig-nip">NIP. <?= $profil['nip_kepala'] ?? '........................' ?></div>
        </div>

        <div class="signature-block">
          <div class="sig-label">
            <?= $tanggal_terakhir ?><br>
            Koordinator Kepegawaian
          </div>
          <div class="sig-space"><i class="fas fa-signature"></i></div>
          <div class="sig-name">....................................</div>
          <div class="sig-nip">NIP. ........................</div>
        </div>
      </div>
    </div>

  </div>

  <script>
    function filterData() {
      const bulan = document.getElementById('bulan').value;
      const tahun = document.getElementById('tahun').value;
      window.location.href = `rekap_bulanan_guru.php?bulan=${bulan}&tahun=${tahun}`;
    }
  </script>
</body>
</html>