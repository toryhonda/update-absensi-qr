<?php

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

include 'config.php';

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $jenis_sholat = $_GET['jenis'] ?? 'dhuha';
    
    if ($jenis_sholat == 'dhuha') {
        $table = 'sholat_dhuha';
        $judul = 'Dhuha';
    } else {
        $table = 'sholat_dhuhur';
        $judul = 'Dhuhur';
    }
    
    $delete_query = "DELETE FROM $table WHERE id = ?";
    $stmt = mysqli_prepare($conn, $delete_query);
    mysqli_stmt_bind_param($stmt, 'i', $id);
    
    if (mysqli_stmt_execute($stmt)) {
        $success_message = "Data sholat $judul berhasil dihapus";
    } else {
        $error_message = "Gagal menghapus data sholat $judul";
    }
    
    $redirect_url = "rekap_sholat.php?tanggal=" . ($_GET['tanggal'] ?? date('Y-m-d')) . 
                   "&kelas=" . ($_GET['kelas'] ?? '') . 
                   "&jenis_sholat=" . $jenis_sholat;
    
    if (isset($success_message)) {
        $redirect_url .= "&success=" . urlencode($success_message);
    }
    if (isset($error_message)) {
        $redirect_url .= "&error=" . urlencode($error_message);
    }
    
    header("Location: $redirect_url");
    exit;
}

$filter_tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d');
$filter_kelas = isset($_GET['kelas']) ? $_GET['kelas'] : '';
$jenis_sholat = isset($_GET['jenis_sholat']) ? $_GET['jenis_sholat'] : 'dhuha';

if ($jenis_sholat == 'dhuha') {
    $table = 'sholat_dhuha';
    $judul = 'Dhuha';
} else {
    $table = 'sholat_dhuhur';
    $judul = 'Dhuhur';
}

$query = "SELECT s.*, sw.nama, sw.kelas, sw.nis 
          FROM $table s 
          JOIN siswa sw ON s.siswa_id = sw.id 
          WHERE s.tanggal = ?";
$params = [$filter_tanggal];

if (!empty($filter_kelas)) {
    $query .= " AND sw.kelas = ?";
    $params[] = $filter_kelas;
}

$query .= " ORDER BY sw.kelas, sw.nama";

$result = false;
if (!empty($params)) {
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt) {
        $types = str_repeat('s', count($params));
        mysqli_stmt_bind_param($stmt, $types, ...$params);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
    }
} else {
    $result = mysqli_query($conn, $query);
}

$kelas_query = "SELECT DISTINCT kelas FROM siswa ORDER BY kelas";
$kelas_result = mysqli_query($conn, $kelas_query);

$total_siswa_query = "SELECT COUNT(*) as total FROM siswa WHERE status='aktif'";
if (!empty($filter_kelas)) {
    $total_siswa_query .= " AND kelas='$filter_kelas'";
}
$total_siswa_result = mysqli_query($conn, $total_siswa_query);
$total_siswa = mysqli_fetch_assoc($total_siswa_result)['total'];

$progress_query = "
    SELECT 
        COUNT(DISTINCT a.siswa_id) as total_masuk,
        COUNT(DISTINCT d.siswa_id) as total_dhuha,
        COUNT(DISTINCT z.siswa_id) as total_dhuhur,
        COUNT(DISTINCT p.siswa_id) as total_pulang
    FROM siswa s
    LEFT JOIN absensi a ON s.id = a.siswa_id AND a.tanggal = '$filter_tanggal'
    LEFT JOIN sholat_dhuha d ON s.id = d.siswa_id AND d.tanggal = '$filter_tanggal'
    LEFT JOIN sholat_dhuhur z ON s.id = z.siswa_id AND z.tanggal = '$filter_tanggal'
    LEFT JOIN absensi p ON s.id = p.siswa_id AND p.tanggal = '$filter_tanggal' AND p.jam_pulang IS NOT NULL
    WHERE s.status = 'aktif'
";

if (!empty($filter_kelas)) {
    $progress_query .= " AND s.kelas = '$filter_kelas'";
}

$progress_result = mysqli_query($conn, $progress_query);
$progress_data = mysqli_fetch_assoc($progress_result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Rekap Sholat <?php echo $judul; ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --purple:#8b5cf6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.06), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1280px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg,#ff9e00,#ff7b00);
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:0 14px 30px -14px rgba(255,123,0,.6);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1280px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:#b45309;
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      margin-bottom:20px;
      overflow:hidden;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:18px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .card-panel-title.warn i{
      background:rgba(255,158,0,.12);
      color:#b45309;
    }

    .card-panel-title.success i{
      background:rgba(16,185,129,.12);
      color:var(--success);
    }

    .card-panel-title.info i{
      background:rgba(59,130,246,.12);
      color:var(--info);
    }

    .card-panel-body{
      padding:22px 24px;
    }

    .filter-grid{
      display:grid;
      grid-template-columns:1.2fr 1fr 1fr auto;
      gap:14px;
      align-items:end;
    }

    .form-group{
      display:flex;
      flex-direction:column;
      gap:7px;
    }

    .form-label{
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
    }

    .form-control{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
      width:100%;
      outline:none;
    }

    .form-control:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-danger{
      background:linear-gradient(135deg,#ef4444,#dc2626);
      color:#fff;
      box-shadow:0 10px 20px -10px rgba(220,38,38,.6);
    }
    .btn-danger:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-secondary{
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      box-shadow:var(--shadow-sm);
    }
    .btn-secondary:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .btn-sm{
      padding:6px 12px;
      font-size:12.5px;
      border-radius:8px;
    }

    .btn-sholat-group{
      display:grid;
      grid-template-columns:1fr 1fr;
      gap:8px;
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:5px;
    }

    .btn-sholat{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      padding:9px 14px;
      font-family:inherit;
      font-size:13px;
      font-weight:500;
      color:var(--ink-2);
      background:transparent;
      border:1px solid transparent;
      border-radius:8px;
      cursor:pointer;
      transition:background .2s ease, color .2s ease, box-shadow .2s ease, border-color .2s ease;
      line-height:1.2;
    }

    .btn-sholat:hover{
      background:rgba(42,82,152,.06);
      color:var(--ink);
    }

    .btn-sholat.active{
      background:linear-gradient(135deg,#ff9e00,#ff7b00);
      color:#fff;
      box-shadow:0 8px 18px -10px rgba(255,123,0,.75);
    }

    .stats-box{
      background:linear-gradient(135deg, rgba(255,158,0,.06), rgba(255,123,0,.04));
      border:1px solid rgba(255,158,0,.2);
      border-left:4px solid #ff9e00;
      border-radius:var(--radius-md);
      padding:20px 22px;
      margin-bottom:20px;
    }

    .stats-box h4{
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 16px;
      display:flex;
      align-items:center;
      gap:10px;
    }

    .stats-box h4 i{
      color:#b45309;
    }

    .stats-summary{
      display:flex;
      flex-wrap:wrap;
      gap:12px;
      margin-bottom:14px;
      font-size:13px;
      color:var(--ink-2);
    }

    .stats-summary span{
      display:inline-flex;
      align-items:center;
      gap:6px;
    }

    .stats-summary strong{
      font-weight:600;
    }

    .stats-summary .ok{ color:#047857; }
    .stats-summary .warn{ color:#b45309; }

    .progress-steps{
      display:grid;
      grid-template-columns:repeat(4, 1fr);
      gap:10px;
      margin-bottom:16px;
    }

    .progress-step{
      text-align:center;
      padding:14px 10px;
      border-radius:var(--radius-md);
      background:var(--surface);
      border:1px solid var(--line);
      transition:transform .2s ease, box-shadow .2s ease, border-color .2s ease;
    }

    .progress-step:hover{
      transform:translateY(-1px);
      box-shadow:var(--shadow-sm);
    }

    .progress-step.active{
      background:linear-gradient(135deg,#ff9e00,#ff7b00);
      color:#fff;
      border-color:transparent;
      box-shadow:0 12px 24px -12px rgba(255,123,0,.7);
    }

    .progress-step.completed{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      border-color:transparent;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.6);
    }

    .progress-step .step-number{
      font-size:12px;
      font-weight:600;
      letter-spacing:1px;
      opacity:.7;
      margin-bottom:4px;
    }

    .progress-step.active .step-number,
    .progress-step.completed .step-number{
      opacity:.85;
    }

    .progress-step .step-title{
      font-size:12.5px;
      font-weight:500;
      margin-bottom:4px;
    }

    .progress-step .step-count{
      font-size:13.5px;
      font-weight:700;
      letter-spacing:.3px;
    }

    .progress-container{
      margin-top:8px;
    }

    .progress{
      height:22px;
      border-radius:999px;
      overflow:hidden;
      background:rgba(15,23,42,.06);
      display:flex;
    }

    .progress-bar{
      display:flex;
      align-items:center;
      justify-content:center;
      color:#fff;
      font-weight:600;
      font-size:11.5px;
      transition:width .6s ease;
      background:linear-gradient(135deg,#10b981,#059669);
    }

    .progress-bar.bg-info{
      background:linear-gradient(135deg,#3b82f6,#2563eb);
    }

    .progress-caption{
      margin-top:8px;
      font-size:12px;
      color:var(--muted);
      display:block;
    }

    .alert{
      padding:14px 18px;
      border-radius:var(--radius-md);
      font-size:13.5px;
      font-weight:500;
      border:1px solid transparent;
      margin-bottom:20px;
      display:flex;
      align-items:flex-start;
      gap:10px;
      line-height:1.55;
    }

    .alert-success{
      background:rgba(16,185,129,.08);
      color:#047857;
      border-color:rgba(16,185,129,.28);
    }

    .alert-danger{
      background:rgba(239,68,68,.08);
      color:#b91c1c;
      border-color:rgba(239,68,68,.28);
    }

    .alert-info{
      background:rgba(59,130,246,.08);
      color:#1d4ed8;
      border-color:rgba(59,130,246,.28);
    }

    .table-wrapper{
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      overflow:hidden;
      background:var(--surface);
    }

    .table-responsive{
      overflow-x:auto;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
      margin:0;
    }

    .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
    .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-responsive::-webkit-scrollbar-track{background:transparent;}

    table{
      margin:0;
      border-collapse:separate;
      border-spacing:0;
      width:100%;
      font-size:13.5px;
      color:var(--ink-2);
      font-family:'Rubik', sans-serif;
    }

    table thead th{
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:13px 16px;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    table tbody td{
      padding:13px 16px;
      vertical-align:middle;
      border-bottom:1px solid var(--line);
      color:var(--ink-2);
    }

    table tbody tr:hover td{
      background:rgba(42,82,152,.04);
    }

    table tbody tr:last-child td{
      border-bottom:0;
    }

    .cell-strong{
      font-weight:600;
      color:var(--ink);
    }

    .badge-nis{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(16,185,129,.1);
      color:#047857;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-kelas{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(139,92,246,.1);
      color:#6d28d9;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .status-hadir{
      display:inline-flex;
      align-items:center;
      gap:5px;
      padding:5px 11px;
      font-size:12px;
      font-weight:500;
      border-radius:999px;
      line-height:1;
      background:rgba(16,185,129,.12);
      color:#047857;
    }

    .status-tidak{
      display:inline-flex;
      align-items:center;
      gap:5px;
      padding:5px 11px;
      font-size:12px;
      font-weight:500;
      border-radius:999px;
      line-height:1;
      background:rgba(239,68,68,.12);
      color:#b91c1c;
    }

    .empty-state{
      text-align:center;
      padding:56px 24px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:42px;
      opacity:.4;
      margin-bottom:14px;
      display:block;
      color:#ff9e00;
    }

    .empty-state h3{
      font-size:16px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 6px;
    }

    .empty-state p{
      font-size:13.5px;
      margin:0 0 14px;
    }

    .action-btns{
      display:inline-flex;
      gap:6px;
      flex-wrap:wrap;
      justify-content:center;
    }

    @media (max-width:1024px){
      .filter-grid{
        grid-template-columns:1fr 1fr;
      }
      .filter-grid .filter-btn{
        grid-column:1 / -1;
      }
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .card-panel-body{padding:18px;}
      .card-panel-header{padding:16px 20px;}
      .progress-steps{grid-template-columns:repeat(2, 1fr);}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .card-panel{border-radius:var(--radius-md);}
      .card-panel-body{padding:16px;}
      .card-panel-header{padding:14px 16px;}
      .card-panel-title{font-size:13.5px;}
      .filter-grid{grid-template-columns:1fr;gap:12px;}
      .filter-grid .filter-btn{grid-column:auto;}
      .filter-grid .filter-btn .btn{width:100%;}
      .btn-sholat-group{grid-template-columns:1fr;}
      .progress-steps{grid-template-columns:1fr;}
      .progress-step{display:flex;align-items:center;justify-content:space-between;text-align:left;padding:12px 14px;}
      .progress-step .step-number{margin:0 12px 0 0;}
      .progress-step .step-title{margin:0;flex:1;}
      .progress-step .step-count{margin-left:auto;}
      .table thead th,
      .table tbody td{padding:11px 12px;font-size:12.5px;}
      .action-btns{flex-direction:column;gap:5px;}
      .action-btns .btn{width:100%;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-pray"></i></div>
        <div class="brand-titles">
          <h1>Rekap Sholat <?php echo $judul; ?></h1>
          <span>Laporan kehadiran sholat siswa</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Laporan Sholat</span>
      <h2>Rekap Sholat <?php echo $judul; ?></h2>
      <p>Pantau kehadiran sholat Dhuha dan Dhuhur siswa berdasarkan tanggal dan kelas.</p>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-filter"></i>
          Filter Data
        </div>
      </div>
      <div class="card-panel-body">
        <form method="GET" class="filter-grid">
          <div class="form-group">
            <label class="form-label">Jenis Sholat</label>
            <div class="btn-sholat-group">
              <button type="submit" name="jenis_sholat" value="dhuha"
                      class="btn-sholat <?php echo $jenis_sholat == 'dhuha' ? 'active' : ''; ?>">
                <i class="fas fa-sun"></i> Sholat Dhuha
              </button>
              <button type="submit" name="jenis_sholat" value="dhuhur"
                      class="btn-sholat <?php echo $jenis_sholat == 'dhuhur' ? 'active' : ''; ?>">
                <i class="fas fa-mosque"></i> Sholat Dhuhur
              </button>
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" for="tanggal">Tanggal</label>
            <input type="date" id="tanggal" name="tanggal"
                   value="<?php echo htmlspecialchars($filter_tanggal); ?>" class="form-control">
          </div>

          <div class="form-group">
            <label class="form-label" for="kelas">Kelas</label>
            <select id="kelas" name="kelas" class="form-control">
              <option value="">Semua Kelas</option>
              <?php 
              if ($kelas_result) {
                  while($kelas = mysqli_fetch_assoc($kelas_result)): 
              ?>
                <option value="<?php echo htmlspecialchars($kelas['kelas']); ?>" 
                        <?php echo $filter_kelas == $kelas['kelas'] ? 'selected' : ''; ?>>
                  <?php echo htmlspecialchars($kelas['kelas']); ?>
                </option>
              <?php 
                  endwhile; 
              }
              ?>
            </select>
          </div>

          <div class="form-group filter-btn">
            <label class="form-label">&nbsp;</label>
            <button type="submit" class="btn btn-primary">
              <i class="fas fa-filter"></i> Filter Data
            </button>
          </div>
        </form>
      </div>
    </div>

    <?php if (isset($_GET['success'])): ?>
      <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <span><?php echo htmlspecialchars($_GET['success']); ?></span>
      </div>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
      <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle"></i>
        <span><?php echo htmlspecialchars($_GET['error']); ?></span>
      </div>
    <?php endif; ?>

    <?php 
    $table_check = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
    if (mysqli_num_rows($table_check) == 0): 
    ?>
      <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle"></i>
        <div>
          <strong>Tabel Tidak Ditemukan:</strong> Tabel <strong><?php echo $table; ?></strong> belum dibuat di database.<br>
          <small>Sistem akan membuat tabel secara otomatis saat pertama kali absensi sholat dilakukan.</small>
        </div>
      </div>
    <?php elseif (!$result): ?>
      <div class="alert alert-danger">
        <i class="fas fa-exclamation-triangle"></i>
        <span>Terjadi kesalahan dalam menjalankan query database.</span>
      </div>
    <?php else: ?>

      <div class="stats-box">
        <h4><i class="fas fa-chart-line"></i> Progress Absensi 4 Kali — <?php echo date('d/m/Y', strtotime($filter_tanggal)); ?></h4>

        <div class="progress-steps">
          <div class="progress-step <?php echo $progress_data['total_masuk'] > 0 ? 'completed' : ''; ?>">
            <div class="step-number">1</div>
            <div class="step-title">Masuk</div>
            <div class="step-count"><?php echo $progress_data['total_masuk']; ?>/<?php echo $total_siswa; ?></div>
          </div>
          <div class="progress-step <?php echo $jenis_sholat == 'dhuha' ? 'active' : ($progress_data['total_dhuha'] > 0 ? 'completed' : ''); ?>">
            <div class="step-number">2</div>
            <div class="step-title">Sholat Dhuha</div>
            <div class="step-count"><?php echo $progress_data['total_dhuha']; ?>/<?php echo $total_siswa; ?></div>
          </div>
          <div class="progress-step <?php echo $jenis_sholat == 'dhuhur' ? 'active' : ($progress_data['total_dhuhur'] > 0 ? 'completed' : ''); ?>">
            <div class="step-number">3</div>
            <div class="step-title">Sholat Dhuhur</div>
            <div class="step-count"><?php echo $progress_data['total_dhuhur']; ?>/<?php echo $total_siswa; ?></div>
          </div>
          <div class="progress-step <?php echo $progress_data['total_pulang'] > 0 ? 'completed' : ''; ?>">
            <div class="step-number">4</div>
            <div class="step-title">Pulang</div>
            <div class="step-count"><?php echo $progress_data['total_pulang']; ?>/<?php echo $total_siswa; ?></div>
          </div>
        </div>

        <div class="progress-container">
          <?php 
          $total_completed = $progress_data['total_pulang'];
          $persentase_completed = $total_siswa > 0 ? round(($total_completed / $total_siswa) * 100, 1) : 0;
          ?>
          <div class="progress">
            <div class="progress-bar" role="progressbar" 
                 style="width: <?php echo $persentase_completed; ?>%" 
                 aria-valuenow="<?php echo $persentase_completed; ?>" 
                 aria-valuemin="0" 
                 aria-valuemax="100">
              <?php echo $persentase_completed; ?>%
            </div>
          </div>
          <span class="progress-caption">Persentase siswa yang telah menyelesaikan semua absensi</span>
        </div>
      </div>

      <?php if (mysqli_num_rows($result) > 0): ?>
        <?php
        $total = mysqli_num_rows($result);
        $hadir = 0;
        $tidak_hadir = 0;
        
        $data_rows = [];
        while($row = mysqli_fetch_assoc($result)) {
            $data_rows[] = $row;
            if ($row['status'] == 'hadir') {
                $hadir++;
            } else {
                $tidak_hadir++;
            }
        }
        
        $persentase_hadir = $total_siswa > 0 ? round(($hadir / $total_siswa) * 100, 1) : 0;
        ?>

        <div class="card-panel">
          <div class="card-panel-header">
            <div class="card-panel-title warn">
              <i class="fas fa-chart-bar"></i>
              Statistik Sholat <?php echo $judul; ?>
            </div>
          </div>
          <div class="card-panel-body">
            <div class="stats-summary">
              <span><i class="fas fa-users" style="color:var(--brand);"></i> Total Siswa: <strong><?php echo $total_siswa; ?></strong></span>
              <span class="ok"><i class="fas fa-check-circle"></i> Hadir: <strong><?php echo $hadir; ?></strong></span>
              <span class="warn"><i class="fas fa-clock"></i> Belum Absen: <strong><?php echo $total_siswa - $hadir; ?></strong></span>
            </div>
            <div class="progress-container">
              <div class="progress">
                <div class="progress-bar bg-info" role="progressbar" 
                     style="width: <?php echo $persentase_hadir; ?>%" 
                     aria-valuenow="<?php echo $persentase_hadir; ?>" 
                     aria-valuemin="0" 
                     aria-valuemax="100">
                  <?php echo $persentase_hadir; ?>%
                </div>
              </div>
              <span class="progress-caption">Persentase kehadiran sholat <?php echo strtolower($judul); ?></span>
            </div>
          </div>
        </div>

        <div class="card-panel">
          <div class="card-panel-header">
            <div class="card-panel-title info">
              <i class="fas fa-list-check"></i>
              Data Kehadiran Sholat <?php echo $judul; ?>
            </div>
            <span class="badge-kelas"><?php echo count($data_rows); ?> Data</span>
          </div>
          <div class="card-panel-body" style="padding:0;">
            <div class="table-wrapper">
              <div class="table-responsive">
                <table>
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>NIS</th>
                      <th>Nama Siswa</th>
                      <th>Kelas</th>
                      <th>Jam Sholat</th>
                      <th>Status</th>
                      <th>Keterangan</th>
                      <th class="text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $no = 1; foreach($data_rows as $row): ?>
                      <tr>
                        <td><?php echo $no++; ?></td>
                        <td><span class="badge-nis"><?php echo htmlspecialchars($row['nis']); ?></span></td>
                        <td class="cell-strong"><?php echo htmlspecialchars($row['nama']); ?></td>
                        <td><span class="badge-kelas"><?php echo htmlspecialchars($row['kelas']); ?></span></td>
                        <td><?php echo !empty($row['jam']) ? htmlspecialchars($row['jam']) : '-'; ?></td>
                        <td>
                          <span class="status-<?php echo $row['status'] == 'hadir' ? 'hadir' : 'tidak'; ?>">
                            <i class="fas fa-<?php echo $row['status'] == 'hadir' ? 'check-circle' : 'times-circle'; ?>"></i>
                            <?php echo $row['status'] == 'hadir' ? 'Hadir' : 'Tidak Hadir'; ?>
                          </span>
                        </td>
                        <td><?php echo !empty($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-'; ?></td>
                        <td class="text-center">
                          <div class="action-btns">
                            <a href="rekap_sholat.php?hapus=<?php echo $row['id']; ?>&jenis=<?php echo $jenis_sholat; ?>&tanggal=<?php echo $filter_tanggal; ?>&kelas=<?php echo $filter_kelas; ?>" 
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Yakin ingin menghapus data sholat <?php echo $judul; ?> untuk <?php echo htmlspecialchars($row['nama']); ?>?')">
                              <i class="fas fa-trash"></i> Hapus
                            </a>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      <?php else: ?>
        <div class="card-panel">
          <div class="card-panel-body">
            <div class="empty-state">
              <i class="fas fa-praying-hands"></i>
              <h3>Data Tidak Ditemukan</h3>
              <p>Tidak ada data sholat <?php echo strtolower($judul); ?> untuk tanggal <?php echo date('d/m/Y', strtotime($filter_tanggal)); ?></p>
              <div class="alert alert-info" style="display:inline-flex;text-align:left;max-width:520px;">
                <i class="fas fa-info-circle"></i>
                <span>Data akan muncul setelah siswa melakukan absensi sholat melalui scan QR code.</span>
              </div>
            </div>
          </div>
        </div>
      <?php endif; ?>

    <?php endif; ?>

  </div>

  <script>
    document.getElementById('tanggal').value = '<?php echo date('Y-m-d'); ?>';
    
    document.querySelectorAll('.btn-sholat').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('form').submit();
        });
    });
    
    setTimeout(function() {
        const successBox = document.querySelector('.alert-success');
        const errorBox = document.querySelector('.alert-danger');
        
        if (successBox) successBox.style.display = 'none';
        if (errorBox) errorBox.style.display = 'none';
    }, 5000);
  </script>

</body>
</html>