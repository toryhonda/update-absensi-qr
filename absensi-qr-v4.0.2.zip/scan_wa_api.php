<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
date_default_timezone_set("Asia/Jakarta");

$tanggal = $_GET['tanggal'] ?? date('Y-m-d');
$kelas   = $_GET['kelas'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Sistem Absensi Digital</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <script src="assets/js/html5-qrcode.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1400px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1400px;
      margin:0 auto;
      padding:28px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .scan-grid{
      display:grid;
      grid-template-columns:1fr 1.15fr 1fr;
      gap:20px;
      align-items:stretch;
    }

    .panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      overflow:hidden;
      display:flex;
      flex-direction:column;
      transition:box-shadow .25s ease;
    }

    .panel:hover{
      box-shadow:var(--shadow-md);
    }

    .panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:16px 20px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14px;
      font-weight:600;
      color:var(--ink);
    }

    .panel-title i{
      width:30px;
      height:30px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:13px;
    }

    .panel-body{
      padding:20px;
      flex:1;
      display:flex;
      flex-direction:column;
    }

    .digital-clock{
      background:linear-gradient(135deg, #1e3c72, #2a5298);
      color:#fff;
      border-radius:var(--radius-md);
      padding:22px 18px;
      text-align:center;
      margin-bottom:18px;
      box-shadow:var(--shadow-brand);
      position:relative;
      overflow:hidden;
    }

    .digital-clock::before{
      content:"";
      position:absolute;
      top:-60px;
      right:-60px;
      width:160px;
      height:160px;
      border-radius:50%;
      background:radial-gradient(circle, rgba(255,255,255,.15), transparent 65%);
      pointer-events:none;
    }

    #clock{
      font-family:'Rubik', monospace;
      font-size:2.4rem;
      font-weight:600;
      letter-spacing:2px;
      line-height:1.1;
      margin-bottom:6px;
      position:relative;
      z-index:1;
    }

    .date-display{
      font-size:12.5px;
      color:rgba(255,255,255,.78);
      letter-spacing:.4px;
      position:relative;
      z-index:1;
    }

    .motivation-title{
      font-size:13px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 12px;
      display:flex;
      align-items:center;
      gap:8px;
    }

    .motivation-title i{
      color:var(--warning);
      font-size:14px;
    }

    .motivation-text{
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      line-height:1.7;
      font-style:italic;
      text-align:center;
      padding:18px;
      border-left:3px solid var(--brand);
      background:var(--surface-2);
      border-radius:var(--radius-md);
      flex:1;
      display:flex;
      flex-direction:column;
      justify-content:center;
    }

    .motivation-author{
      display:block;
      text-align:right;
      font-style:normal;
      color:var(--muted);
      margin-top:14px;
      font-size:12.5px;
      font-weight:500;
    }

    .scanner-type-selector{
      margin-bottom:16px;
      padding:14px;
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
    }

    .scanner-type-selector .form-label{
      display:flex;
      align-items:center;
      gap:8px;
      font-size:12.5px;
      font-weight:600;
      color:var(--ink-2);
      margin-bottom:12px;
    }

    .scanner-type-selector .form-label i{
      color:var(--brand);
    }

    .scanner-type-selector .form-check{
      display:inline-flex;
      align-items:center;
      gap:8px;
      margin-right:14px;
      margin-bottom:0;
      padding:0;
    }

    .scanner-type-selector .form-check-input{
      margin:0;
      width:18px;
      height:18px;
      border:2px solid var(--line-strong);
      cursor:pointer;
      box-shadow:none;
      transition:border-color .2s ease, background .2s ease;
    }

    .scanner-type-selector .form-check-input:checked{
      background-color:var(--brand);
      border-color:var(--brand);
    }

    .scanner-type-selector .form-check-input:focus{
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .scanner-type-selector .form-check-label{
      font-size:13px;
      font-weight:500;
      color:var(--ink-2);
      cursor:pointer;
      display:inline-flex;
      align-items:center;
      gap:6px;
      margin:0;
    }

    .scanner-type-selector .form-check-label i{
      color:var(--muted);
      font-size:12px;
    }

    #reader{
      width:100%;
      max-width:100%;
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      overflow:hidden;
      margin:0 auto;
      background:#0f172a;
      min-height:280px;
      transition:border-color .2s ease, box-shadow .2s ease;
    }

    #reader.scanner-active{
      border-color:var(--success);
      box-shadow:0 0 0 4px rgba(16,185,129,.12);
    }

    #reader video{
      border-radius:var(--radius-md);
    }

    .external-scanner-section{
      margin-top:0;
      padding:24px 18px;
      background:var(--surface-2);
      border:1px dashed var(--line-strong);
      border-radius:var(--radius-md);
    }

    .external-scanner-section .ext-icon{
      text-align:center;
      margin-bottom:14px;
    }

    .external-scanner-section .ext-icon i{
      font-size:2.4rem;
      color:var(--brand);
      margin-bottom:8px;
      display:inline-block;
    }

    .external-scanner-section h5{
      font-size:14px;
      font-weight:600;
      color:var(--ink);
      text-align:center;
      margin:0 0 14px;
    }

    .external-scanner-input{
      font-size:15px !important;
      text-align:center;
      letter-spacing:3px;
      font-weight:600;
      padding:14px 16px !important;
      background:#fff !important;
      border:1px solid var(--line) !important;
      border-radius:var(--radius-sm) !important;
      color:var(--ink) !important;
      width:100%;
    }

    .external-scanner-input:focus{
      border-color:var(--brand) !important;
      box-shadow:0 0 0 4px var(--brand-soft) !important;
      outline:none;
    }

    .scan-info{
      background:var(--brand-soft);
      border:1px solid rgba(42,82,152,.15);
      border-radius:var(--radius-sm);
      padding:12px 14px;
      margin-bottom:14px;
      font-size:12.5px;
      color:var(--brand);
      line-height:1.55;
      text-align:center;
    }

    .scan-info strong{
      font-weight:600;
      color:var(--brand-2);
    }

    .scanner-controls{
      margin-top:auto;
      padding-top:6px;
    }

    .scan-buttons{
      display:flex;
      gap:8px;
      justify-content:center;
      flex-wrap:wrap;
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}
    .btn:disabled{opacity:.55;cursor:not-allowed;transform:none !important;}

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover:not(:disabled){
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-danger{
      background:linear-gradient(135deg,#ef4444,#dc2626);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(220,38,38,.7);
    }
    .btn-danger:hover:not(:disabled){
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-warning{
      background:linear-gradient(135deg,#f59e0b,#d97706);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(217,119,6,.7);
    }
    .btn-warning:hover:not(:disabled){
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-outline-light{
      background:transparent;
      color:#fff;
      border:1px solid rgba(255,255,255,.4);
    }
    .btn-outline-light:hover{
      background:rgba(255,255,255,.15);
      color:#fff;
      border-color:rgba(255,255,255,.6);
    }

    .btn-sm{
      padding:6px 12px;
      font-size:12.5px;
      border-radius:8px;
    }

    .scan-buttons .btn{
      flex:1;
      min-width:110px;
    }

    .result-panel-header{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
    }

    .result-panel-header .panel-title{
      color:#fff;
    }

    .result-panel-header .panel-title i{
      background:rgba(255,255,255,.18);
      color:#fff;
    }

    .result-panel-header .btn-outline-light{
      padding:6px 12px;
      font-size:12px;
    }

    .scan-result-container{
      max-height:520px;
      overflow-y:auto;
      padding:18px;
      background:var(--surface);
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
      flex:1;
    }

    .scan-result-container::-webkit-scrollbar{width:8px;}
    .scan-result-container::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .scan-result-container::-webkit-scrollbar-track{background:transparent;}

    .single-result{
      text-align:center;
      padding:32px 16px;
      color:var(--muted);
    }

    .single-result .result-icon{
      font-size:2.6rem;
      opacity:.35;
      display:block;
      margin-bottom:12px;
      color:var(--brand);
    }

    .single-result p{
      margin:0;
      font-size:13.5px;
    }

    .scan-result-item{
      padding:20px;
      border-radius:var(--radius-md);
      border:1px solid var(--line);
      border-left:4px solid var(--info);
      background:var(--surface);
      text-align:center;
      animation:fadeIn .3s ease;
    }

    .scan-result-item.success{
      border-left-color:var(--success);
      background:rgba(16,185,129,.05);
      border-color:rgba(16,185,129,.25);
    }

    .scan-result-item.error{
      border-left-color:var(--danger);
      background:rgba(239,68,68,.05);
      border-color:rgba(239,68,68,.25);
    }

    .scan-result-item.warning{
      border-left-color:var(--warning);
      background:rgba(245,158,11,.05);
      border-color:rgba(245,158,11,.28);
    }

    .scan-result-item.info{
      border-left-color:var(--info);
      background:rgba(59,130,246,.05);
      border-color:rgba(59,130,246,.25);
    }

    .result-icon{
      font-size:2.6rem;
      margin-bottom:12px;
      display:block;
    }

    .scan-result-item.success .result-icon{color:var(--success);}
    .scan-result-item.error .result-icon{color:var(--danger);}
    .scan-result-item.warning .result-icon{color:var(--warning);}
    .scan-result-item.info .result-icon{color:var(--info);}

    .result-title{
      font-size:15px;
      font-weight:600;
      margin-bottom:8px;
      color:var(--ink);
    }

    .result-message{
      font-size:13.5px;
      color:var(--ink-2);
      line-height:1.65;
    }

    .result-details{
      margin-top:14px;
      padding:10px 14px;
      background:rgba(255,255,255,.7);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      font-size:12.5px;
      color:var(--ink-2);
    }

    .result-details strong{
      color:var(--ink);
      letter-spacing:.5px;
      font-weight:600;
    }

    .result-time{
      margin-top:10px;
      font-size:11.5px;
      color:var(--muted);
    }

    @keyframes fadeIn{
      from{opacity:0;transform:translateY(6px);}
      to{opacity:1;transform:translateY(0);}
    }

    @media (max-width:1024px){
      .scan-grid{
        grid-template-columns:1fr 1fr;
      }
      .scan-grid > .panel:first-child{
        grid-column:1 / -1;
      }
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
    }

    @media (max-width:768px){
      .scan-grid{
        grid-template-columns:1fr;
      }
      .scan-grid > .panel:first-child{
        grid-column:auto;
      }
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .panel-header{padding:14px 16px;}
      .panel-body{padding:16px;}
      #clock{font-size:2rem;}
      .scan-buttons{flex-direction:column;}
      .scan-buttons .btn{width:100%;flex:none;}
      .scanner-type-selector .form-check{margin-right:10px;}
      .scan-result-container{max-height:400px;padding:14px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-qrcode"></i></div>
        <div class="brand-titles">
          <h1>Sistem Absensi Digital</h1>
          <span>Scan QR Code siswa dan guru</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Absensi</span>
      <h2>Scan QR + WA API Otomatis</h2>
      <p>Pindai kartu QR siswa atau guru untuk mencatat kehadiran secara otomatis.</p>
    </div>

    <div class="scan-grid">

      <div class="panel">
        <div class="panel-header">
          <div class="panel-title">
            <i class="fas fa-clock"></i>
            Waktu & Motivasi
          </div>
        </div>
        <div class="panel-body">
          <div class="digital-clock">
            <div id="clock">00:00:00</div>
            <div class="date-display" id="date">-</div>
          </div>
          <h4 class="motivation-title">
            <i class="fas fa-lightbulb"></i> Kata Motivasi
          </h4>
          <div class="motivation-text">
            "Belajar tanpa disiplin hanyalah rutinitas, mengajar tanpa disiplin hanyalah formalitas. Dengan disiplin, keduanya menjadi bermakna."
            <span class="motivation-author">— Filosofi Pendidikan</span>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-header">
          <div class="panel-title">
            <i class="fas fa-camera"></i>
            Scanner
          </div>
        </div>
        <div class="panel-body">
          <div class="scanner-type-selector">
            <label class="form-label">
              <i class="fas fa-sliders"></i> Mode Scanner
            </label>
            <div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="scannerType" id="webcamScanner" value="webcam" checked>
                <label class="form-check-label" for="webcamScanner">
                  <i class="fas fa-camera"></i> Webcam
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="scannerType" id="externalScanner" value="external">
                <label class="form-check-label" for="externalScanner">
                  <i class="fas fa-barcode"></i> Scanner Eksternal
                </label>
              </div>
            </div>
          </div>

          <div id="webcam-scanner-section">
            <div id="reader" class="text-center"></div>
          </div>

          <div id="external-scanner-section" class="external-scanner-section" style="display: none;">
            <div class="ext-icon">
              <i class="fas fa-barcode"></i>
            </div>
            <h5>Scanner Eksternal</h5>
            <input type="text" id="externalScannerInput" class="form-control external-scanner-input" placeholder="SCAN BARCODE..." autocomplete="off" autofocus>
          </div>

          <div class="scanner-controls">
            <div class="scan-info">
              <strong>Mode Scan:</strong> QR Code Siswa (NISN) &amp; Guru (NIP)
            </div>
            <div class="scan-buttons">
              <button type="button" class="btn btn-success" id="startScanner">
                <i class="fas fa-play"></i> Mulai
              </button>
              <button type="button" class="btn btn-danger" id="stopScanner" disabled>
                <i class="fas fa-stop"></i> Stop
              </button>
              <button type="button" class="btn btn-warning" id="resetScanner">
                <i class="fas fa-redo"></i> Reset
              </button>
            </div>
          </div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-header result-panel-header">
          <div class="panel-title">
            <i class="fas fa-circle-check"></i>
            Status Absensi Terbaru
          </div>
          <button type="button" class="btn btn-sm btn-outline-light" id="clearResults">
            <i class="fas fa-trash"></i> Hapus
          </button>
        </div>
        <div class="panel-body p-0">
          <div class="scan-result-container">
            <div id="result" class="single-result">
              <div class="text-center text-muted">
                <i class="fas fa-qrcode result-icon"></i>
                <p>Belum ada hasil scan.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>

    <audio id="beepSound" preload="auto">
      <source src="beep.mp3" type="audio/mpeg">
    </audio>

  </div>

  <script>
    let html5QrcodeScanner = null;
    let isScanning = false;
    let currentScannerType = 'webcam';
    let isProcessing = false;

    function updateClock() {
      const now = new Date();
      document.getElementById('clock').textContent = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
      const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
      document.getElementById('date').textContent = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
    }

    document.querySelectorAll('input[name="scannerType"]').forEach(radio => {
      radio.addEventListener('change', function() {
        currentScannerType = this.value;
        handleScannerTypeChange();
      });
    });

    document.getElementById('externalScannerInput').addEventListener('input', function(e) {
      const value = e.target.value.trim();
      if (value.length > 3 && !isProcessing) {
        processScannedCode(value);
        e.target.value = '';
      }
    });

    document.getElementById('startScanner').addEventListener('click', startScanner);
    document.getElementById('stopScanner').addEventListener('click', stopScanner);
    document.getElementById('resetScanner').addEventListener('click', resetScanner);
    document.getElementById('clearResults').addEventListener('click', clearResults);

    function handleScannerTypeChange() {
      if (currentScannerType === 'webcam') {
        document.getElementById('webcam-scanner-section').style.display = 'block';
        document.getElementById('external-scanner-section').style.display = 'none';
        if (isScanning) {
          stopScanner().then(function() {
            setTimeout(startScanner, 500);
          });
        }
      } else {
        document.getElementById('webcam-scanner-section').style.display = 'none';
        document.getElementById('external-scanner-section').style.display = 'block';
        if (isScanning) {
          stopScanner();
        }
        setTimeout(function() {
          document.getElementById('externalScannerInput').focus();
        }, 100);
      }
    }

    async function startScanner() {
      if (isScanning || currentScannerType !== 'webcam') return;

      const readerEl = document.getElementById('reader');
      const startBtn = document.getElementById('startScanner');
      const stopBtn = document.getElementById('stopScanner');

      try {
        readerEl.innerHTML = '';
        startBtn.disabled = true;
        stopBtn.disabled = false;

        html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: { width: 250, height: 250 } }, false);
        await html5QrcodeScanner.render(onScanSuccess, onScanFailure);
        isScanning = true;
        readerEl.classList.add('scanner-active');
      } catch (error) {
        console.error("Scanner Error:", error);

        let errMsg = 'Gagal membuka kamera. Periksa izin kamera di pengaturan browser.';
        if (error && error.name === 'NotAllowedError') {
          errMsg = 'Izin kamera ditolak. Klik ikon kunci di address bar, izinkan akses kamera, lalu muat ulang halaman.';
        } else if (error && error.name === 'NotFoundError' || error && error.name === 'DevicesNotFoundError') {
          errMsg = 'Kamera tidak ditemukan pada perangkat ini.';
        } else if (error && error.name === 'NotReadableError' || error && error.name === 'TrackStartError') {
          errMsg = 'Kamera sedang dipakai aplikasi lain. Tutup Zoom, Meet, WhatsApp Desktop, atau aplikasi kamera lain, lalu coba lagi.';
        } else if (error && error.name === 'OverconstrainedError') {
          errMsg = 'Kamera tidak mendukung resolusi yang diminta.';
        } else if (error && error.name === 'SecurityError') {
          errMsg = 'Akses kamera diblokir. Pastikan halaman diakses melalui HTTPS.';
        } else if (error && error.message) {
          errMsg = 'Gagal membuka kamera: ' + error.message;
        }

        addResultMessage(errMsg, 'error');
        playBeepSound();

        startBtn.disabled = false;
        stopBtn.disabled = true;
        isScanning = false;
        readerEl.classList.remove('scanner-active');
      }
    }

    async function stopScanner() {
      if (!isScanning) return;
      try {
        if (html5QrcodeScanner) {
          await html5QrcodeScanner.clear();
        }
        document.getElementById('reader').classList.remove('scanner-active');
        document.getElementById('startScanner').disabled = false;
        document.getElementById('stopScanner').disabled = true;
        isScanning = false;
      } catch (error) {
        console.error("Stop Error:", error);
      }
    }

    function resetScanner() {
      if (currentScannerType === 'webcam') {
        stopScanner();
      } else {
        document.getElementById('externalScannerInput').value = '';
        document.getElementById('externalScannerInput').focus();
      }
      isProcessing = false;
      clearResults();
    }

    function clearResults() {
      document.getElementById("result").innerHTML = `<div class="text-center text-muted"><i class="fas fa-qrcode result-icon"></i><p>Belum ada hasil scan.</p></div>`;
    }

    function processScannedCode(qrMessage) {
      if (isProcessing) return;
      isProcessing = true;

      if (!/^\d+$/.test(qrMessage)) {
        addResultMessage('Kode tidak valid. Hanya angka yang diterima.', 'error');
        playBeepSound();
        setTimeout(function() { isProcessing = false; }, 3000);
        return;
      }

      addResultMessage('Memproses absensi...', 'info', qrMessage);

      fetch('rekam_absen.php?code=' + encodeURIComponent(qrMessage))
        .then(async function(response) {
          const text = await response.text();
          try {
            return JSON.parse(text);
          } catch (e) {
            console.error('Response bukan JSON. HTTP Status:', response.status, 'Body:', text);
            throw new Error('Server mengembalikan response tidak valid (HTTP ' + response.status + '). Cek console browser untuk detail.');
          }
        })
        .then(function(data) {
          if (data && data.status && data.message) {
            addResultMessage(data.message, data.status, qrMessage);
          } else {
            addResultMessage('Response server tidak valid.', 'error');
          }
          playBeepSound();

          setTimeout(function() {
            isProcessing = false;
          }, 5000);
        })
        .catch(function(error) {
          console.error('Fetch Error:', error);
          addResultMessage(error.message || 'Error koneksi server.', 'error');
          playBeepSound();
          setTimeout(function() { isProcessing = false; }, 3000);
        });
    }

    function onScanSuccess(qrMessage) {
      processScannedCode(qrMessage);
    }

    function onScanFailure(error) {}

    function addResultMessage(message, type, code) {
      type = type || 'info';
      code = code || '';
      const result = document.getElementById("result");
      let icon = type === 'success' ? 'fa-check-circle' : (type === 'warning' ? 'fa-exclamation-triangle' : (type === 'error' ? 'fa-times-circle' : 'fa-info-circle'));
      let title = type === 'success' ? 'Berhasil' : (type === 'warning' ? 'Peringatan' : (type === 'error' ? 'Error' : 'Informasi'));

      result.innerHTML = `
        <div class="scan-result-item ${type}">
          <div class="result-icon"><i class="fas ${icon}"></i></div>
          <div class="result-title">${title}</div>
          <div class="result-message">${message.replace(/\n/g, '<br>')}</div>
          ${code ? `<div class="result-details">Kode: <strong>${code}</strong></div>` : ''}
          <div class="result-time"><small>Waktu: ${new Date().toLocaleTimeString()}</small></div>
        </div>
      `;
    }

    function playBeepSound() {
      const beep = document.getElementById("beepSound");
      if (beep) { beep.play().catch(function(e) { console.log(e); }); }
    }

    document.addEventListener('DOMContentLoaded', function() {
      updateClock();
      setInterval(updateClock, 1000);
      handleScannerTypeChange();
    });
  </script>
</body>
</html>