<?php

$versi = phpversion();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cek Versi PHP</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root{
            --bg:#f6f8fb;
            --surface:#ffffff;
            --surface-2:#f9fafb;
            --line:#e8edf3;
            --ink:#0f172a;
            --ink-2:#334155;
            --muted:#64748b;
            --muted-2:#94a3b8;
            --brand:#2a5298;
            --brand-2:#1e3c72;
            --brand-soft:rgba(42,82,152,.08);
            --radius-xl:22px;
            --radius-lg:16px;
            --radius-md:12px;
            --shadow-sm:0 1px 2px rgba(15,23,42,.05);
            --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
            --shadow-lg:0 24px 50px -22px rgba(15,23,42,.28), 0 10px 22px -14px rgba(15,23,42,.14);
            --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
        }

        *{box-sizing:border-box;}

        html,body{margin:0;padding:0;}

        body{
            font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 42%),
                radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 42%),
                var(--bg);
            min-height:100vh;
            display:flex;
            justify-content:center;
            align-items:center;
            padding:28px 20px;
            color:var(--ink);
            -webkit-font-smoothing:antialiased;
            -moz-osx-font-smoothing:grayscale;
        }

        .card{
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-xl);
            box-shadow:var(--shadow-lg);
            max-width:460px;
            width:100%;
            padding:38px 34px 30px;
            text-align:center;
            position:relative;
            overflow:hidden;
            animation:fadeUp .5s ease both;
        }

        .card::before{
            content:"";
            position:absolute;
            top:0;left:0;right:0;
            height:4px;
            background:linear-gradient(90deg, var(--brand), var(--brand-2));
        }

        @keyframes fadeUp{
            from{opacity:0; transform:translateY(10px);}
            to{opacity:1; transform:translateY(0);}
        }

        .icon-badge{
            width:66px;
            height:66px;
            border-radius:50%;
            display:inline-flex;
            align-items:center;
            justify-content:center;
            background:linear-gradient(135deg, var(--brand), var(--brand-2));
            color:#fff;
            font-size:26px;
            margin-bottom:18px;
            box-shadow:var(--shadow-brand);
        }

        h1{
            font-size:17px;
            font-weight:600;
            letter-spacing:-.2px;
            color:var(--ink);
            margin:0 0 6px;
            line-height:1.35;
        }

        .subtitle{
            font-size:13px;
            color:var(--muted);
            margin:0 0 24px;
            line-height:1.55;
        }

        .version-box{
            display:inline-flex;
            align-items:center;
            gap:10px;
            padding:16px 28px;
            border-radius:var(--radius-lg);
            background:var(--brand-soft);
            border:1px solid rgba(42,82,152,.18);
            color:var(--brand-2);
            font-size:26px;
            font-weight:600;
            letter-spacing:-.4px;
            line-height:1;
            margin-bottom:8px;
        }

        .version-box i{
            font-size:18px;
            color:var(--brand);
        }

        .status-line{
            display:inline-flex;
            align-items:center;
            gap:7px;
            font-size:12.5px;
            color:var(--muted);
            margin-top:10px;
        }

        .status-line i{
            color:#10b981;
            font-size:12px;
        }

        footer{
            margin-top:28px;
            padding-top:18px;
            border-top:1px solid var(--line);
            font-size:12px;
            color:var(--muted-2);
            letter-spacing:.2px;
        }

        @media (max-width:480px){
            body{padding:20px 14px;}
            .card{padding:32px 22px 26px;border-radius:18px;}
            .icon-badge{width:58px;height:58px;font-size:22px;}
            h1{font-size:15.5px;}
            .subtitle{font-size:12.5px;}
            .version-box{font-size:22px;padding:14px 22px;}
        }

        @media (prefers-reduced-motion:reduce){
            *{animation:none !important;transition:none !important;}
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon-badge">
            <i class="fas fa-server"></i>
        </div>
        <h1>Versi PHP yang Digunakan</h1>
        <p class="subtitle">Informasi runtime PHP pada server ini.</p>

        <div class="version-box">
            <i class="fab fa-php"></i>
            <?php echo htmlspecialchars($versi); ?>
        </div>

        <div class="status-line">
            <i class="fas fa-circle-check"></i>
            <span>Server berjalan normal</span>
        </div>

        <footer>&copy; <?php echo date("Y"); ?> &middot; Info Server</footer>
    </div>
</body>
</html>