<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
require 'vendor/phpqrcode/qrlib.php';
include 'cek_kelas_guru.php';

$role_session = $_SESSION['role'] ?? '';
$is_admin = ($role_session === 'admin');
$kelas_guru = $is_admin ? '' : getKelasGuru($conn);
$dashboardUrl = $is_admin ? 'dashboard.php' : 'dashboard_guru.php';

if (!$is_admin && $kelas_guru === '') {
    echo "<!DOCTYPE html><html lang='id'><head><meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Akses Terbatas</title>
    <link rel='preconnect' href='https://fonts.googleapis.com'>
    <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>
    <link href='https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap' rel='stylesheet'>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css'>
    <style>
        *{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:Rubik,sans-serif;background:radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),#f6f8fb;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;}
        .box{max-width:480px;width:100%;background:#fff;border:1px solid #e8edf3;border-radius:20px;padding:40px 34px 34px;box-shadow:0 18px 40px -18px rgba(15,23,42,.22);text-align:center;position:relative;overflow:hidden;}
        .box::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,#2a5298,#1e3c72);}
        .icon{width:68px;height:68px;border-radius:50%;background:rgba(42,82,152,.08);color:#2a5298;display:flex;align-items:center;justify-content:center;font-size:30px;margin:0 auto 20px;}
        h2{font-size:20px;color:#0f172a;margin:0 0 8px;font-weight:600;letter-spacing:-.3px;}
        p{color:#64748b;font-size:14px;margin:0 0 24px;line-height:1.65;}
        a{display:inline-flex;align-items:center;gap:8px;padding:11px 22px;background:linear-gradient(135deg,#2a5298,#1e3c72);color:#fff;text-decoration:none;border-radius:12px;font-size:13.5px;font-weight:500;box-shadow:0 14px 30px -14px rgba(30,60,114,.55);transition:transform .2s,filter .2s;}
        a:hover{filter:brightness(1.08);transform:translateY(-1px);}
        a i{font-size:12px;}
    </style></head><body>
    <div class='box'>
        <div class='icon'><i class='fas fa-lock'></i></div>
        <h2>Belum Ditugaskan</h2>
        <p>Anda belum ditugaskan sebagai wali kelas. Hubungi administrator untuk menetapkan kelas yang Anda ampu.</p>
        <a href='{$dashboardUrl}'><i class='fas fa-arrow-left'></i> Kembali ke Dashboard</a>
    </div></body></html>";
    exit;
}

$filter_kelas_sql = $is_admin ? "" : " AND kelas = '" . mysqli_real_escape_string($conn, $kelas_guru) . "'";

if (isset($_POST['simpan'])) {
    $nis   = $_POST['nis'];
    $nisn  = $_POST['nisn'];
    $nama  = $_POST['nama'];
    $kelas = $is_admin ? $_POST['kelas'] : $kelas_guru;
    $no_wa = $_POST['no_wa'];

    mysqli_query($conn, "INSERT INTO siswa (nis, nisn, nama, kelas, no_wa, status) 
                         VALUES ('$nis', '$nisn', '$nama', '$kelas', '$no_wa', 'aktif')");

    $username = $nisn;
    $password = md5($nisn);
    $role     = 'siswa';

    $cek_user = mysqli_query($conn, "SELECT id FROM users WHERE username='$username' LIMIT 1");
    if (mysqli_num_rows($cek_user) == 0) {
        mysqli_query($conn, "INSERT INTO users (username, nama, password, role) 
                             VALUES ('$username', '$nama', '$password', '$role')");
    }

    $qr_dir = "assets/qr/";
    if (!is_dir($qr_dir)) mkdir($qr_dir, 0777, true);
    QRcode::png($nisn, $qr_dir . "$nisn.png", QR_ECLEVEL_L, 4);

    $_SESSION['flash_siswa'] = [
        'type'  => 'success',
        'title' => 'Data Siswa Tersimpan',
        'text'  => 'Siswa baru berhasil ditambahkan beserta akun dan QR Code.'
    ];
    header("Location: siswa_2.php");
    exit;
}

if (isset($_POST['update'])) {
    $id = intval($_POST['id']);

    if (!$is_admin) {
        $cek = mysqli_query($conn, "SELECT kelas FROM siswa WHERE id=$id LIMIT 1");
        $d = mysqli_fetch_assoc($cek);
        if (($d['kelas'] ?? '') !== $kelas_guru) {
            $_SESSION['flash_siswa'] = [
                'type'  => 'error',
                'title' => 'Akses Ditolak',
                'text'  => 'Anda tidak berhak mengubah data siswa kelas lain.'
            ];
            header("Location: siswa_2.php");
            exit;
        }
    }

    $nis   = $_POST['nis'];
    $nisn  = $_POST['nisn'];
    $nama  = $_POST['nama'];
    $kelas = $is_admin ? $_POST['kelas'] : $kelas_guru;
    $no_wa = $_POST['no_wa'];

    $res_old = mysqli_query($conn, "SELECT nisn FROM siswa WHERE id=$id LIMIT 1");
    $old     = mysqli_fetch_assoc($res_old);
    $old_nisn = $old['nisn'];

    mysqli_query($conn, "UPDATE siswa 
                         SET nis='$nis', nisn='$nisn', nama='$nama', kelas='$kelas', no_wa='$no_wa' 
                         WHERE id=$id");

    mysqli_query($conn, "UPDATE users 
                         SET username='$nisn', nama='$nama', password=md5('$nisn') 
                         WHERE username='$old_nisn' AND role='siswa'");

    $qr_dir = "assets/qr/";
    if (!is_dir($qr_dir)) mkdir($qr_dir, 0777, true);
    QRcode::png($nisn, $qr_dir . "$nisn.png", QR_ECLEVEL_L, 4);

    $_SESSION['flash_siswa'] = [
        'type'  => 'success',
        'title' => 'Perubahan Disimpan',
        'text'  => 'Data siswa berhasil diperbarui.'
    ];
    header("Location: siswa_2.php");
    exit;
}

if (isset($_POST['generate_akun'])) {
    $q_siswa = mysqli_query($conn, "SELECT nisn, nama FROM siswa WHERE status='aktif' $filter_kelas_sql");
    $count = 0;
    $total = 0;
    while ($s = mysqli_fetch_assoc($q_siswa)) {
        $total++;
        $username = $s['nisn'];
        $nama     = $s['nama'];
        $password = md5($s['nisn']);
        $role     = 'siswa';

        $cek = mysqli_query($conn, "SELECT id FROM users WHERE username='$username' LIMIT 1");
        if (mysqli_num_rows($cek) == 0) {
            mysqli_query($conn, "INSERT INTO users (username, nama, password, role) 
                                 VALUES ('$username', '$nama', '$password', '$role')");
            $count++;
        }
    }

    if ($count > 0) {
        $_SESSION['flash_siswa'] = [
            'type'  => 'success',
            'title' => 'Generate Akun Selesai',
            'text'  => "$count akun baru berhasil dibuat dari $total siswa aktif."
        ];
    } else {
        $_SESSION['flash_siswa'] = [
            'type'  => 'info',
            'title' => 'Tidak Ada Akun Baru',
            'text'  => "Semua $total siswa aktif sudah memiliki akun."
        ];
    }

    header("Location: siswa_2.php");
    exit;
}

$edit_data = null;
if (isset($_GET['edit'])) {
    $id = intval($_GET['edit']);
    $res = mysqli_query($conn, "SELECT * FROM siswa WHERE id=$id LIMIT 1");
    $edit_data = mysqli_fetch_assoc($res);

    if ($edit_data && !$is_admin && ($edit_data['kelas'] ?? '') !== $kelas_guru) {
        $_SESSION['flash_siswa'] = [
            'type'  => 'error',
            'title' => 'Akses Ditolak',
            'text'  => 'Anda tidak berhak mengedit data siswa kelas lain.'
        ];
        header("Location: siswa_2.php");
        exit;
    }
}

$flash = $_SESSION['flash_siswa'] ?? null;
unset($_SESSION['flash_siswa']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Siswa</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1280px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1280px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .kelas-badge{
      display:inline-flex;
      align-items:center;
      gap:6px;
      padding:5px 12px;
      background:var(--brand-soft);
      color:var(--brand);
      border:1px solid rgba(42,82,152,.15);
      border-radius:999px;
      font-size:12px;
      font-weight:600;
      letter-spacing:.2px;
      margin-top:8px;
    }

    .kelas-badge i{font-size:11px;}

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      padding:24px;
      margin-bottom:20px;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      margin-bottom:18px;
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:15px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .form-label-sm{
      display:block;
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
      margin-bottom:6px;
    }

    .form-control{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
      width:100%;
    }

    .form-control::placeholder{
      color:var(--muted-2);
    }

    .form-control:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
      outline:none;
    }

    .form-control[readonly]{
      background:rgba(42,82,152,.04);
      cursor:not-allowed;
      color:var(--brand);
      font-weight:500;
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-warning{
      background:linear-gradient(135deg,#f59e0b,#d97706);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(217,119,6,.7);
    }
    .btn-warning:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-dark{
      background:linear-gradient(135deg,#1e293b,#0f172a);
      color:#fff;
      box-shadow:0 12px 24px -14px rgba(15,23,42,.7);
    }
    .btn-dark:hover{
      filter:brightness(1.15);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-secondary{
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      box-shadow:var(--shadow-sm);
    }
    .btn-secondary:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
    }

    .btn-outline-danger{
      background:transparent;
      color:var(--danger);
      border:1px solid rgba(239,68,68,.35);
    }
    .btn-outline-danger:hover{
      background:rgba(239,68,68,.06);
      border-color:var(--danger);
      color:var(--danger);
    }

    .btn-info{
      background:linear-gradient(135deg,#3b82f6,#2563eb);
      color:#fff;
      box-shadow:0 10px 20px -10px rgba(37,99,235,.6);
    }
    .btn-info:hover{
      filter:brightness(1.08);
      color:#fff;
      transform:translateY(-1px);
    }

    .btn-sm{
      padding:6px 12px;
      font-size:12.5px;
      border-radius:8px;
    }

    .actions-row{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:20px;
    }

    .actions-row form{
      display:inline-flex;
      margin:0;
    }

    .table-wrapper{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      overflow:hidden;
    }

    .table-responsive{
      max-height:72vh;
      overflow-y:auto;
      overflow-x:auto;
      border:0;
      border-radius:0;
      margin:0;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
    }

    .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
    .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-responsive::-webkit-scrollbar-track{background:transparent;}

    .table{
      margin:0;
      --bs-table-bg:transparent;
      --bs-table-border-color:var(--line);
      --bs-table-striped-bg:transparent;
      --bs-table-hover-bg:rgba(42,82,152,.04);
      font-size:13.5px;
      color:var(--ink-2);
      width:100%;
    }

    .table thead th{
      position:sticky;
      top:0;
      z-index:2;
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:14px 16px;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    .table tbody td{
      padding:14px 16px;
      vertical-align:middle;
      border-bottom:1px solid var(--line);
      color:var(--ink-2);
    }

    .table tbody tr{
      transition:background .15s ease;
    }

    .table tbody tr:hover{
      background:rgba(42,82,152,.04);
    }

    .table tbody tr:last-child td{
      border-bottom:0;
    }

    .cell-strong{
      font-weight:600;
      color:var(--ink);
    }

    .badge-nis{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(16,185,129,.1);
      color:#047857;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-nisn{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:var(--brand-soft);
      color:var(--brand);
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-kelas{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(139,92,246,.1);
      color:#6d28d9;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .wa-link{
      display:inline-flex;
      align-items:center;
      gap:6px;
      color:var(--ink-2);
      text-decoration:none;
      font-weight:500;
      transition:color .15s ease;
    }

    .wa-link:hover{color:#25D366;}

    .wa-link i{
      color:#25D366;
      font-size:14px;
    }

    .wa-empty{
      color:var(--muted-2);
      font-style:italic;
      font-size:12.5px;
    }

    .qr-thumb{
      width:52px;
      height:52px;
      border-radius:8px;
      border:1px solid var(--line);
      object-fit:contain;
      background:#fff;
      padding:2px;
      transition:transform .2s ease, box-shadow .2s ease;
    }

    .qr-thumb:hover{
      transform:scale(1.08);
      box-shadow:var(--shadow-md);
    }

    .qr-empty{
      display:inline-block;
      font-size:11.5px;
      padding:5px 10px;
      border-radius:6px;
      background:rgba(148,163,184,.12);
      color:var(--muted);
    }

    .action-btns{
      display:inline-flex;
      gap:6px;
      flex-wrap:wrap;
      justify-content:center;
    }

    .empty-state{
      text-align:center;
      padding:52px 20px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:34px;
      opacity:.35;
      margin-bottom:12px;
      display:block;
    }

    .empty-state p{
      font-size:14px;
      margin:0;
    }

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .card-panel{padding:20px;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .card-panel{padding:16px;border-radius:var(--radius-md);}
      .actions-row{gap:8px;}
      .actions-row .btn,
      .actions-row form{flex:1 1 auto;}
      .actions-row form .btn{width:100%;}
      .table thead th,
      .table tbody td{padding:11px 12px;font-size:12.5px;}
      .qr-thumb{width:44px;height:44px;}
      .action-btns{flex-direction:column;gap:5px;}
      .action-btns .btn{width:100%;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-user-graduate"></i></div>
        <div class="brand-titles">
          <h1>Data Siswa</h1>
          <span>Manajemen data peserta didik</span>
        </div>
      </div>
      <a href="<?= htmlspecialchars($dashboardUrl) ?>" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Manajemen</span>
      <h2><?= $edit_data ? 'Edit Data Siswa' : 'Tambah Data Siswa' ?></h2>
      <p><?= $edit_data ? 'Perbarui informasi siswa yang dipilih.' : 'Lengkapi formulir untuk menambah siswa baru.' ?></p>
      <?php if (!$is_admin && $kelas_guru !== ''): ?>
        <span class="kelas-badge"><i class="fas fa-door-open"></i> Kelas yang diampu: <?= htmlspecialchars($kelas_guru) ?></span>
      <?php endif; ?>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas <?= $edit_data ? 'fa-pen-to-square' : 'fa-user-plus' ?>"></i>
          <?= $edit_data ? 'Form Edit Siswa' : 'Form Tambah Siswa' ?>
        </div>
      </div>

      <form method="post" class="row g-3" autocomplete="off">
        <input type="hidden" name="id" value="<?= $edit_data['id'] ?? '' ?>">
        <div class="col-12 col-md-2">
          <label class="form-label-sm" for="nis">NIS</label>
          <input type="number" id="nis" name="nis" class="form-control" placeholder="NIS" required value="<?= $edit_data['nis'] ?? '' ?>">
        </div>
        <div class="col-12 col-md-2">
          <label class="form-label-sm" for="nisn">NISN</label>
          <input type="number" id="nisn" name="nisn" class="form-control" placeholder="NISN" required value="<?= $edit_data['nisn'] ?? '' ?>">
        </div>
        <div class="col-12 col-md-3">
          <label class="form-label-sm" for="nama">Nama</label>
          <input type="text" id="nama" name="nama" class="form-control" placeholder="Nama lengkap" required value="<?= $edit_data['nama'] ?? '' ?>">
        </div>
        <div class="col-12 col-md-2">
          <label class="form-label-sm" for="kelas">Kelas</label>
          <input type="text" id="kelas" name="kelas" class="form-control" placeholder="Kelas" required
                 value="<?= htmlspecialchars($edit_data['kelas'] ?? $kelas_guru) ?>"
                 <?= $is_admin ? '' : 'readonly' ?>>
        </div>
        <div class="col-12 col-md-3">
          <label class="form-label-sm" for="no_wa">Nomor WhatsApp</label>
          <input type="text" id="no_wa" name="no_wa" class="form-control" placeholder="6285xxxx" value="<?= $edit_data['no_wa'] ?? '' ?>">
        </div>
        <div class="col-12">
          <div class="d-flex gap-2 flex-wrap">
            <?php if ($edit_data): ?>
              <button type="submit" name="update" class="btn btn-warning">
                <i class="fas fa-floppy-disk"></i> Update Data
              </button>
              <a href="siswa_2.php" class="btn btn-secondary">
                <i class="fas fa-xmark"></i> Batal
              </a>
            <?php else: ?>
              <button type="submit" name="simpan" class="btn btn-primary">
                <i class="fas fa-plus"></i> Simpan Data
              </button>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>

    <div class="actions-row">
      <form method="post">
        <button type="submit" name="generate_akun" class="btn btn-dark">
          <i class="fas fa-bolt"></i> Generate Akun Siswa
        </button>
      </form>
      <a href="cetak_kartu.php" class="btn btn-success" target="_blank">
        <i class="fas fa-print"></i> Cetak Semua Kartu QR
      </a>
      <a href="siswa_keluar_2.php" class="btn btn-outline-danger">
        <i class="fas fa-user-slash"></i> Lihat Siswa Keluar
      </a>
      <a href="import_siswa_2.php" class="btn btn-success">
        <i class="fas fa-file-import"></i> Import dari Excel
      </a>
    </div>

    <div class="table-wrapper">
      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th>NIS</th>
              <th>NISN</th>
              <th>Nama</th>
              <th>Kelas</th>
              <th>No. WhatsApp</th>
              <th class="text-center">QR Code</th>
              <th class="text-center">Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $q = mysqli_query($conn, "SELECT * FROM siswa WHERE status='aktif' $filter_kelas_sql ORDER BY nama ASC");
            if ($q && mysqli_num_rows($q) > 0) {
              while ($row = mysqli_fetch_assoc($q)) {
                $qr_file = "assets/qr/{$row['nisn']}.png";
                $no_wa = $row['no_wa'] ?? '';
                echo "<tr>
                  <td><span class='badge-nis'>" . htmlspecialchars($row['nis']) . "</span></td>
                  <td><span class='badge-nisn'>" . htmlspecialchars($row['nisn']) . "</span></td>
                  <td class='cell-strong'>" . htmlspecialchars($row['nama']) . "</td>
                  <td><span class='badge-kelas'>" . htmlspecialchars($row['kelas']) . "</span></td>
                  <td>";
                if (!empty($no_wa)) {
                    echo "<a href='https://wa.me/" . htmlspecialchars($no_wa) . "' target='_blank' rel='noopener' class='wa-link'>
                      <i class='fab fa-whatsapp'></i> " . htmlspecialchars($no_wa) . "
                    </a>";
                } else {
                    echo "<span class='wa-empty'>Belum ada</span>";
                }
                echo "</td>
                  <td class='text-center'>";
                if (file_exists($qr_file)) {
                    echo "<a href='$qr_file' target='_blank'>
                      <img src='$qr_file' class='qr-thumb' alt='QR {$row['nisn']}'>
                    </a>";
                } else {
                    echo "<span class='qr-empty'>QR belum dibuat</span>";
                }
                echo "</td>
                  <td class='text-center'>
                    <div class='action-btns'>
                      <a href='siswa_2.php?edit={$row['id']}' class='btn btn-info btn-sm'>
                        <i class='fas fa-pen'></i> Edit
                      </a>
                    </div>
                  </td>
                </tr>";
              }
            } else {
              echo "<tr><td colspan='7'>
                <div class='empty-state'>
                  <i class='fas fa-inbox'></i>
                  <p>Belum ada data siswa. Silakan tambahkan siswa baru.</p>
                </div>
              </td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <?php if ($flash): ?>
    <script>
      Swal.fire({
        icon: '<?= htmlspecialchars($flash['type'], ENT_QUOTES); ?>',
        title: '<?= htmlspecialchars($flash['title'], ENT_QUOTES); ?>',
        text: '<?= htmlspecialchars($flash['text'], ENT_QUOTES); ?>',
        confirmButtonColor: '#2a5298'
      });
    </script>
  <?php endif; ?>

</body>
</html>