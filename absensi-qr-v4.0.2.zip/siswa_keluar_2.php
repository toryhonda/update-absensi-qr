<?php
session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Riwayat Siswa Keluar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --success-dark:#059669;
      --danger:#ef4444;
      --radius-xl:20px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    html{scroll-behavior:smooth;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 42%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 42%),
        var(--bg) !important;
      min-height:100vh;
      color:var(--ink);
      padding:24px 0 40px;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
      font-size:14px;
    }

    .page-shell{
      max-width:1240px;
      margin:0 auto;
      padding:0 20px;
    }

    .top-nav{
      display:flex;
      align-items:center;
      gap:12px;
      margin-bottom:22px;
      flex-wrap:wrap;
      justify-content:space-between;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      border-radius:999px;
      font-size:13.5px;
      font-weight:500;
      text-decoration:none;
      box-shadow:var(--shadow-sm);
      transition:border-color .2s ease, color .2s ease, transform .2s ease, box-shadow .2s ease;
    }

    .btn-back i{
      font-size:11px;
      color:var(--muted);
      transition:color .2s ease, transform .2s ease;
    }

    .btn-back:hover{
      color:var(--ink);
      border-color:var(--line-strong);
      box-shadow:var(--shadow-md);
      transform:translateY(-1px);
    }

    .btn-back:hover i{
      color:var(--brand);
      transform:translateX(-2px);
    }

    .btn-back:focus-visible{
      outline:3px solid var(--brand-soft);
      outline-offset:2px;
    }

    .page-title-block{
      display:flex;
      flex-direction:column;
      gap:4px;
      margin-bottom:24px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
    }

    .page-title-block h2{
      font-size:26px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
      line-height:1.2;
      display:flex;
      align-items:center;
      gap:10px;
    }

    .page-title-block h2 .title-emoji{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      width:38px;
      height:38px;
      border-radius:var(--radius-md);
      background:rgba(239,68,68,.10);
      color:var(--danger);
      font-size:16px;
      flex-shrink:0;
    }

    .page-title-block p{
      font-size:13.5px;
      color:var(--muted);
      margin:0;
    }

    .table-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-xl);
      box-shadow:var(--shadow-md);
      overflow:hidden;
      animation:fadeUp .5s ease both;
    }

    @keyframes fadeUp{
      from{opacity:0; transform:translateY(10px);}
      to{opacity:1; transform:translateY(0);}
    }

    .table-card-head{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:14px;
      padding:20px 24px 18px;
      border-bottom:1px solid var(--line);
      background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
      flex-wrap:wrap;
    }

    .table-card-title{
      display:flex;
      align-items:center;
      gap:12px;
    }

    .card-head-icon{
      width:38px;
      height:38px;
      border-radius:var(--radius-md);
      background:rgba(239,68,68,.10);
      color:var(--danger);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:15px;
      flex-shrink:0;
    }

    .table-card-title h3{
      font-size:15.5px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 2px;
      letter-spacing:-.15px;
    }

    .table-card-title p{
      font-size:12.5px;
      color:var(--muted);
      margin:0;
    }

    .table-count{
      display:inline-flex;
      align-items:center;
      gap:7px;
      padding:6px 12px;
      border-radius:999px;
      background:rgba(239,68,68,.08);
      color:var(--danger);
      font-size:12.5px;
      font-weight:500;
    }

    .table-count i{font-size:11px;}

    .table-responsive{
      overflow-x:auto;
      -webkit-overflow-scrolling:touch;
    }

    table.data-table{
      width:100%;
      border-collapse:separate;
      border-spacing:0;
      margin:0;
      font-size:13.5px;
    }

    table.data-table thead th{
      background:var(--surface-2);
      padding:13px 16px;
      font-size:11.5px;
      font-weight:600;
      letter-spacing:.6px;
      text-transform:uppercase;
      color:var(--muted);
      text-align:left;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
    }

    table.data-table tbody td{
      padding:14px 16px;
      color:var(--ink-2);
      border-bottom:1px solid var(--line);
      vertical-align:middle;
      background:#fff;
    }

    table.data-table tbody tr:last-child td{
      border-bottom:none;
    }

    table.data-table tbody tr{
      transition:background .15s ease;
    }

    table.data-table tbody tr:hover td{
      background:#fafbfd;
    }

    .cell-nis, .cell-nisn{
      font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size:12.5px;
      color:var(--ink-2);
      font-weight:500;
      white-space:nowrap;
    }

    .cell-name{
      font-weight:500;
      color:var(--ink);
    }

    .cell-kelas{
      display:inline-flex;
      align-items:center;
      gap:6px;
      padding:4px 10px;
      border-radius:999px;
      background:var(--brand-soft);
      color:var(--brand);
      font-size:12px;
      font-weight:500;
      white-space:nowrap;
    }

    .cell-kelas i{font-size:10px;}

    .cell-wa{
      display:inline-flex;
      align-items:center;
      gap:8px;
      font-size:13px;
      color:var(--ink-2);
      text-decoration:none;
      font-weight:500;
      transition:color .15s ease;
    }

    .cell-wa:hover{color:#25D366;}

    .cell-wa .wa-icon{
      width:24px;
      height:24px;
      border-radius:50%;
      background:rgba(37,211,102,.12);
      color:#25D366;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      font-size:12px;
      flex-shrink:0;
    }

    .cell-wa.empty{
      color:var(--muted-2);
      font-weight:400;
      font-style:italic;
    }

    .empty-state{
      padding:60px 24px;
      text-align:center;
      color:var(--muted);
    }

    .empty-state i{
      font-size:36px;
      color:var(--muted-2);
      opacity:.5;
      margin-bottom:14px;
      display:block;
    }

    .empty-state p{
      margin:0 0 4px;
      font-size:14px;
      font-weight:500;
      color:var(--ink-2);
    }

    .empty-state small{
      font-size:12.5px;
      color:var(--muted);
    }

    @media (max-width:768px){
      body{padding:16px 0 32px;font-size:13.5px;}
      .page-shell{padding:0 16px;}
      .page-title-block h2{font-size:22px;}
      .page-title-block h2 .title-emoji{width:34px;height:34px;font-size:14px;}
      .table-card-head{padding:16px 18px 14px;}
      table.data-table{font-size:13px;}
      table.data-table thead th{padding:11px 12px;font-size:11px;}
      table.data-table tbody td{padding:12px 12px;}
    }

    @media (max-width:520px){
      .page-shell{padding:0 12px;}
      .page-title-block h2{font-size:19px;}
      .page-title-block p{font-size:12.5px;}
      table.data-table thead th{padding:10px 10px;font-size:10.5px;}
      table.data-table tbody td{padding:11px 10px;}
      .cell-wa .wa-icon{width:22px;height:22px;font-size:11px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;scroll-behavior:auto !important;}
    }
  </style>
</head>
<body>

<div class="page-shell">

  <div class="top-nav">
    <a href="siswa_2.php" class="btn-back">
      <i class="fas fa-arrow-left"></i> Kembali ke Data Siswa
    </a>
  </div>

  <div class="page-title-block">
    <span class="page-eyebrow">Arsip Siswa</span>
    <h2>
      <span class="title-emoji"><i class="fas fa-folder-open"></i></span>
      Riwayat Data Siswa Keluar
    </h2>
    <p>Daftar siswa yang telah keluar dari sekolah, tetap tersimpan untuk keperluan arsip.</p>
  </div>

  <div class="table-card">
    <div class="table-card-head">
      <div class="table-card-title">
        <div class="card-head-icon">
          <i class="fas fa-user-minus"></i>
        </div>
        <div>
          <h3>Daftar Siswa Keluar</h3>
          <p>Siswa dengan status keluar di sistem</p>
        </div>
      </div>

      <?php
        $q_count = mysqli_query($conn, "SELECT COUNT(*) AS total FROM siswa WHERE status='keluar'");
        $total_keluar = ($q_count && ($r = mysqli_fetch_assoc($q_count))) ? (int)$r['total'] : 0;
      ?>
      <span class="table-count">
        <i class="fas fa-folder"></i> <?= $total_keluar; ?> Siswa Keluar
      </span>
    </div>

    <div class="table-responsive">
      <table class="data-table">
        <thead>
          <tr>
            <th>NIS</th>
            <th>NISN</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>No. WhatsApp</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $q = mysqli_query($conn, "SELECT * FROM siswa WHERE status='keluar' ORDER BY nama ASC");
          $has_data = false;
          if ($q && mysqli_num_rows($q) > 0) {
              while ($row = mysqli_fetch_assoc($q)) {
                $has_data = true;
                $no_wa = $row['no_wa'] ?? '';
          ?>
            <tr>
              <td class="cell-nis"><?= htmlspecialchars($row['nis']) ?></td>
              <td class="cell-nisn"><?= htmlspecialchars($row['nisn']) ?></td>
              <td class="cell-name"><?= htmlspecialchars($row['nama']) ?></td>
              <td>
                <span class="cell-kelas">
                  <i class="fas fa-door-open"></i> <?= htmlspecialchars($row['kelas']) ?>
                </span>
              </td>
              <td>
                <?php if (!empty($no_wa)): ?>
                  <a href="https://wa.me/<?= htmlspecialchars($no_wa) ?>" target="_blank" rel="noopener" class="cell-wa">
                    <span class="wa-icon"><i class="fab fa-whatsapp"></i></span>
                    <?= htmlspecialchars($no_wa) ?>
                  </a>
                <?php else: ?>
                  <span class="cell-wa empty"><i class="fas fa-minus"></i> Belum ada</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php
              }
          }
          if (!$has_data) {
          ?>
            <tr>
              <td colspan="5">
                <div class="empty-state">
                  <i class="fas fa-folder-open"></i>
                  <p>Tidak ada data siswa keluar</p>
                  <small>Semua siswa saat ini masih berstatus aktif.</small>
                </div>
              </td>
            </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

</body>
</html>