<?php

session_start();
include 'config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'siswa') {
    header("Location: index.php");
    exit;
}

if (!isset($_SESSION['siswa_id'])) {
    die("Data siswa tidak ditemukan, silakan login ulang.");
}

$siswa_id = intval($_SESSION['siswa_id']);
$username_session = $_SESSION['username'];

$pesan = "";

$q_user = mysqli_query($conn, "SELECT id, nama, username, password FROM users WHERE username='" . mysqli_real_escape_string($conn, $username_session) . "' AND role='siswa' LIMIT 1");
$data_user = mysqli_fetch_assoc($q_user);

if (!$data_user) {
    $pesan = "<div class='alert alert-danger'><i class='fas fa-circle-exclamation'></i> Data akun tidak ditemukan.</div>";
}

if (isset($_POST['ubah_password']) && $data_user) {
    $pass_lama = trim($_POST['password_lama']);
    $pass_baru = trim($_POST['password_baru']);
    $konfirmasi = trim($_POST['konfirmasi_password']);

    if (empty($pass_lama) || empty($pass_baru) || empty($konfirmasi)) {
        $pesan = "<div class='alert alert-danger'><i class='fas fa-circle-exclamation'></i> Semua kolom wajib diisi.</div>";
    } elseif ($pass_baru !== $konfirmasi) {
        $pesan = "<div class='alert alert-danger'><i class='fas fa-circle-exclamation'></i> Konfirmasi password baru tidak cocok.</div>";
    } elseif (strlen($pass_baru) < 6) {
        $pesan = "<div class='alert alert-danger'><i class='fas fa-circle-exclamation'></i> Password baru minimal 6 karakter.</div>";
    } elseif (md5($pass_lama) !== $data_user['password']) {
        $pesan = "<div class='alert alert-danger'><i class='fas fa-circle-exclamation'></i> Password lama salah.</div>";
    } elseif ($pass_lama === $pass_baru) {
        $pesan = "<div class='alert alert-danger'><i class='fas fa-circle-exclamation'></i> Password baru tidak boleh sama dengan password lama.</div>";
    } else {
        $new_md5 = md5($pass_baru);
        $id_user = (int)$data_user['id'];
        $update = mysqli_query($conn, "UPDATE users SET password='$new_md5' WHERE id=$id_user");

        if ($update) {
            $_SESSION['flash_password'] = "<div class='alert alert-success'><i class='fas fa-circle-check'></i> Password berhasil diubah. Silakan gunakan password baru pada login berikutnya.</div>";
            header("Location: ubah_password.php");
            exit;
        } else {
            $pesan = "<div class='alert alert-danger'><i class='fas fa-circle-exclamation'></i> Gagal memperbarui password.</div>";
        }
    }
}

if (isset($_SESSION['flash_password'])) {
    $pesan = $_SESSION['flash_password'];
    unset($_SESSION['flash_password']);
}

$nama_siswa = $data_user['nama'] ?? ($_SESSION['nama'] ?? 'Siswa');
$initial_siswa = strtoupper(substr($nama_siswa !== '' ? $nama_siswa : 'S', 0, 1));
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Ubah Password Siswa</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --success-dark:#047857;
      --success-soft:rgba(16,185,129,.08);
      --danger:#ef4444;
      --danger-dark:#b91c1c;
      --danger-soft:rgba(239,68,68,.08);
      --warning:#f59e0b;
      --warning-dark:#b45309;
      --radius-xl:20px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg) !important;
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:32px 0 56px;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .page-shell{
      max-width:720px;
      margin:0 auto;
      padding:0 24px;
    }

    .top-nav{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:14px;
      margin-bottom:22px;
      flex-wrap:wrap;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      border-radius:999px;
      font-size:13.5px;
      font-weight:500;
      text-decoration:none;
      box-shadow:var(--shadow-sm);
      transition:border-color .2s ease, color .2s ease, transform .2s ease, box-shadow .2s ease;
    }

    .btn-back i{
      font-size:11px;
      color:var(--muted);
      transition:color .2s ease, transform .2s ease;
    }

    .btn-back:hover{
      color:var(--ink);
      border-color:var(--line-strong);
      box-shadow:var(--shadow-md);
      transform:translateY(-1px);
    }

    .btn-back:hover i{
      color:var(--brand);
      transform:translateX(-2px);
    }

    .btn-back:focus-visible{
      outline:3px solid var(--brand-soft);
      outline-offset:2px;
    }

    .surface-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-xl);
      box-shadow:var(--shadow-lg);
      overflow:hidden;
      animation:fadeUp .5s ease both;
    }

    @keyframes fadeUp{
      from{opacity:0; transform:translateY(10px);}
      to{opacity:1; transform:translateY(0);}
    }

    .card-head{
      position:relative;
      padding:26px 30px 22px;
      border-bottom:1px solid var(--line);
      background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
      display:flex;
      align-items:center;
      gap:16px;
    }

    .card-head::before{
      content:"";
      position:absolute;
      top:0;left:0;right:0;
      height:3px;
      background:linear-gradient(90deg, var(--warning), var(--danger));
    }

    .head-icon{
      width:52px;
      height:52px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--warning), #d97706);
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:22px;
      flex-shrink:0;
      box-shadow:0 14px 30px -14px rgba(217,119,6,.7);
    }

    .head-text h1{
      font-size:20px;
      font-weight:600;
      letter-spacing:-.3px;
      color:var(--ink);
      margin:0 0 4px;
      line-height:1.3;
    }

    .head-text p{
      font-size:13px;
      color:var(--muted);
      margin:0;
      line-height:1.5;
    }

    .card-body-inner{
      padding:26px 30px 30px;
    }

    .user-badge{
      display:flex;
      align-items:center;
      gap:12px;
      padding:14px 16px;
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      margin-bottom:22px;
    }

    .user-badge-avatar{
      width:44px;
      height:44px;
      border-radius:50%;
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      font-weight:600;
      flex-shrink:0;
      overflow:hidden;
      border:2px solid #fff;
      box-shadow:var(--shadow-md);
    }

    .user-badge-text{
      min-width:0;
      flex:1;
    }

    .user-badge-text .ub-name{
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 2px;
      line-height:1.3;
      overflow:hidden;
      text-overflow:ellipsis;
      white-space:nowrap;
    }

    .user-badge-text .ub-meta{
      font-size:12.5px;
      color:var(--muted);
      margin:0;
    }

    .alert{
      border-radius:var(--radius-md);
      border:1px solid transparent;
      padding:13px 16px;
      font-size:13.5px;
      font-weight:500;
      display:flex;
      align-items:flex-start;
      gap:10px;
      margin-bottom:22px;
      line-height:1.55;
      animation:fadeUp .35s ease both;
    }

    .alert i{
      font-size:14px;
      flex-shrink:0;
      margin-top:2px;
    }

    .alert-success{
      background:var(--success-soft);
      border-color:rgba(16,185,129,.25);
      color:var(--success-dark);
    }

    .alert-danger{
      background:var(--danger-soft);
      border-color:rgba(239,68,68,.25);
      color:var(--danger-dark);
    }

    .field{
      margin-bottom:18px;
    }

    .field-label{
      display:flex;
      align-items:center;
      gap:8px;
      font-size:13px;
      font-weight:500;
      color:var(--ink-2);
      margin-bottom:8px;
    }

    .field-label i{
      font-size:12px;
      color:var(--brand);
      width:14px;
      text-align:center;
    }

    .password-wrap{
      position:relative;
    }

    .form-control{
      width:100%;
      padding:12px 46px 12px 15px;
      font-family:inherit;
      font-size:14.5px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      outline:none;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
    }

    .form-control::placeholder{
      color:var(--muted-2);
    }

    .form-control:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .toggle-password{
      position:absolute;
      top:50%;
      right:8px;
      transform:translateY(-50%);
      width:34px;
      height:34px;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      background:transparent;
      border:none;
      border-radius:8px;
      color:var(--muted);
      cursor:pointer;
      transition:background .2s ease, color .2s ease;
      font-size:14px;
      padding:0;
      line-height:1;
    }

    .toggle-password:hover{
      background:rgba(15,23,42,.06);
      color:var(--ink-2);
    }

    .toggle-password:focus-visible{
      outline:2px solid var(--brand);
      outline-offset:2px;
      color:var(--brand);
    }

    .toggle-password.is-active{
      color:var(--brand);
    }

    .hint{
      display:block;
      margin-top:7px;
      font-size:12px;
      color:var(--muted-2);
      line-height:1.5;
    }

    .section-divider{
      display:flex;
      align-items:center;
      gap:12px;
      margin:22px 0 18px;
      color:var(--muted-2);
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
    }

    .section-divider::before,
    .section-divider::after{
      content:"";
      flex:1;
      height:1px;
      background:var(--line);
    }

    .btn-submit{
      width:100%;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:10px;
      padding:14px 20px;
      font-family:inherit;
      font-size:15px;
      font-weight:600;
      letter-spacing:.2px;
      color:#fff;
      cursor:pointer;
      border:none;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--warning) 0%, #d97706 100%);
      box-shadow:0 14px 30px -14px rgba(217,119,6,.7);
      transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
      margin-top:6px;
    }

    .btn-submit i{font-size:14px;}

    .btn-submit:hover{
      transform:translateY(-2px);
      filter:brightness(1.06);
      box-shadow:0 20px 36px -16px rgba(217,119,6,.85);
      color:#fff;
    }

    .btn-submit:active{transform:translateY(0);}

    .btn-submit:focus-visible{
      outline:3px solid rgba(217,119,6,.35);
      outline-offset:3px;
    }

    .foot-note{
      margin-top:22px;
      padding:14px 16px;
      border-radius:var(--radius-md);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-left:3px solid var(--brand);
      display:flex;
      gap:12px;
      align-items:flex-start;
    }

    .foot-note i{
      color:var(--brand);
      font-size:14px;
      margin-top:2px;
      flex-shrink:0;
    }

    .foot-note p{
      margin:0;
      font-size:12.5px;
      color:var(--muted);
      line-height:1.6;
    }

    @media (max-width:640px){
      body{padding:18px 0 36px;}
      .page-shell{padding:0 14px;}
      .card-head{padding:20px 18px 18px;gap:12px;}
      .head-icon{width:44px;height:44px;font-size:18px;}
      .head-text h1{font-size:17px;}
      .head-text p{font-size:12.5px;}
      .card-body-inner{padding:20px 18px 24px;}
      .form-control{font-size:14px;padding:11px 44px 11px 14px;}
      .btn-submit{font-size:14px;padding:12px 18px;}
      .foot-note{padding:12px 14px;}
      .foot-note p{font-size:12px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="page-shell">

    <div class="top-nav">
      <a href="dashboard_siswa.php" class="btn-back">
        <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
      </a>
    </div>

    <div class="surface-card">
      <div class="card-head">
        <div class="head-icon">
          <i class="fas fa-key"></i>
        </div>
        <div class="head-text">
          <h1>Ubah Password</h1>
          <p>Perbarui kata sandi akun Anda secara berkala untuk menjaga keamanan.</p>
        </div>
      </div>

      <div class="card-body-inner">

        <div class="user-badge">
          <div class="user-badge-avatar">
            <?= htmlspecialchars($initial_siswa) ?>
          </div>
          <div class="user-badge-text">
            <p class="ub-name"><?= htmlspecialchars($nama_siswa) ?></p>
            <p class="ub-meta">@<?= htmlspecialchars($username_session) ?></p>
          </div>
        </div>

        <?= $pesan; ?>

        <form method="POST" autocomplete="off">
          <div class="field">
            <label class="field-label" for="password_lama">
              <i class="fas fa-lock"></i> Password Lama
            </label>
            <div class="password-wrap">
              <input
                type="password"
                id="password_lama"
                name="password_lama"
                class="form-control"
                placeholder="Masukkan password saat ini"
                autocomplete="current-password"
                required
              >
              <button type="button" class="toggle-password" data-target="password_lama" aria-label="Lihat password" aria-pressed="false" title="Lihat password">
                <i class="fas fa-eye"></i>
              </button>
            </div>
          </div>

          <div class="section-divider">Password Baru</div>

          <div class="field">
            <label class="field-label" for="password_baru">
              <i class="fas fa-key"></i> Password Baru
            </label>
            <div class="password-wrap">
              <input
                type="password"
                id="password_baru"
                name="password_baru"
                class="form-control"
                placeholder="Minimal 6 karakter"
                autocomplete="new-password"
                required
              >
              <button type="button" class="toggle-password" data-target="password_baru" aria-label="Lihat password" aria-pressed="false" title="Lihat password">
                <i class="fas fa-eye"></i>
              </button>
            </div>
            <small class="hint">Gunakan kombinasi huruf dan angka agar lebih aman.</small>
          </div>

          <div class="field">
            <label class="field-label" for="konfirmasi_password">
              <i class="fas fa-shield-halved"></i> Konfirmasi Password Baru
            </label>
            <div class="password-wrap">
              <input
                type="password"
                id="konfirmasi_password"
                name="konfirmasi_password"
                class="form-control"
                placeholder="Ulangi password baru"
                autocomplete="new-password"
                required
              >
              <button type="button" class="toggle-password" data-target="konfirmasi_password" aria-label="Lihat password" aria-pressed="false" title="Lihat password">
                <i class="fas fa-eye"></i>
              </button>
            </div>
          </div>

          <button type="submit" name="ubah_password" class="btn-submit">
            <i class="fas fa-floppy-disk"></i> Simpan Password Baru
          </button>
        </form>

        <div class="foot-note">
          <i class="fas fa-circle-info"></i>
          <p>Setelah password diubah, gunakan password baru pada login berikutnya. Jangan bagikan password Anda kepada siapa pun.</p>
        </div>

      </div>
    </div>

  </div>

  <script>
    document.querySelectorAll('.toggle-password').forEach(function(btn){
      btn.addEventListener('click', function(){
        var targetId = this.getAttribute('data-target');
        var input = document.getElementById(targetId);
        if (!input) return;

        var isHidden = input.type === 'password';
        input.type = isHidden ? 'text' : 'password';

        var icon = this.querySelector('i');
        if (icon) {
          icon.classList.toggle('fa-eye', !isHidden);
          icon.classList.toggle('fa-eye-slash', isHidden);
        }

        this.classList.toggle('is-active', isHidden);
        this.setAttribute('aria-pressed', isHidden ? 'true' : 'false');
        this.setAttribute('aria-label', isHidden ? 'Sembunyikan password' : 'Lihat password');
        this.setAttribute('title', isHidden ? 'Sembunyikan password' : 'Lihat password');
      });
    });
  </script>

</body>
</html>