<?php
session_start();
include 'config.php';

$qProfil = mysqli_query($conn, "SELECT nama_sekolah FROM profil_sekolah LIMIT 1");
$profil  = mysqli_fetch_assoc($qProfil);
$nama_sekolah = $profil['nama_sekolah'] ?? 'Sistem Absensi Digital';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unduh Aplikasi - <?= htmlspecialchars($nama_sekolah); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        :root{
            --bg:#f6f8fb;
            --surface:#ffffff;
            --surface-2:#f9fafb;
            --line:#e8edf3;
            --line-strong:#dbe3ec;
            --ink:#0f172a;
            --ink-2:#334155;
            --muted:#64748b;
            --muted-2:#94a3b8;
            --brand:#2a5298;
            --brand-2:#1e3c72;
            --brand-soft:rgba(42,82,152,.08);
            --accent:#ffb020;
            --danger:#ef4444;
            --success:#10b981;
            --info:#3b82f6;
            --radius-xl:24px;
            --radius-lg:16px;
            --radius-md:12px;
            --radius-sm:10px;
            --shadow-sm:0 1px 2px rgba(15,23,42,.05);
            --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
            --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
            --shadow-xl:0 30px 60px -22px rgba(15,23,42,.28), 0 10px 24px -16px rgba(15,23,42,.18);
            --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
        }

        *{box-sizing:border-box;margin:0;padding:0;}

        html{scroll-behavior:smooth;}

        body{
            font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(circle at 0% 0%, rgba(42,82,152,.08), transparent 42%),
                radial-gradient(circle at 100% 100%, rgba(255,176,32,.07), transparent 42%),
                var(--bg);
            min-height:100vh;
            display:flex;
            align-items:center;
            justify-content:center;
            padding:32px 20px;
            color:var(--ink);
            -webkit-font-smoothing:antialiased;
            -moz-osx-font-smoothing:grayscale;
        }

        .download-shell{
            width:100%;
            max-width:560px;
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-xl);
            box-shadow:var(--shadow-xl);
            overflow:hidden;
            animation:fadeUp .55s ease both;
        }

        @keyframes fadeUp{
            from{opacity:0; transform:translateY(14px);}
            to{opacity:1; transform:translateY(0);}
        }

        .shell-hero{
            position:relative;
            padding:36px 32px 28px;
            background:linear-gradient(150deg, #1e3c72 0%, #2a5298 55%, #3563ad 100%);
            color:#fff;
            overflow:hidden;
            text-align:center;
        }

        .shell-hero::before{
            content:"";
            position:absolute;
            top:-110px;
            right:-90px;
            width:260px;
            height:260px;
            border-radius:50%;
            background:radial-gradient(circle, rgba(255,255,255,.16), transparent 65%);
            pointer-events:none;
        }

        .shell-hero::after{
            content:"";
            position:absolute;
            bottom:-120px;
            left:-100px;
            width:240px;
            height:240px;
            border-radius:50%;
            background:radial-gradient(circle, rgba(255,176,32,.28), transparent 65%);
            pointer-events:none;
        }

        .hero-icon{
            position:relative;
            z-index:1;
            width:72px;
            height:72px;
            border-radius:22px;
            background:rgba(255,255,255,.14);
            border:1px solid rgba(255,255,255,.22);
            backdrop-filter:blur(8px);
            -webkit-backdrop-filter:blur(8px);
            display:flex;
            align-items:center;
            justify-content:center;
            margin:0 auto 18px;
            font-size:28px;
            color:#fff;
            box-shadow:0 14px 30px -12px rgba(0,0,0,.35);
        }

        .hero-eyebrow{
            position:relative;
            z-index:1;
            display:inline-block;
            padding:5px 13px;
            border-radius:999px;
            font-size:11.5px;
            font-weight:500;
            letter-spacing:.8px;
            text-transform:uppercase;
            background:rgba(255,255,255,.14);
            border:1px solid rgba(255,255,255,.24);
            color:rgba(255,255,255,.92);
            margin-bottom:12px;
        }

        .shell-hero h1{
            position:relative;
            z-index:1;
            font-size:23px;
            font-weight:600;
            letter-spacing:-.3px;
            margin:0 0 8px;
            line-height:1.3;
        }

        .shell-hero p{
            position:relative;
            z-index:1;
            font-size:13.5px;
            line-height:1.65;
            color:rgba(255,255,255,.82);
            margin:0 auto;
            max-width:38ch;
        }

        .school-tag{
            position:relative;
            z-index:1;
            display:inline-flex;
            align-items:center;
            gap:8px;
            margin-top:18px;
            padding:8px 16px;
            border-radius:999px;
            font-size:12.5px;
            font-weight:500;
            background:rgba(255,255,255,.12);
            border:1px solid rgba(255,255,255,.18);
            color:#fff;
        }

        .school-tag i{
            color:var(--accent);
            font-size:12px;
        }

        .shell-body{
            padding:28px 28px 30px;
        }

        .section-label{
            display:flex;
            align-items:center;
            gap:10px;
            margin-bottom:16px;
        }

        .section-label span{
            font-size:11.5px;
            font-weight:600;
            letter-spacing:1.1px;
            text-transform:uppercase;
            color:var(--muted);
        }

        .section-label::after{
            content:"";
            flex:1;
            height:1px;
            background:var(--line);
        }

        .download-list{
            display:flex;
            flex-direction:column;
            gap:12px;
            margin-bottom:26px;
        }

        .download-item{
            display:flex;
            align-items:center;
            gap:14px;
            padding:16px 18px;
            background:var(--surface-2);
            border:1px solid var(--line);
            border-radius:var(--radius-lg);
            text-decoration:none;
            color:var(--ink);
            transition:transform .22s ease, box-shadow .22s ease, border-color .22s ease, background .22s ease;
            position:relative;
            overflow:hidden;
        }

        .download-item::before{
            content:"";
            position:absolute;
            left:0;
            top:0;
            bottom:0;
            width:3px;
            background:var(--item-color, var(--brand));
            opacity:.85;
            transition:width .22s ease;
        }

        .download-item:hover{
            background:#fff;
            border-color:var(--line-strong);
            transform:translateY(-2px);
            box-shadow:var(--shadow-md);
        }

        .download-item:hover::before{
            width:5px;
        }

        .download-item:focus-visible{
            outline:3px solid var(--brand-soft);
            outline-offset:2px;
        }

        .download-icon{
            width:48px;
            height:48px;
            border-radius:var(--radius-md);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:19px;
            color:var(--item-color, var(--brand));
            background:color-mix(in srgb, var(--item-color, var(--brand)) 12%, transparent);
            flex-shrink:0;
            transition:transform .22s ease;
        }

        .download-item:hover .download-icon{
            transform:scale(1.06);
        }

        .download-text{
            flex:1;
            min-width:0;
        }

        .download-text strong{
            display:block;
            font-size:14.5px;
            font-weight:600;
            color:var(--ink);
            margin-bottom:3px;
            letter-spacing:-.1px;
            line-height:1.35;
        }

        .download-text span{
            display:block;
            font-size:12.5px;
            color:var(--muted);
            line-height:1.5;
        }

        .download-arrow{
            width:32px;
            height:32px;
            border-radius:50%;
            background:var(--surface);
            border:1px solid var(--line);
            color:var(--muted);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:11px;
            flex-shrink:0;
            transition:background .22s ease, color .22s ease, border-color .22s ease, transform .22s ease;
        }

        .download-item:hover .download-arrow{
            background:var(--item-color, var(--brand));
            border-color:var(--item-color, var(--brand));
            color:#fff;
            transform:translateX(3px);
        }

        .item-pdf{--item-color:#ef4444;}
        .item-code{--item-color:#3b82f6;}
        .item-excel{--item-color:#10b981;}

        .btn-back{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:9px;
            width:100%;
            padding:13px 20px;
            font-family:inherit;
            font-size:14px;
            font-weight:500;
            letter-spacing:.2px;
            color:var(--ink-2);
            background:var(--surface);
            border:1px solid var(--line-strong);
            border-radius:var(--radius-md);
            text-decoration:none;
            cursor:pointer;
            transition:background .2s ease, border-color .2s ease, color .2s ease, transform .2s ease;
        }

        .btn-back i{
            font-size:12px;
            transition:transform .2s ease;
        }

        .btn-back:hover{
            background:var(--surface-2);
            border-color:var(--brand);
            color:var(--brand);
            transform:translateY(-1px);
        }

        .btn-back:hover i{
            transform:translateX(-2px);
        }

        .btn-back:focus-visible{
            outline:3px solid var(--brand-soft);
            outline-offset:2px;
        }

        @media (max-width:640px){
            body{padding:20px 14px;}
            .shell-hero{padding:28px 22px 24px;}
            .hero-icon{width:62px;height:62px;font-size:24px;border-radius:18px;}
            .shell-hero h1{font-size:20px;}
            .shell-hero p{font-size:12.5px;}
            .shell-body{padding:22px 20px 24px;}
            .download-item{padding:14px 15px;gap:12px;}
            .download-icon{width:42px;height:42px;font-size:17px;}
            .download-text strong{font-size:13.5px;}
            .download-text span{font-size:11.5px;}
        }

        @media (max-width:380px){
            .download-arrow{display:none;}
        }

        @media (prefers-reduced-motion:reduce){
            *{animation:none !important;transition:none !important;}
        }
    </style>
</head>
<body>

  <div class="download-shell">
    <div class="shell-hero">
        <div class="hero-icon">
            <i class="fas fa-cloud-arrow-down"></i>
        </div>
        <span class="hero-eyebrow">Pusat Unduhan</span>
        <h1>Unduh Berkas & Aplikasi</h1>
        <p>Dokumentasi, panduan, dan berkas pendukung sistem absensi digital dalam satu tempat.</p>
        <span class="school-tag">
            <i class="fas fa-school"></i>
            <?= htmlspecialchars($nama_sekolah); ?>
        </span>
    </div>

    <div class="shell-body">
        <div class="section-label">
            <span>Berkas Tersedia</span>
        </div>

        <div class="download-list">
            <a href="#" class="download-item item-pdf">
                <div class="download-icon">
                    <i class="fas fa-file-pdf"></i>
                </div>
                <div class="download-text">
                    <strong>Panduan Penggunaan (PDF)</strong>
                    <span>Manual Book untuk Admin &amp; Guru</span>
                </div>
                <div class="download-arrow">
                    <i class="fas fa-arrow-right"></i>
                </div>
            </a>

            <a href="#" class="download-item item-code">
                <div class="download-icon">
                    <i class="fas fa-laptop-code"></i>
                </div>
                <div class="download-text">
                    <strong>Aplikasi Absensi berbasis PHP</strong>
                    <span>Source Code &amp; File Sistem Utama</span>
                </div>
                <div class="download-arrow">
                    <i class="fas fa-arrow-right"></i>
                </div>
            </a>

            <a href="#" class="download-item item-excel">
                <div class="download-icon">
                    <i class="fas fa-file-excel"></i>
                </div>
                <div class="download-text">
                    <strong>Template Data Siswa</strong>
                    <span>Format Excel untuk Impor Massal</span>
                </div>
                <div class="download-arrow">
                    <i class="fas fa-arrow-right"></i>
                </div>
            </a>
        </div>

        <a href="index.php" class="btn-back">
            <i class="fas fa-arrow-left"></i>
            Kembali ke Halaman Login
        </a>
    </div>
  </div>

</body>
</html>