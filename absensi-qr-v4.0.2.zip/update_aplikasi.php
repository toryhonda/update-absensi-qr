<?php
$updateFile = "update.zip";
$tmpDir = __DIR__ . "/tmp_update/";
$backupDir = __DIR__ . "/backup/backup_" . date("Ymd_His") . "/";

echo <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Proses Update</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
    :root{
        --bg:#f6f8fb;
        --surface:#ffffff;
        --surface-2:#f9fafb;
        --line:#e8edf3;
        --line-strong:#dbe3ec;
        --ink:#0f172a;
        --ink-2:#334155;
        --muted:#64748b;
        --muted-2:#94a3b8;
        --brand:#2a5298;
        --brand-2:#1e3c72;
        --brand-soft:rgba(42,82,152,.08);
        --success:#10b981;
        --success-dark:#047857;
        --success-soft:rgba(16,185,129,.10);
        --danger:#ef4444;
        --danger-dark:#b91c1c;
        --danger-soft:rgba(239,68,68,.10);
        --warning:#f59e0b;
        --warning-dark:#b45309;
        --warning-soft:rgba(245,158,11,.10);
        --radius-xl:20px;
        --radius-lg:16px;
        --radius-md:12px;
        --radius-sm:10px;
        --shadow-sm:0 1px 2px rgba(15,23,42,.05);
        --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
        --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
        --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
        font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
        background:
            radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 42%),
            radial-gradient(circle at 100% 100%, rgba(16,185,129,.06), transparent 42%),
            var(--bg) !important;
        min-height:100vh;
        color:var(--ink);
        margin:0;
        padding:32px 20px 48px;
        -webkit-font-smoothing:antialiased;
        -moz-osx-font-smoothing:grayscale;
    }

    .page-shell{
        max-width:760px;
        margin:0 auto;
    }

    .hero{
        position:relative;
        display:flex;
        align-items:center;
        gap:16px;
        padding:24px 26px;
        background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
        border-radius:var(--radius-xl);
        box-shadow:var(--shadow-brand);
        margin-bottom:20px;
        overflow:hidden;
        animation:fadeUp .5s ease both;
    }

    .hero::before{
        content:"";
        position:absolute;
        top:-80px;
        right:-70px;
        width:220px;
        height:220px;
        border-radius:50%;
        background:radial-gradient(circle, rgba(255,255,255,.16), transparent 65%);
        pointer-events:none;
    }

    .hero-icon{
        width:56px;
        height:56px;
        border-radius:var(--radius-md);
        background:rgba(255,255,255,.16);
        border:1px solid rgba(255,255,255,.28);
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:24px;
        color:#fff;
        flex-shrink:0;
        position:relative;
        z-index:1;
    }

    .hero-text{
        position:relative;
        z-index:1;
        min-width:0;
    }

    .hero-text h1{
        font-size:20px;
        font-weight:600;
        letter-spacing:-.3px;
        color:#fff;
        margin:0 0 4px;
        line-height:1.3;
    }

    .hero-text p{
        font-size:13px;
        color:rgba(255,255,255,.82);
        margin:0;
        line-height:1.5;
    }

    @keyframes fadeUp{
        from{opacity:0; transform:translateY(10px);}
        to{opacity:1; transform:translateY(0);}
    }

    .log{
        background:var(--surface);
        border:1px solid var(--line);
        border-radius:var(--radius-xl);
        box-shadow:var(--shadow-lg);
        padding:24px 26px;
        animation:fadeUp .55s ease both;
        position:relative;
        overflow:hidden;
    }

    .log::before{
        content:"";
        position:absolute;
        top:0;left:0;right:0;
        height:3px;
        background:linear-gradient(90deg, var(--brand), var(--brand-2));
    }

    .log p{
        font-size:13.5px;
        color:var(--ink-2);
        margin:0 0 10px;
        line-height:1.6;
        display:flex;
        align-items:flex-start;
        gap:10px;
        flex-wrap:wrap;
    }

    .log p::before{
        content:"\f111";
        font-family:"Font Awesome 6 Free";
        font-weight:900;
        color:var(--brand);
        font-size:8px;
        margin-top:6px;
        flex-shrink:0;
    }

    .log br{
        display:none;
    }

    .file{
        display:inline-flex;
        align-items:center;
        gap:6px;
        font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size:12px;
        color:var(--muted);
        background:var(--surface-2);
        border:1px solid var(--line);
        border-radius:6px;
        padding:5px 10px;
        margin:3px 0 3px 18px;
        max-width:100%;
        word-break:break-all;
        line-height:1.4;
    }

    .file i{
        color:var(--brand);
        font-size:11px;
        flex-shrink:0;
    }

    .success{
        display:flex;
        align-items:center;
        gap:10px;
        color:var(--success-dark);
        font-weight:600;
        background:var(--success-soft);
        border:1px solid rgba(16,185,129,.22);
        border-radius:var(--radius-md);
        padding:14px 16px;
        margin:16px 0;
        font-size:14px;
        line-height:1.5;
    }

    .success::before{
        content:"\f058";
        font-family:"Font Awesome 6 Free";
        font-weight:900;
        font-size:15px;
        flex-shrink:0;
    }

    .error{
        display:flex;
        align-items:center;
        gap:10px;
        color:var(--danger-dark);
        font-weight:600;
        background:var(--danger-soft);
        border:1px solid rgba(239,68,68,.22);
        border-radius:var(--radius-md);
        padding:14px 16px;
        margin:16px 0;
        font-size:14px;
        line-height:1.5;
    }

    .error::before{
        content:"\f06a";
        font-family:"Font Awesome 6 Free";
        font-weight:900;
        font-size:15px;
        flex-shrink:0;
    }

    .btn{
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap:10px;
        padding:14px 24px;
        font-family:inherit;
        font-size:14.5px;
        font-weight:600;
        letter-spacing:.2px;
        color:#fff !important;
        background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
        border:none;
        border-radius:var(--radius-md);
        text-decoration:none;
        box-shadow:var(--shadow-brand);
        transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
        margin-top:14px;
        cursor:pointer;
    }

    .btn i{font-size:14px;}

    .btn:hover{
        transform:translateY(-2px);
        filter:brightness(1.08);
        color:#fff;
        box-shadow:0 20px 36px -16px rgba(30,60,114,.75);
    }

    .btn:active{transform:translateY(0);}

    .btn:focus-visible{
        outline:3px solid rgba(42,82,152,.35);
        outline-offset:3px;
    }

    @media (max-width:600px){
        body{padding:20px 14px 32px;}
        .hero{padding:20px 22px;gap:14px;}
        .hero-icon{width:48px;height:48px;font-size:20px;}
        .hero-text h1{font-size:17px;}
        .hero-text p{font-size:12.5px;}
        .log{padding:20px 18px;}
        .log p{font-size:13px;}
        .file{font-size:11.5px;padding:4px 8px;margin-left:0;}
        .btn{font-size:13.5px;padding:13px 20px;width:100%;}
    }

    @media (prefers-reduced-motion:reduce){
        *{animation:none !important;transition:none !important;}
    }
</style>
</head>
<body>
<div class="page-shell">
    <div class="hero">
        <div class="hero-icon">
            <i class="fas fa-rotate"></i>
        </div>
        <div class="hero-text">
            <h1>Proses Update Sistem</h1>
            <p>Mengunduh, membackup, dan menerapkan pembaruan aplikasi.</p>
        </div>
    </div>
    <div class="log">
HTML;

ini_set('max_execution_time', 300);
ini_set('memory_limit', '512M');
ignore_user_abort(true);

if (!isset($_GET['file'])) {
    echo "<p class='error'>Tidak ada file update.</p></div></div></body></html>";
    exit;
}
$fileUrl = $_GET['file'];

file_put_contents(__DIR__ . "/maintenance.flag", "Updating...");

echo "Mengunduh file update...<br>";
ob_flush(); flush();
file_put_contents($updateFile, fopen($fileUrl, 'r'));

$zip = new ZipArchive;
if ($zip->open($updateFile) === TRUE) {
    if (is_dir($tmpDir)) {
        exec("rm -rf " . escapeshellarg($tmpDir));
    }
    mkdir($tmpDir, 0755, true);

    $zip->extractTo($tmpDir);
    $zip->close();
    unlink($updateFile);
    echo "Ekstrak berhasil ke tmp_update/<br>";
    ob_flush(); flush();
} else {
    unlink(__DIR__ . "/maintenance.flag");
    echo "<p class='error'>Gagal membuka file update.</p></div></div></body></html>";
    exit;
}

echo "Membuat backup...<br>";
mkdir($backupDir, 0755, true);
$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator(__DIR__, RecursiveDirectoryIterator::SKIP_DOTS),
    RecursiveIteratorIterator::SELF_FIRST
);
foreach ($iterator as $item) {
    if (strpos($item, 'backup') !== false || strpos($item, 'tmp_update') !== false) continue;
    $targetPath = $backupDir . str_replace(__DIR__ . DIRECTORY_SEPARATOR, '', $item);
    if ($item->isDir()) {
        mkdir($targetPath, 0755, true);
    } else {
        copy($item, $targetPath);
        echo "<span class='file'><i class='fas fa-box-archive'></i> " . htmlspecialchars(str_replace(__DIR__ . "/", '', $item)) . "</span><br>";
        ob_flush(); flush();
    }
}
echo "Backup selesai di: <b>$backupDir</b><br>";
ob_flush(); flush();

echo "Mengganti file lama...<br>";
$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($tmpDir, RecursiveDirectoryIterator::SKIP_DOTS),
    RecursiveIteratorIterator::SELF_FIRST
);
foreach ($iterator as $item) {
    $targetPath = __DIR__ . DIRECTORY_SEPARATOR . str_replace($tmpDir, '', $item);
    if ($item->isDir()) {
        if (!is_dir($targetPath)) {
            mkdir($targetPath, 0755, true);
        }
    } else {
        copy($item, $targetPath);
        echo "<span class='file'><i class='fas fa-file-arrow-up'></i> " . htmlspecialchars(str_replace($tmpDir, '', $item)) . "</span><br>";
        ob_flush(); flush();
    }
}

exec("rm -rf " . escapeshellarg($tmpDir));

unlink(__DIR__ . "/maintenance.flag");

echo "<p class='success'>Update file sistem berhasil!</p>";
echo "</div>";

echo "<a href='update_db.php' class='btn'><i class='fas fa-database'></i> Lanjutkan Pembaruan Database</a>";
echo "</div></body></html>";
?>