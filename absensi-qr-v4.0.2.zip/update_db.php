<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include "config.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pembaruan Database</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
    :root{
        --bg:#f6f8fb;
        --surface:#ffffff;
        --surface-2:#f9fafb;
        --line:#e8edf3;
        --ink:#0f172a;
        --ink-2:#334155;
        --muted:#64748b;
        --brand:#2a5298;
        --brand-2:#1e3c72;
        --brand-soft:rgba(42,82,152,.08);
        --success:#10b981;
        --success-dark:#047857;
        --success-soft:rgba(16,185,129,.08);
        --success-line:rgba(16,185,129,.22);
        --danger:#ef4444;
        --danger-dark:#b91c1c;
        --danger-soft:rgba(239,68,68,.08);
        --danger-line:rgba(239,68,68,.22);
        --radius-xl:20px;
        --radius-md:12px;
        --shadow-sm:0 1px 2px rgba(15,23,42,.05);
        --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
        --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}
    html{scroll-behavior:smooth;}

    body{
        font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        background:
            radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 42%),
            radial-gradient(circle at 100% 100%, rgba(16,185,129,.05), transparent 42%),
            var(--bg);
        min-height:100vh;
        margin:0;
        padding:32px 20px 56px;
        color:var(--ink);
        -webkit-font-smoothing:antialiased;
        -moz-osx-font-smoothing:grayscale;
    }

    .page-shell{max-width:720px;margin:0 auto;}

    .page-head{display:flex;flex-direction:column;gap:6px;margin-bottom:24px;}

    .page-eyebrow{
        font-size:11.5px;
        font-weight:600;
        letter-spacing:1.2px;
        text-transform:uppercase;
        color:var(--brand);
    }

    .page-head h1{
        font-size:26px;
        font-weight:600;
        letter-spacing:-.4px;
        color:var(--ink);
        margin:0;
        line-height:1.25;
    }

    .page-head p{margin:0;font-size:14px;color:var(--muted);line-height:1.55;}

    .card{
        background:var(--surface);
        border:1px solid var(--line);
        border-radius:var(--radius-xl);
        box-shadow:var(--shadow-md);
        overflow:hidden;
        animation:fadeUp .5s ease both;
    }

    @keyframes fadeUp{
        from{opacity:0; transform:translateY(10px);}
        to{opacity:1; transform:translateY(0);}
    }

    .card-head{
        position:relative;
        padding:22px 26px 18px;
        border-bottom:1px solid var(--line);
        background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
        display:flex;
        align-items:center;
        gap:14px;
    }

    .card-head::before{
        content:"";
        position:absolute;
        top:0;left:0;right:0;
        height:3px;
        background:linear-gradient(90deg, var(--brand), var(--brand-2));
    }

    .card-icon{
        width:44px;
        height:44px;
        border-radius:var(--radius-md);
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:17px;
        color:var(--brand);
        background:var(--brand-soft);
        flex-shrink:0;
    }

    .card-title{font-size:16px;font-weight:600;letter-spacing:-.2px;color:var(--ink);margin:0 0 3px;line-height:1.35;}
    .card-sub{font-size:12.5px;color:var(--muted);margin:0;line-height:1.5;}
    .card-body-inner{padding:24px 26px 26px;}

    .log-list{display:flex;flex-direction:column;gap:10px;margin-bottom:24px;}

    .log{
        display:flex;
        align-items:flex-start;
        gap:12px;
        padding:13px 16px;
        border-radius:var(--radius-md);
        font-size:13.5px;
        line-height:1.6;
        border:1px solid var(--line);
        background:var(--surface-2);
        color:var(--ink-2);
        animation:fadeUp .35s ease both;
    }

    .log i{font-size:14px;margin-top:2px;flex-shrink:0;color:var(--muted);width:16px;text-align:center;}
    .log b{font-weight:600;color:var(--ink);}

    .log.success{background:var(--success-soft);border-color:var(--success-line);color:var(--success-dark);}
    .log.success i{color:var(--success);}
    .log.success b{color:var(--success-dark);}

    .log.error{background:var(--danger-soft);border-color:var(--danger-line);color:var(--danger-dark);}
    .log.error i{color:var(--danger);}
    .log.error b{color:var(--danger-dark);}

    .log.info i{color:var(--brand);}

    .btn-brand{
        width:100%;
        display:inline-flex;
        align-items:center;
        justify-content:center;
        gap:10px;
        padding:13px 20px;
        font-family:inherit;
        font-size:14.5px;
        font-weight:600;
        letter-spacing:.2px;
        color:#fff;
        background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
        border:none;
        border-radius:var(--radius-md);
        text-decoration:none;
        cursor:pointer;
        box-shadow:var(--shadow-brand);
        transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
        margin-top:6px;
    }

    .btn-brand i{font-size:12px;}

    .btn-brand:hover{
        transform:translateY(-2px);
        filter:brightness(1.08);
        box-shadow:0 20px 36px -16px rgba(30,60,114,.85);
        color:#fff;
    }

    .btn-brand:active{transform:translateY(0);}
    .btn-brand:focus-visible{outline:3px solid rgba(42,82,152,.35);outline-offset:3px;}

    @media (max-width:640px){
        body{padding:22px 14px 40px;}
        .page-head h1{font-size:22px;}
        .card-head{padding:18px 20px 16px;}
        .card-body-inner{padding:20px 20px 22px;}
        .card-icon{width:40px;height:40px;font-size:15px;}
        .card-title{font-size:15px;}
        .log{font-size:13px;padding:12px 14px;}
        .btn-brand{font-size:14px;padding:12px 18px;}
    }

    @media (prefers-reduced-motion:reduce){
        *{animation:none !important;transition:none !important;}
    }
</style>
</head>
<body>
    <div class="page-shell">
        <div class="page-head">
            <span class="page-eyebrow">Pemeliharaan Data</span>
            <h1>Pembaruan Database</h1>
            <p>Sistem secara otomatis memeriksa dan menerapkan perubahan struktur database.</p>
        </div>

        <div class="card">
            <div class="card-head">
                <div class="card-icon"><i class="fas fa-database"></i></div>
                <div>
                    <h2 class="card-title">Proses Pembaruan</h2>
                    <p class="card-sub">Hasil pemeriksaan dan eksekusi pembaruan database.</p>
                </div>
            </div>
            <div class="card-body-inner">
                <div class="log-list">
                <?php
                $check = mysqli_query($conn, "SHOW COLUMNS FROM absensi LIKE 'sesi'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE absensi ADD sesi VARCHAR(50) DEFAULT NULL AFTER jam";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>sesi</b> berhasil ditambahkan ke tabel <b>absensi</b>!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom sesi: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>sesi</b> sudah ada di tabel absensi.</div></div>";
                }

                $check = mysqli_query($conn, "SHOW COLUMNS FROM siswa LIKE 'no_wa'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE siswa ADD no_wa VARCHAR(20) AFTER status";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>no_wa</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom no_wa: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>no_wa</b> sudah ada.</div></div>";
                }

                $check = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'nama'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE users ADD nama VARCHAR(100) AFTER password";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>nama</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom nama: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>nama</b> sudah ada.</div></div>";
                }

                $check = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'role'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE users ADD role VARCHAR(50) AFTER nama";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>role</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom role: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>role</b> sudah ada.</div></div>";
                }

                $check = mysqli_query($conn, "SHOW COLUMNS FROM users LIKE 'foto'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE users ADD foto VARCHAR(255) DEFAULT NULL AFTER role";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>foto</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom foto: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>foto</b> sudah ada.</div></div>";
                }

                $check = mysqli_query($conn, "SHOW COLUMNS FROM profil_sekolah LIKE 'wa_token'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE profil_sekolah ADD wa_token TEXT NULL AFTER nama_sekolah";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>wa_token</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom wa_token: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>wa_token</b> sudah ada.</div></div>";
                }

                $check = mysqli_query($conn, "SHOW COLUMNS FROM profil_sekolah LIKE 'wa_phone_number_id'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE profil_sekolah ADD wa_phone_number_id VARCHAR(50) DEFAULT NULL AFTER wa_token";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>wa_phone_number_id</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom wa_phone_number_id: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>wa_phone_number_id</b> sudah ada.</div></div>";
                }

                $check = mysqli_query($conn, "SHOW COLUMNS FROM profil_sekolah LIKE 'wa_business_account_id'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE profil_sekolah ADD wa_business_account_id VARCHAR(50) DEFAULT NULL AFTER wa_phone_number_id";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>wa_business_account_id</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom wa_business_account_id: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>wa_business_account_id</b> sudah ada.</div></div>";
                }

                $check = mysqli_query($conn, "SHOW COLUMNS FROM absensi LIKE 'jam_pulang'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "ALTER TABLE absensi ADD jam_pulang TIME NULL AFTER jam";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>Kolom <b>jam_pulang</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah kolom jam_pulang: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>Kolom <b>jam_pulang</b> sudah ada.</div></div>";
                }

                mysqli_query($conn, "UPDATE users SET role = 'admin' WHERE username = 'admin'");
                mysqli_query($conn, "UPDATE users SET role = 'wali' WHERE username = 'wali'");

                $check = mysqli_query($conn, "SELECT * FROM users WHERE username='guru'");
                if (mysqli_num_rows($check) == 0) {
                    $sql = "INSERT INTO users (username, password, nama, role)
                            VALUES ('guru', MD5('guru'), 'guru', 'guru')";
                    if (mysqli_query($conn, $sql)) {
                        echo "<div class='log success'><i class='fas fa-circle-check'></i><div>User <b>guru</b> berhasil ditambahkan!</div></div>";
                    } else {
                        echo "<div class='log error'><i class='fas fa-circle-exclamation'></i><div>Error tambah user guru: " . mysqli_error($conn) . "</div></div>";
                    }
                } else {
                    echo "<div class='log info'><i class='fas fa-circle-info'></i><div>User <b>guru</b> sudah ada.</div></div>";
                }
                ?>
                </div>

                <a href="pengaturan.php" class="btn-brand">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</body>
</html>