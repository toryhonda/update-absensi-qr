<?php

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
include 'config.php';
date_default_timezone_set("Asia/Jakarta");

$tanggal = $_GET['tanggal'] ?? date('Y-m-d');
$kelas = $_GET['kelas'] ?? '';

if (isset($_POST['ubah'])) {
  $siswa_id = (int)($_POST['siswa_id'] ?? 0);
  $status = $_POST['status'] ?? 'H';
  $keterangan = $_POST['keterangan'] ?? '';

  if (!in_array($status, ['H','S','I','A'], true)) { $status = 'H'; }
  $status_esc = mysqli_real_escape_string($conn, $status);
  $keterangan_esc = mysqli_real_escape_string($conn, $keterangan);

  $cek = mysqli_query($conn, "SELECT id FROM absensi WHERE siswa_id=$siswa_id AND tanggal='$tanggal_esc'");
  if (mysqli_num_rows($cek) > 0) {
    mysqli_query($conn, "UPDATE absensi SET status='$status_esc', keterangan='$keterangan_esc' WHERE siswa_id=$siswa_id AND tanggal='$tanggal_esc'");
  } else {
    mysqli_query($conn, "INSERT INTO absensi (siswa_id, tanggal, status, keterangan) VALUES ($siswa_id, '$tanggal_esc', '$status_esc', '$keterangan_esc')");
  }
  header("Location: absensi.php?tanggal=" . urlencode($tanggal) . "&kelas=" . urlencode($kelas));
  exit;
}

if (isset($_POST['hadir_semua'])) {
  $filterKelas = $kelas_esc !== "" ? "WHERE kelas='$kelas_esc' AND status='aktif'" : "WHERE status='aktif'";
  $qsiswa = mysqli_query($conn, "SELECT id FROM siswa $filterKelas");
  while ($s = mysqli_fetch_assoc($qsiswa)) {
    $siswa_id = $s['id'];
    $cek = mysqli_query($conn, "SELECT id FROM absensi WHERE siswa_id=$siswa_id AND tanggal='$tanggal_esc'");
    if (mysqli_num_rows($cek) > 0) {
      mysqli_query($conn, "UPDATE absensi SET status='H', keterangan='' WHERE siswa_id=$siswa_id AND tanggal='$tanggal_esc'");
    } else {
      mysqli_query($conn, "INSERT INTO absensi (siswa_id, tanggal, status, keterangan) VALUES ($siswa_id, '$tanggal', 'H', '')");
    }
  }
  header("Location: absensi.php?tanggal=" . urlencode($tanggal) . "&kelas=" . urlencode($kelas));
  exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Rekap Absensi</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --accent:#ffb020;
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --info:#3b82f6;
      --purple:#8b5cf6;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:0;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .topbar{
      background:rgba(255,255,255,.88);
      backdrop-filter:blur(14px);
      -webkit-backdrop-filter:blur(14px);
      border-bottom:1px solid var(--line);
      position:sticky;
      top:0;
      z-index:100;
      padding:14px 0;
    }

    .topbar-inner{
      max-width:1280px;
      margin:0 auto;
      padding:0 24px;
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:16px;
      flex-wrap:wrap;
    }

    .brand-block{
      display:flex;
      align-items:center;
      gap:14px;
      min-width:0;
    }

    .brand-mark{
      width:44px;
      height:44px;
      border-radius:var(--radius-md);
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:18px;
      box-shadow:var(--shadow-brand);
      flex-shrink:0;
    }

    .brand-titles h1{
      font-size:17px;
      font-weight:600;
      letter-spacing:-.2px;
      color:var(--ink);
      margin:0;
      line-height:1.25;
    }

    .brand-titles span{
      display:block;
      font-size:12.5px;
      color:var(--muted);
      margin-top:2px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      text-decoration:none;
      transition:border-color .2s ease, background .2s ease, transform .2s ease;
      box-shadow:var(--shadow-sm);
    }

    .btn-back:hover{
      background:var(--surface-2);
      border-color:var(--line-strong);
      color:var(--ink);
      transform:translateX(-2px);
    }

    .page-wrap{
      max-width:1280px;
      margin:0 auto;
      padding:32px 24px 60px;
    }

    .page-head{
      margin-bottom:22px;
    }

    .page-eyebrow{
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--brand);
      display:block;
      margin-bottom:6px;
    }

    .page-head h2{
      font-size:24px;
      font-weight:600;
      letter-spacing:-.4px;
      color:var(--ink);
      margin:0;
    }

    .page-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:6px 0 0;
    }

    .info-banner{
      display:flex;
      align-items:flex-start;
      gap:12px;
      padding:14px 18px;
      border-radius:var(--radius-md);
      background:rgba(59,130,246,.08);
      border:1px solid rgba(59,130,246,.2);
      border-left:4px solid var(--info);
      color:#1e40af;
      font-size:13px;
      line-height:1.65;
      margin-bottom:20px;
    }

    .info-banner i{
      margin-top:2px;
      font-size:15px;
      flex-shrink:0;
      color:var(--info);
    }

    .info-banner strong{
      font-weight:600;
      color:#1d4ed8;
    }

    .card-panel{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      box-shadow:var(--shadow-sm);
      margin-bottom:20px;
      overflow:hidden;
      transition:box-shadow .25s ease;
    }

    .card-panel:hover{
      box-shadow:var(--shadow-md);
    }

    .card-panel-header{
      display:flex;
      align-items:center;
      justify-content:space-between;
      gap:12px;
      padding:18px 24px;
      border-bottom:1px solid var(--line);
      background:var(--surface-2);
      flex-wrap:wrap;
    }

    .card-panel-title{
      display:flex;
      align-items:center;
      gap:10px;
      font-size:14.5px;
      font-weight:600;
      color:var(--ink);
    }

    .card-panel-title i{
      width:32px;
      height:32px;
      border-radius:var(--radius-sm);
      background:var(--brand-soft);
      color:var(--brand);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:14px;
    }

    .card-panel-body{
      padding:22px 24px;
    }

    .filter-grid{
      display:grid;
      grid-template-columns:1fr 1fr auto;
      gap:14px;
      align-items:end;
    }

    .filter-item{
      display:flex;
      flex-direction:column;
      gap:7px;
    }

    .form-label{
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
    }

    .form-control,
    .form-select{
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      padding:10px 14px;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
      width:100%;
      outline:none;
    }

    .form-control::placeholder{
      color:var(--muted-2);
    }

    .form-control:hover,
    .form-select:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus,
    .form-select:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .form-select-sm,
    .form-control-sm{
      padding:7px 11px;
      font-size:13px;
      border-radius:8px;
    }

    .btn{
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      padding:10px 16px;
      transition:transform .2s ease, box-shadow .2s ease, background .2s ease, border-color .2s ease, color .2s ease, filter .2s ease;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      border:1px solid transparent;
      cursor:pointer;
      line-height:1.2;
      text-decoration:none;
    }

    .btn:active{transform:translateY(1px);}
    .btn:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .btn-primary{
      background:linear-gradient(135deg, var(--brand), var(--brand-2));
      color:#fff;
      box-shadow:var(--shadow-brand);
    }
    .btn-primary:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
      box-shadow:0 18px 34px -16px rgba(30,60,114,.9);
    }

    .btn-success{
      background:linear-gradient(135deg,#10b981,#059669);
      color:#fff;
      box-shadow:0 12px 24px -12px rgba(5,150,105,.7);
    }
    .btn-success:hover{
      filter:brightness(1.08);
      transform:translateY(-1px);
      color:#fff;
    }

    .btn-sm{
      padding:6px 12px;
      font-size:12.5px;
      border-radius:8px;
    }

    .action-bar{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:20px;
    }

    .action-bar form{
      display:inline-flex;
      margin:0;
    }

    .stats-row{
      display:flex;
      flex-wrap:wrap;
      gap:10px;
      margin-bottom:18px;
    }

    .stat-chip{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:8px 14px;
      font-size:12.5px;
      font-weight:500;
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:999px;
      color:var(--ink-2);
    }

    .stat-chip i{
      color:var(--brand);
      font-size:12px;
    }

    .stat-chip strong{
      color:var(--ink);
      font-weight:600;
    }

    .table-wrapper{
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      overflow:hidden;
      background:var(--surface);
    }

    .table-responsive{
      overflow-x:auto;
      scrollbar-width:thin;
      scrollbar-color:#cbd5e1 transparent;
      margin:0;
    }

    .table-responsive::-webkit-scrollbar{width:8px;height:8px;}
    .table-responsive::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:99px;}
    .table-responsive::-webkit-scrollbar-track{background:transparent;}

    .table{
      margin:0;
      --bs-table-bg:transparent;
      --bs-table-border-color:var(--line);
      --bs-table-hover-bg:rgba(42,82,152,.04);
      font-size:13.5px;
      color:var(--ink-2);
      width:100%;
    }

    .table thead th{
      background:var(--surface-2);
      color:var(--muted);
      font-weight:600;
      font-size:11.5px;
      letter-spacing:.6px;
      text-transform:uppercase;
      padding:14px 16px;
      border-bottom:1px solid var(--line);
      white-space:nowrap;
      text-align:left;
      vertical-align:middle;
    }

    .table tbody td{
      padding:14px 16px;
      vertical-align:middle;
      border-bottom:1px solid var(--line);
      color:var(--ink-2);
    }

    .table tbody tr{
      transition:background .15s ease;
    }

    .table tbody tr:hover{
      background:rgba(42,82,152,.04);
    }

    .table tbody tr:last-child td{
      border-bottom:0;
    }

    .cell-strong{
      font-weight:600;
      color:var(--ink);
    }

    .badge-nis{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(16,185,129,.1);
      color:#047857;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .badge-kelas{
      display:inline-block;
      padding:4px 10px;
      font-size:12px;
      font-weight:500;
      background:rgba(139,92,246,.1);
      color:#6d28d9;
      border-radius:6px;
      letter-spacing:.3px;
    }

    .status-select{
      font-weight:600;
      text-align:center;
      min-width:70px;
      background:#fff;
    }

    .status-select.is-H{
      border-color:rgba(16,185,129,.4);
      color:#047857;
      background:rgba(16,185,129,.05);
    }

    .status-select.is-S{
      border-color:rgba(139,92,246,.4);
      color:#6d28d9;
      background:rgba(139,92,246,.05);
    }

    .status-select.is-I{
      border-color:rgba(245,158,11,.4);
      color:#b45309;
      background:rgba(245,158,11,.05);
    }

    .status-select.is-A{
      border-color:rgba(239,68,68,.4);
      color:#b91c1c;
      background:rgba(239,68,68,.05);
    }

    .status-select:focus{
      box-shadow:0 0 0 4px var(--brand-soft);
      background:#fff;
    }

    .empty-state{
      text-align:center;
      padding:56px 24px;
      color:var(--muted);
    }

    .empty-state i{
      font-size:42px;
      opacity:.35;
      margin-bottom:14px;
      display:block;
      color:var(--brand);
    }

    .empty-state h4{
      font-size:16px;
      font-weight:600;
      color:var(--ink);
      margin:0 0 6px;
    }

    .empty-state p{
      font-size:13.5px;
      margin:0;
    }

    .legend{
      display:flex;
      flex-wrap:wrap;
      gap:8px;
      margin-top:16px;
    }

    .legend-item{
      display:inline-flex;
      align-items:center;
      gap:7px;
      padding:5px 11px;
      font-size:12px;
      font-weight:500;
      color:var(--ink-2);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:999px;
    }

    .legend-dot{
      width:10px;
      height:10px;
      border-radius:50%;
      flex-shrink:0;
    }

    .dot-H{background:#10b981;}
    .dot-S{background:#8b5cf6;}
    .dot-I{background:#f59e0b;}
    .dot-A{background:#ef4444;}

    @media (max-width:900px){
      .topbar-inner{padding:0 18px;}
      .page-wrap{padding:24px 18px 48px;}
      .page-head h2{font-size:21px;}
      .card-panel-body{padding:18px;}
      .card-panel-header{padding:16px 20px;}
      .filter-grid{grid-template-columns:1fr 1fr;}
      .filter-grid > .filter-item:last-child{grid-column:1 / -1;}
    }

    @media (max-width:640px){
      .topbar{padding:12px 0;}
      .topbar-inner{padding:0 14px;}
      .brand-mark{width:38px;height:38px;font-size:15px;}
      .brand-titles h1{font-size:15px;}
      .brand-titles span{font-size:11.5px;}
      .btn-back{padding:8px 12px;font-size:12.5px;}
      .btn-back span{display:none;}
      .page-wrap{padding:20px 14px 40px;}
      .page-head h2{font-size:19px;}
      .page-head p{font-size:12.5px;}
      .card-panel{border-radius:var(--radius-md);}
      .card-panel-body{padding:16px;}
      .card-panel-header{padding:14px 16px;}
      .card-panel-title{font-size:13.5px;}
      .filter-grid{grid-template-columns:1fr;gap:12px;}
      .filter-grid > .filter-item:last-child{grid-column:auto;}
      .filter-grid .btn{width:100%;}
      .action-bar{flex-direction:column;}
      .action-bar .btn,
      .action-bar form{width:100%;}
      .action-bar form .btn{width:100%;}
      .table thead th,
      .table tbody td{padding:11px 12px;font-size:12.5px;}
      .status-select{min-width:60px;padding:6px 8px;font-size:12px;}
      .stats-row{gap:6px;}
      .stat-chip{padding:6px 12px;font-size:11.5px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>

  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-clipboard-check"></i></div>
        <div class="brand-titles">
          <h1>Rekap Absensi</h1>
          <span>Kelola status kehadiran siswa</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">

    <div class="page-head">
      <span class="page-eyebrow">Absensi</span>
      <h2>Isi S / I / A</h2>
      <p>Input dan perbarui status Sakit, Izin, atau Alpha untuk setiap siswa secara manual.</p>
    </div>

    <div class="info-banner">
      <i class="fas fa-circle-info"></i>
      <div>
        <strong>Info:</strong> Pilih tanggal dan kelas, lalu ubah status kehadiran setiap siswa. Klik <em>Tandai Semua Hadir</em> untuk mengisi seluruh siswa sekaligus.
      </div>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-filter"></i>
          Filter Data
        </div>
      </div>
      <div class="card-panel-body">
        <form method="get" class="filter-grid">
          <div class="filter-item">
            <label for="tanggal" class="form-label">Tanggal</label>
            <input type="date" id="tanggal" name="tanggal" value="<?= htmlspecialchars($tanggal) ?>" class="form-control">
          </div>
          <div class="filter-item">
            <label for="kelas" class="form-label">Kelas</label>
            <select id="kelas" name="kelas" class="form-select">
              <option value="">Semua Kelas</option>
              <?php
              $qkelas = mysqli_query($conn, "SELECT DISTINCT kelas FROM siswa ORDER BY kelas");
              while ($k = mysqli_fetch_assoc($qkelas)) {
                $selected = $k['kelas'] == $kelas ? 'selected' : '';
                echo "<option $selected>" . htmlspecialchars($k['kelas']) . "</option>";
              }
              ?>
            </select>
          </div>
          <div class="filter-item">
            <label class="form-label">&nbsp;</label>
            <button class="btn btn-primary">
              <i class="fas fa-search"></i> Tampilkan
            </button>
          </div>
        </form>
      </div>
    </div>

    <div class="action-bar">
      <form method="post">
        <button type="submit" name="hadir_semua" class="btn btn-success">
          <i class="fas fa-check-double"></i> Tandai Semua Hadir (H)
        </button>
      </form>
    </div>

    <?php
    $filterKelas = $kelas ? "WHERE s.kelas = '" . mysqli_real_escape_string($conn, $kelas) . "'" : '';
    $q = mysqli_query($conn, "
      SELECT s.id AS siswa_id, s.nis, s.nama, s.kelas,
             a.id AS absen_id, a.status, a.keterangan
      FROM siswa s
      LEFT JOIN absensi a ON a.siswa_id = s.id AND a.tanggal = '" . mysqli_real_escape_string($conn, $tanggal) . "'
      $filterKelas
      ORDER BY s.nama
    ");

    $totalSiswa = $q ? mysqli_num_rows($q) : 0;
    $jumlahSudah = 0;
    if ($q) {
      $check = mysqli_query($conn, "
        SELECT COUNT(*) AS total FROM siswa s
        INNER JOIN absensi a ON a.siswa_id = s.id AND a.tanggal = '" . mysqli_real_escape_string($conn, $tanggal) . "'
        " . ($kelas ? "WHERE s.kelas = '" . mysqli_real_escape_string($conn, $kelas) . "'" : "")
      );
      if ($check) {
        $row = mysqli_fetch_assoc($check);
        $jumlahSudah = (int)$row['total'];
      }
    }
    ?>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-list-check"></i>
          Daftar Absensi Siswa
        </div>
        <span class="stat-chip">
          <i class="fas fa-users"></i> Total: <strong><?= (int)$totalSiswa ?></strong> Siswa
        </span>
      </div>
      <div class="card-panel-body">

        <div class="stats-row">
          <span class="stat-chip">
            <i class="fas fa-calendar-day"></i>
            Tanggal: <strong><?= date('d/m/Y', strtotime($tanggal)) ?></strong>
          </span>
          <span class="stat-chip">
            <i class="fas fa-chalkboard"></i>
            Kelas: <strong><?= $kelas ? htmlspecialchars($kelas) : 'Semua Kelas' ?></strong>
          </span>
          <span class="stat-chip">
            <i class="fas fa-check-circle"></i>
            Sudah Diisi: <strong><?= (int)$jumlahSudah ?></strong>
          </span>
        </div>

        <?php if ($q && mysqli_num_rows($q) > 0): ?>
          <div class="table-wrapper">
            <div class="table-responsive">
              <table class="table align-middle">
                <thead>
                  <tr>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th style="width:110px;">Status</th>
                    <th style="min-width:200px;">Keterangan</th>
                    <th class="text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($d = mysqli_fetch_assoc($q)): 
                    $status = $d['status'] ?? 'H';
                    $status_class = 'is-' . $status;
                  ?>
                    <tr>
                      <form method="post">
                        <input type="hidden" name="siswa_id" value="<?= (int)$d['siswa_id'] ?>">
                        <td><span class="badge-nis"><?= htmlspecialchars($d['nis']) ?></span></td>
                        <td class="cell-strong"><?= htmlspecialchars($d['nama']) ?></td>
                        <td><span class="badge-kelas"><?= htmlspecialchars($d['kelas']) ?></span></td>
                        <td>
                          <select name="status" class="form-select form-select-sm status-select <?= $status_class ?>">
                            <option value="H" <?= $d['status'] == 'H' ? 'selected' : '' ?>>H</option>
                            <option value="S" <?= $d['status'] == 'S' ? 'selected' : '' ?>>S</option>
                            <option value="I" <?= $d['status'] == 'I' ? 'selected' : '' ?>>I</option>
                            <option value="A" <?= $d['status'] == 'A' ? 'selected' : '' ?>>A</option>
                          </select>
                        </td>
                        <td>
                          <input type="text" name="keterangan" class="form-control form-control-sm" value="<?= htmlspecialchars($d['keterangan'] ?? '') ?>" placeholder="Keterangan (opsional)">
                        </td>
                        <td class="text-center">
                          <button type="submit" name="ubah" class="btn btn-sm <?= $d['absen_id'] ? 'btn-primary' : 'btn-success' ?>">
                            <?php if ($d['absen_id']): ?>
                              <i class="fas fa-floppy-disk"></i> Simpan
                            <?php else: ?>
                              <i class="fas fa-plus"></i> Tambah
                            <?php endif; ?>
                          </button>
                        </td>
                      </form>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>

          <div class="legend">
            <div class="legend-item"><span class="legend-dot dot-H"></span> H — Hadir</div>
            <div class="legend-item"><span class="legend-dot dot-S"></span> S — Sakit</div>
            <div class="legend-item"><span class="legend-dot dot-I"></span> I — Izin</div>
            <div class="legend-item"><span class="legend-dot dot-A"></span> A — Alpha</div>
          </div>

        <?php else: ?>
          <div class="empty-state">
            <i class="fas fa-inbox"></i>
            <h4>Tidak ada data siswa</h4>
            <p>Tidak ada siswa pada kelas yang dipilih. Coba ubah filter kelas.</p>
          </div>
        <?php endif; ?>

      </div>
    </div>

  </div>

  <script>
    document.querySelectorAll('.status-select').forEach(function(select){
      select.addEventListener('change', function(){
        this.classList.remove('is-H','is-S','is-I','is-A');
        this.classList.add('is-' + this.value);
      });
    });
  </script>

</body>
</html>