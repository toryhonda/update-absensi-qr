<?php

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
if (!file_exists(__DIR__ . '/fpdf/fpdf.php')) { die('Library FPDF tidak ditemukan.'); }
require 'fpdf/fpdf.php';

$bulan = $_GET['bulan'] ?? date('m');
$tahun = $_GET['tahun'] ?? date('Y');

$bulan_esc = mysqli_real_escape_string($conn, $bulan);
$tahun_esc = mysqli_real_escape_string($conn, $tahun);

$jumlahHari = cal_days_in_month(CAL_GREGORIAN, $bulan, $tahun);

$profil = mysqli_fetch_assoc(mysqli_query($conn, "SELECT logo, nama_sekolah, alamat, kepala_sekolah, nip_kepala FROM profil_sekolah LIMIT 1"));
$logo_path = null;
if ($profil && !empty($profil['logo'])) {
    $kandidat = __DIR__ . '/uploads/' . $profil['logo'];
    if (file_exists($kandidat)) $logo_path = $kandidat;
}
$nama_sekolah   = $profil['nama_sekolah'] ?? 'SEKOLAH';
$alamat_sekolah = $profil['alamat'] ?? '';
$kepala         = $profil['kepala_sekolah'] ?? '....................................';
$nip_kepala     = $profil['nip_kepala'] ?? '........................';

$guruResult = mysqli_query($conn, "SELECT * FROM guru WHERE status='aktif' ORDER BY nama ASC");

$absensiHadir = [];
$qHadir = mysqli_query($conn, "SELECT a.*, g.nip, g.nama FROM absensi_guru a 
                               JOIN guru g ON a.guru_id = g.id 
                               WHERE MONTH(a.tanggal) = '$bulan_esc' 
                                 AND YEAR(a.tanggal) = '$tahun_esc'
                                 AND g.status='aktif'");
if ($qHadir) {
    while ($row = mysqli_fetch_assoc($qHadir)) {
        $gid = $row['guru_id'];
        $tgl = (int)date('j', strtotime($row['tanggal']));
        $absensiHadir[$gid][$tgl] = 'H';
    }
}

$absensiIzin = [];
$qIzin = mysqli_query($conn, "SELECT i.*, g.nip, g.nama FROM izin_guru i 
                              JOIN guru g ON i.guru_id = g.id 
                              WHERE MONTH(i.tanggal) = '$bulan_esc' 
                                AND YEAR(i.tanggal) = '$tahun_esc'
                                AND g.status='aktif'
                                AND i.status = 'disetujui'");
if ($qIzin) {
    while ($row = mysqli_fetch_assoc($qIzin)) {
        $gid = $row['guru_id'];
        $tgl = (int)date('j', strtotime($row['tanggal']));
        $absensiIzin[$gid][$tgl] = $row['jenis_izin'];
    }
}

$absensi = $absensiIzin;
foreach ($absensiHadir as $gid => $hari) {
    foreach ($hari as $tgl => $status) {
        if (!isset($absensi[$gid][$tgl])) {
            $absensi[$gid][$tgl] = $status;
        }
    }
}

$libur = [];
$qLibur = mysqli_query($conn, "SELECT tanggal FROM hari_libur");
if ($qLibur) {
    while ($row = mysqli_fetch_assoc($qLibur)) {
        $libur[] = $row['tanggal'];
    }
}

$nama_bulan = [
    1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
    5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
    9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
];
$bulan_teks = $nama_bulan[(int)$bulan] . ' ' . $tahun;

class RekapGuruPDF extends FPDF
{
    public $namaSekolah;
    public $alamatSekolah;
    public $logoPath;

    function Header()
    {
        if ($this->logoPath && file_exists($this->logoPath)) {
            $this->Image($this->logoPath, 8, 6, 16);
        }

        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor(30, 60, 114);
        $this->Cell(0, 7, 'REKAPITULASI ABSENSI GURU', 0, 1, 'C');

        $this->SetFont('Arial', 'B', 10);
        $this->SetTextColor(15, 23, 42);
        $this->Cell(0, 5, $this->namaSekolah, 0, 1, 'C');

        if (!empty($this->alamatSekolah)) {
            $this->SetFont('Arial', '', 8);
            $this->SetTextColor(100, 116, 139);
            $this->Cell(0, 4, $this->alamatSekolah, 0, 1, 'C');
        }

        $this->SetDrawColor(255, 176, 32);
        $this->SetLineWidth(0.6);
        $this->Line(8, $this->GetY() + 1, 289, $this->GetY() + 1);
        $this->SetLineWidth(0.2);
        $this->Ln(3);
    }

    function Footer()
    {
        $this->SetY(-12);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(148, 163, 184);
        $this->Cell(0, 5, 'Dicetak pada: ' . date('d/m/Y H:i'), 0, 0, 'C');
    }
}

$pdf = new RekapGuruPDF('L', 'mm', 'A4');
$pdf->namaSekolah   = $nama_sekolah;
$pdf->alamatSekolah = $alamat_sekolah;
$pdf->logoPath      = $logo_path;
$pdf->SetAutoPageBreak(true, 22);
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetTextColor(30, 60, 114);
$pdf->Cell(0, 6, 'Periode: ' . $bulan_teks, 0, 1, 'C');
$pdf->Ln(2);

$col_no     = 6;
$col_nip    = 34;
$col_nama   = 48;
$col_rekap  = 11;
$total_fixed = $col_no + $col_nip + $col_nama + ($col_rekap * 4);
$day_w = (281 - $total_fixed) / $jumlahHari;
if ($day_w < 3.8) $day_w = 3.8;

$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(30, 60, 114);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetDrawColor(30, 60, 114);

$row_h = 8;
$pdf->Cell($col_no, $row_h, 'No', 1, 0, 'C', true);
$pdf->Cell($col_nip, $row_h, 'NIP', 1, 0, 'C', true);
$pdf->Cell($col_nama, $row_h, 'Nama Guru', 1, 0, 'C', true);
for ($i = 1; $i <= $jumlahHari; $i++) {
    $pdf->Cell($day_w, $row_h, $i, 1, 0, 'C', true);
}
$pdf->Cell($col_rekap, $row_h, 'H', 1, 0, 'C', true);
$pdf->Cell($col_rekap, $row_h, 'I', 1, 0, 'C', true);
$pdf->Cell($col_rekap, $row_h, 'S', 1, 0, 'C', true);
$pdf->Cell($col_rekap, $row_h, 'A', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 7.5);
$pdf->SetDrawColor(232, 237, 243);
$pdf->SetTextColor(51, 65, 85);

$no = 1;
$fill = false;

if ($guruResult && mysqli_num_rows($guruResult) > 0) {
    mysqli_data_seek($guruResult, 0);
    while ($guru = mysqli_fetch_assoc($guruResult)) {
        if ($pdf->GetY() > 180) {
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 9);
            $pdf->SetFillColor(30, 60, 114);
            $pdf->SetTextColor(255, 255, 255);
            $pdf->SetDrawColor(30, 60, 114);

            $pdf->Cell($col_no, $row_h, 'No', 1, 0, 'C', true);
            $pdf->Cell($col_nip, $row_h, 'NIP', 1, 0, 'C', true);
            $pdf->Cell($col_nama, $row_h, 'Nama Guru', 1, 0, 'C', true);
            for ($i = 1; $i <= $jumlahHari; $i++) {
                $pdf->Cell($day_w, $row_h, $i, 1, 0, 'C', true);
            }
            $pdf->Cell($col_rekap, $row_h, 'H', 1, 0, 'C', true);
            $pdf->Cell($col_rekap, $row_h, 'I', 1, 0, 'C', true);
            $pdf->Cell($col_rekap, $row_h, 'S', 1, 0, 'C', true);
            $pdf->Cell($col_rekap, $row_h, 'A', 1, 1, 'C', true);

            $pdf->SetFont('Arial', '', 7.5);
            $pdf->SetDrawColor(232, 237, 243);
            $fill = false;
        }

        $gid = $guru['id'];

        $bg = $fill ? [249, 250, 251] : [255, 255, 255];
        $pdf->SetFillColor($bg[0], $bg[1], $bg[2]);

        $pdf->SetTextColor(51, 65, 85);
        $pdf->Cell($col_no, 6, $no, 1, 0, 'C', true);
        $pdf->Cell($col_nip, 6, $guru['nip'], 1, 0, 'C', true);

        $nama = $guru['nama'];
        if (strlen($nama) > 28) {
            $nama = substr($nama, 0, 25) . '...';
        }
        $pdf->SetFont('Arial', 'B', 7.5);
        $pdf->Cell($col_nama, 6, $nama, 1, 0, 'L', true);
        $pdf->SetFont('Arial', '', 7.5);

        $countH = $countI = $countS = $countA = 0;

        for ($i = 1; $i <= $jumlahHari; $i++) {
            $val = $absensi[$gid][$i] ?? '';
            $tanggal = "$tahun-" . str_pad($bulan, 2, '0', STR_PAD_LEFT) . "-" . str_pad($i, 2, '0', STR_PAD_LEFT);
            $day = date('w', strtotime($tanggal));

            if ($val == '') {
                if ($day == 0) {
                    $pdf->SetTextColor(220, 38, 38);
                    $pdf->Cell($day_w, 6, 'M', 1, 0, 'C', true);
                    $pdf->SetTextColor(51, 65, 85);
                } elseif (in_array($tanggal, $libur)) {
                    $pdf->SetTextColor(220, 38, 38);
                    $pdf->Cell($day_w, 6, 'L', 1, 0, 'C', true);
                    $pdf->SetTextColor(51, 65, 85);
                } else {
                    $pdf->Cell($day_w, 6, '', 1, 0, 'C', true);
                }
            } else {
                if ($val == 'H') {
                    $pdf->SetTextColor(4, 120, 87);
                    $pdf->Cell($day_w, 6, 'H', 1, 0, 'C', true);
                    $countH++;
                } elseif ($val == 'I') {
                    $pdf->SetTextColor(180, 83, 9);
                    $pdf->Cell($day_w, 6, 'I', 1, 0, 'C', true);
                    $countI++;
                } elseif ($val == 'S') {
                    $pdf->SetTextColor(109, 40, 217);
                    $pdf->Cell($day_w, 6, 'S', 1, 0, 'C', true);
                    $countS++;
                } elseif ($val == 'A') {
                    $pdf->SetTextColor(185, 28, 28);
                    $pdf->Cell($day_w, 6, 'A', 1, 0, 'C', true);
                    $countA++;
                } else {
                    $pdf->SetTextColor(51, 65, 85);
                    $pdf->Cell($day_w, 6, $val, 1, 0, 'C', true);
                }
                $pdf->SetTextColor(51, 65, 85);
            }
        }

        $pdf->SetTextColor(4, 120, 87);
        $pdf->SetFont('Arial', 'B', 7.5);
        $pdf->Cell($col_rekap, 6, $countH, 1, 0, 'C', true);

        $pdf->SetTextColor(180, 83, 9);
        $pdf->Cell($col_rekap, 6, $countI, 1, 0, 'C', true);

        $pdf->SetTextColor(109, 40, 217);
        $pdf->Cell($col_rekap, 6, $countS, 1, 0, 'C', true);

        $pdf->SetTextColor(185, 28, 28);
        $pdf->Cell($col_rekap, 6, $countA, 1, 1, 'C', true);

        $pdf->SetFont('Arial', '', 7.5);
        $no++;
        $fill = !$fill;
    }
} else {
    $total_width = $col_no + $col_nip + $col_nama + ($day_w * $jumlahHari) + ($col_rekap * 4);
    $pdf->SetTextColor(148, 163, 184);
    $pdf->SetFont('Arial', 'I', 10);
    $pdf->Cell($total_width, 12, 'Tidak ada data guru aktif.', 1, 1, 'C');
}

$pdf->Ln(3);

$pdf->SetFont('Arial', '', 7.5);
$pdf->SetTextColor(51, 65, 85);
$pdf->SetDrawColor(42, 82, 152);
$pdf->SetFillColor(249, 250, 251);

$total_width = $col_no + $col_nip + $col_nama + ($day_w * $jumlahHari) + ($col_rekap * 4);
$pdf->Cell($total_width, 6, '  Keterangan: H = Hadir  |  I = Izin  |  S = Sakit  |  A = Alpha  |  M = Minggu  |  L = Libur', 1, 1, 'L', true);

$pdf->Ln(5);

if ($pdf->GetY() > 155) {
    $pdf->AddPage();
}

$y_sig = $pdf->GetY();
$half = 140;
$left_x = 20;
$right_x = 20 + $half + 20;

$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(51, 65, 85);

$pdf->SetXY($left_x, $y_sig);
$pdf->Cell($half, 5, 'Mengetahui,', 0, 2, 'C');
$pdf->SetX($left_x);
$pdf->Cell($half, 5, 'Kepala Sekolah', 0, 2, 'C');

$pdf->SetY($y_sig + 28);
$pdf->SetX($left_x);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->Cell($half, 5, $kepala, 0, 2, 'C');
$pdf->SetX($left_x);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell($half, 5, 'NIP. ' . $nip_kepala, 0, 2, 'C');

$pdf->SetXY($right_x, $y_sig);
$pdf->Cell($half, 5, date('d F Y'), 0, 2, 'C');
$pdf->SetX($right_x);
$pdf->Cell($half, 5, 'Koordinator Kepegawaian', 0, 2, 'C');

$pdf->SetY($y_sig + 28);
$pdf->SetX($right_x);
$pdf->SetFont('Arial', 'BU', 10);
$pdf->Cell($half, 5, '....................................', 0, 2, 'C');
$pdf->SetX($right_x);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell($half, 5, 'NIP. ........................', 0, 2, 'C');

mysqli_close($conn);

$pdf->Output('I', 'rekap_absensi_guru_' . $bulan . '_' . $tahun . '.pdf');
exit;