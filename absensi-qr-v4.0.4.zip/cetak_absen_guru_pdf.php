<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

$query = $_SERVER['QUERY_STRING'] ?? '';
$target = 'cetak_absen_guru.php' . ($query ? '?' . $query : '');
header("Location: $target");
exit;
