<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('BASE_URL', 'https://absensi.rafazmalik.my.id');

date_default_timezone_set('Asia/Jakarta');

$host = 'localhost';
$user = 'absensi';
$pass = 'sastiarya240303';
$dbname = 'absensi';

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

if (file_exists(__DIR__ . '/version.php')) {
    include_once __DIR__ . '/version.php';
}

$__script = basename($_SERVER['SCRIPT_NAME'] ?? '');
$__skip = in_array($__script, ['license_activate.php', 'logout.php']);

if (!$__skip && file_exists(__DIR__ . '/license.php')) {
    include_once __DIR__ . '/license.php';

    if (class_exists('AppLicense')) {
        try {
            $__lic = AppLicense::check($conn);
            if (is_array($__lic) && isset($__lic['valid']) && !$__lic['valid']) {
                $_SESSION['license_reason'] = $__lic['reason'] ?? 'Lisensi tidak valid.';
                header("Location: license_activate.php");
                exit;
            }
            $GLOBALS['LICENSE'] = $__lic;
        } catch (Throwable $e) {
            error_log('License check error: ' . $e->getMessage());
        }
    }
}
