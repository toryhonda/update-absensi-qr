# Changelog

## [4.0.4] - 2026-09-15
- Perbaikan celah keamanan pada wa_token.php (auth admin)
- Perbaikan SQL injection di absensi.php, absensi_2.php, cetak_absen.php, cetak_absen_guru.php
- Perbaikan error 500 pada kelas.php (tabel auto-create)
- Guard license.php di config.php untuk mencegah fatal error
- Redirect cetak_absen_guru_pdf.php ke cetak_absen_guru.php
- Perbaikan bug profil['nama'] di export_guru.php dan export_rekap.php
- Optimalisasi query belum_absensi.php dengan NOT EXISTS

## [4.0.3] - 2026-09-13
- Perbaikan bug pada halaman Import Excel (siswa & guru)
- Tombol download template diarahkan ke folder template/
- Notifikasi error import lebih detail
- Perbaikan handling kolom kosong pada file Excel
- Redesain halaman import dengan gaya SaaS modern
- Update warna brand dan tipografi Rubik

## [4.0.2] - 2026-06-01
- (isi perubahan versi ini)

## [4.0.1] - 2026-01-01
- Rilis awal versi jual
- Fitur scan QR webcam + scanner eksternal
- Integrasi WhatsApp Cloud API (WABA)
- Export PDF & Excel
