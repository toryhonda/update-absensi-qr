# Sistem Absensi QR

![PHP](https://img.shields.io/badge/PHP-7.4%2B-blue)
![Version](https://img.shields.io/badge/version-4.0.4-blue)
![License](https://img.shields.io/badge/license-Commercial-red)

Aplikasi absensi sekolah berbasis QR Code dengan integrasi WhatsApp Cloud API dan rekap PDF/Excel otomatis.

## Fitur

- Scan QR Code siswa via webcam atau scanner eksternal
- Notifikasi WhatsApp otomatis ke orang tua/wali
- Rekap absensi harian, bulanan, dan per kelas
- Export PDF & Excel
- Manajemen data siswa, guru, dan wali kelas
- Login multi-role (admin & guru)
- Jam sesi absensi fleksibel (masuk, sholat, pulang)
- Kartu QR siswa siap cetak
- Backup & restore database

## Spesifikasi Server

- PHP 7.4 atau lebih baru (disarankan PHP 8.0+)
- MySQL 5.7+ / MariaDB 10.3+
- Ekstensi PHP: mysqli, curl, gd
- HTTPS (wajib untuk akses kamera browser)

## Instalasi

1. Upload semua file ke folder hosting atau htdocs.
2. Buat database baru di phpMyAdmin.
3. Import file database.sql ke database tersebut.
4. Rename config.example.php menjadi config.php.
5. Edit config.php sesuai kredensial database Anda.
6. Set permission folder uploads/, assets/qr/, dan assets/qr_guru/ menjadi 775.
7. Buka browser dan akses aplikasi.
8. Login dengan akun default:
   - Username: admin
   - Password: admin
9. Segera ubah password default.
10. Lengkapi profil sekolah di menu Profil Sekolah.
11. Konfigurasi WhatsApp API di menu Pengaturan API WA (opsional).

## Struktur Folder

- assets/js/ - Library JavaScript (html5-qrcode.min.js)
- assets/qr/ - QR code siswa (auto-generate)
- assets/qr_guru/ - QR code guru (auto-generate)
- fpdf/ - Library PDF
- vendor/phpqrcode/ - Library QR Code generator
- template/ - Template Excel import
- uploads/ - Foto profil & logo sekolah
- dokumentasi/ - Dokumentasi & panduan
- config.php - Konfigurasi (dibuat dari example)
- config.example.php - Contoh konfigurasi
- database.sql - Struktur database
- license.php - Sistem lisensi
- version.php - Info versi aplikasi
- index.php - Halaman login
- dashboard.php - Dashboard admin
- dashboard_guru.php - Dashboard guru
- dashboard_siswa.php - Dashboard siswa

## Changelog

Lihat file CHANGELOG.md.

## Support

- Email: tory@autowebportal.com
- WhatsApp: +62 896-5463-0099
- Jam operasional: Senin - Jumat, 09.00 - 17.00 WIB

## Lisensi

Commercial Single License. Lihat file LICENSE.txt.
