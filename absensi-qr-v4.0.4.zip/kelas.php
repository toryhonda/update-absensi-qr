<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

include "config.php";

mysqli_query($conn, "CREATE TABLE IF NOT EXISTS kelas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nama_kelas VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$pesan = "";
$pesan_tipe = "success";

if (isset($_POST['simpan'])) {
    $nama_kelas = trim($_POST['nama_kelas'] ?? '');
    if ($nama_kelas === '') {
        $pesan = "Nama kelas tidak boleh kosong.";
        $pesan_tipe = "danger";
    } else {
        $nama_esc = mysqli_real_escape_string($conn, $nama_kelas);
        $cek = mysqli_query($conn, "SELECT id FROM kelas WHERE nama_kelas='$nama_esc' LIMIT 1");
        if ($cek && mysqli_num_rows($cek) > 0) {
            $pesan = "Kelas '$nama_kelas' sudah ada.";
            $pesan_tipe = "danger";
        } else {
            $ins = mysqli_query($conn, "INSERT INTO kelas (nama_kelas) VALUES ('$nama_esc')");
            if ($ins) {
                $pesan = "Kelas '$nama_kelas' berhasil ditambahkan.";
                $pesan_tipe = "success";
            } else {
                $pesan = "Gagal menambah kelas: " . mysqli_error($conn);
                $pesan_tipe = "danger";
            }
        }
    }
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    if ($id > 0) {
        $del = mysqli_query($conn, "DELETE FROM kelas WHERE id=$id");
        if ($del) {
            $pesan = "Kelas berhasil dihapus.";
            $pesan_tipe = "success";
        } else {
            $pesan = "Gagal menghapus kelas: " . mysqli_error($conn);
            $pesan_tipe = "danger";
        }
    }
}

$kelas = mysqli_query($conn, "SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
$total_kelas = 0;
$data_kelas = [];
if ($kelas) {
    while ($r = mysqli_fetch_assoc($kelas)) {
        $data_kelas[] = $r;
    }
    $total_kelas = count($data_kelas);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Data Kelas</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{--bg:#f6f8fb;--surface:#ffffff;--surface-2:#f9fafb;--line:#e8edf3;--line-strong:#dbe3ec;--ink:#0f172a;--ink-2:#334155;--muted:#64748b;--muted-2:#94a3b8;--brand:#2a5298;--brand-2:#1e3c72;--brand-soft:rgba(42,82,152,.08);--success:#10b981;--danger:#ef4444;--warning:#f59e0b;--radius-lg:16px;--radius-md:12px;--radius-sm:10px;--shadow-sm:0 1px 2px rgba(15,23,42,.05);--shadow-md:0 6px 16px -8px rgba(15,23,42,.12),0 2px 6px -2px rgba(15,23,42,.06);--shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);}
    *{box-sizing:border-box;}
    body{font-family:'Rubik',system-ui,-apple-system,"Segoe UI",Tahoma,Geneva,Verdana,sans-serif!important;background:radial-gradient(circle at 0% 0%,rgba(42,82,152,.06),transparent 40%),radial-gradient(circle at 100% 100%,rgba(255,176,32,.05),transparent 40%),var(--bg);min-height:100vh;color:var(--ink);margin:0;padding:0;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;}
    .topbar{background:rgba(255,255,255,.88);backdrop-filter:blur(14px);border-bottom:1px solid var(--line);position:sticky;top:0;z-index:100;padding:14px 0;}
    .topbar-inner{max-width:900px;margin:0 auto;padding:0 24px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;}
    .brand-block{display:flex;align-items:center;gap:14px;min-width:0;}
    .brand-mark{width:44px;height:44px;border-radius:var(--radius-md);background:linear-gradient(135deg,var(--brand),var(--brand-2));color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;box-shadow:var(--shadow-brand);flex-shrink:0;}
    .brand-titles h1{font-size:17px;font-weight:600;color:var(--ink);margin:0;line-height:1.25;}
    .brand-titles span{display:block;font-size:12.5px;color:var(--muted);margin-top:2px;}
    .btn-back{display:inline-flex;align-items:center;gap:8px;padding:9px 16px;font-size:13.5px;font-weight:500;color:var(--ink-2);background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-sm);text-decoration:none;box-shadow:var(--shadow-sm);transition:all .2s;}
    .btn-back:hover{background:var(--surface-2);border-color:var(--line-strong);color:var(--ink);transform:translateX(-2px);}
    .page-wrap{max-width:900px;margin:0 auto;padding:32px 24px 60px;}
    .page-head{margin-bottom:22px;}
    .page-eyebrow{font-size:11.5px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;color:var(--brand);display:block;margin-bottom:6px;}
    .page-head h2{font-size:24px;font-weight:600;color:var(--ink);margin:0;}
    .page-head p{font-size:13.5px;color:var(--muted);margin:6px 0 0;}
    .stats-row{display:flex;flex-wrap:wrap;gap:10px;margin-bottom:20px;}
    .stat-chip{display:inline-flex;align-items:center;gap:8px;padding:8px 14px;font-size:12.5px;font-weight:500;background:var(--surface);border:1px solid var(--line);border-radius:999px;color:var(--ink-2);box-shadow:var(--shadow-sm);}
    .stat-chip i{color:var(--brand);font-size:12px;}
    .stat-chip strong{color:var(--ink);font-weight:600;}
    .card-panel{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);padding:24px;margin-bottom:20px;}
    .card-panel-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px;flex-wrap:wrap;}
    .card-panel-title{display:flex;align-items:center;gap:10px;font-size:15px;font-weight:600;color:var(--ink);}
    .card-panel-title i{width:32px;height:32px;border-radius:var(--radius-sm);background:var(--brand-soft);color:var(--brand);display:flex;align-items:center;justify-content:center;font-size:14px;}
    .form-label{display:block;font-size:12.5px;font-weight:500;color:var(--ink-2);margin-bottom:6px;}
    .form-control{font-family:inherit;font-size:14px;color:var(--ink);background:var(--surface-2);border:1px solid var(--line);border-radius:var(--radius-sm);padding:10px 14px;width:100%;outline:none;}
    .form-control:focus{background:#fff;border-color:var(--brand);box-shadow:0 0 0 4px var(--brand-soft);}
    .form-row{display:grid;grid-template-columns:1fr auto;gap:14px;align-items:end;}
    .btn{font-family:inherit;font-size:13.5px;font-weight:500;border-radius:var(--radius-sm);padding:10px 16px;display:inline-flex;align-items:center;justify-content:center;gap:8px;border:1px solid transparent;cursor:pointer;text-decoration:none;transition:all .2s;}
    .btn-primary{background:linear-gradient(135deg,var(--brand),var(--brand-2));color:#fff;box-shadow:var(--shadow-brand);}
    .btn-primary:hover{filter:brightness(1.08);transform:translateY(-1px);color:#fff;}
    .btn-danger{background:linear-gradient(135deg,#ef4444,#dc2626);color:#fff;box-shadow:0 10px 20px -10px rgba(220,38,38,.6);}
    .btn-danger:hover{filter:brightness(1.08);transform:translateY(-1px);color:#fff;}
    .btn-sm{padding:6px 12px;font-size:12.5px;border-radius:8px;}
    .alert{padding:14px 18px;border-radius:var(--radius-md);font-size:13.5px;font-weight:500;border:1px solid transparent;margin-bottom:20px;display:flex;align-items:flex-start;gap:10px;}
    .alert-success{background:rgba(16,185,129,.08);color:#047857;border-color:rgba(16,185,129,.28);}
    .alert-danger{background:rgba(239,68,68,.08);color:#b91c1c;border-color:rgba(239,68,68,.28);}
    .table-wrapper{border:1px solid var(--line);border-radius:var(--radius-md);overflow:hidden;background:var(--surface);}
    .table-responsive{overflow-x:auto;}
    table{width:100%;border-collapse:separate;border-spacing:0;font-size:13.5px;color:var(--ink-2);margin:0;}
    table thead th{background:var(--surface-2);color:var(--muted);font-weight:600;font-size:11.5px;letter-spacing:.6px;text-transform:uppercase;padding:13px 16px;border-bottom:1px solid var(--line);text-align:left;}
    table tbody td{padding:13px 16px;vertical-align:middle;border-bottom:1px solid var(--line);color:var(--ink-2);}
    table tbody tr:last-child td{border-bottom:0;}
    table tbody tr:hover td{background:rgba(42,82,152,.04);}
    .badge-kelas{display:inline-block;padding:4px 10px;font-size:12px;font-weight:500;background:rgba(139,92,246,.1);color:#6d28d9;border-radius:6px;}
    .empty-state{text-align:center;padding:52px 20px;color:var(--muted);}
    .empty-state i{font-size:34px;opacity:.35;margin-bottom:12px;display:block;color:var(--brand);}
    .empty-state h4{font-size:15.5px;font-weight:600;color:var(--ink);margin:0 0 6px;}
    .empty-state p{font-size:13.5px;margin:0;}
    .text-center{text-align:center;}
    @media (max-width:900px){.topbar-inner{padding:0 18px;}.page-wrap{padding:24px 18px 48px;}.page-head h2{font-size:21px;}}
    @media (max-width:640px){.topbar{padding:12px 0;}.topbar-inner{padding:0 14px;}.brand-mark{width:38px;height:38px;font-size:15px;}.brand-titles h1{font-size:15px;}.brand-titles span{font-size:11.5px;}.btn-back{padding:8px 12px;font-size:12.5px;}.btn-back span{display:none;}.page-wrap{padding:20px 14px 40px;}.page-head h2{font-size:19px;}.page-head p{font-size:12.5px;}.card-panel{padding:16px;border-radius:var(--radius-md);}.form-row{grid-template-columns:1fr;gap:12px;}.form-row .btn{width:100%;}table thead th,table tbody td{padding:11px 12px;font-size:12.5px;}.stat-chip{padding:6px 12px;font-size:11.5px;}}
    @media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important;}}
  </style>
</head>
<body>
  <div class="topbar">
    <div class="topbar-inner">
      <div class="brand-block">
        <div class="brand-mark"><i class="fas fa-door-open"></i></div>
        <div class="brand-titles">
          <h1>Data Kelas</h1>
          <span>Kelola daftar kelas sekolah</span>
        </div>
      </div>
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i>
        <span>Kembali</span>
      </a>
    </div>
  </div>

  <div class="page-wrap">
    <div class="page-head">
      <span class="page-eyebrow">Data Master</span>
      <h2>Data Kelas</h2>
      <p>Kelola daftar kelas untuk digunakan di data siswa dan wali kelas.</p>
    </div>

    <?php if ($pesan !== ""): ?>
      <div class="alert alert-<?= $pesan_tipe ?>">
        <i class="fas <?= $pesan_tipe === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle' ?>"></i>
        <span><?= htmlspecialchars($pesan) ?></span>
      </div>
    <?php endif; ?>

    <div class="stats-row">
      <span class="stat-chip">
        <i class="fas fa-layer-group"></i>
        Total Kelas: <strong><?= $total_kelas ?></strong>
      </span>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-plus"></i>
          Tambah Kelas
        </div>
      </div>
      <form method="post" autocomplete="off">
        <div class="form-row">
          <div>
            <label class="form-label" for="nama_kelas">Nama Kelas</label>
            <input type="text" id="nama_kelas" name="nama_kelas" class="form-control" placeholder="Contoh: 5A" required>
          </div>
          <button type="submit" name="simpan" class="btn btn-primary">
            <i class="fas fa-floppy-disk"></i> Simpan
          </button>
        </div>
      </form>
    </div>

    <div class="card-panel">
      <div class="card-panel-header">
        <div class="card-panel-title">
          <i class="fas fa-list-check"></i>
          Daftar Kelas
        </div>
      </div>
      <div class="table-wrapper">
        <div class="table-responsive">
          <table>
            <thead>
              <tr>
                <th style="width:60px;">No</th>
                <th>Nama Kelas</th>
                <th class="text-center" style="width:130px;">Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($total_kelas > 0): ?>
                <?php $no = 1; foreach ($data_kelas as $row): ?>
                  <tr>
                    <td><?= $no++ ?></td>
                    <td><span class="badge-kelas"><?= htmlspecialchars($row['nama_kelas']) ?></span></td>
                    <td class="text-center">
                      <a href="kelas.php?hapus=<?= (int)$row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus kelas ini?')">
                        <i class="fas fa-trash"></i> Hapus
                      </a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr>
                  <td colspan="3">
                    <div class="empty-state">
                      <i class="fas fa-inbox"></i>
                      <h4>Belum ada data kelas</h4>
                      <p>Tambahkan kelas melalui formulir di atas.</p>
                    </div>
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
