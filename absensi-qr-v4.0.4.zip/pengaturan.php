<?php

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Pengaturan</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <style>
        :root{
            --bg:#f6f8fb;
            --surface:#ffffff;
            --surface-2:#f9fafb;
            --line:#e8edf3;
            --line-strong:#dbe3ec;
            --ink:#0f172a;
            --ink-2:#334155;
            --muted:#64748b;
            --muted-2:#94a3b8;
            --brand:#2a5298;
            --brand-2:#1e3c72;
            --brand-soft:rgba(42,82,152,.08);
            --success:#10b981;
            --success-soft:rgba(16,185,129,.10);
            --warning:#f59e0b;
            --warning-soft:rgba(245,158,11,.10);
            --danger:#ef4444;
            --danger-soft:rgba(239,68,68,.10);
            --radius-xl:20px;
            --radius-lg:16px;
            --radius-md:12px;
            --radius-sm:10px;
            --shadow-sm:0 1px 2px rgba(15,23,42,.05);
            --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
            --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
        }

        *{box-sizing:border-box;}

        html{scroll-behavior:smooth;}

        body{
            font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
                radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
                var(--bg);
            min-height:100vh;
            color:var(--ink);
            margin:0;
            -webkit-font-smoothing:antialiased;
            -moz-osx-font-smoothing:grayscale;
        }

        header{
            background:rgba(255,255,255,.85);
            backdrop-filter:blur(14px);
            -webkit-backdrop-filter:blur(14px);
            border-bottom:1px solid var(--line);
            position:sticky;
            top:0;
            z-index:15;
        }

        .header-inner{
            max-width:920px;
            margin:0 auto;
            padding:16px 24px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:16px;
        }

        .header-left{
            display:flex;
            align-items:center;
            gap:14px;
            min-width:0;
        }

        .brand-mark{
            width:42px;
            height:42px;
            border-radius:var(--radius-md);
            background:linear-gradient(135deg, var(--brand), var(--brand-2));
            color:#fff;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:17px;
            box-shadow:0 14px 30px -14px rgba(30,60,114,.55);
            flex-shrink:0;
        }

        header h1{
            font-size:17px;
            font-weight:600;
            letter-spacing:-.2px;
            color:var(--ink);
            margin:0 0 2px;
            line-height:1.25;
        }

        header p{
            font-size:12.5px;
            color:var(--muted);
            margin:0;
            line-height:1.4;
        }

        .btn-home{
            display:inline-flex;
            align-items:center;
            justify-content:center;
            gap:8px;
            padding:9px 16px;
            background:var(--surface);
            color:var(--ink-2);
            border:1px solid var(--line);
            border-radius:999px;
            font-size:13px;
            font-weight:500;
            text-decoration:none;
            box-shadow:var(--shadow-sm);
            transition:border-color .2s ease, color .2s ease, transform .2s ease, box-shadow .2s ease;
            flex-shrink:0;
        }

        .btn-home i{
            font-size:12px;
            color:var(--muted);
            transition:color .2s ease, transform .2s ease;
        }

        .btn-home:hover{
            color:var(--ink);
            border-color:var(--line-strong);
            box-shadow:var(--shadow-md);
            transform:translateY(-1px);
        }

        .btn-home:hover i{
            color:var(--brand);
            transform:translateX(-2px);
        }

        .btn-home:focus-visible{
            outline:3px solid var(--brand-soft);
            outline-offset:2px;
        }

        main{
            max-width:920px;
            margin:0 auto;
            padding:36px 24px 56px;
        }

        .page-head{
            display:flex;
            flex-direction:column;
            gap:6px;
            margin-bottom:24px;
        }

        .page-eyebrow{
            font-size:11.5px;
            font-weight:600;
            letter-spacing:1.2px;
            text-transform:uppercase;
            color:var(--brand);
        }

        .page-head h2{
            font-size:26px;
            font-weight:600;
            letter-spacing:-.4px;
            color:var(--ink);
            margin:0;
            line-height:1.25;
        }

        .page-head p{
            margin:0;
            font-size:14px;
            color:var(--muted);
            line-height:1.55;
        }

        .info-banner{
            display:flex;
            align-items:flex-start;
            gap:12px;
            padding:14px 18px;
            border-radius:var(--radius-lg);
            background:var(--brand-soft);
            border:1px solid rgba(42,82,152,.16);
            border-left:4px solid var(--brand);
            margin-bottom:24px;
            font-size:13px;
            color:var(--brand-2);
            line-height:1.6;
            animation:fadeUp .5s ease both;
        }

        .info-banner i{
            color:var(--brand);
            font-size:15px;
            margin-top:2px;
            flex-shrink:0;
        }

        .info-banner strong{
            font-weight:600;
            color:var(--brand-2);
        }

        @keyframes fadeUp{
            from{opacity:0; transform:translateY(8px);}
            to{opacity:1; transform:translateY(0);}
        }

        .settings-list{
            display:flex;
            flex-direction:column;
            gap:12px;
        }

        .menu-item{
            display:flex;
            align-items:center;
            gap:16px;
            padding:18px 22px;
            background:var(--surface);
            border:1px solid var(--line);
            border-radius:var(--radius-lg);
            text-decoration:none;
            color:var(--ink-2);
            box-shadow:var(--shadow-sm);
            transition:transform .2s ease, box-shadow .2s ease, border-color .2s ease;
            position:relative;
            overflow:hidden;
            animation:fadeUp .5s ease both;
        }

        .menu-item::before{
            content:"";
            position:absolute;
            left:0;
            top:0;
            bottom:0;
            width:3px;
            background:var(--accent-color, var(--brand));
            opacity:0;
            transition:opacity .2s ease;
        }

        .menu-item:hover{
            transform:translateY(-2px);
            border-color:var(--line-strong);
            box-shadow:var(--shadow-lg);
        }

        .menu-item:hover::before{
            opacity:1;
        }

        .menu-item:focus-visible{
            outline:3px solid var(--brand-soft);
            outline-offset:2px;
        }

        .menu-icon{
            width:46px;
            height:46px;
            border-radius:var(--radius-md);
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:18px;
            flex-shrink:0;
            background:var(--accent-soft, var(--brand-soft));
            color:var(--accent-color, var(--brand));
            transition:transform .2s ease;
        }

        .menu-item:hover .menu-icon{
            transform:scale(1.06);
        }

        .menu-text{
            display:flex;
            flex-direction:column;
            gap:3px;
            min-width:0;
            flex:1;
        }

        .menu-title{
            font-size:15px;
            font-weight:600;
            letter-spacing:-.15px;
            color:var(--ink);
            line-height:1.35;
        }

        .menu-desc{
            font-size:12.5px;
            color:var(--muted);
            line-height:1.5;
        }

        .menu-arrow{
            font-size:13px;
            color:var(--muted-2);
            flex-shrink:0;
            transition:transform .2s ease, color .2s ease;
        }

        .menu-item:hover .menu-arrow{
            transform:translateX(4px);
            color:var(--accent-color, var(--brand));
        }

        @media (max-width:640px){
            .header-inner{padding:14px 16px;}
            header h1{font-size:15px;}
            header p{font-size:11.5px;}
            .brand-mark{width:38px;height:38px;font-size:15px;}
            main{padding:26px 16px 40px;}
            .page-head h2{font-size:22px;}
            .page-head p{font-size:13px;}
            .info-banner{font-size:12.5px;padding:12px 14px;}
            .menu-item{padding:15px 16px;gap:13px;}
            .menu-icon{width:40px;height:40px;font-size:16px;}
            .menu-title{font-size:14px;}
            .menu-desc{font-size:12px;}
        }

        @media (max-width:420px){
            .menu-desc{display:none;}
            .menu-title{font-size:14.5px;}
        }

        @media (prefers-reduced-motion:reduce){
            *{animation:none !important;transition:none !important;}
        }
    </style>
</head>
<body>
    <header>
        <div class="header-inner">
            <div class="header-left">
                <div class="brand-mark">
                    <i class="fas fa-gear"></i>
                </div>
                <div>
                    <h1>Pengaturan</h1>
                    <p>Konfigurasi sistem dan preferensi aplikasi</p>
                </div>
            </div>
            <a href="dashboard.php" class="btn-home">
                <i class="fas fa-arrow-left"></i> Dashboard
            </a>
        </div>
    </header>

    <main>
        <div class="page-head">
            <span class="page-eyebrow">Sistem</span>
            <h2>Menu Pengaturan</h2>
            <p>Kelola pemeliharaan data, versi PHP, dan pembaruan aplikasi.</p>
        </div>

        <div class="info-banner">
            <i class="fas fa-circle-info"></i>
            <div>
                <strong>Catatan:</strong> Sebelum melakukan tindakan penting, sebaiknya lakukan <strong>Backup</strong> terlebih dahulu untuk menghindari kehilangan data.
            </div>
        </div>

        <div class="settings-list">
            <a href="backup_restore.php" class="menu-item" style="--accent-color:#2a5298; --accent-soft:rgba(42,82,152,.10);">
                <div class="menu-icon">
                    <i class="fas fa-database"></i>
                </div>
                <div class="menu-text">
                    <span class="menu-title">Backup &amp; Restore</span>
                    <span class="menu-desc">Cadangkan dan pulihkan seluruh data sistem.</span>
                </div>
                <i class="fas fa-chevron-right menu-arrow"></i>
            </a>

            <a href="server-info.php" class="menu-item" style="--accent-color:#047857; --accent-soft:rgba(16,185,129,.10);">
                <div class="menu-icon">
                    <i class="fas fa-code"></i>
                </div>
                <div class="menu-text">
                    <span class="menu-title">Cek Versi PHP</span>
                    <span class="menu-desc">Lihat informasi konfigurasi server dan PHP.</span>
                </div>
                <i class="fas fa-chevron-right menu-arrow"></i>
            </a>

            <a href="update_db.php" class="menu-item" style="--accent-color:#b45309; --accent-soft:rgba(245,158,11,.10);">
                <div class="menu-icon">
                    <i class="fas fa-database"></i>
                </div>
                <div class="menu-text">
                    <span class="menu-title">Update Versi Database</span>
                    <span class="menu-desc">Perbarui struktur database ke versi terbaru.</span>
                </div>
                <i class="fas fa-chevron-right menu-arrow"></i>
            </a>

            <a href="cek_update.php" class="menu-item" style="--accent-color:#b91c1c; --accent-soft:rgba(239,68,68,.10);">
                <div class="menu-icon">
                    <i class="fas fa-rotate"></i>
                </div>
                <div class="menu-text">
                    <span class="menu-title">Cek Update Versi Aplikasi</span>
                    <span class="menu-desc">Periksa ketersediaan pembaruan sistem absensi.</span>
                </div>
                <i class="fas fa-chevron-right menu-arrow"></i>
            </a>
        </div>
    </main>
</body>
</html>