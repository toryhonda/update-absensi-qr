<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    http_response_code(401);
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

include "config.php";

if (!isset($_GET['code']) || empty($_GET['code'])) {
    echo json_encode(["status" => "error", "message" => "Kode QR tidak ditemukan"]);
    exit;
}

$code = $_GET['code'];

if (!is_numeric($code)) {
    echo json_encode(["status" => "error", "message" => "Kode QR harus berisi angka"]);
    exit;
}

$code_esc = mysqli_real_escape_string($conn, $code);

$siswa_query = mysqli_query($conn, "SELECT nama, kelas FROM siswa WHERE nisn = '$code_esc' AND status = 'aktif' LIMIT 1");
if ($siswa_query && mysqli_num_rows($siswa_query) > 0) {
    $siswa = mysqli_fetch_assoc($siswa_query);
    echo json_encode([
        "status" => "success",
        "message" => "Siswa: " . $siswa['nama'] . " (" . $siswa['kelas'] . ") - QR Code valid"
    ]);
    exit;
}

$guru_query = mysqli_query($conn, "SELECT nama FROM guru WHERE nip = '$code_esc' AND status = 'aktif' LIMIT 1");
if ($guru_query && mysqli_num_rows($guru_query) > 0) {
    $guru = mysqli_fetch_assoc($guru_query);
    echo json_encode([
        "status" => "success",
        "message" => "Guru: " . $guru['nama'] . " - QR Code valid"
    ]);
    exit;
}

echo json_encode([
    "status" => "error",
    "message" => "Kode $code tidak terdaftar sebagai siswa atau guru aktif"
]);
exit;
