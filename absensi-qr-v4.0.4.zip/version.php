<?php
if (!defined('APP_NAME'))    define('APP_NAME',    'Sistem Absensi QR');
if (!defined('APP_VERSION')) define('APP_VERSION', '4.0.4');
if (!defined('APP_BUILD'))   define('APP_BUILD',   '2026-09-15');
if (!defined('APP_AUTHOR'))  define('APP_AUTHOR',  'Autoweb Portal');
if (!defined('APP_SUPPORT')) define('APP_SUPPORT', 'tory@autowebportal.com');
