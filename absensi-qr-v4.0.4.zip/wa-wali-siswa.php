<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
include 'wa_token.php';

$pesan_notif = $_SESSION['notif'] ?? "";
unset($_SESSION['notif']);

$role_session = $_SESSION['role'] ?? '';
$dashboardUrl = ($role_session === 'admin') ? 'dashboard.php' : 'dashboard_guru.php';

$username = "NISN";
$password = "NISN";

$qProfil = mysqli_query($conn, "SELECT nama_sekolah FROM profil_sekolah LIMIT 1");
$profil  = mysqli_fetch_assoc($qProfil);
$nama_sekolah = $profil['nama_sekolah'] ?? "Sekolah";

$pesanDefault = "Assalamualaikum Wr. Wb.\n\n" .
    "Username: " . $username . "\n" .
    "Password: " . $password . "\n\n" .
    "Mohon izin menginformasikan bahwa kami dari " . $nama_sekolah . " telah menggunakan teknologi absen digital " .
    "yang dapat dipantau secara langsung oleh Bapak/Ibu Orang Tua/Wali Siswa. " .
    "Mohon simpan nomor ini agar kami bisa mengirim informasi dengan lancar. Terima Kasih";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['kirim_waba'])) {
    $tujuan = trim($_POST['nomor_tujuan']);
    $isi_pesan = trim($_POST['isi_pesan']);

    if (empty($tujuan) || empty($isi_pesan)) {
        $_SESSION['notif'] = "<div class='alert alert-danger'>Nomor tujuan dan isi pesan tidak boleh kosong!</div>";
    } else {
        $hasil = kirimPesanWhatsApp($tujuan, $isi_pesan);
        if ($hasil['status']) {
            $_SESSION['notif'] = "<div class='alert alert-success'>Pesan berhasil dikirim via WABA Cloud API ke nomor {$tujuan}!</div>";
        } else {
            $err_msg = $hasil['response']['error']['message'] ?? json_encode($hasil['response']);
            $_SESSION['notif'] = "<div class='alert alert-danger'>Gagal mengirim: " . htmlspecialchars($err_msg) . "</div>";
        }
    }
    header("Location: wa-wali-siswa.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Kirim Informasi Absensi via WABA Cloud API</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --wa:#25D366;
      --wa-dark:#128C7E;
      --radius-xl:20px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-wa:0 14px 30px -14px rgba(37,211,102,.55);
    }

    *{box-sizing:border-box;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif !important;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 42%),
        radial-gradient(circle at 100% 100%, rgba(37,211,102,.06), transparent 42%),
        var(--bg) !important;
      min-height:100vh;
      color:var(--ink);
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
      padding:32px 0;
    }

    .page-shell{
      max-width:820px;
      margin:0 auto;
      padding:0 20px;
    }

    .top-nav{
      display:flex;
      align-items:center;
      gap:12px;
      margin-bottom:22px;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      border-radius:999px;
      font-size:13.5px;
      font-weight:500;
      text-decoration:none;
      box-shadow:var(--shadow-sm);
      transition:border-color .2s ease, color .2s ease, transform .2s ease, box-shadow .2s ease;
    }

    .btn-back i{
      font-size:11px;
      color:var(--muted);
      transition:color .2s ease, transform .2s ease;
    }

    .btn-back:hover{
      color:var(--ink);
      border-color:var(--line-strong);
      box-shadow:var(--shadow-md);
      transform:translateY(-1px);
    }

    .btn-back:hover i{
      color:var(--brand);
      transform:translateX(-2px);
    }

    .btn-back:focus-visible{
      outline:3px solid var(--brand-soft);
      outline-offset:2px;
    }

    .surface-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-xl);
      box-shadow:var(--shadow-lg);
      overflow:hidden;
      animation:fadeUp .5s ease both;
    }

    @keyframes fadeUp{
      from{opacity:0; transform:translateY(10px);}
      to{opacity:1; transform:translateY(0);}
    }

    .card-head{
      position:relative;
      padding:28px 32px 24px;
      border-bottom:1px solid var(--line);
      background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
    }

    .card-head::before{
      content:"";
      position:absolute;
      top:0;left:0;right:0;
      height:3px;
      background:linear-gradient(90deg, var(--wa), var(--wa-dark));
    }

    .eyebrow{
      display:inline-flex;
      align-items:center;
      gap:8px;
      font-size:11.5px;
      font-weight:600;
      letter-spacing:1.2px;
      text-transform:uppercase;
      color:var(--wa-dark);
      padding:5px 12px;
      border-radius:999px;
      background:rgba(37,211,102,.10);
      margin-bottom:14px;
    }

    .eyebrow i{
      font-size:12px;
    }

    .card-head h1{
      font-size:22px;
      font-weight:600;
      letter-spacing:-.3px;
      color:var(--ink);
      margin:0 0 6px;
      line-height:1.3;
    }

    .card-head p{
      font-size:13.5px;
      color:var(--muted);
      margin:0;
      line-height:1.55;
    }

    .card-body-inner{
      padding:28px 32px 32px;
    }

    .field{
      margin-bottom:20px;
    }

    .field-label{
      display:flex;
      align-items:center;
      gap:8px;
      font-size:13px;
      font-weight:500;
      color:var(--ink-2);
      margin-bottom:8px;
    }

    .field-label i{
      font-size:12px;
      color:var(--brand);
      width:14px;
      text-align:center;
    }

    .form-control{
      width:100%;
      padding:12px 15px;
      font-family:inherit;
      font-size:14.5px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      outline:none;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
      box-shadow:none;
    }

    .form-control::placeholder{
      color:var(--muted-2);
    }

    .form-control:hover{
      border-color:var(--line-strong);
    }

    .form-control:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    textarea.form-control{
      resize:vertical;
      min-height:180px;
      line-height:1.65;
      font-size:14px;
    }

    .form-control.mono{
      font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
      font-size:13.5px;
    }

    .hint{
      display:block;
      margin-top:7px;
      font-size:12px;
      color:var(--muted-2);
      line-height:1.5;
    }

    .btn-whatsapp{
      width:100%;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:10px;
      padding:14px 20px;
      font-family:inherit;
      font-size:15px;
      font-weight:600;
      letter-spacing:.2px;
      color:#fff !important;
      background:linear-gradient(135deg, var(--wa) 0%, var(--wa-dark) 100%) !important;
      border:none !important;
      border-radius:var(--radius-md);
      cursor:pointer;
      box-shadow:var(--shadow-wa);
      transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
      margin-top:6px;
    }

    .btn-whatsapp i{
      font-size:18px;
    }

    .btn-whatsapp:hover{
      transform:translateY(-2px);
      filter:brightness(1.05);
      box-shadow:0 20px 36px -16px rgba(37,211,102,.65);
    }

    .btn-whatsapp:active{
      transform:translateY(0);
    }

    .btn-whatsapp:focus-visible{
      outline:3px solid rgba(37,211,102,.35);
      outline-offset:3px;
    }

    .foot-note{
      margin-top:26px;
      padding:14px 16px;
      border-radius:var(--radius-md);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-left:3px solid var(--brand);
      display:flex;
      gap:12px;
      align-items:flex-start;
    }

    .foot-note i{
      color:var(--brand);
      font-size:14px;
      margin-top:2px;
      flex-shrink:0;
    }

    .foot-note p{
      margin:0;
      font-size:12.5px;
      color:var(--muted);
      line-height:1.6;
    }

    .alert{
      border-radius:var(--radius-md);
      border:1px solid transparent;
      padding:13px 16px;
      font-size:13.5px;
      font-weight:500;
      display:flex;
      align-items:flex-start;
      gap:10px;
      margin-bottom:22px;
      line-height:1.55;
      animation:fadeUp .35s ease both;
    }

    .alert-success{
      background:rgba(16,185,129,.08);
      border-color:rgba(16,185,129,.20);
      color:#047857;
    }

    .alert-danger{
      background:rgba(239,68,68,.08);
      border-color:rgba(239,68,68,.20);
      color:#b91c1c;
    }

    .alert::before{
      font-family:"Font Awesome 6 Free";
      font-weight:900;
      flex-shrink:0;
      margin-top:1px;
    }

    .alert-success::before{
      content:"\f058";
    }

    .alert-danger::before{
      content:"\f06a";
    }

    @media (max-width:768px){
      body{padding:20px 0;}
      .page-shell{padding:0 16px;}
      .card-head{padding:22px 22px 20px;}
      .card-head h1{font-size:19px;}
      .card-head p{font-size:12.5px;}
      .card-body-inner{padding:22px 22px 26px;}
      .eyebrow{font-size:10.5px;padding:4px 10px;}
      .field-label{font-size:12.5px;}
      .form-control{font-size:14px;padding:11px 14px;}
      textarea.form-control{min-height:160px;font-size:13px;}
      .btn-whatsapp{font-size:14.5px;padding:13px 18px;}
    }

    @media (max-width:480px){
      .page-shell{padding:0 12px;}
      .top-nav{margin-bottom:16px;}
      .btn-back{font-size:13px;padding:8px 14px;}
      .card-head{padding:20px 18px 18px;}
      .card-head h1{font-size:17px;}
      .card-body-inner{padding:20px 18px 22px;}
      .alert{font-size:12.5px;padding:11px 14px;}
      .foot-note{padding:12px 14px;}
      .foot-note p{font-size:12px;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>
  <div class="page-shell">
    <div class="top-nav">
      <a href="<?= htmlspecialchars($dashboardUrl) ?>" class="btn-back">
        <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
      </a>
    </div>

    <div class="surface-card">
      <div class="card-head">
        <span class="eyebrow">
          <i class="fab fa-whatsapp"></i> WABA Cloud API
        </span>
        <h1>Kirim Informasi Absensi</h1>
        <p>Kirim pesan WhatsApp resmi kepada orang tua/wali siswa melalui server Meta WhatsApp Business Account.</p>
      </div>

      <div class="card-body-inner">
        <?= $pesan_notif; ?>

        <form method="POST" action="">
          <div class="field">
            <label class="field-label" for="nomor_tujuan">
              <i class="fas fa-phone"></i> Nomor WhatsApp Orang Tua/Wali (Tujuan)
            </label>
            <input
              type="text"
              id="nomor_tujuan"
              name="nomor_tujuan"
              class="form-control"
              placeholder="Contoh: 6281234567890"
              required
            >
            <small class="hint">Gunakan format internasional tanpa tanda + atau spasi.</small>
          </div>

          <div class="field">
            <label class="field-label" for="isi_pesan">
              <i class="fas fa-comment-dots"></i> Isi Pesan WhatsApp
            </label>
            <textarea
              id="isi_pesan"
              name="isi_pesan"
              class="form-control mono"
              rows="8"
              required
            ><?php echo htmlspecialchars($pesanDefault); ?></textarea>
          </div>

          <button type="submit" name="kirim_waba" class="btn-whatsapp">
            <i class="fab fa-whatsapp"></i> Kirim Pesan Otomatis
          </button>
        </form>

        <div class="foot-note">
          <i class="fas fa-circle-info"></i>
          <p>Pesan akan dikirim secara otomatis melalui server Meta WhatsApp Business Account (WABA) yang telah dikonfigurasi di sistem.</p>
        </div>
      </div>
    </div>
  </div>
</body>
</html>