<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
include 'config.php';

$sql_table = "CREATE TABLE IF NOT EXISTS wali_kelas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  kelas VARCHAR(50) NOT NULL,
  nama_wali VARCHAR(100) NOT NULL,
  nip_wali VARCHAR(50)
)";
mysqli_query($conn, $sql_table);

$check_col = mysqli_query($conn, "SHOW COLUMNS FROM wali_kelas LIKE 'user_id'");
if ($check_col && mysqli_num_rows($check_col) == 0) {
    @mysqli_query($conn, "ALTER TABLE wali_kelas ADD user_id INT NULL AFTER id");
}

if (isset($_POST['tambah'])) {
    $user_id   = intval($_POST['user_id']);
    $kelas     = mysqli_real_escape_string($conn, $_POST['kelas']);
    $nip_wali  = mysqli_real_escape_string($conn, $_POST['nip_wali']);

    $qUser = mysqli_query($conn, "SELECT nama FROM users WHERE id = $user_id AND role = 'guru' LIMIT 1");
    $u = mysqli_fetch_assoc($qUser);
    if (!$u) {
        $_SESSION['swal'] = ['icon' => 'error', 'title' => 'Gagal!', 'text' => 'Guru tidak ditemukan.'];
        header("Location: wali_kelas.php");
        exit;
    }
    $nama_wali = mysqli_real_escape_string($conn, $u['nama']);

    $res = mysqli_query($conn, "INSERT INTO wali_kelas (user_id, kelas, nama_wali, nip_wali) VALUES ($user_id, '$kelas', '$nama_wali', '$nip_wali')");
    if ($res) {
        $_SESSION['swal'] = ['icon' => 'success', 'title' => 'Berhasil!', 'text' => 'Data wali kelas berhasil ditambahkan!'];
    } else {
        $_SESSION['swal'] = ['icon' => 'error', 'title' => 'Gagal!', 'text' => mysqli_error($conn)];
    }
    header("Location: wali_kelas.php");
    exit;
}

if (isset($_POST['edit'])) {
    $id        = intval($_POST['id']);
    $user_id   = intval($_POST['user_id']);
    $kelas     = mysqli_real_escape_string($conn, $_POST['kelas']);
    $nip_wali  = mysqli_real_escape_string($conn, $_POST['nip_wali']);

    $qUser = mysqli_query($conn, "SELECT nama FROM users WHERE id = $user_id AND role = 'guru' LIMIT 1");
    $u = mysqli_fetch_assoc($qUser);
    if (!$u) {
        $_SESSION['swal'] = ['icon' => 'error', 'title' => 'Gagal!', 'text' => 'Guru tidak ditemukan.'];
        header("Location: wali_kelas.php");
        exit;
    }
    $nama_wali = mysqli_real_escape_string($conn, $u['nama']);

    $res = mysqli_query($conn, "UPDATE wali_kelas SET user_id=$user_id, kelas='$kelas', nama_wali='$nama_wali', nip_wali='$nip_wali' WHERE id=$id");
    if ($res) {
        $_SESSION['swal'] = ['icon' => 'success', 'title' => 'Berhasil!', 'text' => 'Data wali kelas berhasil diperbarui!'];
    } else {
        $_SESSION['swal'] = ['icon' => 'error', 'title' => 'Gagal!', 'text' => mysqli_error($conn)];
    }
    header("Location: wali_kelas.php");
    exit;
}

if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM wali_kelas WHERE id=$id");
    $_SESSION['swal'] = ['icon' => 'success', 'title' => 'Terhapus!', 'text' => 'Data wali kelas berhasil dihapus.'];
    header("Location: wali_kelas.php");
    exit;
}

$waliList = mysqli_query($conn, "SELECT w.*, u.username, u.nama AS nama_user FROM wali_kelas w LEFT JOIN users u ON u.id = w.user_id ORDER BY w.kelas ASC");
$total_wali = $waliList ? mysqli_num_rows($waliList) : 0;

$guruList = mysqli_query($conn, "SELECT id, nama, username FROM users WHERE role='guru' ORDER BY nama ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kelola Wali Kelas</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    :root{
      --bg:#f6f8fb;
      --surface:#ffffff;
      --surface-2:#f9fafb;
      --line:#e8edf3;
      --line-strong:#dbe3ec;
      --ink:#0f172a;
      --ink-2:#334155;
      --muted:#64748b;
      --muted-2:#94a3b8;
      --brand:#2a5298;
      --brand-2:#1e3c72;
      --brand-soft:rgba(42,82,152,.08);
      --success:#10b981;
      --warning:#f59e0b;
      --danger:#ef4444;
      --radius-xl:20px;
      --radius-lg:16px;
      --radius-md:12px;
      --radius-sm:10px;
      --shadow-sm:0 1px 2px rgba(15,23,42,.05);
      --shadow-md:0 6px 16px -8px rgba(15,23,42,.12), 0 2px 6px -2px rgba(15,23,42,.06);
      --shadow-lg:0 18px 40px -18px rgba(15,23,42,.22), 0 8px 18px -10px rgba(15,23,42,.12);
      --shadow-brand:0 14px 30px -14px rgba(30,60,114,.55);
    }

    *{box-sizing:border-box;}
    html{scroll-behavior:smooth;}

    body{
      font-family:'Rubik', system-ui, -apple-system, "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background:
        radial-gradient(circle at 0% 0%, rgba(42,82,152,.06), transparent 40%),
        radial-gradient(circle at 100% 100%, rgba(255,176,32,.05), transparent 40%),
        var(--bg);
      min-height:100vh;
      color:var(--ink);
      margin:0;
      padding:32px 20px 56px;
      -webkit-font-smoothing:antialiased;
      -moz-osx-font-smoothing:grayscale;
    }

    .page-shell{max-width:1100px;margin:0 auto;}

    .top-nav{
      display:flex;
      align-items:center;
      justify-content:flex-end;
      gap:16px;
      margin-bottom:24px;
      flex-wrap:wrap;
    }

    .btn-back{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:9px 16px;
      background:var(--surface);
      color:var(--ink-2);
      border:1px solid var(--line);
      border-radius:999px;
      font-size:13.5px;
      font-weight:500;
      text-decoration:none;
      box-shadow:var(--shadow-sm);
      transition:border-color .2s ease, color .2s ease, transform .2s ease, box-shadow .2s ease;
    }

    .btn-back i{font-size:11px;color:var(--muted);transition:color .2s ease, transform .2s ease;}
    .btn-back:hover{color:var(--ink);border-color:var(--line-strong);box-shadow:var(--shadow-md);transform:translateY(-1px);}
    .btn-back:hover i{color:var(--brand);transform:translateX(-2px);}
    .btn-back:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .page-head{display:flex;flex-direction:column;gap:6px;margin-bottom:24px;}
    .page-eyebrow{font-size:11.5px;font-weight:600;letter-spacing:1.2px;text-transform:uppercase;color:var(--brand);}
    .page-head h1{font-size:26px;font-weight:600;letter-spacing:-.4px;color:var(--ink);margin:0;line-height:1.25;}
    .page-head p{margin:0;font-size:14px;color:var(--muted);line-height:1.55;}

    .stats-row{
      display:grid;
      grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));
      gap:16px;
      margin-bottom:22px;
    }

    .stat-card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-lg);
      padding:18px 20px;
      display:flex;
      align-items:center;
      gap:14px;
      box-shadow:var(--shadow-sm);
      animation:fadeUp .5s ease both;
    }

    .stat-icon{
      width:42px;
      height:42px;
      border-radius:var(--radius-md);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:16px;
      color:var(--brand);
      background:var(--brand-soft);
      flex-shrink:0;
    }

    .stat-info{display:flex;flex-direction:column;gap:2px;min-width:0;}
    .stat-label{font-size:12px;color:var(--muted);font-weight:500;letter-spacing:.2px;}
    .stat-value{font-size:20px;font-weight:600;color:var(--ink);letter-spacing:-.3px;line-height:1.2;}

    @keyframes fadeUp{
      from{opacity:0; transform:translateY(8px);}
      to{opacity:1; transform:translateY(0);}
    }

    .card{
      background:var(--surface);
      border:1px solid var(--line);
      border-radius:var(--radius-xl);
      box-shadow:var(--shadow-md);
      overflow:hidden;
      margin-bottom:22px;
      animation:fadeUp .5s ease both;
    }

    .card-head{
      position:relative;
      padding:20px 26px 18px;
      border-bottom:1px solid var(--line);
      background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
      display:flex;
      align-items:center;
      gap:14px;
    }

    .card-head::before{
      content:"";
      position:absolute;
      top:0;left:0;right:0;
      height:3px;
      background:linear-gradient(90deg, var(--brand), var(--brand-2));
    }

    .card-head-inner{display:flex;align-items:center;gap:14px;flex:1;min-width:0;}

    .card-icon{
      width:42px;
      height:42px;
      border-radius:var(--radius-md);
      display:flex;
      align-items:center;
      justify-content:center;
      font-size:16px;
      color:var(--brand);
      background:var(--brand-soft);
      flex-shrink:0;
    }

    .card-title{font-size:15.5px;font-weight:600;letter-spacing:-.2px;color:var(--ink);margin:0 0 2px;line-height:1.35;}
    .card-sub{font-size:12.5px;color:var(--muted);margin:0;line-height:1.5;}
    .card-body-inner{padding:22px 26px 26px;}

    .field-label{
      display:flex;
      align-items:center;
      gap:8px;
      font-size:12.5px;
      font-weight:500;
      color:var(--ink-2);
      margin-bottom:7px;
    }

    .field-label i{font-size:11px;color:var(--brand);width:14px;text-align:center;}

    .form-control,
    .form-select{
      width:100%;
      padding:11px 14px;
      font-family:inherit;
      font-size:14px;
      color:var(--ink);
      background:var(--surface-2);
      border:1px solid var(--line);
      border-radius:var(--radius-md);
      outline:none;
      transition:border-color .2s ease, box-shadow .2s ease, background .2s ease;
    }

    .form-control::placeholder{color:var(--muted-2);}
    .form-control:hover,
    .form-select:hover{border-color:var(--line-strong);}

    .form-control:focus,
    .form-select:focus{
      background:#fff;
      border-color:var(--brand);
      box-shadow:0 0 0 4px var(--brand-soft);
    }

    .btn-brand{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:9px;
      padding:11px 22px;
      font-family:inherit;
      font-size:14px;
      font-weight:600;
      letter-spacing:.2px;
      color:#fff;
      background:linear-gradient(135deg, var(--brand) 0%, var(--brand-2) 100%);
      border:none;
      border-radius:var(--radius-md);
      cursor:pointer;
      box-shadow:var(--shadow-brand);
      transition:transform .2s ease, box-shadow .2s ease, filter .2s ease;
    }

    .btn-brand i{font-size:12px;}
    .btn-brand:hover{transform:translateY(-2px);filter:brightness(1.08);box-shadow:0 20px 36px -16px rgba(30,60,114,.85);color:#fff;}
    .btn-brand:active{transform:translateY(0);}
    .btn-brand:focus-visible{outline:3px solid rgba(42,82,152,.35);outline-offset:3px;}

    .table-responsive{overflow-x:auto;-webkit-overflow-scrolling:touch;}

    .table{
      width:100%;
      margin:0;
      border-collapse:separate;
      border-spacing:0;
      font-size:13.5px;
      color:var(--ink-2);
    }

    .table thead th{
      padding:13px 16px;
      font-size:11.5px;
      font-weight:600;
      letter-spacing:.8px;
      text-transform:uppercase;
      color:var(--muted);
      background:var(--surface-2);
      border-bottom:1px solid var(--line);
      text-align:left;
      white-space:nowrap;
    }

    .table tbody td{
      padding:14px 16px;
      border-bottom:1px solid var(--line);
      vertical-align:middle;
      color:var(--ink-2);
    }

    .table tbody tr:last-child td{border-bottom:none;}
    .table tbody tr{transition:background .15s ease;}
    .table tbody tr:hover{background:var(--surface-2);}

    .badge-kelas{
      display:inline-flex;
      align-items:center;
      padding:4px 12px;
      border-radius:999px;
      font-size:12px;
      font-weight:600;
      color:var(--brand);
      background:var(--brand-soft);
      border:1px solid rgba(42,82,152,.15);
      letter-spacing:.2px;
    }

    .badge-guru{
      display:inline-flex;
      align-items:center;
      padding:4px 12px;
      border-radius:999px;
      font-size:12px;
      font-weight:600;
      color:#047857;
      background:rgba(16,185,129,.10);
      border:1px solid rgba(16,185,129,.20);
    }

    .badge-unlinked{
      display:inline-flex;
      align-items:center;
      padding:4px 12px;
      border-radius:999px;
      font-size:12px;
      font-weight:600;
      color:#b91c1c;
      background:rgba(239,68,68,.08);
      border:1px solid rgba(239,68,68,.20);
    }

    .text-name{font-weight:500;color:var(--ink);}
    .text-mono{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;font-size:13px;color:var(--muted);}

    .action-group{display:inline-flex;gap:8px;align-items:center;}

    .btn-action{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:6px;
      padding:7px 13px;
      font-family:inherit;
      font-size:12.5px;
      font-weight:500;
      border-radius:var(--radius-sm);
      border:1px solid transparent;
      cursor:pointer;
      text-decoration:none;
      transition:background .2s ease, color .2s ease, border-color .2s ease, transform .2s ease;
      white-space:nowrap;
    }

    .btn-action i{font-size:11px;}

    .btn-edit{color:#b45309;background:rgba(245,158,11,.10);border-color:rgba(245,158,11,.22);}
    .btn-edit:hover{background:rgba(245,158,11,.18);color:#92400e;border-color:rgba(245,158,11,.35);transform:translateY(-1px);}

    .btn-delete{color:#b91c1c;background:rgba(239,68,68,.08);border-color:rgba(239,68,68,.20);}
    .btn-delete:hover{background:rgba(239,68,68,.16);color:#991b1b;border-color:rgba(239,68,68,.32);transform:translateY(-1px);}

    .btn-action:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .empty-state{text-align:center;padding:60px 20px;color:var(--muted);}
    .empty-state i{font-size:38px;color:var(--muted-2);opacity:.55;display:block;margin-bottom:14px;}
    .empty-state strong{display:block;font-size:15px;font-weight:600;color:var(--ink-2);margin-bottom:6px;}
    .empty-state span{font-size:13px;line-height:1.55;}

    .modal-content{border:none;border-radius:var(--radius-xl);box-shadow:var(--shadow-lg);overflow:hidden;}

    .modal-header{
      padding:20px 24px 16px;
      border-bottom:1px solid var(--line);
      background:linear-gradient(180deg, #fbfcfe 0%, #ffffff 100%);
      position:relative;
    }

    .modal-header::before{
      content:"";
      position:absolute;
      top:0;left:0;right:0;
      height:3px;
      background:linear-gradient(90deg, var(--brand), var(--brand-2));
    }

    .modal-title{
      font-size:16px;
      font-weight:600;
      color:var(--ink);
      letter-spacing:-.2px;
      display:flex;
      align-items:center;
      gap:10px;
    }

    .modal-title i{color:var(--brand);font-size:15px;}
    .modal-header .btn-close{opacity:.5;transition:opacity .2s ease;}
    .modal-header .btn-close:hover{opacity:1;}
    .modal-body{padding:22px 24px;}
    .modal-footer{padding:16px 24px;border-top:1px solid var(--line);background:var(--surface-2);gap:10px;}

    .btn-soft{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      padding:10px 18px;
      font-family:inherit;
      font-size:13.5px;
      font-weight:500;
      color:var(--ink-2);
      background:#fff;
      border:1px solid var(--line);
      border-radius:var(--radius-sm);
      cursor:pointer;
      transition:background .2s ease, border-color .2s ease, color .2s ease;
    }

    .btn-soft:hover{background:var(--surface-2);border-color:var(--line-strong);color:var(--ink);}
    .btn-soft:focus-visible{outline:3px solid var(--brand-soft);outline-offset:2px;}

    .hint{
      display:block;
      margin-top:7px;
      font-size:12px;
      color:var(--muted-2);
      line-height:1.5;
    }

    .info-banner{
      display:flex;
      align-items:flex-start;
      gap:12px;
      padding:14px 18px;
      border-radius:var(--radius-md);
      background:rgba(59,130,246,.08);
      border:1px solid rgba(59,130,246,.20);
      border-left:4px solid #3b82f6;
      color:#1e40af;
      font-size:13px;
      line-height:1.65;
      margin-bottom:20px;
    }

    .info-banner i{margin-top:2px;font-size:15px;flex-shrink:0;color:#3b82f6;}
    .info-banner strong{font-weight:600;color:#1d4ed8;}

    @media (max-width:768px){
      body{padding:22px 14px 40px;}
      .page-head h1{font-size:22px;}
      .card-head{padding:18px 20px 16px;}
      .card-body-inner{padding:18px 20px 22px;}
      .card-icon{width:38px;height:38px;font-size:14px;}
      .card-title{font-size:14.5px;}
      .stat-card{padding:15px 16px;}
      .stat-icon{width:38px;height:38px;font-size:14px;}
      .stat-value{font-size:18px;}
      .table{font-size:13px;}
      .table thead th{padding:11px 12px;font-size:10.5px;}
      .table tbody td{padding:12px 12px;}
      .btn-action{padding:6px 10px;font-size:12px;}
      .btn-action span{display:none;}
    }

    @media (max-width:480px){
      body{padding:16px 10px 32px;}
      .page-head h1{font-size:19px;}
      .page-eyebrow{font-size:10.5px;}
      .card-head{padding:16px 16px 14px;}
      .card-body-inner{padding:16px 16px 20px;}
      .btn-brand{width:100%;padding:12px 18px;font-size:13.5px;}
      .action-group{flex-direction:column;gap:6px;width:100%;}
      .btn-action{width:100%;justify-content:center;}
      .btn-action span{display:inline;}
    }

    @media (prefers-reduced-motion:reduce){
      *{animation:none !important;transition:none !important;}
    }
  </style>
</head>
<body>
  <div class="page-shell">
    <div class="top-nav">
      <a href="dashboard.php" class="btn-back">
        <i class="fas fa-arrow-left"></i> Kembali
      </a>
    </div>

    <div class="page-head">
      <span class="page-eyebrow">Data Master</span>
      <h1>Manajemen Wali Kelas</h1>
      <p>Tugaskan setiap guru menjadi wali kelas. Guru hanya akan melihat siswa di kelas yang diampu.</p>
    </div>

    <div class="info-banner">
      <i class="fas fa-circle-info"></i>
      <div>
        <strong>Info:</strong> Pilih guru dari daftar, lalu tentukan kelas yang diampu. Sistem akan otomatis memfilter tampilan siswa sesuai kelas guru tersebut.
      </div>
    </div>

    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-icon"><i class="fas fa-chalkboard-teacher"></i></div>
        <div class="stat-info">
          <span class="stat-label">Total Wali Kelas</span>
          <span class="stat-value"><?= $total_wali; ?></span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-head-inner">
          <div class="card-icon"><i class="fas fa-user-plus"></i></div>
          <div>
            <h2 class="card-title">Tambah Wali Kelas</h2>
            <p class="card-sub">Pilih guru dan tentukan kelas yang diampu.</p>
          </div>
        </div>
      </div>
      <div class="card-body-inner">
        <form method="post">
          <div class="row g-3 mb-3">
            <div class="col-12 col-md-4">
              <label class="field-label" for="user_id_tambah">
                <i class="fas fa-chalkboard-user"></i> Pilih Guru
              </label>
              <select id="user_id_tambah" name="user_id" class="form-select" required>
                <option value="">— Pilih Guru —</option>
                <?php
                if ($guruList && mysqli_num_rows($guruList) > 0) {
                    mysqli_data_seek($guruList, 0);
                    while ($g = mysqli_fetch_assoc($guruList)) {
                        echo "<option value='{$g['id']}'>" . htmlspecialchars($g['nama']) . " (@" . htmlspecialchars($g['username']) . ")</option>";
                    }
                }
                ?>
              </select>
            </div>
            <div class="col-12 col-md-3">
              <label class="field-label" for="kelas_tambah">
                <i class="fas fa-door-open"></i> Kelas
              </label>
              <input type="text" id="kelas_tambah" name="kelas" class="form-control" placeholder="Misal: VII-A" required>
            </div>
            <div class="col-12 col-md-5">
              <label class="field-label" for="nip_wali_tambah">
                <i class="fas fa-id-badge"></i> NIP Wali
              </label>
              <input type="text" id="nip_wali_tambah" name="nip_wali" class="form-control" placeholder="NIP (untuk cetak laporan)">
              <small class="hint">NIP dipakai di tanda tangan laporan cetak/PDF.</small>
            </div>
          </div>
          <button type="submit" name="tambah" class="btn-brand">
            <i class="fas fa-plus"></i> Tugaskan Wali Kelas
          </button>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-head">
        <div class="card-head-inner">
          <div class="card-icon"><i class="fas fa-list-ul"></i></div>
          <div>
            <h2 class="card-title">Daftar Wali Kelas</h2>
            <p class="card-sub"><?= $total_wali; ?> data wali kelas terdaftar.</p>
          </div>
        </div>
      </div>
      <div class="card-body-inner p-0">
        <div class="table-responsive">
          <table class="table">
            <thead>
              <tr>
                <th width="6%">No</th>
                <th>Kelas</th>
                <th>Nama Wali</th>
                <th>Akun User</th>
                <th>NIP</th>
                <th width="20%">Aksi</th>
              </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            if ($waliList && mysqli_num_rows($waliList) > 0) {
                while ($row = mysqli_fetch_assoc($waliList)) {
                    ?>
                    <tr>
                      <td><?= $no; ?></td>
                      <td><span class="badge-kelas"><?= htmlspecialchars($row['kelas']); ?></span></td>
                      <td><span class="text-name"><?= htmlspecialchars($row['nama_wali']); ?></span></td>
                      <td>
                        <?php if (!empty($row['username'])): ?>
                          <span class="badge-guru"><i class="fas fa-check-circle" style="font-size:10px;margin-right:4px;"></i>@<?= htmlspecialchars($row['username']); ?></span>
                        <?php else: ?>
                          <span class="badge-unlinked"><i class="fas fa-unlink" style="font-size:10px;margin-right:4px;"></i>Belum terhubung</span>
                        <?php endif; ?>
                      </td>
                      <td><span class="text-mono"><?= htmlspecialchars($row['nip_wali']); ?></span></td>
                      <td>
                        <div class="action-group">
                          <button class="btn-action btn-edit" data-bs-toggle="modal" data-bs-target="#editModal<?= $row['id']; ?>">
                            <i class="fas fa-pen"></i> <span>Edit</span>
                          </button>
                          <a href="wali_kelas.php?hapus=<?= $row['id']; ?>" class="btn-action btn-delete" onclick="return confirm('Yakin hapus data ini?')">
                            <i class="fas fa-trash"></i> <span>Hapus</span>
                          </a>
                        </div>
                      </td>
                    </tr>
                    <?php
                    $no++;
                }
            } else {
                echo "<tr><td colspan='6'>";
                echo "<div class='empty-state'>";
                echo "<i class='fas fa-inbox'></i>";
                echo "<strong>Belum ada data wali kelas</strong>";
                echo "<span>Tambahkan data wali kelas melalui form di atas.</span>";
                echo "</div>";
                echo "</td></tr>";
            }
            ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

  <?php
  if ($waliList && mysqli_num_rows($waliList) > 0) {
      mysqli_data_seek($waliList, 0);
      while ($row = mysqli_fetch_assoc($waliList)) {
          ?>
          <div class="modal fade" id="editModal<?= $row['id']; ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <form method="post">
                  <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-pen-to-square"></i> Edit Wali Kelas</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <input type="hidden" name="id" value="<?= $row['id']; ?>">
                    <div class="mb-3">
                      <label class="field-label" for="user_id_<?= $row['id']; ?>">
                        <i class="fas fa-chalkboard-user"></i> Guru
                      </label>
                      <select id="user_id_<?= $row['id']; ?>" name="user_id" class="form-select" required>
                        <option value="">— Pilih Guru —</option>
                        <?php
                        mysqli_data_seek($guruList, 0);
                        while ($g = mysqli_fetch_assoc($guruList)) {
                            $sel = ($g['id'] == $row['user_id']) ? 'selected' : '';
                            echo "<option value='{$g['id']}' $sel>" . htmlspecialchars($g['nama']) . " (@" . htmlspecialchars($g['username']) . ")</option>";
                        }
                        ?>
                      </select>
                    </div>
                    <div class="mb-3">
                      <label class="field-label" for="kelas_<?= $row['id']; ?>">
                        <i class="fas fa-door-open"></i> Kelas
                      </label>
                      <input type="text" id="kelas_<?= $row['id']; ?>" name="kelas" class="form-control" value="<?= htmlspecialchars($row['kelas']); ?>" required>
                    </div>
                    <div class="mb-0">
                      <label class="field-label" for="nip_wali_<?= $row['id']; ?>">
                        <i class="fas fa-id-badge"></i> NIP Wali
                      </label>
                      <input type="text" id="nip_wali_<?= $row['id']; ?>" name="nip_wali" class="form-control" value="<?= htmlspecialchars($row['nip_wali']); ?>">
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn-soft" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="edit" class="btn-brand">
                      <i class="fas fa-check"></i> Simpan Perubahan
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <?php
      }
  }
  ?>

  <?php if (isset($_SESSION['swal'])): ?>
    <script>
      Swal.fire({
        icon: '<?= $_SESSION['swal']['icon']; ?>',
        title: '<?= $_SESSION['swal']['title']; ?>',
        text: '<?= $_SESSION['swal']['text']; ?>',
        confirmButtonColor: '#2a5298'
      });
    </script>
    <?php unset($_SESSION['swal']); ?>
  <?php endif; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>