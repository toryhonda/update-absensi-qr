# Changelog

## [4.02] - 2026-09-13
- Perbaikan bug pada halaman Import Excel (siswa & guru)
- Tombol download template diarahkan ke folder `template/`
- Notifikasi error import lebih detail
- Perbaikan handling kolom kosong pada file Excel
- Redesain halaman import dengan gaya SaaS modern
- Update warna brand dan tipografi Rubik

## [4.00] - 2026-01-01
- Rilis awal versi jual
- Fitur scan QR webcam + scanner eksternal
- Integrasi WhatsApp Cloud API (WABA)
- Export PDF & Excel