# Sistem Absensi QR

Aplikasi absensi sekolah berbasis QR Code dengan integrasi WhatsApp Cloud API dan rekap PDF/Excel otomatis.

## Fitur

- Scan QR Code siswa via webcam atau scanner eksternal
- Notifikasi WhatsApp otomatis ke orang tua/wali
- Rekap absensi harian, bulanan, dan per kelas
- Export PDF & Excel
- Manajemen data siswa, guru, dan wali kelas
- Login multi-role (admin & guru)
- Jam sesi absensi fleksibel (masuk, sholat, pulang)
- Kartu QR siswa siap cetak
- Backup & restore database

## Spesifikasi Server

- PHP 7.4 atau lebih baru (disarankan PHP 8.0+)
- MySQL 5.7+ / MariaDB 10.3+
- Ekstensi: mysqli, curl, gd
- HTTPS (wajib untuk akses kamera browser)

## Instalasi

1. Upload semua file ke folder hosting atau `htdocs`.
2. Buat database baru di phpMyAdmin.
3. Import file `database.sql` ke database tersebut.
4. Rename `config.example.php` menjadi `config.php`.
5. Edit `config.php` sesuai kredensial database Anda.
6. Buka browser dan akses aplikasi.
7. Login dengan akun default:
   - Username: `admin`
   - Password: `admin`
8. Segera ubah password default.
9. Lengkapi profil sekolah di menu **Profil Sekolah**.
10. Konfigurasi WhatsApp API di menu **Pengaturan Key API WA** (opsional).

## Struktur Folder

├── assets/
├── fpdf/
├── uploads/
├── vendor/
├── config.example.php
├── database.sql
├── index.php
├── dashboard.php
├── dashboard_guru.php
└── ...


## Changelog

Lihat file `CHANGELOG.md`.

## Support

Email: tory@autowebportal.com
WhatsApp: 089654630099

## Lisensi

Commercial Single License. Lihat file `LICENSE.txt`.