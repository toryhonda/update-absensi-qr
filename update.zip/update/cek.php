<?php
session_start();
include 'config.php';

$user = mysqli_real_escape_string($conn, $_POST['username'] ?? '');
$pass = trim($_POST['password'] ?? '');
$pass_md5 = md5($pass);

// 1. Cek ke tabel `users` utama (Admin / Role umum)[cite: 7]
$q = mysqli_query($conn, "SELECT * FROM users WHERE username='$user' AND password='$pass_md5' LIMIT 1");

if ($q && mysqli_num_rows($q) > 0) {
    $data = mysqli_fetch_assoc($q);

    $_SESSION['username'] = $user;
    $_SESSION['role'] = $data['role'];

    if ($data['role'] === 'admin') {
        header("Location: dashboard.php");
    } elseif ($data['role'] === 'guru') {
        header("Location: dashboard_guru.php");
    } elseif ($data['role'] === 'siswa') {
        $qSiswa = mysqli_query($conn, "SELECT id FROM siswa WHERE nisn='$user' LIMIT 1");
        if ($rowSiswa = mysqli_fetch_assoc($qSiswa)) {
            $_SESSION['siswa_id'] = $rowSiswa['id'];
        } else {
            $_SESSION['login_error'] = "Data siswa tidak ditemukan. Hubungi admin.";
            header("Location: index.php");
            exit;
        }
        header("Location: dashboard_siswa.php");
    } else {
        $_SESSION['login_error'] = "Role tidak dikenali";
        header("Location: index.php");
    }
    exit;
}

// 2. Cek ke tabel `users_guru` khusus guru[cite: 7]
$q_guru = mysqli_query($conn, "SELECT * FROM users_guru WHERE username='$user' AND password='$pass_md5' LIMIT 1");
if ($q_guru && mysqli_num_rows($q_guru) > 0) {
    $data_guru = mysqli_fetch_assoc($q_guru);

    $_SESSION['username'] = $data_guru['username'];
    $_SESSION['role'] = 'guru';

    header("Location: dashboard_guru.php");
    exit;
}

// 3. Cek langsung ke tabel `guru` (jika password cocok dengan NIP)[cite: 7]
$q_guru_direct = mysqli_query($conn, "SELECT * FROM guru WHERE nip='$user' AND status='aktif' LIMIT 1");
if ($q_guru_direct && mysqli_num_rows($q_guru_direct) > 0) {
    $data_gd = mysqli_fetch_assoc($q_guru_direct);
    
    if ($pass_md5 === md5($data_gd['nip'])) {
        $_SESSION['username'] = $data_gd['nip'];
        $_SESSION['role'] = 'guru';

        @mysqli_query($conn, "INSERT IGNORE INTO users_guru (username, nama, password, role) VALUES ('{$data_gd['nip']}', '{$data_gd['nama']}', '$pass_md5', 'guru')");

        header("Location: dashboard_guru.php");
        exit;
    }
}

// Jika gagal, simpan pesan error ke session dan kembalikan ke index.php
$_SESSION['login_error'] = "Username atau password salah!";
header("Location: index.php");
exit;
?>