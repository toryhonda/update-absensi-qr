<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';
$currentVersion = "4.0.0"; // Versi yang sedang berjalan di server Anda

// Ambil file version.json langsung dari server PHP (bypass CORS browser)
$json_url = "https://raw.githubusercontent.com/toryhonda/update-absensi-qr/main/version.json";
$remote_data = @file_get_contents($json_url);
$data = $remote_data ? json_decode($remote_data, true) : null;

$latestVersion = $data['version'] ?? null;
$updateUrl = $data['url'] ?? '#';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Cek Update Aplikasi</title>
  <!-- Google Fonts Rubik -->
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Rubik', sans-serif !important;
      margin: 0;
      padding: 0;
      background: #f4f6f9;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .container {
      background: #fff;
      padding: 25px;
      max-width: 400px;
      width: 90%;
      text-align: center;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    h2 {
      margin-bottom: 15px;
      color: #333;
      font-size: 20px;
    }
    p {
      font-size: 15px;
      color: #555;
      margin-bottom: 20px;
    }
    .btn {
      display: inline-block;
      padding: 10px 20px;
      font-size: 15px;
      border-radius: 6px;
      text-decoration: none;
      transition: 0.3s;
      cursor: pointer;
      font-weight: 500;
    }
    .btn-update {
      background: #28a745;
      color: #fff;
    }
    .btn-update:hover {
      background: #218838;
    }
    .btn-ok {
      background: #007bff;
      color: #fff;
    }
    .btn-ok:hover {
      background: #0069d9;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Cek Versi Aplikasi</h2>
    <div id="status">
      <?php if (!$latestVersion): ?>
        <p style="color:red; font-size:14px;">Gagal mengecek update dari GitHub!<br><small style="color:#666;">Pastikan file version.json sudah ada dan akses internet server aktif.</small></p>
        <a class="btn btn-ok" href="dashboard.php">Kembali</a>
      <?php elseif (version_compare($latestVersion, $currentVersion, '>')): ?>
        <p>Versi baru tersedia: <b><?= htmlspecialchars($latestVersion) ?></b></p>
        <a id="btnUpdate" class="btn btn-update" href="update_aplikasi.php?file=<?= urlencode($updateUrl) ?>">Update Sekarang</a>
      <?php else: ?>
        <p>Aplikasi sudah versi terbaru <b>(<?= htmlspecialchars($currentVersion) ?>)</b></p>
        <a class="btn btn-ok" href="dashboard.php">Kembali</a>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>