<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';
// install_dompdf.php
echo "Menginstall DomPDF...<br>";

// URL download DomPDF
$dompdfUrl = 'https://github.com/dompdf/dompdf/releases/download/v2.0.3/dompdf_2-0-3.zip';
$zipFile = 'dompdf.zip';
$extractPath = 'dompdf';

// Download DomPDF
echo "Mendownload DomPDF...<br>";
$fileContent = file_get_contents($dompdfUrl);
if ($fileContent === FALSE) {
    die("Gagal mendownload DomPDF. Coba manual download dari: https://github.com/dompdf/dompdf/releases");
}

file_put_contents($zipFile, $fileContent);
echo "Download selesai.<br>";

// Extract zip
echo "Mengekstrak file...<br>";
$zip = new ZipArchive;
if ($zip->open($zipFile) === TRUE) {
    // Buat folder dompdf jika belum ada
    if (!file_exists($extractPath)) {
        mkdir($extractPath, 0777, true);
    }
    
    $zip->extractTo($extractPath);
    $zip->close();
    echo "Ekstraksi selesai.<br>";
    
    // Hapus file zip
    unlink($zipFile);
    echo "File zip dihapus.<br>";
    
    echo "<h3 style='color: green;'>Dompdf berhasil diinstall!</h3>";
    echo "Folder: " . realpath($extractPath);
    echo "<br><br><a href='cetak_absen_guru.php'>Kembali ke Rekap Absensi</a>";
} else {
    echo "Gagal mengekstrak file. Silakan extract manual file dompdf.zip ke folder dompdf/";
}
?>