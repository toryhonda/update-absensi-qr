<?php
// Base URL Aplikasi
define('BASE_URL', 'https://absensi.rafazmalik.my.id/');

// Pengaturan zona waktu
date_default_timezone_set('Asia/Jakarta');

// Kredensial Database
$host = 'localhost';
$user = 'absensi';
$pass = 'sastiarya240303';
$dbname = 'absensi';

// Koneksi ke database
$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Set karakter encoding
mysqli_set_charset($conn, "utf8mb4");