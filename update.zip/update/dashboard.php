<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

include 'config.php';
$username_session = $_SESSION['username'];
$q_user = mysqli_query($conn, "SELECT nama FROM users WHERE username='$username_session' LIMIT 1");
$data_user = mysqli_fetch_assoc($q_user);
$nama_admin = $data_user['nama'] ?? $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Admin Absensi QR</title>
  <!-- Google Fonts Rubik -->
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Font Awesome Free CDN -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    :root {
      --primary: #4361ee;
      --secondary: #3a0ca3;
      --accent: #f72585;
      --success: #4cc9f0;
      --info: #7209b7;
      --warning: #f9c74f;
      --danger: #f94144;
      --dark: #2b2d42;
      --light: #f8f9fa;
      --card-bg: #ffffff;
      --text-primary: #2b2d42;
      --text-secondary: #6c757d;
      --gradient-primary: linear-gradient(135deg, #4361ee 0%, #3a0ca3 100%);
      --gradient-accent: linear-gradient(135deg, #f72585 0%, #b5179e 100%);
      --shadow: 0 10px 20px rgba(0,0,0,0.12);
      --shadow-hover: 0 15px 30px rgba(0,0,0,0.2);
    }
    
    * { margin: 0; padding: 0; box-sizing: border-box; }
    
    body {
      font-family: 'Rubik', sans-serif;
      background: linear-gradient(135deg, #f5f7fa 0%, #e2e8f0 100%);
      min-height: 100vh;
      overflow-x: hidden;
      color: var(--text-primary);
    }

    .notification-bar {
      background: var(--gradient-accent);
      color: white;
      padding: 15px 0;
      text-align: center;
      box-shadow: var(--shadow);
      position: relative;
      z-index: 10;
      overflow: hidden;
    }

    .notification-text {
      display: inline-block;
      padding-left: 100%;
      white-space: nowrap;
      animation: marquee 25s linear infinite;
      font-weight: bold;
      font-size: 18px;
      text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
      letter-spacing: 0.5px;
    }

    .notification-text i {
      margin-right: 12px;
      font-size: 20px;
      color: #ffdd00;
    }

    @keyframes marquee {
      0%   { transform: translateX(0); }
      100% { transform: translateX(-100%); }
    }

    header {
      background: var(--gradient-primary);
      color: white;
      padding: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: var(--shadow);
      position: relative;
      z-index: 10;
    }
    
    header h1 {
      font-size: 2.2rem;
      margin-bottom: 5px;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
    }
    
    .user-info {
      font-size: 0.9rem;
      opacity: 0.9;
    }

    /* Profil Dropdown Pojok Kanan Atas */
    .user-profile-menu {
      position: relative;
      display: inline-block;
    }
    .profile-btn {
      display: flex;
      align-items: center;
      gap: 10px;
      background: rgba(255, 255, 255, 0.2);
      padding: 6px 14px;
      border-radius: 30px;
      cursor: pointer;
      color: white;
      font-weight: bold;
      text-decoration: none;
      transition: background 0.3s;
    }
    .profile-btn:hover { background: rgba(255, 255, 255, 0.3); }
    .profile-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: #fff;
      color: var(--primary);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      font-weight: bold;
    }
    .dropdown-content {
      display: none;
      position: absolute;
      right: 0;
      top: 100%;
      padding-top: 8px;
      min-width: 180px;
      z-index: 10;
    }
    .dropdown-box {
      background-color: #fff;
      box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
      border-radius: 8px;
      overflow: hidden;
    }
    .dropdown-content a {
      color: #333;
      padding: 12px 16px;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
    }
    .dropdown-content a:hover { background-color: #f1f1f1; }
    .user-profile-menu:hover .dropdown-content { display: block; }

    h2 {
      margin: 25px 0 15px 0;
      text-align: center;
      color: var(--dark);
      font-size: 1.8rem;
      position: relative;
      display: inline-block;
      left: 50%;
      transform: translateX(-50%);
    }
    
    h2:after {
      content: '';
      display: block;
      width: 50px;
      height: 3px;
      background: var(--accent);
      margin: 8px auto;
      border-radius: 2px;
    }

    .dashboard-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
      position: relative;
      z-index: 5;
    }

    .search-container {
      max-width: 500px;
      margin: 0 auto 30px auto;
      position: relative;
    }

    .search-input {
      width: 100%;
      padding: 12px 20px 12px 45px;
      font-size: 1rem;
      font-family: 'Rubik', sans-serif;
      border: 2px solid #cbd5e1;
      border-radius: 4px;
      outline: none;
      transition: all 0.3s ease;
      background: white;
    }

    .search-input:focus {
      border-color: var(--primary);
      box-shadow: 0 4px 12px rgba(67, 97, 238, 0.15);
    }

    .search-icon {
      position: absolute;
      top: 50%;
      left: 18px;
      transform: translateY(-50%);
      color: var(--text-secondary);
      font-size: 1.1rem;
    }

    .menu-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
      gap: 20px;
      margin: 0 auto;
    }

    .menu-card {
      background: var(--card-bg);
      border-radius: 4px;
      overflow: hidden;
      box-shadow: var(--shadow);
      transition: all 0.3s ease;
      position: relative;
      height: 100%;
      display: flex;
      flex-direction: column;
      border: 1px solid rgba(0,0,0,0.05);
    }
    
    .menu-card:hover {
      transform: translateY(-10px) scale(1.03);
      box-shadow: var(--shadow-hover);
    }
    
    .menu-card:before {
      content: '';
      position: absolute;
      top: 0; left: 0;
      width: 100%; height: 5px;
      background: var(--card-color, var(--primary));
    }
    
    .card-content {
      padding: 20px;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    
    .card-icon {
      font-size: 2.5rem;
      margin-bottom: 15px;
      color: var(--card-color, var(--primary));
      text-align: center;
    }
    
    .card-title {
      font-size: 1.1rem;
      font-weight: 600;
      margin-bottom: 10px;
      text-align: center;
      color: var(--text-primary);
    }
    
    .card-desc {
      font-size: 0.85rem;
      color: var(--text-secondary);
      text-align: center;
      margin-bottom: 15px;
      line-height: 1.4;
    }
    
    .card-button {
      display: block;
      text-align: center;
      padding: 10px;
      background: var(--card-color, var(--primary));
      color: white;
      text-decoration: none;
      border-radius: 6px;
      font-weight: 500;
      transition: all 0.2s ease;
      margin-top: auto;
    }
    
    .card-button:hover {
      background: var(--card-dark, var(--secondary));
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    footer {
      margin-top: 40px;
      background: var(--dark);
      color: white;
      text-align: center;
      padding: 15px;
      font-size: 14px;
    }
    
    @media (max-width: 768px) {
      header { flex-direction: column; gap: 15px; text-align: center; }
      .menu-grid { grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); }
      header h1 { font-size: 1.8rem; }
    }
  </style>
</head>
<body>
  <div class="notification-bar">
    <div class="notification-text">
      <i class="fas fa-bullhorn"></i> فَمَنْ يَّعْمَلْ مِثْقَالَ ذَرَّةٍ خَيْرًا يَّرَهٗۚ ۝٧ Siapa yang mengerjakan kebaikan seberat zarah, dia akan melihat (balasan)-nya.Az-Zalzalah.Ayat 7
    </div>
  </div>

  <header>
    <div>
      <h1>Dashboard Admin</h1>
      <div class="user-info">Selamat datang, <b><?php echo htmlspecialchars($nama_admin); ?></b> | Role: <?php echo $_SESSION['role']; ?></div>
    </div>

    <div class="user-profile-menu">
      <div class="profile-btn">
        <div class="profile-avatar"><i class="fa-solid fa-user"></i></div>
        <span><?php echo htmlspecialchars($nama_admin); ?> <i class="fa-solid fa-caret-down"></i></span>
      </div>
      <div class="dropdown-content">
        <div class="dropdown-box">
          <a href="profil_admin.php"><i class="fa-solid fa-user-pen"></i> Pengaturan Akun</a>
          <a href="logout.php" style="color: red;"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
      </div>
    </div>
  </header>

  <div class="dashboard-container">
    <h2>Menu Utama</h2>

    <div class="search-container">
      <i class="fas fa-search search-icon"></i>
      <input type="text" id="searchMenu" class="search-input" placeholder="Cari menu (misal: siswa, rekap, sholat, wa, jam)" onkeyup="filterMenu()">
    </div>
    
    <div class="menu-grid" id="menuGrid">
      <div class="menu-card" style="--card-color: #25a244; --card-dark: #1b4332;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-chalkboard-teacher"></i></div>
          <div class="card-title">Data Guru</div>
          <div class="card-desc">Kelola data guru, NIP, mata pelajaran, dan barcode</div>
          <a href="guru.php" class="card-button">Akses Menu</a>
        </div>
      </div>

      <div class="menu-card" style="--card-color: #7209b7; --card-dark: #560bad;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-chart-column"></i></div>
          <div class="card-title">Rekap Kehadiran Guru</div>
          <div class="card-desc">Lihat rekap kehadiran guru per periode</div>
          <a href="rekap_guru.php" class="card-button">Akses Menu</a>
        </div>
      </div>

      <div class="menu-card" style="--card-color: #4361ee; --card-dark: #3a0ca3;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-user-graduate"></i></div>
          <div class="card-title">Data Siswa</div>
          <div class="card-desc">Kelola data siswa, NIS, NISN, kelas, dan kontak</div>
          <a href="siswa.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #3a0ca3; --card-dark: #480ca8;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-qrcode"></i></div>
          <div class="card-title">SCAN QR + WA API OTOMATIS</div>
          <div class="card-desc">Scan QR dengan notifikasi WhatsApp otomatis</div>
          <a href="scan_wa_api.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #f72585; --card-dark: #b5179e;">
        <div class="card-content">
          <div class="card-icon"><i class="fab fa-whatsapp"></i></div>
          <div class="card-title">Pengaturan Key API WA</div>
          <div class="card-desc">Kelola kunci API untuk integrasi WhatsApp</div>
          <a href="wa_token.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #f94144; --card-dark: #f3722c;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-user"></i></div>
          <div class="card-title">Siswa Belum Hadir</div>
          <div class="card-desc">Lihat daftar siswa yang belum melakukan absensi</div>
          <a href="belum_absensi.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #4361ee; --card-dark: #3a0ca3;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-clipboard-check"></i></div>
          <div class="card-title">Isi S/I/A</div>
          <div class="card-desc">Input data Sakit, Izin, atau Alpha untuk siswa</div>
          <a href="absensi.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #7209b7; --card-dark: #560bad;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-clock"></i></div>
          <div class="card-title">Jam Waktu Absensi</div>
          <div class="card-desc">Atur jadwal dan batas waktu absensi</div>
          <a href="jam_absensi.php" class="card-button">Akses Menu</a>
        </div>
      </div>

      <div class="menu-card" style="--card-color: #3a0ca3; --card-dark: #2b0880;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-clock-rotate-left"></i></div>
          <div class="card-title">Pengaturan Jam Sesi Absensi</div>
          <div class="card-desc">Atur jam absensi masuk, sholat, & pulang</div>
          <a href="jam_absensi_multi.php" class="card-button">Akses Menu</a>
        </div>
      </div>

      <div class="menu-card" style="--card-color: #3b82f6; --card-dark: #1d4ed8;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-book-open"></i></div>
          <div class="card-title">Panduan Sistem</div>
          <div class="card-desc">Pedoman penggunaan dan dokumentasi fitur</div>
          <a href="pedoman.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #4cc9f0; --card-dark: #4895ef;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-calendar-days"></i></div>
          <div class="card-title">Rekap Bulanan</div>
          <div class="card-desc">Lihat rekap absensi per bulan</div>
          <a href="rekap_bulanan.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #f9c74f; --card-dark: #f8961e;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-chalkboard-teacher"></i></div>
          <div class="card-title">Rekap Bulanan Guru</div>
          <div class="card-desc">Lihat rekap kehadiran guru per bulan</div>
          <a href="rekap_bulanan_guru.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #ff9e00; --card-dark: #ff7b00;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-pray"></i></div>
          <div class="card-title">Rekap Sholat</div>
          <div class="card-desc">Lihat rekap sholat Dhuha dan Dhuhur siswa</div>
          <a href="rekap_sholat.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #f72585; --card-dark: #b5179e;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-chart-pie"></i></div>
          <div class="card-title">Prosentase Kehadiran</div>
          <div class="card-desc">Statistik persentase kehadiran siswa</div>
          <a href="hadir.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #90be6d; --card-dark: #43aa8b;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-plane"></i></div>
          <div class="card-title">Hari Libur</div>
          <div class="card-desc">Kelola hari libur dan cuti bersama</div>
          <a href="libur.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #43aa8b; --card-dark: #4d908e;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-file-excel"></i></div>
          <div class="card-title">Export Excel</div>
          <div class="card-desc">Ekspor data absensi ke format Excel</div>
          <a href="export.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #25d366; --card-dark: #128c7e;">
        <div class="card-content">
          <div class="card-icon"><i class="fab fa-whatsapp"></i></div>
          <div class="card-title">Grup WA</div>
          <div class="card-desc">Bergabung dengan grup WhatsApp komunitas</div>
          <a href="https://chat.whatsapp.com/KtdYP6nx3eZLVhqJkQ1Zbs?mode=ac_t" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #25d366; --card-dark: #128c7e;">
        <div class="card-content">
          <div class="card-icon"><i class="fab fa-whatsapp"></i></div>
          <div class="card-title">Kirim WA Orang Tua/Wali</div>
          <div class="card-desc">Kirim pesan WhatsApp ke orang tua/wali siswa</div>
          <a href="wa-wali-siswa.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #577590; --card-dark: #4d908e;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-school"></i></div>
          <div class="card-title">Profil Sekolah</div>
          <div class="card-desc">Kelola informasi dan identitas sekolah</div>
          <a href="profil.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #7209b7; --card-dark: #560bad;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-chalkboard-teacher"></i></div>
          <div class="card-title">Wali Kelas</div>
          <div class="card-desc">Kelola data wali kelas dan pembagiannya</div>
          <a href="wali_kelas.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #f94144; --card-dark: #f3722c;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-trash"></i></div>
          <div class="card-title">Hapus/Kosongkan Data</div>
          <div class="card-desc">Kosongkan data absensi dan siswa</div>
          <a href="kosongkan_data.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #4cc9f0; --card-dark: #4895ef;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-rotate"></i></div>
          <div class="card-title">Backup Restore</div>
          <div class="card-desc">Backup dan restore database sistem</div>
          <a href="backup_restore.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #577590; --card-dark: #4d908e;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-gear"></i></div>
          <div class="card-title">Pengaturan</div>
          <div class="card-desc">Konfigurasi sistem dan preferensi</div>
          <a href="pengaturan.php" class="card-button">Akses Menu</a>
        </div>
      </div>
      
      <div class="menu-card" style="--card-color: #f94144; --card-dark: #f3722c;">
        <div class="card-content">
          <div class="card-icon"><i class="fas fa-right-from-bracket"></i></div>
          <div class="card-title">Logout</div>
          <div class="card-desc">Keluar dari sistem administrasi</div>
          <a href="logout.php" class="card-button">Keluar</a>
        </div>
      </div>
    </div>
  </div>

  <footer>
    TK. Tadika Mesra | &copy; <?php echo date('Y'); ?> Sistem Absensi QR
  </footer>

  <script>
    function filterMenu() {
      const input = document.getElementById('searchMenu');
      const filter = input.value.toLowerCase();
      const grid = document.getElementById('menuGrid');
      const cards = grid.getElementsByClassName('menu-card');

      for (let i = 0; i < cards.length; i++) {
        const title = cards[i].getElementsByClassName('card-title')[0];
        const desc = cards[i].getElementsByClassName('card-desc')[0];
        
        if (title || desc) {
          const titleText = title.textContent || title.innerText;
          const descText = desc.textContent || desc.innerText;
          
          if (titleText.toLowerCase().indexOf(filter) > -1 || descText.toLowerCase().indexOf(filter) > -1) {
            cards[i].style.display = "";
          } else {
            cards[i].style.display = "none";
          }
        }
      }
    }
  </script>
</body>
</html>
