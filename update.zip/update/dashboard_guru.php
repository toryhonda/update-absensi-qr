<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

$username_session = $_SESSION['username'];
$q_user = mysqli_query($conn, "SELECT nama FROM users WHERE username='$username_session' LIMIT 1");
$data_user = mysqli_fetch_assoc($q_user);
$nama_user = $data_user['nama'] ?? 'Guru';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Guru Absensi QR</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    body {
      font-family: sans-serif;
      margin: 0;
      padding: 0;
      background: #f4f4f4;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }
    .marquee-container {
      background: #ff9800;
      overflow: hidden;
      white-space: nowrap;
      padding: 10px 0;
    }
    .marquee-text {
      display: inline-block;
      padding-left: 100%;
      animation: marquee 15s linear infinite;
      color: white;
      font-weight: bold;
      font-size: 16px;
    }
    @keyframes marquee {
      0%   { transform: translateX(0); }
      100% { transform: translateX(-100%); }
    }
    header {
      background-color: #4CAF50;
      color: white;
      padding: 15px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: relative;
    }
    header h1 { margin: 0; font-size: 24px; }
    header p { margin: 5px 0 0 0; font-size: 14px; opacity: 0.9; }

    .user-profile-menu {
      position: relative;
      display: inline-block;
    }
    .profile-btn {
      display: flex;
      align-items: center;
      gap: 10px;
      background: rgba(255, 255, 255, 0.2);
      padding: 6px 12px;
      border-radius: 30px;
      cursor: pointer;
      color: white;
      font-weight: bold;
      text-decoration: none;
      transition: background 0.3s;
    }
    .profile-btn:hover { background: rgba(255, 255, 255, 0.3); }
    .profile-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: #fff;
      color: #4CAF50;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      font-weight: bold;
    }

    /* Dropdown disesuaikan dengan padding tambahan agar area kursor tidak terputus */
    .dropdown-content {
      display: none;
      position: absolute;
      right: 0;
      top: 100%;
      padding-top: 8px; /* Jembatan agar kursor tidak kehilangan fokus */
      min-width: 180px;
      z-index: 10;
    }
    .dropdown-box {
      background-color: #fff;
      box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
      border-radius: 8px;
      overflow: hidden;
    }
    .dropdown-content a {
      color: #333;
      padding: 12px 16px;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
    }
    .dropdown-content a:hover { background-color: #f1f1f1; }
    .user-profile-menu:hover .dropdown-content { display: block; }

    h2 { margin: 20px; text-align: center; }
    ul {
      list-style-type: none;
      padding: 0; margin: 20px auto;
      display: flex; flex-direction: column;
      gap: 10px; max-width: 400px;
    }
    li a {
      display: flex; align-items: center; justify-content: center;
      gap: 8px; background-color: #fff; color: #333;
      text-decoration: none; padding: 15px;
      border-radius: 8px; font-weight: bold;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      transition: background-color 0.3s ease;
      border: 4px solid transparent;
    }
    li a:hover { background-color: #e0e0e0; }
    .siswa { border-color: orange; }
    .scan { border-color: green; }
    .sia { border-color: blue; }
    .jam { border-color: purple; }
    .rekap { border-color: black; }
    .grafik { border-color: black; }
    .prosentase { border-color: black; }
    .libur { border-color: red; }
    .excel { border-color: green; }
    .wa { border-color: green; }
    .logout { border-color: red; }

    @media (min-width: 600px) {
      ul { flex-direction: row; flex-wrap: wrap; justify-content: center; }
      li { flex: 1 1 40%; margin: 5px; }
    }
    footer {
      margin-top: auto; background: #333;
      color: white; text-align: center;
      padding: 10px; font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="marquee-container">
    <span class="marquee-text">
      Kehadiran Bapak/Ibu Guru membersamai siswa belajar tidak akan pernah dapat digantikan oleh Robot AI
    </span>
  </div>

  <header>
    <div>
      <h1>Dashboard Guru</h1>
      <p>Selamat Datang, <b><?= htmlspecialchars($nama_user); ?></b></p>
    </div>
    
    <div class="user-profile-menu">
      <div class="profile-btn">
        <div class="profile-avatar">
          <i class="fa-solid fa-user"></i>
        </div>
        <span><?= htmlspecialchars($nama_user); ?> <i class="fa-solid fa-caret-down"></i></span>
      </div>
      <div class="dropdown-content">
        <div class="dropdown-box">
          <a href="profil_guru.php"><i class="fa-solid fa-user-pen"></i> Pengaturan Akun</a>
          <a href="logout.php" style="color: red;"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
      </div>
    </div>
  </header>

  <h2>Menu</h2>
  <ul>
    <li><a href="siswa_2.php" class="siswa"><i class="fa-solid fa-user-graduate"></i> Data Siswa</a></li>
    <li><a href="scan_2.php" class="scan"><i class="fa-solid fa-qrcode"></i> SCAN QR</a></li>
    <li><a href="belum_absensi_2.php" class="libur"><i class="fa-solid fa-user"></i> Siswa Belum Hadir</a></li>
    <li><a href="absensi_2.php" class="sia"><i class="fa-solid fa-clipboard-check"></i> Isi S/I/A</a></li>
    <li><a href="jam_absensi_2.php" class="jam"><i class="fa-solid fa-clock"></i> Jam Waktu Absensi</a></li>
    <li><a href="rekap_bulanan_2.php" class="rekap"><i class="fa-solid fa-calendar-days"></i> Rekap Bulanan</a></li>
    <li><a href="grafik_2.php" class="grafik"><i class="fa-solid fa-chart-line"></i> Grafik</a></li>
    <li><a href="hadir_2.php" class="prosentase"><i class="fa-solid fa-chart-pie"></i> Prosentase Kehadiran</a></li>
    <li><a href="libur_2.php" class="libur"><i class="fa-solid fa-plane"></i> Hari Libur</a></li>
    <li><a href="export.php" class="excel"><i class="fa-solid fa-file-excel"></i> Export Excel</a></li>
    <li><a href="wa-wali-siswa.php" class="wa"><i class="fa-brands fa-whatsapp"></i> Kirim WA Orang Tua/Wali Siswa</a></li>
    <li><a href="logout.php" class="logout"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
  </ul>

  <footer>
    Versi Aplikasi: 4.00
  </footer>
</body>
</html>
