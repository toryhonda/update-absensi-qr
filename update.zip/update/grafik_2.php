<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

// Ambil data statistik kehadiran berdasarkan status (H, S, I, A)
$query = "SELECT status, COUNT(*) as total FROM absensi GROUP BY status";
$result = mysqli_query($conn, $query);

$dataStat = [
    'H' => 0,
    'S' => 0,
    'I' => 0,
    'A' => 0
];

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        if (array_key_exists($row['status'], $dataStat)) {
            $dataStat[$row['status']] = (int)$row['total'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Grafik Statistik Kehadiran</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 20px;
      color: #333;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      background: white;
      padding: 25px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
      color: #2c3e50;
      text-align: center;
      margin-bottom: 20px;
      padding-bottom: 10px;
      border-bottom: 2px solid #eee;
    }
    .btn-back {
      display: inline-block;
      background: #6c757d;
      color: white;
      padding: 8px 15px;
      border-radius: 4px;
      text-decoration: none;
      font-weight: bold;
      margin-bottom: 20px;
      transition: background 0.3s;
    }
    .btn-back:hover {
      background: #5a6268;
    }
    .chart-box {
      position: relative;
      width: 100%;
      max-width: 550px;
      margin: 20px auto;
      height: 320px;
    }
    .info-box {
      background: #e7f4ff;
      border-left: 4px solid #3498db;
      padding: 10px 15px;
      margin-bottom: 20px;
      border-radius: 4px;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="container">
    <a href="dashboard_guru.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
    
    <h2>Grafik Statistik Kehadiran Siswa</h2>

    <div class="info-box">
      <strong>Informasi:</strong> Grafik di bawah menyajikan rekapitulasi jumlah kehadiran secara keseluruhan berdasarkan status (Hadir, Sakit, Izin, Alpha).
    </div>

    <div class="chart-box">
      <canvas id="grafikAbsensi"></canvas>
    </div>
  </div>

  <script>
    const ctx = document.getElementById('grafikAbsensi').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Hadir (H)', 'Sakit (S)', 'Izin (I)', 'Alpha (A)'],
        datasets: [{
          data: [
            <?= $dataStat['H']; ?>,
            <?= $dataStat['S']; ?>,
            <?= $dataStat['I']; ?>,
            <?= $dataStat['A']; ?>
          ],
          backgroundColor: ['#28a745', '#ffc107', '#17a2b8', '#dc3545'],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1 }
          }
        }
      }
    });
  </script>
</body>
</html>
