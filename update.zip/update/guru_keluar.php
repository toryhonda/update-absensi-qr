<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

include 'config.php';

// Proses kembalikan guru ke status aktif
if (isset($_GET['aktifkan'])) {
    $id = intval($_GET['aktifkan']);
    mysqli_query($conn, "UPDATE guru SET status='aktif' WHERE id=$id");
    header("Location: guru_keluar.php");
    exit;
}

// Proses hapus permanen guru keluar
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $res = mysqli_query($conn, "SELECT nip FROM guru WHERE id=$id LIMIT 1");
    if ($res && mysqli_num_rows($res) > 0) {
        $data = mysqli_fetch_assoc($res);
        $nip = $data['nip'];
        // Hapus file QR code jika ada
        if (file_exists("assets/qr_guru/$nip.png")) {
            @unlink("assets/qr_guru/$nip.png");
        }
        mysqli_query($conn, "DELETE FROM guru WHERE id=$id");
    }
    header("Location: guru_keluar.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Data Guru Keluar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { font-family: 'Rubik', sans-serif; background-color: #f8f9fa; }
  </style>
</head>
<body class="container py-4">

  <h2 class="text-center mb-4">Riwayat Data Guru Keluar</h2>

  <a href="guru.php" class="btn btn-secondary mb-3">← Kembali ke Data Guru Aktif</a>

  <div class="table-responsive">
    <table class="table table-bordered table-striped align-middle bg-white shadow-sm">
      <thead class="table-danger text-center">
        <tr>
          <th>NIP</th>
          <th>Nama</th>
          <th>Mata Pelajaran</th>
          <th>No. WhatsApp</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Cek apakah kolom status ada di tabel guru
        $check_status = mysqli_query($conn, "SHOW COLUMNS FROM guru LIKE 'status'");
        if (mysqli_num_rows($check_status) == 0) {
            mysqli_query($conn, "ALTER TABLE guru ADD status ENUM('aktif','keluar') DEFAULT 'aktif'");
        }

        $q = mysqli_query($conn, "SELECT * FROM guru WHERE status='keluar' ORDER BY nama ASC");
        if (mysqli_num_rows($q) > 0) {
            while ($row = mysqli_fetch_assoc($q)) {
              $no_wa = $row['no_wa'] ?? ($row['whatsapp'] ?? '-');
              echo "<tr>
                <td>{$row['nip']}</td>
                <td>{$row['nama']}</td>
                <td>{$row['mapel']}</td>
                <td>{$no_wa}</td>
                <td class='text-center'>
                  <a href='guru_keluar.php?aktifkan={$row['id']}' class='btn btn-success btn-sm mb-1' onclick='return confirm(\"Kembalikan guru ini menjadi aktif?\")'>Aktifkan Kembali</a>
                  <a href='guru_keluar.php?hapus={$row['id']}' class='btn btn-danger btn-sm mb-1' onclick='return confirm(\"Hapus permanen data guru ini?\")'>Hapus Permanen</a>
                </td>
              </tr>";
            }
        } else {
            echo "<tr><td colspan='5' class='text-center text-muted py-3'>Tidak ada data guru keluar.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

</body>
</html>
