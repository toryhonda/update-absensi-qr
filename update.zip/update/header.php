<?php
// Pastikan koneksi dan session sudah aktif jika file ini disertakan
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($conn)) {
    include 'config.php';
}

// Ambil logo sekolah dari database profil_sekolah untuk favicon dinamis
$query_fav = mysqli_query($conn, "SELECT logo FROM profil_sekolah LIMIT 1");
$data_fav = ($query_fav && mysqli_num_rows($query_fav) > 0) ? mysqli_fetch_assoc($query_fav) : null;
$logo_favicon = !empty($data_fav['logo']) ? 'uploads/' . $data_fav['logo'] : 'default.png';
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($page_title) ? $page_title : 'Sistem Absensi QR Code'; ?></title>
  
  <!-- Favicon Dinamis Mengikuti Logo Sekolah -->
  <link rel="icon" type="image/png" href="<?php echo htmlspecialchars($logo_favicon); ?>">
  
  <!-- Google Fonts Rubik -->
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- SweetAlert2 CDN -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  
  <style>
    body { font-family: 'Rubik', sans-serif !important; background-color: #f8f9fa; }
    .card { border-radius: 1rem; border: none; box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.05); }
  </style>
</head>
<body>
