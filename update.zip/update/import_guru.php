<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

// Aktifkan error reporting untuk debugging jika diperlukan
ini_set('display_errors', 0);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}
include 'config.php';

// Pastikan file QR Code ada
if (file_exists('vendor/phpqrcode/qrlib.php')) {
    require 'vendor/phpqrcode/qrlib.php';
}

// Fitur Download Template Excel fisik untuk Guru
if (isset($_GET['download_template'])) {
    $file_template = "template_guru.xlsx";
    if (file_exists($file_template)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . basename($file_template) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_template));
        readfile($file_template);
        exit;
    } else {
        $_SESSION['msg'] = "<div class='alert alert-danger'>File template fisik 'template_guru.xlsx' belum diunggah ke server!</div>";
        header("Location: import_guru.php");
        exit;
    }
}

$msg = "";
$errors = [];

// Cek apakah kolom no_wa ada di tabel guru (standar baru)
$check_column = mysqli_query($conn, "SHOW COLUMNS FROM guru LIKE 'no_wa'");
$no_wa_column_exists = (mysqli_num_rows($check_column) > 0);

// Jika belum ada no_wa, cek apakah masih pakai whatsapp lama
if (!$no_wa_column_exists) {
    $check_wa = mysqli_query($conn, "SHOW COLUMNS FROM guru LIKE 'whatsapp'");
    $whatsapp_legacy_exists = (mysqli_num_rows($check_wa) > 0);
} else {
    $whatsapp_legacy_exists = false;
}

// Fungsi pembacaan file .xlsx yang aman dengan try-catch
function baca_xlsx($filename) {
    $rows = [];
    try {
        $zip = new ZipArchive();
        if ($zip->open($filename) === TRUE) {
            $sharedStrings = [];
            if (($index = $zip->locateName('xl/sharedStrings.xml')) !== false) {
                $xmlContent = $zip->getFromIndex($index);
                if ($xmlContent) {
                    $xml = @simplexml_load_string($xmlContent);
                    if ($xml && isset($xml->si)) {
                        foreach ($xml->si as $si) {
                            $sharedStrings[] = (string)$si->t;
                        }
                    }
                }
            }

            if (($index = $zip->locateName('xl/worksheets/sheet1.xml')) !== false) {
                $xmlContent = $zip->getFromIndex($index);
                if ($xmlContent) {
                    $xml = @simplexml_load_string($xmlContent);
                    if ($xml && isset($xml->sheetData->row)) {
                        foreach ($xml->sheetData->row as $row) {
                            $rowData = [];
                            if (isset($row->c)) {
                                foreach ($row->c as $c) {
                                    $val = "";
                                    $t = isset($c['t']) ? (string)$c['t'] : "";
                                    if (isset($c->v)) {
                                        $v = (string)$c->v;
                                        if ($t == 's') {
                                            $val = $sharedStrings[intval($v)] ?? "";
                                        } else {
                                            $val = $v;
                                        }
                                    }
                                    $rowData[] = trim($val);
                                }
                            }
                            $rows[] = $rowData;
                        }
                    }
                }
            }
            $zip->close();
        }
    } catch (Exception $e) {
        // Tangkap exception zip
    }
    return $rows;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['import'])) {
    $berhasil = 0;
    $gagal = 0;
    $errors = [];

    if (!empty($_FILES['file_excel']['tmp_name'])) {
        $inputFileName = $_FILES['file_excel']['tmp_name'];
        $ext = strtolower(pathinfo($_FILES['file_excel']['name'], PATHINFO_EXTENSION));

        $data_rows = [];
        if ($ext == 'xlsx') {
            $data_rows = baca_xlsx($inputFileName);
        } else if ($ext == 'csv') {
            if (($handle = fopen($inputFileName, "r")) !== FALSE) {
                while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
                    if (count($data) == 1 && strpos($data[0], ';') !== false) {
                        $data = explode(';', $data[0]);
                    }
                    $data_rows[] = $data;
                }
                fclose($handle);
            }
        }

        if (!empty($data_rows)) {
            $row_idx = 0;
            foreach ($data_rows as $data) {
                $row_idx++;
                if ($row_idx == 1) continue; // Lewati header

                $raw_nip  = trim($data[0] ?? '');
                $nama     = trim($data[1] ?? '');
                $mapel    = trim($data[2] ?? '');
                $whatsapp = trim($data[3] ?? '');

                // Bersihkan NIP dari spasi atau karakter non-angka
                $nip = preg_replace('/[^0-9]/', '', $raw_nip);

                if ($nip != "" && $nama != "" && $mapel != "") {
                    // Validasi NIP (8-18 digit angka)
                    if (!preg_match('/^[0-9]{8,18}$/', $nip)) {
                        $gagal++;
                        $errors[] = "Baris $row_idx: NIP ($raw_nip) harus 8-18 digit angka.";
                        continue;
                    }

                    $whatsapp_value = '';
                    if (!empty($whatsapp)) {
                        $whatsapp_clean = preg_replace('/[^0-9]/', '', $whatsapp);
                        if (substr($whatsapp_clean, 0, 1) === '0') {
                            $whatsapp_value = '62' . substr($whatsapp_clean, 1);
                        } else {
                            $whatsapp_value = $whatsapp_clean;
                        }
                    }

                    // Escape data untuk keamanan database
                    $nip    = mysqli_real_escape_string($conn, $nip);
                    $nama   = mysqli_real_escape_string($conn, $nama);
                    $mapel  = mysqli_real_escape_string($conn, $mapel);
                    $whatsapp_value = mysqli_real_escape_string($conn, $whatsapp_value);

                    // Query berdasarkan kolom yang tersedia di database
                    if ($no_wa_column_exists) {
                        $sql = "INSERT INTO guru (nip, nama, mapel, no_wa, status) 
                                VALUES ('$nip','$nama','$mapel','$whatsapp_value','aktif') 
                                ON DUPLICATE KEY UPDATE nama='$nama', mapel='$mapel', no_wa='$whatsapp_value', status='aktif'";
                    } elseif ($whatsapp_legacy_exists) {
                        $sql = "INSERT INTO guru (nip, nama, mapel, whatsapp, status) 
                                VALUES ('$nip','$nama','$mapel','$whatsapp_value','aktif') 
                                ON DUPLICATE KEY UPDATE nama='$nama', mapel='$mapel', whatsapp='$whatsapp_value', status='aktif'";
                    } else {
                        // Jika kolom nomor belum ada sama sekali di tabel guru, buat otomatis atau simpan tanpa kolom nomor
                        @mysqli_query($conn, "ALTER TABLE guru ADD no_wa VARCHAR(20) AFTER mapel");
                        $sql = "INSERT INTO guru (nip, nama, mapel, no_wa, status) 
                                VALUES ('$nip','$nama','$mapel','$whatsapp_value','aktif') 
                                ON DUPLICATE KEY UPDATE nama='$nama', mapel='$mapel', no_wa='$whatsapp_value', status='aktif'";
                    }
                    
                    if (mysqli_query($conn, $sql)) {
                        $berhasil++;
                        $qr_dir = "assets/qr_guru/";
                        if (!is_dir($qr_dir)) mkdir($qr_dir, 0777, true);
                        if (class_exists('QRcode')) {
                            @QRcode::png($nip, $qr_dir . "$nip.png", QR_ECLEVEL_L, 4);
                        }
                    } else {
                        $gagal++;
                        $errors[] = "Baris $row_idx: Gagal disimpan ke database (" . mysqli_error($conn) . ").";
                    }
                } else {
                    if (!empty(array_filter($data))) {
                        $gagal++;
                        $errors[] = "Baris $row_idx: Kolom data tidak lengkap.";
                    }
                }
            }

            if ($berhasil > 0 && empty($errors)) {
                $_SESSION['msg'] = "<div class='alert alert-success'>✅ Import berhasil! $berhasil data guru ditambahkan.</div>";
            } else {
                $_SESSION['msg'] = "<div class='alert alert-warning'>⚠️ Import selesai dengan catatan. Berhasil: $berhasil, Gagal: $gagal.</div>";
            }
            $_SESSION['errors'] = $errors;
        } else {
            $_SESSION['msg'] = "<div class='alert alert-danger'>❌ Gagal membaca file Excel. Pastikan file berformat .xlsx yang valid dan tidak kosong.</div>";
        }
    } else {
        $_SESSION['msg'] = "<div class='alert alert-danger'>❌ Harap pilih file terlebih dahulu.</div>";
    }

    header("Location: import_guru.php");
    exit;
}

$msg = $_SESSION['msg'] ?? "";
$errors = $_SESSION['errors'] ?? [];
unset($_SESSION['msg'], $_SESSION['errors']);
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Import Data Guru</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { font-family: 'Rubik', sans-serif !important; }
    .card { border-radius: 1rem; }
  </style>
</head>
<body class="bg-light container py-4">

  <div class="row justify-content-center">
    <div class="col-12 col-md-10 col-lg-8">
      <div class="card shadow-sm">
        <div class="card-body p-4">
          <a href="guru.php" class="btn btn-secondary btn-sm mb-3">← Kembali</a>
          <h2 class="h4 mb-3 text-center">📥 Import Data Guru Excel (.xlsx)</h2>

          <?= $msg; ?>

          <form method="post" enctype="multipart/form-data" autocomplete="off">
              <div class="mb-3">
                  <label class="form-label">Pilih File Excel (.xlsx)</label>
                  <input type="file" name="file_excel" accept=".xlsx" class="form-control" required>
                  <div class="form-text">
                      Unduh template resminya di sini: <a href="?download_template=1" class="text-decoration-none fw-bold">📂 Unduh Template Excel (.xlsx)</a>
                  </div>
              </div>
              <div class="d-grid">
                  <button type="submit" name="import" class="btn btn-success btn-lg">Import Data Guru</button>
              </div>
          </form>

          <?php if (!empty($errors)) { ?>
            <div class="card mt-3 border-danger">
              <div class="card-header bg-danger text-white">❌ Detail Error / Gagal</div>
              <div class="card-body" style="max-height: 200px; overflow-y: auto;">
                <ul class="mb-0">
                  <?php foreach ($errors as $err) { echo "<li>$err</li>"; } ?>
                </ul>
              </div>
            </div>
          <?php } ?>

          <hr class="my-4">
          <p class="text-muted small mb-0">
            Format urutan kolom: <b>NIP | Nama | Mata Pelajaran | Nomor WhatsApp</b>
          </p>
        </div>
      </div>
    </div>
  </div>

</body>
</html>
