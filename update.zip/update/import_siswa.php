<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

// Aktifkan error reporting untuk debugging jika diperlukan
ini_set('display_errors', 0);
error_reporting(E_ALL);

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}
include 'config.php';

// Pastikan file QR Code ada
if (file_exists('vendor/phpqrcode/qrlib.php')) {
    require 'vendor/phpqrcode/qrlib.php';
}

// Fitur Download Template Excel fisik
if (isset($_GET['download_template'])) {
    $file_template = "template_siswa.xlsx";
    if (file_exists($file_template)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . basename($file_template) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_template));
        readfile($file_template);
        exit;
    } else {
        $_SESSION['msg'] = "<div class='alert alert-danger'>File template fisik 'template_siswa.xlsx' belum diunggah ke server!</div>";
        header("Location: import_siswa.php");
        exit;
    }
}

$msg = "";
$errors = [];

// Fungsi pembacaan file .xlsx yang aman dengan try-catch
function baca_xlsx($filename) {
    $rows = [];
    try {
        $zip = new ZipArchive();
        if ($zip->open($filename) === TRUE) {
            $sharedStrings = [];
            if (($index = $zip->locateName('xl/sharedStrings.xml')) !== false) {
                $xmlContent = $zip->getFromIndex($index);
                if ($xmlContent) {
                    $xml = @simplexml_load_string($xmlContent);
                    if ($xml && isset($xml->si)) {
                        foreach ($xml->si as $si) {
                            $sharedStrings[] = (string)$si->t;
                        }
                    }
                }
            }

            if (($index = $zip->locateName('xl/worksheets/sheet1.xml')) !== false) {
                $xmlContent = $zip->getFromIndex($index);
                if ($xmlContent) {
                    $xml = @simplexml_load_string($xmlContent);
                    if ($xml && isset($xml->sheetData->row)) {
                        foreach ($xml->sheetData->row as $row) {
                            $rowData = [];
                            if (isset($row->c)) {
                                foreach ($row->c as $c) {
                                    $val = "";
                                    $t = isset($c['t']) ? (string)$c['t'] : "";
                                    if (isset($c->v)) {
                                        $v = (string)$c->v;
                                        if ($t == 's') {
                                            $val = $sharedStrings[intval($v)] ?? "";
                                        } else {
                                            $val = $v;
                                        }
                                    }
                                    $rowData[] = trim($val);
                                }
                            }
                            $rows[] = $rowData;
                        }
                    }
                }
            }
            $zip->close();
        }
    } catch (Exception $e) {
        // Tangkap exception zip
    }
    return $rows;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['import'])) {
    $berhasil = 0;
    $gagal = 0;

    if (!empty($_FILES['file_excel']['tmp_name'])) {
        $inputFileName = $_FILES['file_excel']['tmp_name'];
        $ext = strtolower(pathinfo($_FILES['file_excel']['name'], PATHINFO_EXTENSION));

        $data_rows = [];
        if ($ext == 'xlsx') {
            $data_rows = baca_xlsx($inputFileName);
        } else if ($ext == 'csv') {
            if (($handle = fopen($inputFileName, "r")) !== FALSE) {
                while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
                    if (count($data) == 1 && strpos($data[0], ';') !== false) {
                        $data = explode(';', $data[0]);
                    }
                    $data_rows[] = $data;
                }
                fclose($handle);
            }
        }

        if (!empty($data_rows)) {
            $row_idx = 0;
            foreach ($data_rows as $data) {
                $row_idx++;
                if ($row_idx == 1) continue; // Lewati header

                $nis      = trim($data[0] ?? '');
                $nisn     = trim($data[1] ?? '');
                $nama     = trim($data[2] ?? '');
                $kelas    = trim($data[3] ?? '');
                $no_wa    = trim($data[4] ?? '');

                if ($nis != "" && $nisn != "" && $nama != "" && $kelas != "") {
                    // Validasi NIS (harus 4 digit angka)
                    if (!preg_match('/^[0-9]{4}$/', $nis)) {
                        $gagal++;
                        $errors[] = "Baris $row_idx: NIS ($nis) harus 4 digit angka.";
                        continue;
                    }

                    // Escape data untuk keamanan database
                    $nis   = mysqli_real_escape_string($conn, $nis);
                    $nisn  = mysqli_real_escape_string($conn, $nisn);
                    $nama  = mysqli_real_escape_string($conn, $nama);
                    $kelas = mysqli_real_escape_string($conn, $kelas);
                    $no_wa = mysqli_real_escape_string($conn, $no_wa);

                    // Menggunakan kolom no_wa sesuai database
                    $sql = "INSERT INTO siswa (nis, nisn, nama, kelas, no_wa, status) 
                            VALUES ('$nis','$nisn','$nama','$kelas','$no_wa','aktif') 
                            ON DUPLICATE KEY UPDATE nama='$nama', kelas='$kelas', no_wa='$no_wa', status='aktif'";
                    
                    if (mysqli_query($conn, $sql)) {
                        $berhasil++;
                        $qr_dir = "assets/qr/";
                        if (!is_dir($qr_dir)) mkdir($qr_dir, 0777, true);
                        if (class_exists('QRcode')) {
                            @QRcode::png($nisn, $qr_dir . "$nisn.png", QR_ECLEVEL_L, 4);
                        }
                    } else {
                        $gagal++;
                        $errors[] = "Baris $row_idx: Gagal disimpan ke database (" . mysqli_error($conn) . ").";
                    }
                } else {
                    if (!empty(array_filter($data))) {
                        $gagal++;
                        $errors[] = "Baris $row_idx: Kolom data tidak lengkap.";
                    }
                }
            }

            // Jika ada data yang berhasil di-import, langsung arahkan ke siswa.php
            if ($berhasil > 0) {
                $_SESSION['msg'] = "Import berhasil! $berhasil data ditambahkan.";
                header("Location: siswa.php");
                exit;
            } else {
                $msg = "<div class='alert alert-danger'>❌ Tidak ada data yang berhasil diimport. Periksa detail error di bawah.</div>";
            }
        } else {
            $msg = "<div class='alert alert-danger'>❌ Gagal membaca file Excel. Pastikan file berformat .xlsx yang valid dan tidak kosong.</div>";
        }
    } else {
        $msg = "<div class='alert alert-danger'>❌ Harap pilih file terlebih dahulu.</div>";
    }
}

if (isset($_SESSION['msg'])) {
    $msg = $_SESSION['msg'];
    unset($_SESSION['msg']);
}
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Import Data Siswa</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { font-family: 'Rubik', sans-serif !important; }
    .card { border-radius: 1rem; }
  </style>
</head>
<body class="bg-light container py-4">

  <div class="row justify-content-center">
    <div class="col-12 col-md-10 col-lg-8">
      <div class="card shadow-sm">
        <div class="card-body p-4">
          <a href="siswa.php" class="btn btn-secondary btn-sm mb-3">← Kembali</a>
          <h2 class="h4 mb-3 text-center">📥 Import Data Siswa Excel (.xlsx)</h2>

          <?= is_array($msg) ? '' : $msg; ?>

          <form method="post" enctype="multipart/form-data" autocomplete="off">
              <div class="mb-3">
                  <label class="form-label">Pilih File Excel (.xlsx)</label>
                  <input type="file" name="file_excel" accept=".xlsx" class="form-control" required>
                  <div class="form-text">
                      Unduh template resminya di sini: <a href="?download_template=1" class="text-decoration-none fw-bold">📂 Unduh Template Excel (.xlsx)</a>
                  </div>
              </div>
              <div class="d-grid">
                  <button type="submit" name="import" class="btn btn-success btn-lg">Import Data</button>
              </div>
          </form>

          <?php if (!empty($errors)) { ?>
            <div class="card mt-3 border-danger">
              <div class="card-header bg-danger text-white">❌ Detail Error / Gagal</div>
              <div class="card-body" style="max-height: 200px; overflow-y: auto;">
                <ul class="mb-0">
                  <?php foreach ($errors as $err) { echo "<li>$err</li>"; } ?>
                </ul>
              </div>
            </div>
          <?php } ?>

          <hr class="my-4">
          <p class="text-muted small mb-0">
            Format urutan kolom: <b>NIS | NISN | Nama | Kelas | Nomor WhatsApp</b>
          </p>
        </div>
      </div>
    </div>
  </div>

</body>
</html>