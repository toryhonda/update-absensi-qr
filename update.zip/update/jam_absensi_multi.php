<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

$pesan_notif = "";

// Proses simpan pengaturan jam
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $sesi_list = $_POST['sesi'] ?? [];
    $mulai_list = $_POST['jam_mulai'] ?? [];
    $selesai_list = $_POST['jam_selesai'] ?? [];

    $success = true;
    for ($i = 0; $i < count(($sesi_list)); $i++) {
        $sesi = mysqli_real_escape_string($conn, $sesi_list[$i]);
        $mulai = mysqli_real_escape_string($conn, $mulai_list[$i]);
        $selesai = mysqli_real_escape_string($conn, $selesai_list[$i]);

        // Update atau Insert ke database
        $query = "INSERT INTO pengaturan_jam_sesi (sesi, jam_mulai, jam_selesai) 
                  VALUES ('$sesi', '$mulai', '$selesai') 
                  ON DUPLICATE KEY UPDATE jam_mulai='$mulai', jam_selesai='$selesai'";
        
        if (!mysqli_query($conn, $query)) {
            $success = false;
        }
    }

    if ($success) {
        $pesan_notif = "<div class='alert alert-success'>Pengaturan jam absensi berhasil disimpan! Sesi tidak akan saling bertabrakan.</div>";
    } else {
        $pesan_notif = "<div class='alert alert-danger'>Terjadi kesalahan saat menyimpan data.</div>";
    }
}

// Ambil data jam sesi dari database
$result = mysqli_query($conn, "SELECT * FROM pengaturan_jam_sesi");
$jadwalSesi = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $jadwalSesi[$row['sesi']] = $row;
    }
}

// Default jika tabel masih kosong
$sesiDefault = ['Masuk', 'Sholat Dhuha', 'Sholat Dhuhur', 'Pulang'];
?>
<!DOCTYPE html>
<html lang="id" data-bs-theme="light">
<head>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pengaturan Jam Sesi Absensi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    body { background-color: #f8f9fa; font-family: 'Rubik', sans-serif; }
    .container { max-width: 800px; margin-top: 40px; }
    .card { border-radius: 1rem; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
    .card-header { background-color: #4361ee; color: white; border-top-left-radius: 1rem !important; border-top-right-radius: 1rem !important; }
  </style>
</head>
<body>
  <div class="container py-4">
    <div class="card shadow">
      <div class="card-header p-3">
        <h3 class="mb-0"><i class="fas fa-clock"></i> Pengaturan Jam Sesi Absensi & Pencegahan Bentrok</h3>
      </div>
      <div class="card-body p-4">
        <a href="dashboard_guru.php" class="btn btn-secondary btn-sm mb-3"><i class="fas fa-arrow-left"></i> Kembali ke Dashboard</a>

        <?= $pesan_notif; ?>

        <div class="alert alert-info small">
          <i class="fas fa-info-circle"></i> Atur rentang waktu masing-masing sesi di bawah ini. Sistem akan otomatis mendeteksi sesi mana yang aktif saat siswa melakukan <em>scan</em> QR, sehingga absensi Masuk, Sholat Dhuha, Sholat Dhuhur, dan Pulang tidak akan saling bertabrakan.
        </div>

        <form method="POST" action="">
          <div class="table-responsive">
            <table class="table table-bordered align-middle">
              <thead class="table-light">
                <tr>
                  <th>Sesi Absensi</th>
                  <th>Jam Mulai</th>
                  <th>Jam Selesai</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($sesiDefault as $sesi): 
                  $mulai = $jadwalSesi[$sesi]['jam_mulai'] ?? '00:00:00';
                  $selesai = $jadwalSesi[$sesi]['jam_selesai'] ?? '00:00:00';
                ?>
                <tr>
                  <td>
                    <strong><?php echo $sesi; ?></strong>
                    <input type="hidden" name="sesi[]" value="<?php echo $sesi; ?>">
                  </td>
                  <td>
                    <input type="time" name="jam_mulai[]" class="form-control" value="<?php echo $mulai; ?>" required>
                  </td>
                  <td>
                    <input type="time" name="jam_selesai[]" class="form-control" value="<?php echo $selesai; ?>" required>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <div class="d-grid gap-2 mt-4">
            <button type="submit" class="btn btn-primary btn-lg">
              <i class="fas fa-save"></i> Simpan Pengaturan Jam Sesi
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
