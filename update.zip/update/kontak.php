<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
include 'config.php';

// Ambil data profil sekolah untuk header jika diperlukan
$qProfil = mysqli_query($conn, "SELECT nama_sekolah FROM profil_sekolah LIMIT 1");
$profil  = mysqli_fetch_assoc($qProfil);
$nama_sekolah = $profil['nama_sekolah'] ?? 'Sistem Absensi Digital';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak Developer - <?= htmlspecialchars($nama_sekolah); ?></title>
    <!-- Google Fonts Rubik -->
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Rubik', sans-serif !important;
            background: linear-gradient(135deg, #1e3c72, #2a5298);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .contact-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.25);
            width: 100%;
            max-width: 500px;
            padding: 35px;
        }
        .developer-avatar {
            width: 90px;
            height: 90px;
            background: #e9ecef;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 2.5rem;
            color: #1e3c72;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .contact-item {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            background: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 12px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            border: 1px solid #dee2e6;
        }
        .contact-item:hover {
            background: #e2e6ea;
            transform: translateY(-2px);
            color: #0d6efd;
        }
        .contact-item i {
            font-size: 1.5rem;
            margin-right: 15px;
            width: 30px;
            text-align: center;
        }
    </style>
</head>
<body>

  <div class="contact-card">
    <div class="text-center mb-4">
        <div class="developer-avatar">
            <i class="fas fa-code"></i>
        </div>
        <h3 class="fw-bold text-dark mb-1">Kontak Developer</h3>
        <p class="text-muted small">Butuh bantuan teknis atau pengembangan sistem?</p>
    </div>

    <div class="contact-list">
        <!-- WhatsApp -->
        <a href="https://wa.me/6289666164080" target="_blank" class="contact-item">
            <i class="fab fa-whatsapp text-success"></i>
            <div>
                <strong>WhatsApp</strong><br>
                <span class="text-muted small">+62 896-5463-0099</span>
            </div>
        </a>

        <!-- Email -->
        <a href="mailto:admin@rafazmalik.my.id" class="contact-item">
            <i class="fas fa-envelope text-danger"></i>
            <div>
                <strong>Email Resmi</strong><br>
                <span class="text-muted small">tory@autowebportal.com</span>
            </div>
        </a>
    </div>

    <div class="text-center mt-4">
        <a href="index.php" class="btn btn-secondary w-100 py-2 rounded-pill">
            <i class="fas fa-arrow-left me-2"></i> Kembali ke Halaman Login
        </a>
    </div>
  </div>

</body>
</html>