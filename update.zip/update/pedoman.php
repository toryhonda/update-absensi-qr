<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

$role = $_SESSION['role'] ?? '';
if (!in_array($role, ['guru','admin'])) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panduan & Pedoman Penggunaan Sistem</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    body {
      font-family: 'Rubik', sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 20px;
      color: #333;
      line-height: 1.6;
    }
    .container {
      max-width: 900px;
      margin: 0 auto;
      background: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    h2 {
      color: #2c3e50;
      margin-top: 0;
      padding-bottom: 10px;
      border-bottom: 2px solid #eee;
    }
    h4 {
      color: #34495e;
      margin-top: 30px;
      margin-bottom: 10px;
      border-left: 4px solid #4361ee;
      padding-left: 10px;
    }
    .btn-back {
      display: inline-block;
      background: #6c757d;
      color: white;
      padding: 8px 15px;
      border-radius: 4px;
      text-decoration: none;
      font-weight: bold;
      margin-bottom: 20px;
      transition: background 0.3s;
    }
    .btn-back:hover {
      background: #5a6268;
    }
    .info-box {
      background: #e7f4ff;
      border-left: 4px solid #3498db;
      padding: 12px 15px;
      margin-bottom: 20px;
      border-radius: 4px;
      font-size: 14px;
    }
    .code-box {
      background: #f8f9fa;
      border: 1px solid #ddd;
      padding: 12px;
      border-radius: 4px;
      font-family: monospace;
      font-size: 13px;
      word-break: break-all;
      margin-top: 5px;
      color: #d63384;
    }
    ul, ol {
      padding-left: 20px;
      font-size: 14px;
      color: #555;
    }
    li {
      margin-bottom: 8px;
    }
  </style>
</head>
<body>
  <div class="container">
    <a href="dashboard.php" class="btn-back"><i class="fa-solid fa-arrow-left"></i> Kembali ke Dashboard</a>
    
    <h2>Pedoman Penggunaan & Dokumentasi Fitur Web Absensi</h2>

    <div class="info-box">
      <strong>Tentang Sistem:</strong> Platform absensi digital terintegrasi WhatsApp Cloud API (WABA) yang dirancang untuk memudahkan pencatatan kehadiran siswa/guru serta komunikasi otomatis dengan orang tua.
    </div>

    <h4>1. QR Code Aktivasi WhatsApp Wali Siswa</h4>
    <p style="font-size: 14px; color: #555;">Fitur ini memudahkan orang tua/wali murid terhubung ke sistem notifikasi WABA sekolah secara instan sebelum siswa berangkat.</p>
    <div class="code-box">
      https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=https://wa.me/62896661xxxxx?text=Aktivasi%20Notifikasi%20Absensi
    </div>
    <ol style="margin-top: 10px;">
      <li>Orang tua memindai QR Code via kamera ponsel pintar.</li>
      <li>Aplikasi WhatsApp terbuka otomatis dengan pesan bawaan: <em>"Aktivasi Notifikasi Absensi"</em>.</li>
      <li>Kirim pesan tersebut untuk mengaktifkan sesi komunikasi resmi dengan server WABA sekolah.</li>
    </ol>

    <h4>2. Pengaturan Jam Sesi Absensi Multi</h4>
    <ul>
      <li>Digunakan untuk mengatur rentang waktu operasional spesifik (Masuk, Sholat Dhuha, Sholat Dhuhur, dan Pulang).</li>
      <li>Mencegah terjadinya bentrok waktu (*temporal collision*) saat siswa melakukan pemindaian kartu (*scan*).</li>
      <li>Atur jam mulai dan selesai melalui menu <strong>Pengaturan Jam Sesi Absensi</strong> di dashboard utama.</li>
    </ul>

    <h4>3. Konfigurasi WABA Cloud API</h4>
    <ul>
      <li>Pastikan <em>Phone Number ID</em>, <em>WABA ID</em>, dan <em>Permanent Access Token</em> dari Meta sudah diisi dengan benar pada menu <strong>Pengaturan Key API WA</strong>.</li>
      <li>Gunakan fitur <em>Tes Koneksi WABA</em> untuk memastikan pesan uji coba berhasil terkirim ke nomor tujuan.</li>
    </ul>

    <h4>4. Scan QR & Rekapitulasi Kehadiran</h4>
    <ul>
      <li><strong>Scan QR + WA API:</strong> Digunakan oleh guru piket untuk mencatat kehadiran sekaligus memicu pengiriman pesan otomatis ke orang tua.</li>
      <li><strong>Rekapitulasi:</strong> Data kehadiran harian, bulanan, serta rekap sholat dapat dipantau langsung melalui menu rekap dan diekspor ke format Excel.</li>
    </ul>
  </div>
</body>
</html>
