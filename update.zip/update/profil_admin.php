<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

include 'config.php';

$username_session = $_SESSION['username'];
$pesan = "";

$q_user = mysqli_query($conn, "SELECT * FROM users WHERE username='$username_session' LIMIT 1");
$data_user = mysqli_fetch_assoc($q_user);
$id_user = $data_user['id'] ?? 0;
$nama_user = $data_user['nama'] ?? '';

if (isset($_POST['update_profil'])) {
    $nama_baru          = trim($_POST['nama']);
    $username_baru      = trim($_POST['username']);
    $password_baru      = trim($_POST['password']);
    $konfirmasi_password = trim($_POST['konfirmasi_password']);

    if (!empty($password_baru) && $password_baru !== $konfirmasi_password) {
        $pesan = "<div class='alert alert-danger'>Konfirmasi password baru tidak cocok!</div>";
    } else {
        $cek_username = mysqli_query($conn, "SELECT id FROM users WHERE username='$username_baru' AND id != $id_user LIMIT 1");
        if (mysqli_num_rows($cek_username) > 0) {
            $pesan = "<div class='alert alert-danger'>Username '$username_baru' sudah digunakan akun lain!</div>";
        } else {
            if (!empty($password_baru)) {
                $pass_md5 = md5($password_baru);
                $update = mysqli_query($conn, "UPDATE users SET nama='$nama_baru', username='$username_baru', password='$pass_md5' WHERE id=$id_user");
            } else {
                $update = mysqli_query($conn, "UPDATE users SET nama='$nama_baru', username='$username_baru' WHERE id=$id_user");
            }

            if ($update) {
                $_SESSION['username'] = $username_baru;
                $pesan = "<div class='alert alert-success'>Profil berhasil diperbarui!</div>";
                
                $q_user = mysqli_query($conn, "SELECT * FROM users WHERE id=$id_user LIMIT 1");
                $data_user = mysqli_fetch_assoc($q_user);
                $nama_user = $data_user['nama'];
            } else {
                $pesan = "<div class='alert alert-danger'>Gagal memperbarui profil!</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pengaturan Profil Admin</title>
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <style>
    body { font-family: 'Rubik', sans-serif; background: #f4f4f4; }
  </style>
</head>
<body class="container py-5">
  <div class="row justify-content-center">
    <div class="col-12 col-md-6">
      <div class="card shadow-sm border-0">
        <div class="card-body p-4">
          <a href="dashboard.php" class="btn btn-secondary btn-sm mb-3">← Kembali ke Dashboard</a>
          <h3 class="text-center mb-4"><i class="fa-solid fa-user-pen"></i> Pengaturan Profil & Akun Admin</h3>
          
          <?= $pesan; ?>

          <form method="POST">
            <div class="mb-3">
              <label class="form-label fw-bold">Nama Lengkap</label>
              <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($data_user['nama'] ?? ''); ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold">Username</label>
              <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($data_user['username'] ?? ''); ?>" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold">Password Baru <small class="text-muted fw-normal">(Kosongkan jika tidak diubah)</small></label>
              <input type="password" name="password" class="form-control" placeholder="Masukkan password baru">
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold">Konfirmasi Password Baru</label>
              <input type="password" name="konfirmasi_password" class="form-control" placeholder="Ulangi password baru">
            </div>
            <div class="d-grid">
              <button type="submit" name="update_profil" class="btn btn-success btn-lg">Simpan Perubahan</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
