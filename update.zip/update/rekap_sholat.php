<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Include file config.php yang sudah ada
include 'config.php';

// Proses hapus data sholat
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $jenis_sholat = $_GET['jenis'] ?? 'dhuha';
    
    if ($jenis_sholat == 'dhuha') {
        $table = 'sholat_dhuha';
        $judul = 'Dhuha';
    } else {
        $table = 'sholat_dhuhur';
        $judul = 'Dhuhur';
    }
    
    // Hapus data
    $delete_query = "DELETE FROM $table WHERE id = ?";
    $stmt = mysqli_prepare($conn, $delete_query);
    mysqli_stmt_bind_param($stmt, 'i', $id);
    
    if (mysqli_stmt_execute($stmt)) {
        $success_message = "Data sholat $judul berhasil dihapus";
    } else {
        $error_message = "Gagal menghapus data sholat $judul";
    }
    
    // Redirect ke halaman yang sama tanpa parameter hapus
    $redirect_url = "rekap_sholat.php?tanggal=" . ($_GET['tanggal'] ?? date('Y-m-d')) . 
                   "&kelas=" . ($_GET['kelas'] ?? '') . 
                   "&jenis_sholat=" . $jenis_sholat;
    
    if (isset($success_message)) {
        $redirect_url .= "&success=" . urlencode($success_message);
    }
    if (isset($error_message)) {
        $redirect_url .= "&error=" . urlencode($error_message);
    }
    
    header("Location: $redirect_url");
    exit;
}

// Filter berdasarkan tanggal dan jenis sholat
$filter_tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d');
$filter_kelas = isset($_GET['kelas']) ? $_GET['kelas'] : '';
$jenis_sholat = isset($_GET['jenis_sholat']) ? $_GET['jenis_sholat'] : 'dhuha';

// Query untuk mendapatkan data sholat berdasarkan jenis
if ($jenis_sholat == 'dhuha') {
    $table = 'sholat_dhuha';
    $judul = 'Dhuha';
} else {
    $table = 'sholat_dhuhur';
    $judul = 'Dhuhur';
}

// Query data sholat
$query = "SELECT s.*, sw.nama, sw.kelas, sw.nis 
          FROM $table s 
          JOIN siswa sw ON s.siswa_id = sw.id 
          WHERE s.tanggal = ?";
$params = [$filter_tanggal];

if (!empty($filter_kelas)) {
    $query .= " AND sw.kelas = ?";
    $params[] = $filter_kelas;
}

$query .= " ORDER BY sw.kelas, sw.nama";

// Eksekusi query
$result = false;
if (!empty($params)) {
    $stmt = mysqli_prepare($conn, $query);
    if ($stmt) {
        // Bind parameters
        $types = str_repeat('s', count($params));
        mysqli_stmt_bind_param($stmt, $types, ...$params);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
    }
} else {
    $result = mysqli_query($conn, $query);
}

// Query untuk mendapatkan daftar kelas
$kelas_query = "SELECT DISTINCT kelas FROM siswa ORDER BY kelas";
$kelas_result = mysqli_query($conn, $kelas_query);

// Hitung statistik keseluruhan dan progress absensi
$total_siswa_query = "SELECT COUNT(*) as total FROM siswa WHERE status='aktif'";
if (!empty($filter_kelas)) {
    $total_siswa_query .= " AND kelas='$filter_kelas'";
}
$total_siswa_result = mysqli_query($conn, $total_siswa_query);
$total_siswa = mysqli_fetch_assoc($total_siswa_result)['total'];

// Hitung progress absensi 4 kali
$progress_query = "
    SELECT 
        COUNT(DISTINCT a.siswa_id) as total_masuk,
        COUNT(DISTINCT d.siswa_id) as total_dhuha,
        COUNT(DISTINCT z.siswa_id) as total_dhuhur,
        COUNT(DISTINCT p.siswa_id) as total_pulang
    FROM siswa s
    LEFT JOIN absensi a ON s.id = a.siswa_id AND a.tanggal = '$filter_tanggal'
    LEFT JOIN sholat_dhuha d ON s.id = d.siswa_id AND d.tanggal = '$filter_tanggal'
    LEFT JOIN sholat_dhuhur z ON s.id = z.siswa_id AND z.tanggal = '$filter_tanggal'
    LEFT JOIN absensi p ON s.id = p.siswa_id AND p.tanggal = '$filter_tanggal' AND p.jam_pulang IS NOT NULL
    WHERE s.status = 'aktif'
";

if (!empty($filter_kelas)) {
    $progress_query .= " AND s.kelas = '$filter_kelas'";
}

$progress_result = mysqli_query($conn, $progress_query);
$progress_data = mysqli_fetch_assoc($progress_result);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Sholat <?php echo $judul; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        body { font-family: 'Rubik', sans-serif !important; }
        :root {
            --primary: #4361ee;
            --secondary: #3a0ca3;
            --accent: #f72585;
            --success: #4cc9f0;
            --warning: #f9c74f;
            --danger: #f94144;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e2e8f0 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        .header {
            background: linear-gradient(135deg, #ff9e00 0%, #ff7b00 100%);
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 1.8rem;
            margin-bottom: 5px;
        }
        
        .user-info {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .filter-section {
            padding: 20px;
            background: #f8f9fa;
            border-bottom: 1px solid #dee2e6;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            align-items: end;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
        }
        
        .form-group label {
            margin-bottom: 5px;
            font-weight: 500;
            color: #495057;
        }
        
        .form-control {
            padding: 8px 12px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 14px;
        }
        
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            font-size: 14px;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--secondary);
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn-danger:hover {
            background: #d13438;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .btn-group {
            display: flex;
            gap: 10px;
        }
        
        .btn-sholat {
            flex: 1;
            padding: 10px;
            border: 2px solid transparent;
            border-radius: 6px;
            background: #e9ecef;
            color: #495057;
            cursor: pointer;
            transition: all 0.2s ease;
            font-size: 14px;
        }
        
        .btn-sholat.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        .content {
            padding: 20px;
        }
        
        .table-responsive {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        
        th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }
        
        tr:hover {
            background: #f8f9fa;
        }
        
        .status-hadir {
            color: #28a745;
            font-weight: 500;
        }
        
        .status-tidak {
            color: #dc3545;
            font-weight: 500;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #adb5bd;
        }
        
        .nav-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        
        .btn-back {
            background: #6c757d;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 6px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-back:hover {
            background: #5a6268;
            color: white;
        }
        
        .info-box {
            background: #e7f3ff;
            border: 1px solid #b3d9ff;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .error-box {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 20px;
            color: #721c24;
        }
        
        .success-box {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 20px;
            color: #155724;
        }
        
        .stats-box {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            border-radius: 6px;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .progress-container {
            margin-top: 10px;
        }
        
        .progress {
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .progress-bar {
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 12px;
        }
        
        .progress-steps {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-top: 15px;
        }
        
        .progress-step {
            text-align: center;
            padding: 10px;
            border-radius: 8px;
            background: #f8f9fa;
        }
        
        .progress-step.active {
            background: #28a745;
            color: white;
        }
        
        .progress-step.completed {
            background: #17a2b8;
            color: white;
        }
        
        .step-number {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .step-title {
            font-size: 0.8rem;
        }
        
        .step-count {
            font-size: 0.9rem;
            font-weight: bold;
            margin-top: 5px;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        
        @media (max-width: 768px) {
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .btn-group {
                flex-direction: column;
            }
            
            th, td {
                padding: 8px;
                font-size: 14px;
            }
            
            .progress-steps {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Rekap Sholat <?php echo $judul; ?></h1>
            <div class="user-info">Selamat datang, <?php echo $_SESSION['username']; ?></div>
        </div>
        
        <div class="filter-section">
            <form method="GET" class="filter-form">
                <div class="form-group">
                    <label for="jenis_sholat">Jenis Sholat</label>
                    <div class="btn-group">
                        <button type="submit" name="jenis_sholat" value="dhuha" 
                                class="btn-sholat <?php echo $jenis_sholat == 'dhuha' ? 'active' : ''; ?>">
                            <i class="fas fa-sun"></i> Sholat Dhuha
                        </button>
                        <button type="submit" name="jenis_sholat" value="dhuhur" 
                                class="btn-sholat <?php echo $jenis_sholat == 'dhuhur' ? 'active' : ''; ?>">
                            <i class="fas fa-mosque"></i> Sholat Dhuhur
                        </button>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="tanggal">Tanggal</label>
                    <input type="date" id="tanggal" name="tanggal" 
                           value="<?php echo $filter_tanggal; ?>" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="kelas">Kelas</label>
                    <select id="kelas" name="kelas" class="form-control">
                        <option value="">Semua Kelas</option>
                        <?php 
                        if ($kelas_result) {
                            while($kelas = mysqli_fetch_assoc($kelas_result)): 
                        ?>
                            <option value="<?php echo $kelas['kelas']; ?>" 
                                    <?php echo $filter_kelas == $kelas['kelas'] ? 'selected' : ''; ?>>
                                <?php echo $kelas['kelas']; ?>
                            </option>
                        <?php 
                            endwhile; 
                        }
                        ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-filter"></i> Filter Data
                    </button>
                </div>
            </form>
        </div>
        
        <div class="content">
            <?php 
            // Tampilkan pesan sukses/error
            if (isset($_GET['success'])): 
            ?>
                <div class="success-box">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($_GET['success']); ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['error'])): ?>
                <div class="error-box">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($_GET['error']); ?>
                </div>
            <?php endif; ?>
            
            <!-- Cek jika tabel tidak ada -->
            <?php 
            $table_check = mysqli_query($conn, "SHOW TABLES LIKE '$table'");
            if (mysqli_num_rows($table_check) == 0): 
            ?>
                <div class="error-box">
                    <h3><i class="fas fa-exclamation-triangle"></i> Tabel Tidak Ditemukan</h3>
                    <p>Tabel <strong><?php echo $table; ?></strong> belum dibuat di database.</p>
                    <p><strong>Solusi:</strong> Sistem akan membuat tabel secara otomatis saat pertama kali absensi sholat dilakukan.</p>
                </div>
            <?php elseif (!$result): ?>
                <div class="error-box">
                    <h3><i class="fas fa-exclamation-triangle"></i> Error Query</h3>
                    <p>Terjadi kesalahan dalam menjalankan query database.</p>
                </div>
            <?php else: ?>
                <!-- Progress Absensi 4 Kali -->
                <div class="stats-box">
                    <h4><i class="fas fa-chart-line"></i> Progress Absensi 4 Kali - <?php echo date('d/m/Y', strtotime($filter_tanggal)); ?></h4>
                    
                    <div class="progress-steps">
                        <div class="progress-step <?php echo $progress_data['total_masuk'] > 0 ? 'completed' : ''; ?>">
                            <div class="step-number">1</div>
                            <div class="step-title">Masuk</div>
                            <div class="step-count"><?php echo $progress_data['total_masuk']; ?>/<?php echo $total_siswa; ?></div>
                        </div>
                        <div class="progress-step <?php echo $jenis_sholat == 'dhuha' ? 'active' : ($progress_data['total_dhuha'] > 0 ? 'completed' : ''); ?>">
                            <div class="step-number">2</div>
                            <div class="step-title">Sholat Dhuha</div>
                            <div class="step-count"><?php echo $progress_data['total_dhuha']; ?>/<?php echo $total_siswa; ?></div>
                        </div>
                        <div class="progress-step <?php echo $jenis_sholat == 'dhuhur' ? 'active' : ($progress_data['total_dhuhur'] > 0 ? 'completed' : ''); ?>">
                            <div class="step-number">3</div>
                            <div class="step-title">Sholat Dhuhur</div>
                            <div class="step-count"><?php echo $progress_data['total_dhuhur']; ?>/<?php echo $total_siswa; ?></div>
                        </div>
                        <div class="progress-step <?php echo $progress_data['total_pulang'] > 0 ? 'completed' : ''; ?>">
                            <div class="step-number">4</div>
                            <div class="step-title">Pulang</div>
                            <div class="step-count"><?php echo $progress_data['total_pulang']; ?>/<?php echo $total_siswa; ?></div>
                        </div>
                    </div>
                    
                    <div class="progress-container mt-3">
                        <?php 
                        $total_completed = $progress_data['total_pulang'];
                        $persentase_completed = $total_siswa > 0 ? round(($total_completed / $total_siswa) * 100, 1) : 0;
                        ?>
                        <div class="progress">
                            <div class="progress-bar bg-success" role="progressbar" 
                                 style="width: <?php echo $persentase_completed; ?>%" 
                                 aria-valuenow="<?php echo $persentase_completed; ?>" 
                                 aria-valuemin="0" 
                                 aria-valuemax="100">
                                <?php echo $persentase_completed; ?>% Selesai
                            </div>
                        </div>
                        <small class="text-muted">Persentase siswa yang telah menyelesaikan semua absensi</small>
                    </div>
                </div>

                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php
                    // Hitung statistik untuk sholat yang dipilih
                    $total = mysqli_num_rows($result);
                    $hadir = 0;
                    $tidak_hadir = 0;
                    
                    $data_rows = [];
                    while($row = mysqli_fetch_assoc($result)) {
                        $data_rows[] = $row;
                        if ($row['status'] == 'hadir') {
                            $hadir++;
                        } else {
                            $tidak_hadir++;
                        }
                    }
                    
                    $persentase_hadir = $total_siswa > 0 ? round(($hadir / $total_siswa) * 100, 1) : 0;
                    ?>
                    
                    <div class="stats-box">
                        <h4><i class="fas fa-chart-bar"></i> Statistik Sholat <?php echo $judul; ?></h4>
                        <p>
                            Total Siswa: <strong><?php echo $total_siswa; ?> siswa</strong> | 
                            Hadir Sholat: <strong style="color: #28a745;"><?php echo $hadir; ?> siswa</strong> | 
                            Belum Absen: <strong style="color: #dc3545;"><?php echo $total_siswa - $hadir; ?> siswa</strong>
                        </p>
                        <div class="progress-container">
                            <div class="progress">
                                <div class="progress-bar bg-info" role="progressbar" 
                                     style="width: <?php echo $persentase_hadir; ?>%" 
                                     aria-valuenow="<?php echo $persentase_hadir; ?>" 
                                     aria-valuemin="0" 
                                     aria-valuemax="100">
                                    <?php echo $persentase_hadir; ?>%
                                </div>
                            </div>
                            <small class="text-muted">Persentase kehadiran sholat <?php echo strtolower($judul); ?></small>
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table>
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NIS</th>
                                    <th>Nama Siswa</th>
                                    <th>Kelas</th>
                                    <th>Jam Sholat</th>
                                    <th>Status</th>
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1; foreach($data_rows as $row): ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo $row['nis']; ?></td>
                                        <td><?php echo $row['nama']; ?></td>
                                        <td><?php echo $row['kelas']; ?></td>
                                        <td><?php echo $row['jam'] ?: '-'; ?></td>
                                        <td>
                                            <span class="status-<?php echo $row['status']; ?>">
                                                <?php echo $row['status'] == 'hadir' ? 'Hadir' : 'Tidak Hadir'; ?>
                                            </span>
                                        </td>
                                        <td><?php echo $row['keterangan'] ?: '-'; ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="rekap_sholat.php?hapus=<?php echo $row['id']; ?>&jenis=<?php echo $jenis_sholat; ?>&tanggal=<?php echo $filter_tanggal; ?>&kelas=<?php echo $filter_kelas; ?>" 
                                                   class="btn btn-danger btn-sm"
                                                   onclick="return confirm('Yakin ingin menghapus data sholat <?php echo $judul; ?> untuk <?php echo $row['nama']; ?>?')">
                                                    <i class="fas fa-trash"></i> Hapus
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-praying-hands"></i>
                        <h3>Data Tidak Ditemukan</h3>
                        <p>Tidak ada data sholat <?php echo strtolower($judul); ?> untuk tanggal <?php echo date('d/m/Y', strtotime($filter_tanggal)); ?></p>
                        <div class="info-box">
                            <strong>Info:</strong> Data akan muncul setelah siswa melakukan absensi sholat melalui scan QR code.
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
            
            <div class="nav-buttons">
                <a href="dashboard.php" class="btn-back">
                    <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
                </a>
            </div>
        </div>
    </div>

    <script>
        // Set tanggal default ke hari ini
        document.getElementById('tanggal').value = '<?php echo date('Y-m-d'); ?>';
        
        // Auto submit ketika memilih jenis sholat
        document.querySelectorAll('.btn-sholat').forEach(btn => {
            btn.addEventListener('click', function() {
                this.closest('form').submit();
            });
        });
        
        // Auto-hide pesan sukses/error setelah 5 detik
        setTimeout(function() {
            const successBox = document.querySelector('.success-box');
            const errorBox = document.querySelector('.error-box');
            
            if (successBox) successBox.style.display = 'none';
            if (errorBox) errorBox.style.display = 'none';
        }, 5000);
    </script>
</body>
</html>