<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
date_default_timezone_set("Asia/Jakarta");

$tanggal = $_GET['tanggal'] ?? date('Y-m-d');
$kelas   = $_GET['kelas'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Sistem Absensi Digital</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <script src="https://unpkg.com/html5-qrcode"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body { background-color: #f8f9fa; padding: 20px; font-family: 'Rubik', sans-serif; }
    .container { max-width: 1400px; margin: 0 auto; }
    #reader { width: 100%; max-width: 500px; border: 2px solid #007bff; border-radius: 10px; overflow: hidden; margin: 0 auto; }
    .scan-info { background-color: #e9ecef; border-radius: 5px; padding: 10px; margin-bottom: 15px; text-align: center; }
    .camera-select { margin-bottom: 15px; }
    .scanner-active { border: 3px solid #28a745 !important; }
    .scan-result-container { max-height: 500px; overflow-y: auto; border: 1px solid #dee2e6; border-radius: 5px; padding: 15px; background-color: #f8f9fa; }
    .scan-result-item { padding: 15px; margin-bottom: 10px; border-radius: 8px; border-left: 4px solid #007bff; }
    .scan-result-item.success { border-left-color: #28a745; background-color: #d4edda; }
    .scan-result-item.error { border-left-color: #dc3545; background-color: #f8d7da; }
    .scan-result-item.warning { border-left-color: #ffc107; background-color: #fff3cd; }
    .scan-result-item.info { border-left-color: #17a2b8; background-color: #d1ecf1; }
    .scanner-column { display: flex; flex-direction: column; justify-content: center; }
    .single-result { text-align: center; padding: 20px; }
    .result-icon { font-size: 3rem; margin-bottom: 15px; }
    .result-title { font-size: 1.5rem; font-weight: bold; margin-bottom: 10px; }
    .result-details { margin-top: 15px; padding: 10px; background-color: rgba(255, 255, 255, 0.7); border-radius: 5px; }
    .scanner-controls { margin-top: 20px; padding: 15px; background-color: #f8f9fa; border-radius: 8px; border: 1px solid #dee2e6; }
    .scanner-wrapper { display: flex; flex-direction: column; align-items: center; }
    .motivation-column { background-color: #fff; border-radius: 8px; padding: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); height: 100%; display: flex; flex-direction: column; }
    .digital-clock { font-family: 'Courier New', monospace; font-size: 2.2rem; font-weight: bold; text-align: center; background: linear-gradient(135deg, #2c3e50, #4a6491); color: #ecf0f1; padding: 15px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    .date-display { font-size: 1.1rem; text-align: center; margin-top: 5px; color: #bdc3c7; }
    .motivation-title { font-size: 1.2rem; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #eee; display: flex; justify-content: space-between; align-items: center; }
    .motivation-text { font-size: 1.3rem; font-weight: bold; color: #2c3e50; line-height: 1.6; font-style: italic; text-align: center; padding: 20px; border-left: 4px solid #3498db; background-color: #f8f9fa; border-radius: 8px; margin-bottom: 20px; }
    .motivation-author { text-align: right; font-style: normal; color: #7f8c8d; margin-top: 15px; font-size: 1rem; }
    .scan-buttons { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; }
    .scan-buttons .btn { min-width: 120px; }
    .card-header { background-color: #3b5998 !important; }
    .card-header-secondary { background-color: #6c757d !important; }
    .row { align-items: stretch; }
    .motivation-column, .scanner-column, .result-column { display: flex; flex-direction: column; }
    .scanner-column .scanner-wrapper { flex: 1; display: flex; flex-direction: column; }
    .scanner-column .scanner-controls { margin-top: auto; }
    .scanner-type-selector { margin-bottom: 15px; padding: 10px; background-color: #e9f7fe; border-radius: 8px; border: 1px solid #b8e6ff; }
    .external-scanner-section { margin-top: 15px; padding: 15px; background-color: #f8f9fa; border-radius: 8px; border: 1px dashed #6c757d; }
    .external-scanner-input { font-size: 1.2rem; text-align: center; letter-spacing: 2px; }
  </style>
</head>
<body class="container mt-4">
  <div class="card shadow">
    <div class="card-header text-white">
      <h2 class="mb-0"><i class="fas fa-qrcode"></i> Sistem Absensi Digital</h2>
    </div>
    <div class="card-body">
      <a href="dashboard.php" class="btn btn-secondary mb-3"><i class="fas fa-arrow-left"></i> Kembali</a>

      <div class="row">
        <div class="col-lg-4 col-md-12 mb-4">
          <div class="motivation-column">
            <div class="digital-clock">
              <div id="clock">00:00:00</div>
              <div class="date-display" id="date">-</div>
            </div>
            <h4 class="motivation-title"><span><i class="fas fa-lightbulb"></i> Kata Motivasi</span></h4>
            <div class="motivation-text">
              "Belajar tanpa disiplin hanyalah rutinitas, mengajar tanpa disiplin hanyalah formalitas. Dengan disiplin, keduanya menjadi bermakna."
              <div class="motivation-author">- Filosofi Pendidikan</div>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-md-6 scanner-column mb-4">
          <div class="scanner-wrapper">
            <div class="scanner-type-selector">
              <label class="form-label"><strong><i class="fas fa-scanner"></i> Mode Scanner:</strong></label>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="scannerType" id="webcamScanner" value="webcam" checked>
                <label class="form-check-label" for="webcamScanner"><i class="fas fa-camera"></i> Webcam</label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="scannerType" id="externalScanner" value="external">
                <label class="form-check-label" for="externalScanner"><i class="fas fa-barcode"></i> Scanner Eksternal</label>
              </div>
            </div>

            <div id="webcam-scanner-section">
              <div id="reader" class="text-center"></div>
            </div>

            <div id="external-scanner-section" class="external-scanner-section" style="display: none;">
              <div class="text-center mb-3">
                <i class="fas fa-barcode fa-3x text-primary mb-2"></i>
                <h5>Scanner Eksternal</h5>
              </div>
              <div class="mb-3">
                <input type="text" id="externalScannerInput" class="form-control external-scanner-input" placeholder="Scan barcode..." autocomplete="off" autofocus>
              </div>
            </div>
            
            <div class="scanner-controls w-100">
              <div class="scan-info">
                <p><strong>Mode Scan:</strong> QR Code Siswa (NISN) & Guru (NIP)</p>
              </div>
              <div class="text-center mb-3">
                <div class="scan-buttons">
                  <button type="button" class="btn btn-success" id="startScanner"><i class="fas fa-play"></i> Mulai Scan</button>
                  <button type="button" class="btn btn-danger" id="stopScanner" disabled><i class="fas fa-stop"></i> Stop Scan</button>
                  <button type="button" class="btn btn-warning" id="resetScanner"><i class="fas fa-redo"></i> Reset</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div class="col-lg-4 col-md-6 result-column">
          <div class="card h-100">
            <div class="card-header text-white card-header-secondary d-flex justify-content-between align-items-center">
              <h4 class="mb-0"><i class="fas fa-check-circle"></i> Status Absensi Terbaru</h4>
              <button type="button" class="btn btn-sm btn-outline-light" id="clearResults"><i class="fas fa-trash"></i> Hapus</button>
            </div>
            <div class="card-body p-0">
              <div class="scan-result-container">
                <div id="result" class="single-result">
                  <div class="text-center text-muted">
                    <i class="fas fa-qrcode result-icon"></i>
                    <p>Belum ada hasil scan.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <audio id="beepSound" preload="auto">
        <source src="beep.mp3" type="audio/mpeg">
      </audio>
    </div>
  </div>

  <script>
    let html5QrcodeScanner = null;
    let isScanning = false;
    let currentScannerType = 'webcam';
    let isProcessing = false;

    function updateClock() {
      const now = new Date();
      document.getElementById('clock').textContent = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
      const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
      const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
      document.getElementById('date').textContent = `${days[now.getDay()]}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;
    }

    document.querySelectorAll('input[name="scannerType"]').forEach(radio => {
      radio.addEventListener('change', function() {
        currentScannerType = this.value;
        handleScannerTypeChange();
      });
    });

    document.getElementById('externalScannerInput').addEventListener('input', function(e) {
      const value = e.target.value.trim();
      if (value.length > 3 && !isProcessing) {
        processScannedCode(value);
        e.target.value = '';
      }
    });

    document.getElementById('startScanner').addEventListener('click', startScanner);
    document.getElementById('stopScanner').addEventListener('click', stopScanner);
    document.getElementById('resetScanner').addEventListener('click', resetScanner);
    document.getElementById('clearResults').addEventListener('click', clearResults);

    function handleScannerTypeChange() {
      if (currentScannerType === 'webcam') {
        document.getElementById('webcam-scanner-section').style.display = 'block';
        document.getElementById('external-scanner-section').style.display = 'none';
        if (isScanning) { stopScanner(); setTimeout(startScanner, 500); }
      } else {
        document.getElementById('webcam-scanner-section').style.display = 'none';
        document.getElementById('external-scanner-section').style.display = 'block';
        if (isScanning) { stopScanner(); }
        setTimeout(() => { document.getElementById('externalScannerInput').focus(); }, 100);
      }
    }

    async function startScanner() {
      if (isScanning || currentScannerType !== 'webcam') return;
      try {
        document.getElementById('reader').innerHTML = '';
        document.getElementById('startScanner').disabled = true;
        document.getElementById('stopScanner').disabled = false;
        
        html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: { width: 250, height: 250 } }, false);
        await html5QrcodeScanner.render(onScanSuccess, onScanFailure);
        isScanning = true;
        document.getElementById('reader').classList.add('scanner-active');
      } catch (error) {
        console.error("Error:", error);
      }
    }

    async function stopScanner() {
      if (!isScanning || currentScannerType !== 'webcam') return;
      try {
        if (html5QrcodeScanner) { await html5QrcodeScanner.clear(); }
        document.getElementById('reader').classList.remove('scanner-active');
        document.getElementById('startScanner').disabled = false;
        document.getElementById('stopScanner').disabled = true;
        isScanning = false;
      } catch (error) { console.error(error); }
    }

    function resetScanner() {
      if (currentScannerType === 'webcam') { stopScanner(); } 
      else { document.getElementById('externalScannerInput').value = ''; document.getElementById('externalScannerInput').focus(); }
      isProcessing = false;
      clearResults();
    }

    function clearResults() {
      document.getElementById("result").innerHTML = `<div class="text-center text-muted"><i class="fas fa-qrcode result-icon"></i><p>Belum ada hasil scan.</p></div>`;
    }

    function processScannedCode(qrMessage) {
      if (isProcessing) return;
      isProcessing = true;
      
      if (!/^\d+$/.test(qrMessage)) {
        addResultMessage('Kode tidak valid.', 'error');
        playBeepSound();
        setTimeout(() => { isProcessing = false; }, 3000);
        return;
      }
      
      addResultMessage('Memproses absensi...', 'info', qrMessage);
      
      fetch('rekam_absen_wa_api.php?code=' + encodeURIComponent(qrMessage))
        .then(response => response.json())
        .then(data => {
          if (data.status && data.message) {
            addResultMessage(data.message, data.status, qrMessage);
          } else {
            addResultMessage('Response server tidak valid.', 'error');
          }
          playBeepSound();
          
          setTimeout(() => {
            isProcessing = false;
          }, 5000);
        })
        .catch(error => {
          console.error('Error:', error);
          addResultMessage('Error koneksi server.', 'error');
          playBeepSound();
          setTimeout(() => { isProcessing = false; }, 3000);
        });
    }

    function onScanSuccess(qrMessage) {
      processScannedCode(qrMessage);
    }

    function onScanFailure(error) {}

    function addResultMessage(message, type = 'info', code = '') {
      const result = document.getElementById("result");
      let icon = type === 'success' ? 'fa-check-circle' : (type === 'warning' ? 'fa-exclamation-triangle' : (type === 'error' ? 'fa-times-circle' : 'fa-info-circle'));
      let title = type === 'success' ? 'Berhasil' : (type === 'warning' ? 'Peringatan' : (type === 'error' ? 'Error' : 'Informasi'));
      
      result.innerHTML = `
        <div class="scan-result-item ${type}">
          <div class="result-icon text-${type}"><i class="fas ${icon}"></i></div>
          <div class="result-title">${title}</div>
          <div class="result-message">${message.replace(/\n/g, '<br>')}</div>
          ${code ? `<div class="result-details mt-3">Kode: <strong>${code}</strong></div>` : ''}
          <div class="result-time mt-2"><small>Waktu: ${new Date().toLocaleTimeString()}</small></div>
        </div>
      `;
    }

    function playBeepSound() {
      const beep = document.getElementById("beepSound");
      if (beep) { beep.play().catch(e => console.log(e)); }
    }

    document.addEventListener('DOMContentLoaded', function() {
      updateClock();
      setInterval(updateClock, 1000);
      handleScannerTypeChange();
    });
  </script>
</body>
</html>
