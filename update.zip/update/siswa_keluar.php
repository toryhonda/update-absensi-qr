<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';

// Proses aktifkan kembali siswa yang keluar
if (isset($_GET['aktifkan'])) {
    $id = intval($_GET['aktifkan']);
    $res = mysqli_query($conn, "SELECT nisn, nama FROM siswa WHERE id=$id LIMIT 1");
    if ($res && mysqli_num_rows($res) > 0) {
        $data = mysqli_fetch_assoc($res);
        $nisn = $data['nisn'];
        $nama = $data['nama'];

        // Ubah status siswa jadi aktif
        mysqli_query($conn, "UPDATE siswa SET status='aktif' WHERE id=$id");

        // Buat kembali akun user-nya
        $password = md5($nisn);
        $cek_user = mysqli_query($conn, "SELECT id FROM users WHERE username='$nisn' LIMIT 1");
        if (mysqli_num_rows($cek_user) == 0) {
            mysqli_query($conn, "INSERT INTO users (username, nama, password, role) VALUES ('$nisn', '$nama', '$password', 'siswa')");
        }
    }
    header("Location: siswa_keluar.php");
    exit;
}

// Proses Hapus Permanen siswa keluar (Aman dari Error 500 Relasi Tabel)
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $res = mysqli_query($conn, "SELECT nisn FROM siswa WHERE id=$id AND status='keluar' LIMIT 1");
    if ($res && mysqli_num_rows($res) > 0) {
        $data = mysqli_fetch_assoc($res);
        $nisn_hapus = $data['nisn'];

        // Hapus file QR code jika ada
        $qr_file = "assets/qr/" . $nisn_hapus . ".png";
        if (file_exists($qr_file)) {
            @unlink($qr_file);
        }

        // Matikan pengecekan foreign key sementara agar tidak Error 500
        mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 0");
        
        // Hapus data terkait jika perlu (misal riwayat absensi atau biarkan)
        mysqli_query($conn, "DELETE FROM siswa WHERE id=$id");
        
        // Aktifkan kembali pengecekan foreign key
        mysqli_query($conn, "SET FOREIGN_KEY_CHECKS = 1");
    }
    header("Location: siswa_keluar.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Riwayat Siswa Keluar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { font-family: 'Rubik', sans-serif; }
  </style>
</head>
<body class="container py-4">

  <h2 class="text-center mb-4">📁 Riwayat Data Siswa Keluar</h2>

  <a href="siswa.php" class="btn btn-secondary mb-3">← Kembali ke Data Siswa</a>

  <div class="table-responsive">
    <table class="table table-bordered table-striped align-middle">
      <thead class="table-light text-center">
        <tr>
          <th>NIS</th>
          <th>NISN</th>
          <th>Nama</th>
          <th>Kelas</th>
          <th>No. WhatsApp</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $q = mysqli_query($conn, "SELECT * FROM siswa WHERE status='keluar' ORDER BY nama ASC");
        if ($q && mysqli_num_rows($q) > 0) {
            while ($row = mysqli_fetch_assoc($q)) {
              echo "<tr>
                <td>{$row['nis']}</td>
                <td>{$row['nisn']}</td>
                <td>{$row['nama']}</td>
                <td>{$row['kelas']}</td>
                <td>{$row['no_wa']}</td>
                <td class='text-center'>
                  <a href='siswa_keluar.php?aktifkan={$row['id']}' class='btn btn-success btn-sm mb-1' onclick='return confirm(\"Aktifkan kembali siswa ini?\")'>Aktifkan Kembali</a>
                  <a href='siswa_keluar.php?hapus={$row['id']}' class='btn btn-danger btn-sm mb-1' onclick='return confirm(\"Yakin ingin menghapus data siswa ini secara permanen?\")'>Hapus Permanen</a>
                </td>
              </tr>";
            }
        } else {
            echo "<tr><td colspan='6' class='text-center text-muted'>Tidak ada data siswa keluar.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

</body>
</html>
