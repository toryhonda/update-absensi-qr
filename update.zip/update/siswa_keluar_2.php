<?php
$page_title = "Data Siswa"; // (Opsional) Judul halaman dinamis
include 'header.php';

session_start();
if (!isset($_SESSION['username']) || !in_array($_SESSION['role'], ['admin', 'guru'])) {
    header("Location: index.php");
    exit;
}

include 'config.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Riwayat Siswa Keluar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { font-family: 'Rubik', sans-serif; }
  </style>
</head>
<body class="container py-4">

  <h2 class="text-center mb-4">📁 Riwayat Data Siswa Keluar</h2>

  <a href="siswa_2.php" class="btn btn-secondary mb-3">← Kembali ke Data Siswa</a>

  <div class="table-responsive">
    <table class="table table-bordered table-striped align-middle">
      <thead class="table-light text-center">
        <tr>
          <th>NIS</th>
          <th>NISN</th>
          <th>Nama</th>
          <th>Kelas</th>
          <th>No. WhatsApp</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $q = mysqli_query($conn, "SELECT * FROM siswa WHERE status='keluar' ORDER BY nama ASC");
        if ($q && mysqli_num_rows($q) > 0) {
            while ($row = mysqli_fetch_assoc($q)) {
              echo "<tr>
                <td>{$row['nis']}</td>
                <td>{$row['nisn']}</td>
                <td>{$row['nama']}</td>
                <td>{$row['kelas']}</td>
                <td>{$row['no_wa']}</td>
              </tr>";
            }
        } else {
            echo "<tr><td colspan='5' class='text-center text-muted'>Tidak ada data siswa keluar.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>

</body>
</html>